'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createPortal } from 'react-dom';
import { Layers, ArrowLeft, Save, RotateCcw } from 'lucide-react';
import { Breadcrumbs } from "@/components/admin/Breadcrumbs";
import { AdminLoadingState } from "@/components/admin/AdminLoadingState";
import { usePopup } from '@/components/admin/AdminPopupProvider';
import AdminCommandBar, { CommandBarButton } from "@/components/admin/AdminCommandBar";
import { AdminHeader } from '@/components/admin/AdminHeader';

export default function FeaturesPage() {
    const [features, setFeatures] = useState<Record<string, boolean>>({});
    const [savedFeatures, setSavedFeatures] = useState<Record<string, boolean>>({});
    const [loading, setLoading] = useState(true);
    const [mounted, setMounted] = useState(false);
    const router = useRouter();
    const popup = usePopup();

    const featureDescriptions: Record<string, string> = {
        blog: 'Enable blog posts, categories, and writing tools',
        gallery: 'Photo grid and media showcase capability',
        newsletter: 'Email subscription forms and management',
        monetization: 'Subscription plans and payment processing',
        comments: 'User commenting system on posts',
        servicePages: 'Dedicated pages for services offered',
        menu: 'Restaurant menu management',
        booking: 'Appointment scheduling system',
        customerPortal: 'Private area for logged-in customers',
        analytics: 'Traffic and engagement tracking',
    };

    const loadData = async () => {
        try {
            const featuresRes = await fetch('/api/admin/features');
            const feats = await featuresRes.json() as Record<string, boolean>;
            setFeatures(feats);
            setSavedFeatures(feats);
        } catch (e) {
            console.error('Failed to load features', e);
        } finally {
            setLoading(false);
        }
    };

    const handleFeatureToggle = (key: string, currentValue: boolean) => {
        setFeatures(prev => ({ ...prev, [key]: !currentValue }));
    };

    const handleSaveConfirm = async () => {
        try {
            const res = await fetch('/api/admin/features', {
                method: 'POST',
                body: JSON.stringify(features)
            });
            if (res.ok) {
                setSavedFeatures(features);
                popup.success('System modules configuration synchronized successfully.');
                router.refresh();
            } else {
                popup.error('Failed to commit module changes.');
            }
        } catch (e) {
            console.error('Failed to update features', e);
            popup.error('Connectivity interruption during module save.');
        }
    };

    const handleRevertConfirm = () => {
        setFeatures(JSON.parse(JSON.stringify(savedFeatures)));
    };

    useEffect(() => {
        setMounted(true);
        loadData();
    }, []);

    if (loading) return (
        <div className="max-w-7xl mx-auto px-6 pt-4 pb-12 space-y-8">
            <AdminLoadingState message="Scanning system modules..." />
        </div>
    );

    const hasChanges = JSON.stringify(features) !== JSON.stringify(savedFeatures);

    return (
        <div className="max-w-7xl mx-auto px-6 pt-0 space-y-8">
            <AdminHeader
                title={<>Feature <span className="text-indigo-500">Modules</span></>}
                description="Enable or disable system capabilities across your platform."
                breadcrumbs={[
                    { label: 'Admin', href: '/admin' },
                    { label: 'Design', href: '/admin/design' },
                    { label: 'Modules' }
                ]}
                badge={
                    hasChanges ? (
                        <div className="px-3 py-1.5 bg-amber-500/10 border border-amber-500/20 rounded-lg text-[10px] font-bold uppercase tracking-widest text-amber-600 dark:text-amber-400 animate-pulse">
                            Unsaved Changes
                        </div>
                    ) : (
                        <div className="px-3 py-1.5 bg-indigo-500/10 border border-indigo-500/20 rounded-lg text-[10px] font-bold uppercase tracking-widest text-indigo-600 dark:text-indigo-400">
                            Configuration Active
                        </div>
                    )
                }
                actions={
                    <Link
                        href="/admin/design"
                        className="px-3 py-1.5 bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 rounded-lg text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
                    >
                        <ArrowLeft size={12} /> Back
                    </Link>
                }
            />

            {/* Features Grid */}
            <section className="space-y-6">
                <div>
                    <h2 className="text-xl font-semibold">Active Modules</h2>
                    <p className="text-sm text-gray-500 mt-1">
                        Control which features are enabled across your application. Disabled features will be hidden from navigation.
                    </p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                    {Object.entries(features).map(([key, enabled]) => (
                        <div key={key} className={`flex items-center justify-between px-6 py-5 rounded-[1.5rem] transition-all ${enabled
                            ? 'bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/30'
                            : 'bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800'
                            }`}>
                            <div className="pr-4 flex-1">
                                <div className="flex items-center gap-2 mb-1">
                                    <div className="font-medium capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</div>
                                    {enabled ? (
                                        <span className="text-[9px] px-2 py-0.5 bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 rounded-full font-bold uppercase">
                                            Active
                                        </span>
                                    ) : (
                                        <span className="text-[9px] px-2 py-0.5 bg-gray-200 dark:bg-zinc-800 text-gray-600 dark:text-gray-400 rounded-full font-bold uppercase">
                                            Disabled
                                        </span>
                                    )}
                                </div>
                                <div className="text-xs text-gray-500 dark:text-gray-400">
                                    {featureDescriptions[key] || 'Controls this feature'}
                                    {!enabled && (
                                        <span className="text-yellow-600 dark:text-yellow-500 ml-1 font-medium">
                                            (Hidden from navigation)
                                        </span>
                                    )}
                                </div>
                            </div>
                            <button
                                onClick={() => handleFeatureToggle(key, enabled)}
                                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${enabled ? 'bg-emerald-600' : 'bg-gray-200 dark:bg-gray-700'
                                    }`}
                                title={enabled ? 'Click to disable' : 'Click to enable'}
                            >
                                <span
                                    className={`${enabled ? 'translate-x-6' : 'translate-x-1'
                                        } inline-block h-4 w-4 transform rounded-full bg-white transition-transform duration-200 ease-in-out shadow-sm`}
                                />
                            </button>
                        </div>
                    ))}
                </div>
            </section>

            {/* Admin Actions Portal */}
            {mounted && (() => {
                const portalTarget = document.getElementById('admin-actions-portal');
                if (!portalTarget) return null;

                return createPortal(
                    <div className="flex items-center gap-2 pointer-events-auto">
                        <CommandBarButton
                            onClick={async () => {
                                const confirmed = await popup.confirm('Are you sure you want to revert these module changes? All unsaved toggles will be reset.', { isDanger: true });
                                if (confirmed) handleRevertConfirm();
                            }}
                            disabled={!hasChanges}
                            label="Revert Logic"
                            variant="secondary"
                            icon={<RotateCcw size={14} />}
                        />
                        <CommandBarButton
                            onClick={async () => {
                                const confirmed = await popup.confirm('Are you sure you want to apply these module changes? This will instantly enable or disable features across your entire site.');
                                if (confirmed) await handleSaveConfirm();
                            }}
                            disabled={!hasChanges}
                            label="Apply Modules"
                            variant="primary"
                            icon={<Save size={14} />}
                        />
                    </div>,
                    portalTarget
                );
            })()}
        </div>
    );
}
