"use client";

import { useEditor, EditorContent, Editor } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import { useState, useEffect } from "react";
import Image from "@tiptap/extension-image";
import Link from "@tiptap/extension-link";
import Placeholder from "@tiptap/extension-placeholder";
import CodeBlockLowlight from "@tiptap/extension-code-block-lowlight";
import { common, createLowlight } from "lowlight";
import Underline from "@tiptap/extension-underline";
import TaskList from "@tiptap/extension-task-list";
import TaskItem from "@tiptap/extension-task-item";
import Superscript from "@tiptap/extension-superscript";
import Subscript from "@tiptap/extension-subscript";
import TextAlign from "@tiptap/extension-text-align";
import Highlight from "@tiptap/extension-highlight";
import { VariablePill } from "@/extensions/VariablePill";
import "./editor-styles.css";
import { useTheme } from "next-themes";

import EditorToolbar from "./EditorToolbar";

const lowlight = createLowlight(common);

interface RichTextEditorProps {
    content: string;
    onChange: (content: string) => void;
    placeholder?: string;
    minHeight?: string;
    editable?: boolean;
}

export default function RichTextEditor({
    content,
    onChange,
    placeholder = "Start writing...",
    minHeight = "400px",
    editable = true,
}: RichTextEditorProps) {
    const { resolvedTheme, setTheme } = useTheme();
    const theme = (resolvedTheme === "dark" ? "dark" : "light") as "light" | "dark";

    const editor = useEditor({
        extensions: [
            StarterKit.configure({
                codeBlock: false,
                // Disable these since we configure them separately below
                link: false,
                underline: false,
            }),
            CodeBlockLowlight.configure({
                lowlight,
            }),
            Underline,
            TaskList,
            TaskItem.configure({
                nested: true,
            }),
            Superscript,
            Subscript,
            TextAlign.configure({
                types: ["heading", "paragraph"],
            }),
            Highlight.configure({
                multicolor: true,
            }),
            Image.configure({
                inline: true,
                HTMLAttributes: {
                    class: "rounded-lg max-w-full h-auto",
                },
            }),
            Link.configure({
                openOnClick: false,
                HTMLAttributes: {
                    class: "text-page-subtitle hover:text-page-subtitle/80 underline cursor-pointer",
                },
            }),
            Placeholder.configure({
                placeholder,
            }),
            VariablePill,  // Add variable pill support
        ],
        content: preprocessVariables(content),
        editable,
        immediatelyRender: false,
        onUpdate: ({ editor }) => {
            const markdown = editorToMarkdown(editor);
            onChange(markdown);
        },
        editorProps: {
            attributes: {
                class: `tiptap-editor ${theme === "dark" ? "dark" : ""}`,
                style: `min-height: ${minHeight}`,
            },
        },
    });

    // Sync with external content changes (like Revert)
    useEffect(() => {
        if (editor && content !== undefined) {
            // Check if content matches what's currently in editor (after post-processing)
            const currentContent = editorToMarkdown(editor);
            if (content !== currentContent) {
                editor.commands.setContent(preprocessVariables(content));
            }
        }
    }, [content, editor]);

    // Helper to convert Tiptap editor content to markdown
    function editorToMarkdown(ed: Editor): string {
        const html = ed.getHTML();
        // Convert pills back to {{variable}} syntax for storage
        return html.replace(/<span[^>]*data-variable="([^"]*)"[^>]*>.*?<\/span>/g, (match, name) => {
            return `{{${name}}}`;
        });
    }

    // Preprocess on load
    function preprocessVariables(content: string): string {
        if (!content) return "";
        // Convert {{name}} to <span data-variable="name">{{name}}</span>
        return content.replace(/\{\{([a-zA-Z0-9_]+)\}\}/g, (match, variableName) => {
            return `<span data-variable="${variableName}">${match}</span>`;
        });
    }

    if (!editor) {
        return null;
    }

    return (
        <div className={`
                border border-borders rounded-xl overflow-hidden shadow-sm transition-all duration-300
                ${theme === "dark" ? "dark bg-zinc-900" : "bg-white"}
            `}>
            {editable && (
                <EditorToolbar
                    editor={editor}
                    theme={theme}
                    onThemeToggle={() => setTheme(theme === "light" ? "dark" : "light")}
                />
            )}
            <div className={`
                relative
                ${theme === "dark" ? "bg-zinc-900 text-zinc-100 dark" : "bg-white text-slate-800"}
            `}>
                <EditorContent editor={editor} />
            </div>
        </div>
    );
}

