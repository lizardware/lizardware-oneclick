'use client';

import React, { useEffect, useRef } from 'react';
import { ChevronDown } from 'lucide-react';

export interface DropdownProps {
    /**
     * The trigger button content (icon, text, etc.)
     */
    trigger: React.ReactNode;

    /**
     * The dropdown menu items
     */
    children: React.ReactNode;

    /**
     * Whether the dropdown is currently open (controlled mode)
     */
    isOpen?: boolean;

    /**
     * Callback when dropdown should close
     */
    onClose?: () => void;

    /**
     * Whether the trigger button should show active state
     */
    isActive?: boolean;

    /**
     * Optional title/tooltip for the trigger button
     */
    title?: string;

    /**
     * Whether to show a chevron icon in the trigger
     * @default true
     */
    showChevron?: boolean;

    /**
     * Alignment of the dropdown menu
     * @default 'left'
     */
    align?: 'left' | 'right';

    /**
     * Custom className for the trigger button
     */
    triggerClassName?: string;

    /**
     * Custom className for the dropdown menu
     */
    menuClassName?: string;
}

export function Dropdown({
    trigger,
    children,
    isOpen = false,
    onClose,
    isActive = false,
    title,
    showChevron = true,
    align = 'left',
    triggerClassName = '',
    menuClassName = ''
}: DropdownProps) {
    const menuRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
                onClose?.();
            }
        };

        if (isOpen) {
            document.addEventListener('mousedown', handleClickOutside);
            return () => document.removeEventListener('mousedown', handleClickOutside);
        }
    }, [isOpen, onClose]);

    const alignmentStyles = {
        left: 'left-0 origin-top-left',
        right: 'right-0 origin-top-right'
    };

    return (
        <div className="relative" ref={menuRef}>
            <button
                title={title}
                className={`
                    flex items-center justify-center gap-1
                    h-9 min-w-[48px] px-2
                    text-sm rounded-md transition-all duration-200
                    ${isActive
                        ? 'bg-page-subtitle shadow-md shadow-page-subtitle/20 text-white'
                        : 'hover:bg-info-box-link-bg text-info-box-text hover:shadow-sm'
                    }
                    active:scale-95
                    ${triggerClassName}
                `}
            >
                {trigger}
                {showChevron && (
                    <ChevronDown
                        className={`w-3 h-3 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}
                    />
                )}
            </button>

            {isOpen && (
                <>
                    {/* Backdrop for mobile */}
                    <div className="fixed inset-0 z-20" onClick={onClose} />

                    {/* Dropdown Menu */}
                    <div
                        className={`
                            absolute top-full mt-1.5 py-1 min-w-[160px] z-30
                            bg-page-background border border-borders rounded-lg shadow-2xl
                            animate-in fade-in zoom-in-95 duration-100
                            overflow-hidden
                            ${alignmentStyles[align]}
                            ${menuClassName}
                        `}
                    >
                        {children}
                    </div>
                </>
            )}
        </div>
    );
}

export interface DropdownItemProps {
    /**
     * Click handler for the item
     */
    onClick: () => void;

    /**
     * Whether this item is currently active/selected
     */
    isActive?: boolean;

    /**
     * The item content
     */
    children: React.ReactNode;

    /**
     * Optional callback when item is clicked (for auto-close)
     */
    onClose?: () => void;

    /**
     * Custom className
     */
    className?: string;
}

export function DropdownItem({
    onClick,
    isActive = false,
    children,
    onClose,
    className = ''
}: DropdownItemProps) {
    const handleClick = () => {
        onClick();
        onClose?.();
    };

    return (
        <button
            onClick={handleClick}
            className={`
                flex items-center w-full px-3 py-2 text-sm text-left transition-colors
                ${isActive
                    ? 'bg-page-subtitle/10 text-page-subtitle font-semibold'
                    : 'text-page-text hover:bg-info-box-link-bg hover:text-page-subtitle'
                }
                ${className}
            `}
        >
            {children}
        </button>
    );
}

export interface DropdownDividerProps {
    className?: string;
}

export function DropdownDivider({ className = '' }: DropdownDividerProps) {
    return <div className={`h-px bg-borders my-1 ${className}`} />;
}
