export interface ServiceData {
    id: number;
    title: string;
    intro: string;
    tagline?: string;
    sections: {
        title: string;
        content?: string;
        list?: { title: string; description: string }[];
    }[];
    cta: {
        title: string;
        text: string;
        buttonText: string;
        reasonSlug: string;
    };
    icon: string;
    shortTitle?: string;
}

export const servicesData: Record<string, ServiceData> = {
    "content-management": {
        id: 1,
        title: "Advanced Content Management",
        tagline: "Modern content management that empowers your team",
        intro: "Experience a distraction-free writing environment designed for creators. {{siteName}} provides the perfect balance between powerful structural tools and a clean, intuitive interface that lets you focus on what matters most: your content.",
        sections: [
            {
                title: "Visual Editing Experience",
                content: "{{siteName}} features a modern WYSIWYG editor powered by Tiptap, giving you familiar word-processor controls. No HTML knowledge required. Unlike traditional CMSs that show confusing markup, our editor displays exactly what your readers will see.",
                list: [
                    { title: "Rich Text Formatting", description: "Bold, italic, headings, and other familiar controls." },
                    { title: "Media Management", description: "Easy link insertion and table support for structured data." },
                    { title: "Real-time Feedback", description: "See exactly what your readers will see as you type." },
                    { title: "Power User Tools", description: "Keyboard shortcuts and draft auto-save functionality." }
                ]
            },
            {
                title: "Markdown Support",
                content: "For technical users who prefer Markdown, we support full MDX syntax. Write in plain text with simple formatting markers, or mix React components directly into your content.",
                list: [
                    { title: "Preferred Formats", description: "Developers can work in MDX while content teams use visual tools." },
                    { title: "Seamless Collaboration", description: "Both approaches work together perfectly in the same environment." },
                    { title: "Version Control", description: "Plain text format is inherently friendly for Git tracking." }
                ]
            },
            {
                title: "Organization & Management",
                content: "Keep your content organized even as your site grows. Perfect for teams managing dozens or hundreds of pages and posts.",
                list: [
                    { title: "Categorization", description: "Tag-based organization and search across all content." },
                    { title: "Status Tracking", description: "Manage draft and published statuses with ease." },
                    { title: "Bulk Operations", description: "Perform editing and management tasks at scale." },
                    { title: "Activity History", description: "Track changes and updates across your team's work." }
                ]
            }
        ],
        cta: {
            title: "Start writing today.",
            text: "Experience the most intuitive editor in the ecosystem.",
            buttonText: "Open Editor",
            reasonSlug: "content-management"
        },
        icon: "🖋️",
        shortTitle: "Editor"
    },
    "theme-customization": {
        id: 2,
        title: "Visual Theme Engine",
        tagline: "Your brand, your style - no code required",
        intro: "Take control of your site's visual identity without touching a single line of code. Our Theme Transformer engine allows you to customize every aspect of your brand's presence, ensuring a professional look that resonates with your audience and stays consistent across all platforms.",
        sections: [
            {
                title: "Live Visual Editor",
                content: "The Theme Transformer dashboard lets you customize every color in real-time. See changes instantly as you edit - no refresh needed. Your theme applies across the entire site automatically.",
                list: [
                    { title: "Color Control", description: "Customize headers, navigation, and background combinations." },
                    { title: "Brand Identity", description: "Set primary colors for buttons, links, and accents." },
                    { title: "Dark Mode Variants", description: "Refine your site's appearance for low-light environments." },
                    { title: "Visual Consistency", description: "Cards, borders, and UI elements update instantly." }
                ]
            },
            {
                title: "Industry Templates",
                content: "Start with one of our 5 carefully crafted templates, each including optimized colors for both light and dark modes.",
                list: [
                    { title: "MSP & IT Service", description: "Professional blue tones for technology and business." },
                    { title: "Creative Blogger", description: "Clean, minimal design focused on readability." },
                    { title: "Service & Hospitality", description: "Elegant cyan and warm amber for high-end brands." },
                    { title: "Healthcare & Wellness", description: "Trustworthy green tones for medical professionals." }
                ]
            },
            {
                title: "Brand Consistency",
                content: "Maintaining a consistent brand is crucial. Our theme system ensures your site looks professional on all devices while remaining accessible.",
                list: [
                    { title: "Design Systems", description: "Uses consistent CSS variables throughout the entire site." },
                    { title: "Accessibility Native", description: "Ensures colors meet WCAG AA contrast standards." },
                    { title: "Automated Styling", description: "New content inherits your brand styles automatically." },
                    { title: "Portable Themes", description: "Export your theme as JSON for backup or version control." }
                ]
            }
        ],
        cta: {
            title: "Design your site.",
            text: "Create a unique visual identity with our intuitive visual engine.",
            buttonText: "Customizer",
            reasonSlug: "theme-customization"
        },
        icon: "🎨",
        shortTitle: "Theme"
    },
    "blog-publishing": {
        id: 3,
        title: "Enterprise-Grade Publishing",
        tagline: "Publish once, distribute everywhere",
        intro: "{{siteName}} isn't just a place to write; it's a global distribution platform. We've built enterprise-grade publishing tools into the core, ensuring your voice reaches your audience through every channel—from search engines and RSS feeds to social media—with maximum impact and minimal effort.",
        sections: [
            {
                title: "SEO Optimization",
                content: "Every post is automatically optimized for search engines. Your content is discoverable without manual SEO work.",
                list: [
                    { title: "Metadata Management", description: "Custom meta titles, descriptions, and canonical URL control." },
                    { title: "Rich Integration", description: "Automatic Open Graph tags and Twitter Card support." },
                    { title: "Semantic Markup", description: "Built with HTML5 and structured data (JSON-LD) in mind." },
                    { title: "Auto-Indexing", description: "Automatic sitemap generation for all of your content." }
                ]
            },
            {
                title: "Tags & Organization",
                content: "Organize content your way. Readers can find related content easily, increasing engagement and time on site.",
                list: [
                    { title: "Dynamic Tagging", description: "Unlimited tags per post with auto-generated archive pages." },
                    { title: "Content Discovery", description: "Smart related posts suggestions for every article." },
                    { title: "Logical Grouping", description: "Robust category management for large-scale blogs." },
                    { title: "Search Focus", description: "Powerful search functionality built into the core." }
                ]
            },
            {
                title: "RSS & Distribution",
                content: "Automatic RSS feed generation lets readers subscribe via their favorite tools. Plus, your content is served globally via Cloudflare's CDN.",
                list: [
                    { title: "Subscription Feeds", description: "Ready for Feedly, Inoreader, and email digest services." },
                    { title: "Social Distribution", description: "Easy integration with social media auto-posting tools." },
                    { title: "Global Delivery", description: "Served from 300+ data centers for instant access." },
                    { title: "Content Portability", description: "Syndicate your content to aggregators seamlessly." }
                ]
            }
        ],
        cta: {
            title: "Go global.",
            text: "Launch a publishing platform that can handle any amount of traffic.",
            buttonText: "View Blog",
            reasonSlug: "blog-publishing"
        },
        icon: "🚀",
        shortTitle: "Publish"
    },
    "developer-experience": {
        id: 4,
        title: "Developer First Philosophy",
        tagline: "Built for developers, designed for everyone",
        intro: "We believe that a CMS should be a joy to work with for developers, not a source of frustration. {{siteName}} is built on a modern, type-safe stack that leverages the best of Git-based workflows and the latest web standards, providing a development experience that is fast, reliable, and incredibly flexible.",
        sections: [
            {
                title: "Git-Backed Workflow",
                content: "Unlike database-only CMSs, {{siteName}} stores content in Git. Developers love it. Non-technical users don't even notice it's happening.",
                list: [
                    { title: "Version Control", description: "Full history of every change with instant rollback capability." },
                    { title: "Review Systems", description: "Collaborate via pull requests and review before publishing." },
                    { title: "Built-in Backups", description: "Your content repository is your backup by default." },
                    { title: "Offline Sync", description: "Work offline and sync changes whenever you're ready." }
                ]
            },
            {
                title: "TypeScript & Type Safety",
                content: "Built entirely in TypeScript and React with Next.js 15. The codebase is clean, well-typed, and ready to extend.",
                list: [
                    { title: "Error Prevention", description: "Catch bugs during development, not in production." },
                    { title: "Speedy Development", description: "Full autocomplete and self-documenting code structures." },
                    { title: "Modern Patterns", description: "Leverages React Server Components and Edge runtime." },
                    { title: "Extensibility", description: "Easy to add custom features with a solid type foundation." }
                ]
            },
            {
                title: "Local Development",
                content: "Experience a perfect local dev environment. Deploy to production in seconds with a simple git push.",
                list: [
                    { title: "Hot Reloading", description: "Instant feedback during the development process." },
                    { title: "Edge Simulation", description: "Test with real Cloudflare bindings on your local machine." },
                    { title: "Code Quality", description: "ESLint and TypeScript checking built into the workflow." },
                    { title: "IDE Support", description: "Full integration with VS Code, WebStorm, and more." }
                ]
            }
        ],
        cta: {
            title: "Read the docs.",
            text: "Dive into our technical documentation and start building.",
            buttonText: "Developer Guide",
            reasonSlug: "developer-experience"
        },
        icon: "🛠️",
        shortTitle: "Dev Exp"
    },
    "performance-optimization": {
        id: 5,
        title: "Edge Performance Stack",
        tagline: "Blazing fast, globally distributed",
        intro: "Speed is a core feature, not an afterthought. In a world where every millisecond counts, {{siteName}} delivers unmatched performance by running natively on the edge. Our architecture is designed to eliminate lag, ensure instant load times, and provide a seamless experience for your visitors, no matter where they are.",
        sections: [
            {
                title: "Edge CDN Delivery",
                content: "Powered by Cloudflare's global network. Your visitors get instant page loads regardless of where they are.",
                list: [
                    { title: "Global Presence", description: "300+ data centers serving content from the nearest location." },
                    { title: "Low Latency", description: "Sub-100ms response times across the globe." },
                    { title: "Built-in Security", description: "Automatic DDoS protection and zero cold start times." },
                    { title: "High Availability", description: "Enterprise-grade 99.99% uptime for your content." }
                ]
            },
            {
                title: "Core Web Vitals Excellence",
                content: "Google's Core Web Vitals measure real user experience. No performance plugins or optimization services needed - it's fast by design.",
                list: [
                    { title: "Perfect Scores", description: "Consistently hits LCP < 1.0s and FID < 50ms benchmarks." },
                    { title: "Visual Stability", description: "Optimized for minimal Cumulative Layout Shift (CLS)." },
                    { title: "SEO Advantage", description: "Higher search rankings through superior performance scores." },
                    { title: "Native Speed", description: "Engineered for speed without relying on heavy plugins." }
                ]
            },
            {
                title: "Serverless Architecture",
                content: "Zero server maintenance. Focus on content, not infrastructure.",
                list: [
                    { title: "Zero Ops", description: "No servers to patch, scale, or manually update." },
                    { title: "Infinite Scaling", description: "Automatically handles traffic spikes without configuration." },
                    { title: "Cost Efficiency", description: "Pay only for what you use with minimal energy waste." },
                    { title: "Modern Compute", description: "Leverages the latest in edge computing technology." }
                ]
            }
        ],
        cta: {
            title: "See the speed.",
            text: "Experience the fastest CMS platform on the planet.",
            buttonText: "Performance Docs",
            reasonSlug: "performance"
        },
        icon: "⚡",
        shortTitle: "Speed"
    },
    "security-ownership": {
        id: 6,
        title: "Security & Ownership",
        tagline: "Your content, your control, your security",
        intro: "In an era of platform lock-in and data privacy concerns, {{siteName}} gives you complete ownership of your digital assets. We combine the security of enterprise-grade infrastructure with the freedom of open standards, ensuring your content remains yours while being protected by the most advanced security protocols available.",
        sections: [
            {
                title: "Full Data Ownership",
                content: "Unlike proprietary platforms, you own everything. Your data isn't held hostage. You're in complete control.",
                list: [
                    { title: "GitHub Based", description: "Your content lives in your own Git repository." },
                    { title: "Cloudflare Native", description: "Your database is in your own Cloudflare account." },
                    { title: "No Vendor Lock-in", description: "Export or migrate your site anytime without restrictions." },
                    { title: "Compliance Ready", description: "Maintain full control over where and how data is stored." }
                ]
            },
            {
                title: "Version Control Security",
                content: "Every change is tracked and auditable. Perfect for teams that need accountability and regulatory compliance.",
                list: [
                    { title: "Audit Trails", description: "See who changed what and when with full history." },
                    { title: "Instant Recovery", description: "Restore previous versions of any page or post instantly." },
                    { title: "Change Management", description: "Review and approve content before it goes live." },
                    { title: "Conflict Prevention", description: "Collaborative editing without risk of data loss." }
                ]
            },
            {
                title: "Platform Security",
                content: "Built on Cloudflare's enterprise security. No plugins to update, no security patches to manually apply.",
                list: [
                    { title: "Enterprise WAF", description: "Protected by a world-class Web Application Firewall." },
                    { title: "SSL & Protection", description: "Automatic HTTPS and DDoS protection included." },
                    { title: "Access Control", description: "Cloudflare Access for robust admin protection." },
                    { title: "Safe Infrastructure", description: "Secured by the same tech protecting Fortune 500s." }
                ]
            }
        ],
        cta: {
            title: "Secure your site.",
            text: "Launch a platform that prioritizes your data ownership.",
            buttonText: "Security Guide",
            reasonSlug: "security-ownership"
        },
        icon: "🛡️",
        shortTitle: "Security"
    }
};

