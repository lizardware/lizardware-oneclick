"use client";

import React from "react";
import { Globe } from "lucide-react";
import { VERSION } from "@/lib/version";

interface SystemStatusBubbleProps {
    status?: 'sync' | 'pending' | 'syncing';
    className?: string;
}

/**
 * SystemStatusBubble
 * A reusable indicator for edge synchronization and system versioning.
 * Previously used in the Admin Bottom Navigation Bar.
 */
export function SystemStatusBubble({ status = 'sync', className = "" }: SystemStatusBubbleProps) {
    return (
        <div className={`flex items-center gap-3 px-3 lg:px-4 py-2 bg-gradient-to-b from-white to-gray-50 dark:from-zinc-800 dark:to-zinc-900 border border-gray-200 dark:border-zinc-700 rounded-lg shadow-sm relative overflow-hidden group/status cursor-default transition-all duration-500 ${status === 'syncing' ? 'border-blue-500/30' : 'border-emerald-500/20'} ${className}`}>
            <div className="relative flex items-center justify-center w-5 h-5">
                <Globe size={14} className={`${status === 'syncing' ? 'text-blue-500 animate-spin-slow' : 'text-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.4)]'}`} />
                {status === 'sync' && <div className="absolute inset-0 bg-emerald-500 rounded-full animate-ping opacity-20 scale-150"></div>}
            </div>
            <div className="hidden sm:flex flex-col items-start leading-none">
                <div className={`text-[8px] font-black uppercase tracking-[0.15em] ${status === 'syncing' ? 'text-blue-500' : 'text-emerald-500'}`}>
                    {status === 'syncing' ? 'Propagating Edits' : 'Edge: Operational'}
                </div>
                <div className="text-[10px] font-bold text-page-title mt-0.5 opacity-60 flex items-center gap-1">
                    v{VERSION} <span className="w-1 h-1 rounded-full bg-gray-300 dark:bg-zinc-600"></span> Global Sync
                </div>
            </div>
        </div>
    );
}
