'use client';

import { Page } from '@/types/page';
import { Post } from '@/types/blog';
import { ArrowLeft, Save, RotateCcw, Image as ImageIcon, Zap, Check, GripVertical, ChevronRight, Lock, Unlock, Layout, Blocks, Type } from 'lucide-react';
import { useState } from 'react';
import MediaPickerModal from './MediaPickerModal';
import RichTextEditor from '../editor/RichTextEditor';
import VariableInput from './VariableInput';
import NavigationSettings from './NavigationSettings';
import BlockLibrary from './blocks/BlockLibrary';
import BlockProperties from './blocks/BlockProperties';
import { Block } from '@/types/blocks';
import { findBlockById, updateBlockInTree } from '@/lib/blocks/tree';

type ContentType = 'page' | 'blog';
type Content = Page | Post;

interface EditorSidebarProps {
  type: ContentType;
  content: Content;
  onChange: (content: Content) => void;
  onSave: () => void;
  onRevert: () => void;
  onCancel: () => void;
  isSaving: boolean;
  hasChanges: boolean;
  isSyncing: boolean;
  autoSaveEnabled: boolean;
  onAutoSaveToggle: (enabled: boolean) => void;
  width?: string;
  editorMode?: 'rich-text' | 'builder';
  onModeChange?: (mode: 'rich-text' | 'builder') => void;

  // Block Editing Props
  blocks?: Block[];
  selectedBlockId?: string | null;
  onSelectedBlockChange?: (id: string | null) => void;
  onBlocksChange?: (blocks: Block[]) => void;
}

export default function EditorSidebar({
  type,
  content,
  onChange,
  onSave,
  onRevert,
  onCancel,
  isSaving,
  hasChanges,
  isSyncing,
  autoSaveEnabled,
  onAutoSaveToggle,
  width = "320px",
  editorMode = 'rich-text',
  onModeChange,
  blocks = [],
  selectedBlockId,
  onSelectedBlockChange,
  onBlocksChange
}: EditorSidebarProps) {
  const [activeBuilderTab, setActiveBuilderTab] = useState<'settings' | 'blocks'>('blocks');
  const isPage = type === 'page';
  const pageContent = isPage ? (content as Page) : null;
  const postContent = !isPage ? (content as Post) : null;
  const [showMediaPicker, setShowMediaPicker] = useState(false);
  const [slugLocked, setSlugLocked] = useState(content.slug !== '' && content.slug !== 'new');

  const handleFieldChange = (field: string, value: any) => {
    let updates: any = { [field]: value };

    // Auto-populate slug from title if unlocked
    if (field === 'title' && !slugLocked) {
      const generatedSlug = value
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');
      updates.slug = generatedSlug;
    }

    onChange({ ...content, ...updates });
  };

  const selectedBlock = selectedBlockId ? findBlockById(blocks, selectedBlockId) : null;

  return (
    <div
      className="flex-shrink-0 flex flex-col border-r border-gray-200 dark:border-zinc-800 bg-white dark:bg-zinc-900"
      style={{ width }}
    >
      {/* Header - Fixed */}
      <div className="p-3 border-b border-gray-200 dark:border-zinc-800 flex-shrink-0 relative">
        {onModeChange && (
          <div className="flex bg-gray-100 dark:bg-zinc-800 rounded-lg p-1 mb-3">
            <button
              onClick={() => onModeChange('rich-text')}
              className={`flex-1 text-[10px] font-bold uppercase tracking-wider py-1.5 rounded-md transition-all ${editorMode === 'rich-text' ? 'bg-white dark:bg-zinc-700 shadow-sm text-primary' : 'text-gray-400 hover:text-gray-600'}`}
            >
              <div className="flex items-center justify-center gap-1.5"><Type size={12} /> Classic</div>
            </button>
            <button
              onClick={() => {
                onModeChange('builder');
                setActiveBuilderTab('blocks');
              }}
              className={`flex-1 text-[10px] font-bold uppercase tracking-wider py-1.5 rounded-md transition-all ${editorMode === 'builder' ? 'bg-white dark:bg-zinc-700 shadow-sm text-purple-600' : 'text-gray-400 hover:text-gray-600'}`}
            >
              <div className="flex items-center justify-center gap-1.5"><Blocks size={12} /> Builder</div>
            </button>
          </div>
        )}

        <div className="mb-0 flex items-center justify-between">
          {editorMode === 'builder' ? (
            <div className="flex items-center gap-1 bg-gray-100 dark:bg-zinc-800 p-0.5 rounded-lg w-full">
              <button
                onClick={() => {
                  setActiveBuilderTab('blocks');
                  onSelectedBlockChange?.(null);
                }}
                className={`flex-1 text-[10px] font-bold px-3 py-1.5 rounded-md transition-colors ${activeBuilderTab === 'blocks' && !selectedBlock ? 'bg-purple-500 text-white shadow-sm' : 'text-gray-500 hover:text-gray-900'}`}
              >Blocks</button>
              <button
                onClick={() => setActiveBuilderTab('settings')}
                className={`flex-1 text-[10px] font-bold px-3 py-1.5 rounded-md transition-colors ${activeBuilderTab === 'settings' ? 'bg-white dark:bg-zinc-700 text-gray-900 dark:text-gray-200 shadow-sm' : 'text-gray-500 hover:text-gray-900'}`}
              >Settings</button>
            </div>
          ) : (
            <h1 className="font-bold text-base flex items-center gap-2 py-1">
              <span>{isPage ? '📄' : '📝'}</span>
              {isPage ? 'Page' : 'Blog'} Editor
            </h1>
          )}
        </div>



        {/* Resize Hint - Absolute positioned at the far right edge of the header */}
        <div className="absolute top-0 bottom-0 right-0 flex items-center pointer-events-none pr-0.5">
          <div className="flex flex-col items-center gap-0.5 text-gray-300 dark:text-zinc-700 animate-pulse">
            <GripVertical size={14} />
          </div>
        </div>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto p-3 space-y-4">
        {editorMode === 'builder' && selectedBlock ? (
          <BlockProperties
            block={selectedBlock}
            onChange={(updates: { props?: Record<string, any>; styleOptions?: Block['styleOptions'] }) => {
              if (onBlocksChange) {
                onBlocksChange(updateBlockInTree(blocks, selectedBlock.id, updates));
              }
            }}
            onBack={() => onSelectedBlockChange?.(null)}
          />
        ) : editorMode === 'builder' && activeBuilderTab === 'blocks' ? (
          <BlockLibrary />
        ) : (
          <>
            {/* Title */}
            <VariableInput
              label="Title"
              value={content.title}
              onChange={(val) => handleFieldChange('title', val)}
              placeholder={isPage ? 'Page title...' : 'Post title...'}
            />

            {/* Slug */}
            <div>
              <label className="block text-sm font-medium mb-1">Slug</label>
              <div className="relative group/slug">
                <input
                  type="text"
                  value={content.slug}
                  onChange={(e) => handleFieldChange('slug', e.target.value)}
                  disabled={slugLocked}
                  className={`w-full px-3 py-2 border rounded-lg dark:bg-zinc-800 dark:border-zinc-700 outline-none font-mono text-sm transition-all ${slugLocked
                    ? 'opacity-60 bg-gray-50 dark:bg-zinc-900 border-dashed cursor-not-allowed'
                    : 'focus:ring-2 focus:ring-primary border-primary/50'
                    }`}
                  placeholder="url-slug"
                />
                <button
                  onClick={() => setSlugLocked(!slugLocked)}
                  className={`absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-md transition-all ${slugLocked
                    ? 'text-gray-400 hover:text-primary hover:bg-primary/10'
                    : 'text-primary bg-primary/10 hover:bg-primary/20'
                    }`}
                  title={slugLocked ? "Unlock Slug" : "Lock Slug"}
                >
                  {slugLocked ? <Lock size={14} /> : <Unlock size={14} />}
                </button>
              </div>
              {!slugLocked && (
                <p className="text-[10px] text-primary mt-1 font-bold animate-pulse">Slug is now syncing with title or editable manually.</p>
              )}
            </div>

            {/* Description / Excerpt */}
            <VariableInput
              label={isPage ? 'Description' : 'Excerpt'}
              value={content.description || ''}
              onChange={(val) => handleFieldChange('description', val)}
              rows={3}
              placeholder={isPage ? 'Brief description...' : 'Post excerpt...'}
            />

            {/* Content - ONLY SHOW IF NOT BUILDER MODE */}
            {editorMode !== 'builder' && (
              <div>
                <label className="block text-sm font-medium mb-1">Content</label>
                <RichTextEditor
                  content={content.content || ''}
                  onChange={(newContent) => handleFieldChange('content', newContent)}
                  placeholder="Write your content here..."
                  minHeight="400px"
                  editable={true}
                />
              </div>
            )}

            {/* Status */}
            <div>
              <label className="block text-sm font-medium mb-1">Status</label>
              <select
                value={content.status}
                onChange={(e) => handleFieldChange('status', e.target.value as 'published' | 'draft')}
                className="w-full px-3 py-2 border rounded-lg dark:bg-zinc-800 dark:border-zinc-700 focus:ring-2 focus:ring-primary outline-none"
              >
                <option value="draft">Draft</option>
                <option value="published">Published</option>
              </select>
            </div>

            {/* Navigation Sync */}
            <NavigationSettings
              showInNav={content.show_in_nav || false}
              navLabel={content.nav_label || ''}
              navParent={content.nav_parent || ''}
              navOrder={content.nav_order || 0}
              title={content.title}
              onChange={handleFieldChange}
            />

            {/* Page-specific: Template metadata */}
            {isPage && pageContent && (
              <div className="pt-4 border-t border-gray-200 dark:border-zinc-800 space-y-4">
                <h3 className="text-sm font-semibold flex items-center gap-2">
                  <Layout size={16} className="text-primary" />
                  Page Architecture
                </h3>

                {/* Layout Selector */}
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1.5">Selected Theme</label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { id: 'standard', name: 'Standard Protocol', icon: '🏛️' },
                      { id: 'minimal', name: 'Minimal Focus', icon: '📝' },
                      { id: 'sidebar_right', name: 'Documentation', icon: '📚' },
                      { id: 'full_width', name: 'Hero Power', icon: '⚡' },
                      { id: 'blocks', name: 'Block Builder', icon: '🧱' }
                    ].map((layout) => (
                      <button
                        key={layout.id}
                        onClick={() => handleFieldChange('layout_id', layout.id)}
                        className={`flex flex-col items-center gap-2 p-3 rounded-xl border transition-all ${pageContent.layout_id === layout.id || (!pageContent.layout_id && layout.id === 'standard')
                          ? 'bg-primary/5 border-primary shadow-sm ring-2 ring-primary/20'
                          : 'bg-gray-50 dark:bg-zinc-950 border-gray-100 dark:border-zinc-800 grayscale hover:grayscale-0'
                          }`}
                      >
                        <span className="text-xl">{layout.icon}</span>
                        <span className="text-[9px] font-black uppercase tracking-tighter text-center leading-none">{layout.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="pt-2">
                  <label className="flex items-center gap-2 mb-3 cursor-pointer group">
                    <input
                      type="checkbox"
                      checked={pageContent.is_template || false}
                      onChange={(e) => handleFieldChange('is_template', e.target.checked)}
                      className="w-4 h-4 rounded border-gray-300 text-primary focus:ring-primary"
                    />
                    <span className="text-sm font-medium group-hover:text-primary transition-colors">Mark as Template Page</span>
                  </label>

                  {pageContent.is_template && (
                    <div className="ml-6 space-y-3 animate-in slide-in-from-left-2 fade-in">
                      <div>
                        <label className="block text-xs font-medium mb-1">Category</label>
                        <select
                          value={pageContent.template_category || ''}
                          onChange={(e) => handleFieldChange('template_category', e.target.value)}
                          className="w-full px-2 py-1 border rounded text-sm dark:bg-zinc-800 dark:border-zinc-700"
                        >
                          <option value="">None</option>
                          <option value="Company">Company</option>
                          <option value="Legal">Legal</option>
                          <option value="Support">Support</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-medium mb-1">Sort Order</label>
                        <input
                          type="number"
                          value={pageContent.sort_order || 0}
                          onChange={(e) => handleFieldChange('sort_order', parseInt(e.target.value))}
                          className="w-full px-2 py-1 border rounded text-sm dark:bg-zinc-800 dark:border-zinc-700"
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Blog-specific: Publish date, and Featured Image */}
            {!isPage && postContent && (
              <div className="pt-4 border-t border-gray-200 dark:border-zinc-800 space-y-4">
                <h3 className="text-sm font-semibold">Post Settings</h3>

                {/* Featured Image */}
                <div>
                  <label className="block text-xs font-medium mb-1">Featured Image URL</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={postContent.featured_image_id || ''}
                      onChange={(e) => handleFieldChange('featured_image_id', e.target.value)}
                      className="flex-1 px-2 py-1 border rounded text-xs dark:bg-zinc-800 dark:border-zinc-700"
                      placeholder="https://..."
                    />
                    <button
                      onClick={() => setShowMediaPicker(true)}
                      className="px-2 py-1 bg-gray-100 hover:bg-gray-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 rounded text-xs border border-gray-200 dark:border-zinc-700"
                      title="Select from Library"
                    >
                      <ImageIcon size={14} />
                    </button>
                  </div>
                  {postContent.featured_image_id && (
                    <div className="mt-2 relative aspect-video rounded overflow-hidden border border-gray-200 dark:border-zinc-800 bg-gray-50">
                      <img src={postContent.featured_image_id.startsWith('http') ? postContent.featured_image_id : `/api/media/${postContent.featured_image_id}`} alt="Preview" className="w-full h-full object-cover" />
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-medium mb-1">Publish Date</label>
                  <input
                    type="datetime-local"
                    value={postContent.date ? new Date(postContent.date).toISOString().slice(0, 16) : ''}
                    onChange={(e) => handleFieldChange('date', e.target.value)}
                    className="w-full px-2 py-1 border rounded text-sm dark:bg-zinc-800 dark:border-zinc-700"
                  />
                </div>
              </div>
            )}
          </>
        )}
      </div>



      {/* Media Picker Modal */}
      <MediaPickerModal
        isOpen={showMediaPicker}
        onClose={() => setShowMediaPicker(false)}
        onSelect={(url) => {
          handleFieldChange('featured_image_id', url);
          setShowMediaPicker(false);
        }}
      />
    </div>
  );
}
