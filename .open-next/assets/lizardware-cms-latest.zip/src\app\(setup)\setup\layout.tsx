import { ReactNode } from 'react';
import { Metadata } from 'next';

export const metadata: Metadata = {
    title: 'Setup Wizard'
};

export default function SetupLayout({ children }: { children: ReactNode }) {
    return <>{children}</>;
}
