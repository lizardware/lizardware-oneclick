import { NextResponse } from 'next/server';
import { getD1Database } from '@/lib/cloudflare';

export async function GET() {
    try {
        const db = await getD1Database();
        if (!db) {
            // In development, we might not have D1, but we still want to check if setup is done
            if (process.env.NODE_ENV === 'development') {
                return NextResponse.json({ setup_completed: false });
            }
            return NextResponse.json({ error: 'Database not available' }, { status: 500 });
        }

        const config = await db.prepare('SELECT setup_completed FROM site_config LIMIT 1').first();

        return NextResponse.json({
            setup_completed: config?.setup_completed === 1,
        });
    } catch (error) {
        console.error('Failed to check setup status:', error);
        return NextResponse.json({ error: 'Failed to check setup status' }, { status: 500 });
    }
}

export async function POST(request: Request) {
    try {
        const body = await request.json() as { unlock?: boolean };
        const db = await getD1Database();

        if (!db) {
            return NextResponse.json({ error: 'Database not available' }, { status: 500 });
        }

        if (body.unlock) {
            await db.prepare('UPDATE site_config SET setup_completed = 0').run();
            return NextResponse.json({ success: true });
        }

        return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
    } catch (error) {
        console.error('Failed to update setup status:', error);
        return NextResponse.json({ error: 'Failed to update setup status' }, { status: 500 });
    }
}
