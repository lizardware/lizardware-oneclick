'use client';

import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
    children: ReactNode;
    fallback: ReactNode;
}

interface State {
    hasError: boolean;
}

export class ClerkErrorBoundary extends Component<Props, State> {
    constructor(props: Props) {
        super(props);
        this.state = { hasError: false };
    }

    static getDerivedStateFromError(error: Error): State {
        // Check if the error is related to Clerk's missing key
        if (error.message.includes('Missing publishableKey') || error.message.includes('clerk-react')) {
            return { hasError: true };
        }
        // Re-throw other errors
        return { hasError: false };
    }

    componentDidCatch(error: Error, errorInfo: ErrorInfo) {
        if (error.message.includes('Missing publishableKey') || error.message.includes('clerk-react')) {
            console.warn('⚠️ Clerk crashed due to missing key. Falling back to Local Auth.', error);
        } else {
            // Log other errors but don't swallow them? 
            // Actually getDerivedStateFromError handling controls the state, 
            // validation here is for logging.
        }
    }

    render() {
        if (this.state.hasError) {
            return this.props.fallback;
        }

        return this.props.children;
    }
}
