-- Migration: Create SEO configuration table
-- Version: 0.3.0
-- Purpose: Store SEO settings like robots.txt rules and meta configurations

CREATE TABLE IF NOT EXISTS seo_config (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Default robots.txt configuration (single-line to avoid D1 API parsing issues)
INSERT INTO seo_config (key, value) VALUES ('robots_txt', 'User-agent: *\nAllow: /\nDisallow: /admin/\nDisallow: /api/\nDisallow: /setup/\n\nSitemap: {{site_url}}/sitemap.xml');
