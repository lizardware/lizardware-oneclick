-- Seed: Production Defaults (Minimal)
-- Created: 2025-12-28
-- Decision A1: 1 Welcome post + 1 Draft example

-- Welcome Post
INSERT OR IGNORE INTO posts (slug, title, content, description, author, date, status)
VALUES (
  'welcome',
  'Welcome to Your New Site',
  '<h1>Welcome!</h1><p>This is your first blog post. You can:</p><ul><li>Edit this post in the Admin Dashboard</li><li>Delete it entirely</li><li>Create new content</li></ul><p>To get started, visit <a href="/admin">/admin</a> to access your dashboard.</p><p>Happy publishing! 🎉</p>',
  'Welcome to your new CMS-powered website. Get started by visiting the admin dashboard.',
  'Site Administrator',
  datetime('now'),
  'published'
);

-- Example Draft
INSERT OR IGNORE INTO posts (slug, title, content, description, author, date, status)
VALUES (
  'example-draft-post',
  'Example Draft Post',
  '<h1>Example Draft</h1><p>This is an example of a draft post. Drafts are only visible to you in the admin dashboard.</p><p>When you''re ready to publish, change the status to "Published".</p>',
  'An example draft post to demonstrate the blog editor',
  'Site Administrator',
  datetime('now'),
  'draft'
);

-- Forum Categories (Basic set)
INSERT OR IGNORE INTO forum_categories (name, slug, description, icon, color, sort_order) VALUES
('General Discussion', 'general', 'Talk about anything and everything', '💬', '#3b82f6', 1),
('Questions & Answers', 'qa', 'Get help from the community', '❓', '#10b981', 2),
('Announcements', 'announcements', 'Official updates and news', '📢', '#8b5cf6', 0);
