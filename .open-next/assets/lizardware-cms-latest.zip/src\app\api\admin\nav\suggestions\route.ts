import { NextResponse } from 'next/server';
import { getD1Database } from '@/lib/cloudflare';

export const runtime = 'nodejs';

export async function GET() {
    try {
        const db = await getD1Database();
        if (!db) {
            // Local fallback logic if needed, but for admin intelligence we mostly rely on D1
            return NextResponse.json({ pages: [], posts: [], internal_routes: getInternalRoutes() });
        }

        // Fetch published pages with nav metadata
        const pages = await db
            .prepare(`
                SELECT slug, title, status, show_in_nav, nav_label 
                FROM pages 
                WHERE status = 'published' 
                ORDER BY title ASC
            `)
            .all();

        // Fetch published posts with nav metadata
        const posts = await db
            .prepare(`
                SELECT slug, title, status, show_in_nav, nav_label 
                FROM posts 
                WHERE status = 'published' 
                ORDER BY title ASC
            `)
            .all();

        return NextResponse.json({
            pages: pages.results || [],
            posts: posts.results || [],
            internal_routes: getInternalRoutes()
        });
    } catch (error) {
        console.error('Failed to fetch nav suggestions:', error);
        return NextResponse.json({ error: 'Failed to fetch suggestions' }, { status: 500 });
    }
}

function getInternalRoutes() {
    return [
        { path: '/', label: 'Home', type: 'system' },
        { path: '/blog', label: 'Blog Feed', type: 'system' },
        { path: '/docs', label: 'Documentation Hub', type: 'system' },
        { path: '/admin', label: 'Admin Dashboard', type: 'system' },
        { path: '/admin/content/pages', label: 'Page Playground', type: 'system' },
        { path: '/admin/content/blog', label: 'Blazing Blogger', type: 'system' },
        { path: '/admin/design/nav', label: 'Nifty Navigation', type: 'system' },
        { path: '/admin/design/theme', label: 'Theme Transformer', type: 'system' },
    ];
}
