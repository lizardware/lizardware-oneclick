
export const isClerkConfigured = () => {
    const key = process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY;
    return !!key && key.trim().length > 0 && key !== 'undefined';
};

export const DEFAULT_LOCAL_USER = {
    id: 'local-admin',
    email: 'admin@lizardware.dev',
    name: 'Local Administrator',
    imageUrl: '',
    role: 'owner' as const,
};
