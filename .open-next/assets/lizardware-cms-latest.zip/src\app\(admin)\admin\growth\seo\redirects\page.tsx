'use client';

import { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { Plus, Trash2, ExternalLink, Shuffle, ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import { Breadcrumbs } from "@/components/admin/Breadcrumbs";
import { AdminLoadingState } from "@/components/admin/AdminLoadingState";
import { usePopup } from '@/components/admin/AdminPopupProvider';
import AdminCommandBar, { CommandBarButton } from "@/components/admin/AdminCommandBar";
import { RoutePicker } from '@/components/admin/RoutePicker';
import { AdminHeader } from '@/components/admin/AdminHeader';

interface Redirect {
    id: number;
    source_path: string;
    destination_path: string;
    type: number;
    created_at: string;
}

export default function RedirectsPage() {
    const popup = usePopup();
    const [redirects, setRedirects] = useState<Redirect[]>([]);
    const [showForm, setShowForm] = useState(false);
    const [formData, setFormData] = useState({
        source_path: '',
        destination_path: '',
        type: 301
    });
    const [loading, setLoading] = useState(false);
    const [pageLoading, setPageLoading] = useState(true);
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        setMounted(true);
    }, []);

    useEffect(() => {
        fetchRedirects();
    }, []);

    async function fetchRedirects() {
        setPageLoading(true);
        const res = await fetch('/api/admin/seo/redirects');
        if (res.ok) {
            const data = await res.json() as any;
            setRedirects(data.redirects || []);
        }
        setPageLoading(false);
    }

    async function handleSubmit(e: React.FormEvent) {
        e.preventDefault();
        setLoading(true);

        const res = await fetch('/api/admin/seo/redirects', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });

        setLoading(false);

        if (res.ok) {
            setFormData({ source_path: '', destination_path: '', type: 301 });
            setShowForm(false);
            fetchRedirects();
            popup.success('Traffic routing rule created.');
        } else {
            const error = await res.json() as any;
            popup.error(error.error || 'Failed to create redirect');
        }
    }

    async function handleDelete(id: number) {
        const confirmed = await popup.confirm('Are you sure you want to delete this redirect?', { isDanger: true });
        if (!confirmed) return;

        const res = await fetch(`/api/admin/seo/redirects/${id}`, {
            method: 'DELETE'
        });

        if (res.ok) {
            fetchRedirects();
        }
    }

    if (pageLoading) return (
        <div className="max-w-7xl mx-auto px-6 pt-4 pb-12 space-y-8">
            <AdminLoadingState message="Calculating travel paths..." />
        </div>
    );

    return (
        <div className="max-w-7xl mx-auto px-6 pt-4 pb-12 space-y-8">

            <AdminHeader
                title={<>Redirects <span className="text-green-500 text-shadow-glow">Manager</span></>}
                description="Manage 301/302 URL redirects to control traffic flow and preserve SEO value."
                breadcrumbs={[
                    { label: 'Admin', href: '/admin' },
                    { label: 'Growth', href: '/admin/growth' },
                    { label: 'SEO', href: '/admin/growth/seo' },
                    { label: 'Redirects' }
                ]}
                badge={
                    <div className="px-3 py-1.5 bg-green-500/10 border border-green-500/20 rounded-lg text-[10px] font-bold uppercase tracking-widest text-green-600 dark:text-green-400 flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
                        Traffic Control Active
                    </div>
                }
                actions={
                    <Link
                        href="/admin/growth/seo"
                        className="px-4 py-2 bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 rounded-xl text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
                    >
                        <ArrowLeft size={12} />
                        Back
                    </Link>
                }
            />

            {showForm && (
                <div className="bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-xl p-6 shadow-sm">
                    <h3 className="font-bold text-lg mb-4 dark:text-white">New Redirect</h3>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div>
                            <label className="block text-sm font-bold mb-2 dark:text-slate-300">Source Path</label>
                            <input
                                type="text"
                                placeholder="/old-page"
                                value={formData.source_path}
                                onChange={(e) => setFormData({ ...formData, source_path: e.target.value })}
                                className="w-full p-2 border border-slate-200 dark:border-zinc-700 rounded-lg bg-white dark:bg-zinc-800 dark:text-white"
                                required
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-bold mb-2 dark:text-slate-300">Destination Path</label>
                            <RoutePicker
                                value={formData.destination_path}
                                onChange={(value) => setFormData({ ...formData, destination_path: value })}
                                placeholder="/new-page"
                                className="dark:text-white"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-bold mb-2 dark:text-slate-300">Redirect Type</label>
                            <select
                                value={formData.type}
                                onChange={(e) => setFormData({ ...formData, type: parseInt(e.target.value) })}
                                className="w-full p-2 border border-slate-200 dark:border-zinc-700 rounded-lg bg-white dark:bg-zinc-800 dark:text-white"
                            >
                                <option value={301}>301 - Permanent</option>
                                <option value={302}>302 - Temporary</option>
                            </select>
                        </div>
                        <div className="flex gap-2">
                            <button
                                type="submit"
                                disabled={loading}
                                className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 font-bold disabled:opacity-50"
                            >
                                {loading ? 'Creating...' : 'Create Redirect'}
                            </button>
                            <button
                                type="button"
                                onClick={() => setShowForm(false)}
                                className="px-4 py-2 border border-slate-200 dark:border-zinc-700 rounded-lg hover:bg-slate-50 dark:hover:bg-zinc-800 dark:text-white"
                            >
                                Cancel
                            </button>
                        </div>
                    </form>
                </div>
            )}

            <div className="bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-xl overflow-hidden shadow-sm">
                <div className="overflow-x-auto">
                    <table className="w-full">
                        <thead className="bg-slate-50 dark:bg-zinc-800 border-b border-slate-200 dark:border-zinc-700">
                            <tr>
                                <th className="text-left p-4 font-bold text-sm dark:text-slate-300">Source</th>
                                <th className="text-left p-4 font-bold text-sm dark:text-slate-300">Destination</th>
                                <th className="text-center p-4 font-bold text-sm dark:text-slate-300">Type</th>
                                <th className="text-center p-4 font-bold text-sm dark:text-slate-300">Created</th>
                                <th className="text-center p-4 font-bold text-sm dark:text-slate-300">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {redirects.length === 0 ? (
                                <tr>
                                    <td colSpan={5} className="text-center p-8 text-slate-500 dark:text-slate-400">
                                        No redirects configured. Add one to get started.
                                    </td>
                                </tr>
                            ) : (
                                redirects.map((redirect) => (
                                    <tr key={redirect.id} className="border-b border-slate-100 dark:border-zinc-800 hover:bg-slate-50 dark:hover:bg-zinc-800/50">
                                        <td className="p-4 font-mono text-sm dark:text-slate-300">{redirect.source_path}</td>
                                        <td className="p-4 font-mono text-sm dark:text-slate-300 ">{redirect.destination_path}</td>
                                        <td className="p-4 text-center">
                                            <span className={`px-2 py-1 rounded text-xs font-bold ${redirect.type === 301 ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400'}`}>
                                                {redirect.type}
                                            </span>
                                        </td>
                                        <td className="p-4 text-center text-sm text-slate-500 dark:text-slate-400">
                                            {new Date(redirect.created_at).toLocaleDateString()}
                                        </td>
                                        <td className="p-4 text-center">
                                            <div className="flex gap-2 justify-center">
                                                <a
                                                    href={redirect.source_path}
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                    className="p-2 hover:bg-slate-100 dark:hover:bg-zinc-700 rounded-lg text-slate-600 dark:text-slate-400"
                                                    title="Test redirect"
                                                >
                                                    <ExternalLink size={16} />
                                                </a>
                                                <button
                                                    onClick={() => handleDelete(redirect.id)}
                                                    className="p-2 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg text-red-600"
                                                    title="Delete redirect"
                                                >
                                                    <Trash2 size={16} />
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            <div className="flex justify-end items-center">
                <p className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400">
                    {redirects.length} Active Routing Rule{redirects.length !== 1 ? 's' : ''}
                </p>
            </div>

            {/* Admin Actions Portal */}
            {mounted && (() => {
                const portalTarget = document.getElementById('admin-actions-portal');
                if (!portalTarget) return null;

                return createPortal(
                    <div className="flex items-center gap-2 pointer-events-auto">
                        <CommandBarButton
                            onClick={() => setShowForm(!showForm)}
                            label={showForm ? "Close Form" : "Add Redirect"}
                            variant={showForm ? "default" : "primary"}
                            icon={showForm ? <Trash2 size={14} /> : <Plus size={14} />}
                        />
                    </div>,
                    portalTarget
                );
            })()}
        </div>
    );
}
