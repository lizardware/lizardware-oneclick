import { ReactNode } from 'react';
import { Metadata } from 'next';

export const metadata: Metadata = {
    title: {
        default: 'Admin Dashboard',
        template: '%s - Admin'
    }
};

export default function AdminPagesLayout({ children }: { children: ReactNode }) {
    return <>{children}</>;
}
