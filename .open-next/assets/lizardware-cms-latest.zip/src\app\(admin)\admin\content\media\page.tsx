"use client";

import { Breadcrumbs } from "@/components/admin/Breadcrumbs";
import MediaLibrary from "@/components/admin/MediaLibrary";
import { Image as ImageIcon, ArrowLeft } from "lucide-react";
import Link from "next/link";
import { AdminHeader } from "@/components/admin/AdminHeader";
import { useFeature } from "@/hooks/useFeatures";
import { useRouter } from "next/navigation";
import { useEffect } from "react";

export default function MediaPage() {
    const router = useRouter();
    const galleryEnabled = useFeature('gallery');

    useEffect(() => {
        if (!galleryEnabled) {
            router.push('/admin?feature=gallery&disabled=true');
        }
    }, [galleryEnabled, router]);

    return (
        <div className="bg-site-background">
            <div className="max-w-7xl mx-auto px-6 pt-0 space-y-8">


                <AdminHeader
                    title={<>Media <span className="text-purple-500">Vault</span></>}
                    description="Manage broadcasting assets for your transmissions."
                    breadcrumbs={[
                        { label: 'Admin', href: '/admin' },
                        { label: 'Content', href: '/admin/content' },
                        { label: 'Gallery' }
                    ]}
                    badge={
                        <div className="px-3 py-1.5 bg-purple-500/10 border border-purple-500/20 rounded-lg text-[10px] font-bold uppercase tracking-widest text-purple-600 dark:text-purple-400">
                            Unlimited Storage
                        </div>
                    }
                    actions={
                        <Link
                            href="/admin/content"
                            className="px-3 py-1.5 bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 rounded-lg text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
                        >
                            <ArrowLeft size={12} /> Back
                        </Link>
                    }
                />

                <div className="bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-3xl p-6 shadow-sm overflow-hidden">
                    <MediaLibrary />
                </div>
            </div>
        </div>
    );
}
