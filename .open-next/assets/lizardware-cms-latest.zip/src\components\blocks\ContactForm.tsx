import { Mail, Send } from 'lucide-react';

interface ContactFormProps {
    title?: string;
    emailTo?: string;
}

export default function ContactForm({ title = 'Get in Touch', emailTo }: ContactFormProps) {
    return (
        <div className="max-w-xl mx-auto bg-card-background rounded-2xl shadow-xl border border-borders p-8">
            <div className="text-center mb-8">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center text-primary mx-auto mb-4">
                    <Mail size={24} />
                </div>
                <h2 className="text-2xl font-bold text-page-title">{title}</h2>
                <p className="text-page-text opacity-70 mt-2">We'd love to hear from you. Send us a message!</p>
            </div>

            <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-page-text opacity-50 mb-1.5">Name</label>
                    <input
                        type="text"
                        className="w-full px-4 py-3 rounded-lg bg-input-background text-page-text border border-borders focus:ring-2 focus:ring-primary outline-none transition-all"
                        placeholder="John Doe"
                    />
                </div>

                <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-page-text opacity-50 mb-1.5">Email</label>
                    <input
                        type="email"
                        className="w-full px-4 py-3 rounded-lg bg-input-background text-page-text border border-borders focus:ring-2 focus:ring-primary outline-none transition-all"
                        placeholder="john@example.com"
                    />
                </div>

                <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-page-text opacity-50 mb-1.5">Message</label>
                    <textarea
                        rows={4}
                        className="w-full px-4 py-3 rounded-lg bg-input-background text-page-text border border-borders focus:ring-2 focus:ring-primary outline-none transition-all resize-none"
                        placeholder="How can we help you?"
                    />
                </div>

                <button
                    type="submit"
                    className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-4 rounded-xl shadow-lg shadow-primary/20 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
                >
                    <Send size={18} /> Send Message
                </button>
            </form>
        </div>
    );
}
