import { NextResponse } from 'next/server';
import { getD1Database } from '@/lib/cloudflare';
import { INSTALL_STRUCTURE_SQL, SEEDS } from '@/data/install-sql';

export async function POST(req: Request) {
    try {
        const body = await req.json().catch(() => ({ seedType: 'production' }));
        const seedType = (body as { seedType?: string }).seedType || 'production';

        const db = await getD1Database();

        // In local development WITHOUT a D1 binding, we mock success (files already exist)
        // But if a D1 binding exists (like in Preview or with remote bindings), we SHOULD run the SQL.
        if (process.env.NODE_ENV === 'development' && !db) {
            console.log('📦 Development mode (No D1): Skipping D1 initialization (using local fallback)');
            return NextResponse.json({ success: true });
        }
        if (!db) {
            return NextResponse.json({ error: 'Database not available' }, { status: 500 });
        }

        console.log(`🌱 Seeding database with business type: ${seedType}`);

        // STRUCTURE SQL is now run during BUILD TIME via GitHub Actions (wrangler d1 execute)
        // This API endpoint ONLY runs the business-type seed data to avoid subrequest limits

        // Run Business Type Seed SQL (lightweight - stays under 50 subrequest limit)
        if (seedType && SEEDS[seedType]) {
            console.log(`📝 Applying ${seedType} seed data...`);
            await runSql(db, SEEDS[seedType]);
        } else {
            console.log('⚠️  No seed type specified or invalid seed type');
        }

        return NextResponse.json({ success: true });
    } catch (error) {
        console.error('Database init error:', error);
        return NextResponse.json(
            { error: 'Failed to initialize database', details: (error as Error).message },
            { status: 500 }
        );
    }
}

async function runSql(db: any, sql: string) {
    const statements: string[] = [];
    let currentStatement = '';
    let inString = false;

    // Robust parsing to handle semicolons inside strings
    for (let i = 0; i < sql.length; i++) {
        const char = sql[i];

        if (char === "'") {
            // Check for escaped quote ('') - simple lookahead
            if (inString && sql[i + 1] === "'") {
                currentStatement += "''";
                i++; // Skip the next quote
                continue;
            }
            inString = !inString;
        }

        if (char === ';' && !inString) {
            statements.push(currentStatement);
            currentStatement = '';
            continue;
        }

        currentStatement += char;
    }

    // Add any trailing statement
    if (currentStatement.trim()) {
        statements.push(currentStatement);
    }

    for (const statement of statements) {
        let trimmed = statement.trim();

        // Skip empty statements
        if (!trimmed) continue;

        // REMOVE COMMENTS - Filter out lines that are purely comments or empty
        // This prevents executing "-- some command" as SQL
        const lines = trimmed.split('\n')
            .map(line => line.trim())
            .filter(line => {
                // Keep the line if it has content and IS NOT a comment
                return line.length > 0 && !line.startsWith('--');
            });

        // Reassemble the SQL code without the comment lines
        const cleanSql = lines.join('\n');

        // If nothing is left (e.g. statement was just comments), skip it
        if (!cleanSql) continue;

        try {
            // Execute the CLEANED sql (without comments)
            // We use 'trimmed' in the prepare if we want to preserve newlines/formatting, 
            // but stripping comments is safer to avoid parsing issues.
            // Using 'cleanSql' is safer.
            await db.prepare(cleanSql).run();
        } catch (err: any) {
            const msg = err.message || '';

            // Silently skip expected errors (idempotency)
            if (
                msg.includes('duplicate column name') ||
                msg.includes('already exists') ||
                msg.includes('UNIQUE constraint failed') ||
                msg.includes('FOREIGN KEY constraint failed')
            ) {
                continue;
            }

            // Log unexpected errors
            console.error(`X [ERROR] [DB Init] Statement failed: ${msg}`, '\n\n  ' + cleanSql.substring(0, 50) + '...\n');
        }
    }
}
