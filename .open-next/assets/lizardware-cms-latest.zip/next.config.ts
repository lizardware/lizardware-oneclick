import type { NextConfig } from "next";
import { execSync } from "child_process";
import { initOpenNextCloudflareForDev } from "@opennextjs/cloudflare";

// Initialize OpenNext Cloudflare for development
initOpenNextCloudflareForDev();

// Generate docs data during build/dev
try {
  console.log('📄 Generating documentation content...');
  execSync('node scripts/generate-docs.js', { stdio: 'inherit' });
} catch (error) {
  console.error('⚠️ Failed to generate documentation content:', error);
}

const nextConfig: NextConfig = {
  /* config options here */
  env: {
    // Inject build-time environment variables into server runtime
    // Required for the Setup Wizard to auto-detect system tokens
    CLOUDFLARE_API_TOKEN: process.env.CLOUDFLARE_API_TOKEN,
    CLOUDFLARE_ACCOUNT_ID: process.env.CLOUDFLARE_ACCOUNT_ID,
    CF_PROJECT_NAME: process.env.CF_PROJECT_NAME,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  serverExternalPackages: ['@opennextjs/cloudflare'],
};

export default nextConfig;
