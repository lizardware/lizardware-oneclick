/**
 * MDX utilities for parsing and serializing blog post frontmatter and content.
 * Phase 1: Basic YAML frontmatter parsing.
 */

export interface BlogFrontmatter {
  title: string;
  slug: string;
  date: string;
  author?: string;
  author_id?: string;
  description?: string;
  tags?: string[];
  draft?: boolean;
  status?: "draft" | "published";
}

/**
 * Parse MDX file: extract frontmatter and content body.
 * Expects format:
 * ---
 * title: "Post Title"
 * slug: "post-slug"
 * date: "2025-01-01"
 * ---
 * # Content here
 */
export function parseMDX(mdxContent: string): {
  frontmatter: BlogFrontmatter;
  body: string;
} {
  const lines = mdxContent.split("\n");

  if (lines[0] !== "---") {
    throw new Error("MDX file must start with --- frontmatter delimiter");
  }

  let endIndex = -1;
  for (let i = 1; i < lines.length; i++) {
    if (lines[i] === "---") {
      endIndex = i;
      break;
    }
  }

  if (endIndex === -1) {
    throw new Error("MDX file must have closing --- frontmatter delimiter");
  }

  const frontmatterLines = lines.slice(1, endIndex);
  const bodyLines = lines.slice(endIndex + 1);

  const frontmatter = parseFrontmatter(frontmatterLines.join("\n"));
  const body = bodyLines.join("\n").trim();

  return { frontmatter, body };
}

/**
 * Simple YAML frontmatter parser (handles basic key: value syntax).
 */
function parseFrontmatter(yamlStr: string): BlogFrontmatter {
  const data: Record<string, unknown> = {};

  const lines = yamlStr.split("\n").filter((line) => line.trim());
  for (const line of lines) {
    const [key, ...valueParts] = line.split(":").map((s) => s.trim());
    const value = valueParts.join(":").trim();

    // Remove quotes
    let parsedValue: unknown = value
      .replace(/^["']|["']$/g, "");

    // Handle arrays
    if (parsedValue?.toString().startsWith("[")) {
      parsedValue = parsedValue
        .toString()
        .replace(/[\[\]]/g, "")
        .split(",")
        .map((s: string) => s.trim());
    }

    // Handle booleans
    if (parsedValue === "true") parsedValue = true;
    if (parsedValue === "false") parsedValue = false;

    data[key] = parsedValue;
  }

  return {
    title: (data.title as string) || "Untitled",
    slug: (data.slug as string) || "",
    date: (data.date as string) || new Date().toISOString().split("T")[0],
    author: (data.author as string) || undefined,
    description: (data.description as string) || undefined,
    tags: (data.tags as string[]) || undefined,
    draft: (data.draft as boolean) || false,
  };
}

/**
 * Serialize frontmatter and body back to MDX.
 */
export function serializeMDX(
  frontmatter: BlogFrontmatter,
  body: string
): string {
  const yamlLines = [
    `title: "${frontmatter.title}"`,
    `slug: "${frontmatter.slug}"`,
    `date: "${frontmatter.date}"`,
  ];

  if (frontmatter.author) {
    yamlLines.push(`author: "${frontmatter.author}"`);
  }
  if (frontmatter.author_id) {
    yamlLines.push(`author_id: "${frontmatter.author_id}"`);
  }
  if (frontmatter.description) {
    yamlLines.push(`description: "${frontmatter.description}"`);
  }
  if (frontmatter.tags && frontmatter.tags.length > 0) {
    yamlLines.push(`tags: [${frontmatter.tags.map((t) => `"${t}"`).join(", ")}]`);
  }
  if (frontmatter.draft) {
    yamlLines.push(`draft: ${frontmatter.draft}`);
  }
  if (frontmatter.status) {
    yamlLines.push(`status: "${frontmatter.status}"`);
  }

  return `---\n${yamlLines.join("\n")}\n---\n\n${body}`;
}
