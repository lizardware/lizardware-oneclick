"use client";

import { ReactNode } from "react";

interface AdminCommandBarProps {
    children: ReactNode;
}

export default function AdminCommandBar({ children }: AdminCommandBarProps) {
    return (
        <div className="fixed bottom-6 inset-x-0 z-50 flex justify-center pointer-events-none">
            <div className="bg-white/80 dark:bg-zinc-900/80 backdrop-blur-xl border border-white/20 dark:border-zinc-700/50 rounded-2xl shadow-2xl p-2 flex items-center gap-2 pointer-events-auto transform transition-all hover:scale-105 hover:shadow-emerald-500/10 ring-1 ring-black/5">
                {children}
            </div>
        </div>
    );
}

export function CommandBarButton({
    onClick,
    disabled,
    variant = 'default',
    label,
    icon
}: {
    onClick?: () => void,
    disabled?: boolean,
    variant?: 'default' | 'primary' | 'danger' | 'secondary' | 'warning',
    label: string,
    icon?: ReactNode
}) {
    const variants = {
        default: "bg-gray-100 dark:bg-zinc-800 text-gray-600 dark:text-zinc-400 hover:bg-gray-200 dark:hover:bg-zinc-700",
        primary: "bg-emerald-500 text-white shadow-lg shadow-emerald-500/30 hover:bg-emerald-600",
        danger: "bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 border border-red-100 dark:border-red-800 hover:bg-red-100 dark:hover:bg-red-900/40",
        secondary: "bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 border border-blue-100 dark:border-blue-800 hover:bg-blue-100 dark:hover:bg-blue-900/40",
        warning: "bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400 border border-amber-100 dark:border-amber-800 hover:bg-amber-100 dark:hover:bg-amber-900/40"
    };

    const disabledStyles = "opacity-50 cursor-not-allowed saturate-0";

    return (
        <button
            onClick={onClick}
            disabled={disabled}
            className={`px-4 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all flex items-center gap-2 ${variants[variant]} ${disabled ? disabledStyles : ''}`}
        >
            {icon}
            {label}
        </button>
    );
}
