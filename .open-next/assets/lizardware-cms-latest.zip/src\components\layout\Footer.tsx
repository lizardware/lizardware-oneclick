import Link from "next/link";

export default function Footer({ siteName, whiteLabel }: { siteName?: string; whiteLabel?: boolean }) {
    return (
        <footer className="bg-footer-background text-footer-text py-8 border-t border-borders mt-auto">
            <div className="max-w-[1024px] mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-6">
                <div className="flex flex-col md:flex-row items-center gap-4">
                    <p className="text-sm">
                        &copy; {new Date().getFullYear()} <span className="text-header-text font-semibold">{siteName || "Lizardware"}</span>. All rights reserved.
                    </p>
                    {(!whiteLabel) && (
                        <div className="flex items-center gap-2 text-xs opacity-60 hover:opacity-100 transition-opacity">
                            <span>Powered by</span>
                            <a
                                href="https://lizardware.io"
                                target="_blank"
                                rel="noopener noreferrer"
                                className="font-bold text-primary hover:underline decoration-primary/30"
                            >
                                Lizardware CMS
                            </a>
                        </div>
                    )}
                </div>
                <div className="flex space-x-6">
                    <FooterLink href="/privacy" label="Privacy Policy" />
                    <FooterLink href="/terms" label="Terms of Service" />
                    <FooterLink href="/support" label="Support" />
                </div>
            </div>
        </footer>
    );
}

function FooterLink({ href, label }: { href: string; label: string }) {
    return (
        <Link href={href} className="text-sm hover:text-primary transition-colors">
            {label}
        </Link>
    );
}
