export default function AboutPage() {
    return (
        <div className="bg-page-background">
            <div className="max-w-4xl mx-auto px-4 py-section space-y-20">
                {/* Mission */}
                <section className="text-center">
                    <h1 className="text-title font-bold mb-8 text-header-text">About Our Platform</h1>
                    <p className="text-subtitle text-page-text leading-relaxed">
                        We believe content management should be fast, secure, and delightful.
                        This platform combines the best of static sites and dynamic CMSs,
                        running on Cloudflare's edge network for unmatched performance.
                    </p>
                </section>

                {/* Why We Built This */}
                <section className="prose prose-lg dark:prose-invert max-w-none">
                    <h2 className="text-subtitle font-bold text-header-text mb-6">Why We Built This</h2>
                    <p>
                        Traditional CMSs are slow, complex, and require constant maintenance.
                        JAMstack sites are fast but lack editing interfaces. We wanted both:
                        the speed of static sites with the convenience of a CMS.
                    </p>
                    <p>
                        Unlike WordPress or traditional CMSs, our system runs entirely on serverless
                        infrastructure. No servers to maintain, no patches to apply, no downtime.
                        Your content is stored in Git and served from the edge.
                    </p>
                </section>

                {/* Philosophy Grid */}
                <section className="bg-slate-50 dark:bg-zinc-800/50 p-container rounded-3xl border border-borders">
                    <h2 className="text-subtitle font-bold mb-10 text-center">Technology Philosophy</h2>
                    <div className="grid md:grid-cols-2 gap-10">
                        <div className="flex gap-4">
                            <div className="text-3xl">🚀</div>
                            <div>
                                <h3 className="text-xl font-bold mb-2">Edge-first</h3>
                                <p className="text-page-text">Deploy to 300+ cities worldwide for near-zero latency.</p>
                            </div>
                        </div>
                        <div className="flex gap-4">
                            <div className="text-3xl">🌿</div>
                            <div>
                                <h3 className="text-xl font-bold mb-2">Git-backed</h3>
                                <p className="text-page-text">Every single change is version controlled and audit-ready.</p>
                            </div>
                        </div>
                        <div className="flex gap-4">
                            <div className="text-3xl">🛡️</div>
                            <div>
                                <h3 className="text-xl font-bold mb-2">Type-safe</h3>
                                <p className="text-page-text">Built with TypeScript and Next.js for industrial-grade stability.</p>
                            </div>
                        </div>
                        <div className="flex gap-4">
                            <div className="text-3xl">🔓</div>
                            <div>
                                <h3 className="text-xl font-bold mb-2">Open</h3>
                                <p className="text-page-text">Deploy anywhere, use standard tools, zero vendor lock-in.</p>
                            </div>
                        </div>
                    </div>
                </section>

                {/* Differentiation */}
                <section className="space-y-8">
                    <h2 className="text-subtitle font-bold text-header-text">What Makes Us Different</h2>
                    <div className="grid md:grid-cols-3 gap-6">
                        <div className="p-container border-l-4 border-primary bg-primary/5 rounded-r-xl">
                            <h3 className="font-bold mb-2">No Databases</h3>
                            <p className="text-body opacity-80">We use D1 at the edge and Git for persistence. No heavy RDS instances.</p>
                        </div>
                        <div className="p-container border-l-4 border-primary bg-primary/5 rounded-r-xl">
                            <h3 className="font-bold mb-2">Instant Previews</h3>
                            <p className="text-body opacity-80">See your content exactly as it will look, globally, before you hit publish.</p>
                        </div>
                        <div className="p-container border-l-4 border-primary bg-primary/5 rounded-r-xl">
                            <h3 className="font-bold mb-2">Scale for Free</h3>
                            <p className="text-body opacity-80">Serverless architecture means you only pay for what you use, often $0.</p>
                        </div>
                    </div>
                </section>

                {/* CTA */}
                <section className="text-center py-section bg-primary text-white rounded-3xl overflow-hidden relative">
                    <div className="relative z-10">
                        <h2 className="text-title font-bold mb-4">Join the Edge Revolution</h2>
                        <p className="text-subtitle mb-8 opacity-90">Experience the future of content management today.</p>
                        <a href="/setup" className="inline-block px-10 py-4 bg-white text-primary rounded-xl font-bold text-lg hover:bg-slate-100 transition">
                            Deploy Your Instance
                        </a>
                    </div>
                    {/* Background accent */}
                    <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-32 -mt-32 blur-3xl"></div>
                    <div className="absolute bottom-0 left-0 w-64 h-64 bg-black/10 rounded-full -ml-32 -mb-32 blur-3xl"></div>
                </section>
            </div>
        </div>
    );
}
