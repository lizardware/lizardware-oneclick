-- Migration 018: Create forum reactions table
-- Version: 0.6.0
-- Purpose: User reactions (likes, helpful, etc.) on posts and threads

CREATE TABLE IF NOT EXISTS forum_reactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id INTEGER, -- Can be NULL if reacting to thread
  thread_id INTEGER, -- Can be NULL if reacting to post
  user_id INTEGER NOT NULL,
  reaction_type TEXT NOT NULL, -- 'like', 'helpful', 'love', 'laugh'
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (post_id) REFERENCES forum_posts(id) ON DELETE CASCADE,
  FOREIGN KEY (thread_id) REFERENCES forum_threads(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES forum_users(id) ON DELETE CASCADE,
  UNIQUE(post_id, user_id, reaction_type),
  UNIQUE(thread_id, user_id, reaction_type),
  CHECK ((post_id IS NOT NULL AND thread_id IS NULL) OR (post_id IS NULL AND thread_id IS NOT NULL))
);

CREATE INDEX idx_forum_reactions_post ON forum_reactions(post_id);
CREATE INDEX idx_forum_reactions_thread ON forum_reactions(thread_id);
CREATE INDEX idx_forum_reactions_user ON forum_reactions(user_id);
CREATE INDEX idx_forum_reactions_type ON forum_reactions(reaction_type);
