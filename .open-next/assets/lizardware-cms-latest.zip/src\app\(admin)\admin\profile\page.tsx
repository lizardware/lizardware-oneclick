'use client';

import { SafeUserProfile } from "@/components/auth/SafeUserProfile";
import { AdminHeader } from "@/components/admin/AdminHeader";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export default function ProfilePage() {
    return (
        <div className="space-y-6">
            <AdminHeader
                title={<>User <span className="text-primary">Profile</span></>}
                description="Manage your account settings and security preferences."
                breadcrumbs={[
                    { label: 'Admin', href: '/admin' },
                    { label: 'Profile' }
                ]}
                badge={
                    <div className="px-3 py-1.5 bg-blue-100 dark:bg-blue-900/30 rounded-lg text-[10px] font-bold uppercase tracking-widest text-blue-600 dark:text-blue-400">Account</div>
                }
                actions={
                    <Link
                        href="/admin"
                        className="px-3 py-1.5 bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 rounded-lg text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
                    >
                        <ArrowLeft size={12} /> Back
                    </Link>
                }
            />

            <div className="rounded-2xl border border-white/20 dark:border-zinc-800/50 bg-white/50 dark:bg-zinc-900/50 backdrop-blur-xl p-1 overflow-hidden">
                <SafeUserProfile
                    appearance={{
                        elements: {
                            rootBox: "w-full",
                            cardBox: "w-full shadow-none border-none bg-transparent",
                            navbar: "hidden lg:flex", // Using Clerk's navbar on desktop
                            scrollBox: "bg-transparent",
                            pageScrollBox: "bg-transparent",
                        }
                    }}
                    routing="path"
                    path="/admin/profile"
                />
            </div>
        </div>
    );
}
