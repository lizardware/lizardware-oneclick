'use client';

import { Globe } from 'lucide-react';

export interface SERPPreviewProps {
    title?: string;
    url?: string;
    description?: string;
    siteName?: string;
}

/**
 * Real-time SERP (Search Engine Results Page) Preview Component
 * Shows how content will appear in Google search results
 */
export function SERPPreview({ title, url, description, siteName = 'yoursite.com' }: SERPPreviewProps) {
    const truncatedTitle = truncateText(title || 'Untitled Page - Add a title to improve SEO', 60);
    const truncatedDescription = truncateText(
        description || 'No meta description yet. Add one to improve click-through rate from search results.',
        160
    );

    // Clean URL for display
    const displayUrl = url ? url.replace(/^\//, '') : 'page-url';

    return (
        <div className="serp-preview bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-lg p-4 shadow-sm">
            <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mb-1">
                <Globe size={12} />
                <span className="font-medium">{siteName}</span>
                <span>›</span>
                <span className="truncate">{displayUrl}</span>
            </div>

            <div className={`text-lg font-medium mb-1 hover:underline cursor-pointer transition-colors ${title ? 'text-blue-600 dark:text-blue-400' : 'text-slate-400 dark:text-slate-600'
                }`}>
                {truncatedTitle}
                {!title && <span className="text-xs ml-2 text-orange-500">⚠️ Missing</span>}
                {title && title.length > 60 && <span className="text-xs ml-2 text-orange-500">✂️ Truncated</span>}
            </div>

            <div className={`text-sm ${description ? 'text-slate-600 dark:text-slate-400' : 'text-slate-400 dark:text-slate-600 italic'
                }`}>
                {truncatedDescription}
                {!description && <span className="text-xs ml-2 text-orange-500">⚠️ Missing</span>}
                {description && description.length > 160 && <span className="text-xs ml-2 text-orange-500">✂️ Truncated</span>}
            </div>

            {/* Character count indicators */}
            <div className="mt-3 pt-3 border-t border-slate-100 dark:border-zinc-800 flex gap-4 text-xs">
                <div className="flex items-center gap-2">
                    <span className="text-slate-500 dark:text-slate-400">Title:</span>
                    <span className={`font-bold ${getCountColor(title?.length || 0, 50, 60)}`}>
                        {title?.length || 0} / 60
                    </span>
                </div>
                <div className="flex items-center gap-2">
                    <span className="text-slate-500 dark:text-slate-400">Description:</span>
                    <span className={`font-bold ${getCountColor(description?.length || 0, 140, 160)}`}>
                        {description?.length || 0} / 160
                    </span>
                </div>
            </div>
        </div>
    );
}

/**
 * Truncate text at specified length with ellipsis
 */
function truncateText(text: string, maxLength: number): string {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
}

/**
 * Get color class based on character count
 */
function getCountColor(count: number, min: number, max: number): string {
    if (count === 0) return 'text-red-500 dark:text-red-400';
    if (count >= min && count <= max) return 'text-green-600 dark:text-green-400';
    if (count < min || (count > max && count <= max + 20)) return 'text-orange-500 dark:text-orange-400';
    return 'text-red-500 dark:text-red-400';
}
