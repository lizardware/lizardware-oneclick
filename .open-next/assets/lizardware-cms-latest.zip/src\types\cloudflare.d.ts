// Type definitions for Cloudflare bindings
import '@opennextjs/cloudflare';

declare module '@opennextjs/cloudflare' {
    interface CloudflareEnv {
        DB: D1Database;
        CONFIG_KV: KVNamespace;
        USE_D1_BLOG?: string;
    }
}
