'use client';

export function AdminLoadingState({ message = "Synchronizing data..." }: { message?: string }) {
    return (
        <div className="space-y-8 animate-in fade-in duration-500">
            {/* Skeleton Header */}
            <div className="bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-3xl p-8 shadow-sm">
                <div className="flex flex-col md:flex-row justify-between items-center gap-6">
                    <div className="space-y-4 w-full md:w-2/3">
                        <div className="h-4 w-32 bg-gray-100 dark:bg-zinc-800 rounded-full animate-pulse"></div>
                        <div className="h-10 w-64 bg-gray-200 dark:bg-zinc-700 rounded-xl animate-pulse"></div>
                        <div className="h-4 w-48 bg-gray-100 dark:bg-zinc-800 rounded-full animate-pulse"></div>
                    </div>
                </div>
            </div>

            {/* Skeleton Content Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3].map((i) => (
                    <div key={i} className="bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-2xl p-6 space-y-4 shadow-sm">
                        <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-gray-100 dark:bg-zinc-800 rounded-xl animate-pulse"></div>
                            <div className="flex-1 space-y-2">
                                <div className="h-4 w-1/2 bg-gray-100 dark:bg-zinc-800 rounded animate-pulse"></div>
                                <div className="h-3 w-3/4 bg-gray-50 dark:bg-zinc-900 rounded animate-pulse"></div>
                            </div>
                        </div>
                        <div className="h-32 w-full bg-gray-50 dark:bg-zinc-950 rounded-xl animate-pulse"></div>
                    </div>
                ))}
            </div>

            {/* Loading Indicator */}
            <div className="flex flex-col items-center justify-center py-12 text-center space-y-4">
                <div className="relative">
                    <div className="w-12 h-12 border-4 border-primary/20 rounded-full"></div>
                    <div className="absolute top-0 left-0 w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                </div>
                <div className="text-xs font-bold uppercase tracking-widest text-gray-400 animate-pulse">
                    {message}
                </div>
            </div>
        </div>
    );
}
