'use client';

import { useState, useEffect, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { usePopup } from '@/components/admin/AdminPopupProvider';
import { NavItem, NavConfig } from '@/types/nav';
import { Plus, Trash2, Edit2, X, ArrowUp, ArrowDown, GripVertical, ArrowLeft, Save, RotateCcw, Compass } from 'lucide-react';
import Header from "@/components/layout/Header";
import { enrichNavigation } from "@/lib/navigation";
import AdminCommandBar, { CommandBarButton } from "@/components/admin/AdminCommandBar";
import { Breadcrumbs } from "@/components/admin/Breadcrumbs";
import { AdminLoadingState } from "@/components/admin/AdminLoadingState";
import NavSyncIntelligence, { Suggestion } from "@/components/admin/NavSyncIntelligence";
import { RoutePicker } from '@/components/admin/RoutePicker';
import { AdminHeader } from '@/components/admin/AdminHeader';
import { useMemo } from 'react';
import {
    DndContext,
    closestCenter,
    KeyboardSensor,
    PointerSensor,
    useSensor,
    useSensors,
    DragOverlay,
    DragEndEvent,
    DragStartEvent
} from '@dnd-kit/core';
import {
    arrayMove,
    SortableContext,
    sortableKeyboardCoordinates,
    verticalListSortingStrategy,
    useSortable
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

export default function NavEditorPage() {
    const [config, setConfig] = useState<NavConfig | null>(null);
    const [savedConfig, setSavedConfig] = useState<NavConfig | null>(null);
    const [loading, setLoading] = useState(true);
    const [isSaveModalOpen, setIsSaveModalOpen] = useState(false);
    const [isRevertModalOpen, setIsRevertModalOpen] = useState(false);
    const [isPropagating, setIsPropagating] = useState(false);
    const [editingItem, setEditingItem] = useState<{ parentId: string | null; item: NavItem } | null>(null);
    const [activeId, setActiveId] = useState<string | null>(null);
    const [mounted, setMounted] = useState(false);

    const router = useRouter();
    const popup = usePopup();

    const sensors = useSensors(
        useSensor(PointerSensor, {
            activationConstraint: {
                distance: 8,
            },
        }),
        useSensor(KeyboardSensor, {
            coordinateGetter: sortableKeyboardCoordinates,
        })
    );


    const existingHrefs = useMemo(() => {
        const hrefs = new Set<string>();
        if (!config) return hrefs;
        const flatten = (items: NavItem[]) => {
            items.forEach(item => {
                if (item.href) hrefs.add(item.href);
                if (item.children) flatten(item.children);
            });
        };
        flatten(config.navigation);
        return hrefs;
    }, [config]);

    // Sensors moved to top (already there)

    useEffect(() => {
        setMounted(true);
    }, []);

    useEffect(() => {
        fetch('/api/admin/nav')
            .then((res) => res.json() as Promise<NavConfig>)
            .then((data) => {
                setConfig(data);
                setSavedConfig(data);
                setLoading(false);
            })
            .catch((err) => {
                console.error('Error fetching nav:', err);
                setLoading(false);
            });
    }, []);

    const handleSaveConfirm = async () => {
        if (!config) return;
        try {
            const res = await fetch('/api/admin/nav', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(config)
            });
            if (res.ok) {
                setSavedConfig(JSON.parse(JSON.stringify(config)));
                setIsPropagating(true);
                setTimeout(() => setIsPropagating(false), 3000);
                popup.success('Navigation hub updated globally.');
                router.refresh();
            } else {
                popup.error('Failed to save navigation.');
            }
        } catch (err) {
            console.error(err);
            popup.error('Error saving navigation.');
        }
    };

    const handleRevertConfirm = useCallback(() => {
        if (savedConfig) {
            setConfig(JSON.parse(JSON.stringify(savedConfig)));
        }
    }, [savedConfig]);

    const addItem = (parentId: string | null = null) => {
        const newItem: NavItem = {
            id: `item-${Date.now()}`,
            label: 'New Item',
            href: '/',
            children: []
        };

        if (!config) return;

        const newConfig = JSON.parse(JSON.stringify(config));
        if (parentId === null) {
            newConfig.navigation.push(newItem);
        } else {
            const findAndAdd = (items: NavItem[]): boolean => {
                for (const item of items) {
                    if (item.id === parentId) {
                        if (!item.children) item.children = [];
                        item.children.push(newItem);
                        return true;
                    }
                    if (item.children && findAndAdd(item.children)) return true;
                }
                return false;
            };
            findAndAdd(newConfig.navigation);
        }
        setConfig(newConfig);
        setEditingItem({ parentId, item: newItem });
    };

    const removeItem = (id: string, parentId: string | null = null) => {
        if (!config) return;
        const newConfig = JSON.parse(JSON.stringify(config));

        const findAndRemove = (items: NavItem[]): NavItem[] => {
            return items.filter(item => {
                if (item.id === id) return false;
                if (item.children) {
                    item.children = findAndRemove(item.children);
                }
                return true;
            });
        };

        newConfig.navigation = findAndRemove(newConfig.navigation);
        setConfig(newConfig);
        if (editingItem?.item.id === id) setEditingItem(null);
    };

    const updateItem = (id: string, updates: Partial<NavItem>, parentId: string | null = null) => {
        if (!config) return;
        const newConfig = JSON.parse(JSON.stringify(config));

        const findAndUpdate = (items: NavItem[]): boolean => {
            for (const item of items) {
                if (item.id === id) {
                    Object.assign(item, updates);
                    return true;
                }
                if (item.children && findAndUpdate(item.children)) return true;
            }
            return false;
        };

        findAndUpdate(newConfig.navigation);
        setConfig(newConfig);
    };

    const moveItem = (id: string, direction: 'up' | 'down') => {
        // ... (existing implementation)
    };

    const handleDragStart = (event: DragStartEvent) => {
        setActiveId(event.active.id as string);
    };

    const handleDragEnd = (event: DragEndEvent) => {
        const { active, over } = event;
        setActiveId(null);

        if (!over || active.id === over.id || !config) return;

        const newConfig = JSON.parse(JSON.stringify(config));

        // Helper to find parent array and index
        const findItemContainer = (items: NavItem[], id: string): { container: NavItem[], index: number } | null => {
            const index = items.findIndex(i => i.id === id);
            if (index !== -1) return { container: items, index };

            for (const item of items) {
                if (item.children) {
                    const result = findItemContainer(item.children, id);
                    if (result) return result;
                }
            }
            return null;
        };

        const activeResult = findItemContainer(newConfig.navigation, active.id as string);
        const overResult = findItemContainer(newConfig.navigation, over.id as string);

        if (activeResult && overResult && activeResult.container === overResult.container) {
            // Reordering within the same container
            const container = activeResult.container;
            const oldIndex = activeResult.index;
            const newIndex = overResult.index;

            // Apply the move
            const newItems = arrayMove(container, oldIndex, newIndex);

            if (activeResult.container === newConfig.navigation) {
                newConfig.navigation = newItems;
            } else {
                const updateContainer = (items: NavItem[]) => {
                    if (items === activeResult.container) {
                        newConfig.navigation = newItems;
                        return true;
                    }
                    for (const item of items) {
                        if (item.children === activeResult.container) {
                            item.children = newItems;
                            return true;
                        }
                        if (item.children && updateContainer(item.children)) return true;
                    }
                    return false;
                };
                updateContainer(newConfig.navigation);
            }

            setConfig(newConfig);
        }
    };

    if (loading) return (
        <div className="max-w-7xl mx-auto px-6 pt-4 pb-12 space-y-8">
            <AdminLoadingState message="Mapping orbital coordinates..." />
        </div>
    );
    if (!config) return <div className="p-8 text-center text-red-500 font-bold">Failed to establish comms with Nav API.</div>;

    const hasChanges = JSON.stringify(config) !== JSON.stringify(savedConfig);



    const handleAddSuggestion = (suggestion: Suggestion) => {
        const newItem: NavItem = {
            id: `item-${Date.now()}`,
            label: suggestion.nav_label || suggestion.title,
            href: suggestion.href,
            children: []
        };

        if (!config) return;

        const newConfig = JSON.parse(JSON.stringify(config));
        let added = false;

        if (suggestion.nav_parent) {
            const parentLabel = suggestion.nav_parent.toLowerCase();
            const findAndAdd = (items: NavItem[]): boolean => {
                for (const item of items) {
                    if (item.id === suggestion.nav_parent || item.label.toLowerCase().includes(parentLabel)) {
                        if (!item.children) item.children = [];
                        item.children.push(newItem);
                        return true;
                    }
                    if (item.children && findAndAdd(item.children)) return true;
                }
                return false;
            };
            added = findAndAdd(newConfig.navigation);
        }

        if (!added) {
            newConfig.navigation.push(newItem);
        }

        setConfig(newConfig);
        popup.success(`Successfully added "${newItem.label}" logic to the navigation stack.`);
    };

    return (
        <div className="bg-site-background text-page-text">
            <div className="max-w-7xl mx-auto px-6 pt-0 space-y-6">

                <AdminHeader
                    title={<>Nifty <span className="text-emerald-500">Navigation</span></>}
                    description="Standardize your orbital path and menu structure across the global edge."
                    breadcrumbs={[
                        { label: 'Admin', href: '/admin' },
                        { label: 'Design', href: '/admin/design' },
                        { label: 'Navigation' }
                    ]}
                    badge={
                        <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-gray-400">
                            <div className="relative flex items-center justify-center w-2 h-2">
                                <span className={`absolute inline-flex h-full w-full rounded-full opacity-75 animate-ping ${isPropagating ? 'bg-blue-500' : hasChanges ? 'bg-amber-500' : 'bg-emerald-500'}`}></span>
                                <span className={`relative inline-flex rounded-full h-1.5 w-1.5 ${isPropagating ? 'bg-blue-500' : hasChanges ? 'bg-amber-500' : 'bg-emerald-500'}`}></span>
                            </div>
                            {isPropagating ? 'Propagating...' : hasChanges ? 'Unsaved Edits Detected' : 'All Routes Synced'}
                        </div>
                    }
                    actions={
                        <Link
                            href="/admin/design"
                            className="px-3 py-1.5 bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 rounded-lg text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
                        >
                            <ArrowLeft size={12} /> Back
                        </Link>
                    }
                />

                {/* Preview Theater */}
                <div className="space-y-4">
                    <div className="flex items-center justify-between px-2">
                        <h3 className="text-xs font-bold uppercase tracking-[0.2em] text-gray-400 flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                            Real-time Preview Theater
                        </h3>
                        <span className="text-[10px] text-gray-400 italic">This is how your menu looks live</span>
                    </div>
                    <div className="bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-[2rem] shadow-xl relative z-[60]">
                        <div className="scale-95 origin-top transform transition-all p-4">
                            <Header customItems={enrichNavigation(config.navigation)} isPreview={true} />
                        </div>
                    </div>
                </div>

                <div className="grid lg:grid-cols-3 gap-gap">
                    {/* Left: Structure Editor */}
                    <div className="lg:col-span-2 space-y-gap">
                        <div className="bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-3xl p-container shadow-xl overflow-hidden relative">
                            <div className="flex items-center justify-between mb-6">
                                <h2 className="text-xl font-extrabold text-page-title tracking-tight">Menu Structure</h2>
                                <button
                                    onClick={() => addItem(null)}
                                    className="px-4 py-2 bg-emerald-500 text-white rounded-xl text-[10px] font-bold uppercase tracking-widest shadow-lg shadow-emerald-500/20 hover:brightness-110 transition-all flex items-center gap-2"
                                >
                                    <Plus size={12} /> Add Master
                                </button>
                            </div>

                            <DndContext
                                sensors={sensors}
                                collisionDetection={closestCenter}
                                onDragStart={handleDragStart}
                                onDragEnd={handleDragEnd}
                            >
                                <div className="space-y-1.5">
                                    {(() => {
                                        const renderItems = (items: NavItem[], parentId: string | null = null, level: number = 0) => {
                                            return (
                                                <SortableContext
                                                    items={items.map(item => item.id)}
                                                    strategy={verticalListSortingStrategy}
                                                >
                                                    <div className={level > 0 ? "ml-4 space-y-1 border-l-2 border-gray-100 dark:border-zinc-800 pl-4 mt-1" : "space-y-1.5"}>
                                                        {items.map((item) => (
                                                            <SortableNavItem
                                                                key={item.id}
                                                                item={item}
                                                                level={level}
                                                                onEdit={() => setEditingItem({ parentId, item })}
                                                                onRemove={() => removeItem(item.id)}
                                                                onAddChild={() => addItem(item.id)}
                                                            >
                                                                {item.children && item.children.length > 0 &&
                                                                    renderItems(item.children, item.id, level + 1)
                                                                }
                                                            </SortableNavItem>
                                                        ))}
                                                    </div>
                                                </SortableContext>
                                            );
                                        };
                                        return renderItems(config.navigation);
                                    })()}

                                    <DragOverlay>
                                        {activeId ? (
                                            <div className="opacity-90 rotate-2 scale-105 cursor-grabbing">
                                                {(() => {
                                                    const findItem = (items: NavItem[]): NavItem | undefined => {
                                                        for (const item of items) {
                                                            if (item.id === activeId) return item;
                                                            if (item.children) {
                                                                const found = findItem(item.children);
                                                                if (found) return found;
                                                            }
                                                        }
                                                    };
                                                    const item = findItem(config.navigation);
                                                    if (!item) return null;
                                                    return <NavItemRow item={item} onEdit={() => { }} onRemove={() => { }} />;
                                                })()}
                                            </div>
                                        ) : null}
                                    </DragOverlay>
                                </div>
                            </DndContext>
                        </div>

                        {/* Hint Box */}
                        <div className="bg-zinc-900 text-zinc-400 p-6 rounded-3xl border border-zinc-800 flex items-start gap-4">
                            <div className="w-10 h-10 rounded-xl bg-zinc-800 flex items-center justify-center text-xl flex-shrink-0 shadow-lg">
                                🧠
                            </div>
                            <div>
                                <h3 className="font-bold text-zinc-100 mb-1 text-[10px] uppercase tracking-widest">Architect's Note</h3>
                                <p className="text-[11px] leading-relaxed max-w-2xl opacity-60">
                                    Navigation is the nervous system of your site. Use the <strong className="text-blue-400">blue grab handles</strong> on the left to drag and reorder items. Changes propagate globally in &lt;30s. Keep master routes to a minimum (4-6).
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* Right: Tactics & Meta */}
                    <div className="space-y-gap">
                        <div className="bg-emerald-600 p-6 rounded-3xl text-white shadow-xl shadow-emerald-600/20 relative overflow-hidden">
                            <div className="relative z-10">
                                <h3 className="font-black text-lg mb-2 flex items-center gap-2">
                                    <span>🛡️</span> Protected
                                </h3>
                                <p className="text-[11px] text-white/80 mb-4 leading-relaxed">
                                    Routes like <span className="font-bold">/features</span> are managed dynamically and cannot be deleted.
                                </p>
                                <div className="p-3 bg-white/10 backdrop-blur-md rounded-xl border border-white/20">
                                    <div className="flex items-center gap-3">
                                        <span className="text-lg">🔥</span>
                                        <div>
                                            <div className="text-[9px] font-bold text-emerald-200 uppercase tracking-widest">Active Dynamic</div>
                                            <div className="text-[11px] font-bold">Services Engine</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 blur-2xl"></div>
                        </div>

                        <div className="bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-3xl p-6 shadow-sm space-y-4">
                            <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Nav Health</h4>
                            <div className="space-y-3">
                                <div className="flex justify-between items-center text-xs">
                                    <span className="text-gray-500 font-medium">Link Integrity</span>
                                    <span className="px-2 py-0.5 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-500 rounded-full text-[9px] font-bold uppercase">Optimal</span>
                                </div>
                                <div className="flex justify-between items-center text-xs">
                                    <span className="text-gray-500 font-medium">Edge Status</span>
                                    <span className="px-2 py-0.5 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-500 rounded-full text-[9px] font-bold uppercase">Verified</span>
                                </div>
                            </div>
                        </div>

                        {/* Sync Intelligence Integration */}
                        <NavSyncIntelligence
                            existingHrefs={existingHrefs}
                            onAdd={handleAddSuggestion}
                        />
                    </div>
                </div>
            </div>

            {/* Edit Modal */}
            {editingItem && (
                <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-300">
                    <div className="bg-white dark:bg-zinc-900 w-full max-w-md rounded-[2.5rem] shadow-2xl border border-white/20 overflow-hidden animate-in slide-in-from-bottom-8 duration-500">
                        <div className="p-8 border-b border-slate-100 dark:border-zinc-800 flex justify-between items-center bg-gray-50/50 dark:bg-zinc-950/50">
                            <div>
                                <h3 className="font-black text-xl text-page-title">Edit Route</h3>
                                <div className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest mt-1">Route Configuration</div>
                            </div>
                            <button onClick={() => setEditingItem(null)} className="p-2 bg-white dark:bg-zinc-800 rounded-full shadow-sm hover:scale-110 transition-transform">
                                <X size={20} />
                            </button>
                        </div>
                        <div className="p-8 space-y-6">
                            <div className="space-y-2">
                                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Label</label>
                                <input
                                    type="text"
                                    value={editingItem.item.label}
                                    onChange={(e) => updateItem(editingItem.item.id, { label: e.target.value })}
                                    className="w-full px-5 py-3 border border-slate-200 dark:border-zinc-800 rounded-2xl bg-white dark:bg-zinc-950 text-page-text focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all font-bold"
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Target Path</label>
                                <RoutePicker
                                    value={editingItem.item.href}
                                    onChange={(value) => updateItem(editingItem.item.id, { href: value })}
                                    placeholder="/your-path"
                                />
                            </div>
                        </div>
                        <div className="p-8 bg-gray-50/50 dark:bg-zinc-950/50 border-t border-slate-100 dark:border-zinc-800 flex justify-end gap-3">
                            <button
                                onClick={() => setEditingItem(null)}
                                className="px-8 py-3 bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl hover:scale-105 active:scale-95 transition-all"
                            >
                                Confirm Updates
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Admin Actions Portal */}
            {mounted && (() => {
                const portalTarget = document.getElementById('admin-actions-portal');
                if (!portalTarget) return null;

                return createPortal(
                    <div className="flex items-center gap-2 pointer-events-auto">
                        <CommandBarButton
                            onClick={async () => {
                                const confirmed = await popup.confirm('Are you sure you want to revert to the live production menu? All unsaved orbital coordinates will be lost.', { isDanger: true });
                                if (confirmed) handleRevertConfirm();
                            }}
                            disabled={!hasChanges || isPropagating}
                            label="Revert"
                            variant="danger"
                            icon={<RotateCcw size={14} />}
                        />
                        <div className="w-px h-6 bg-gray-300 dark:bg-zinc-700 mx-1"></div>
                        <CommandBarButton
                            onClick={async () => {
                                const confirmed = await popup.confirm('This will update the global navigation across all edge regions immediately. Proceed with deployment?');
                                if (confirmed) await handleSaveConfirm();
                            }}
                            disabled={!hasChanges || isPropagating}
                            label={isPropagating ? "Deploying..." : "Publish Nav"}
                            variant={hasChanges ? 'primary' : 'default'}
                            icon={<Save size={14} />}
                        />
                    </div>,
                    portalTarget
                );
            })()}

        </div>
    );
}


function SortableNavItem({
    item,
    onEdit,
    onRemove,
    onAddChild,
    level = 0,
    children
}: {
    item: NavItem;
    onEdit: () => void;
    onRemove: () => void;
    onAddChild?: () => void;
    level?: number;
    children?: React.ReactNode;
}) {
    const {
        attributes,
        listeners,
        setNodeRef,
        transform,
        transition,
        isDragging
    } = useSortable({ id: item.id });

    const style = {
        transform: CSS.Translate.toString(transform),
        transition,
        opacity: isDragging ? 0.3 : 1,
        zIndex: isDragging ? 50 : 0
    };

    return (
        <div ref={setNodeRef} style={style} className="space-y-2">
            <NavItemRow
                item={item}
                onEdit={onEdit}
                onRemove={onRemove}
                onAddChild={onAddChild}
                level={level}
                dragHandleProps={{ ...attributes, ...listeners }}
            />
            {children}
        </div>
    );
}

function NavItemRow({
    item,
    onEdit,
    onRemove,
    onAddChild,
    level = 0,
    dragHandleProps
}: {
    item: NavItem;
    onEdit: () => void;
    onRemove: () => void;
    onAddChild?: () => void;
    level?: number;
    dragHandleProps?: any;
}) {
    const isProtected = item.id === 'services' || item.id === 'features' || item.id === 'blog' || item.id === 'about';

    return (
        <div className={`group flex items-center justify-between py-3 px-5 rounded-2xl border transition-all duration-300 ${isProtected
            ? 'bg-amber-50/50 dark:bg-amber-500/5 border-amber-200/50 dark:border-amber-500/20'
            : 'bg-white dark:bg-zinc-900 border-zinc-100 dark:border-zinc-800 hover:border-emerald-500/30 hover:shadow-lg'
            }`}>
            <div className="flex items-center gap-4">
                <div
                    className="text-zinc-300 dark:text-zinc-700 w-6 h-6 flex items-center justify-center cursor-grab active:cursor-grabbing hover:text-emerald-500 transition-colors"
                    {...dragHandleProps}
                >
                    <GripVertical size={18} />
                </div>

                {item.icon && (
                    <div className="w-10 h-10 bg-gray-50 dark:bg-zinc-800 rounded-xl flex items-center justify-center text-lg shadow-inner group-hover:scale-110 transition-transform">
                        {item.icon}
                    </div>
                )}

                <div className="min-w-0">
                    <div className="font-black text-page-title text-sm flex items-center gap-2 truncate">
                        {item.label}
                        {isProtected && (
                            <span className="text-[7px] bg-amber-500 text-white px-2 py-0.5 rounded-full uppercase font-black tracking-tighter shadow-sm">
                                Core Guard
                            </span>
                        )}
                    </div>
                    <div className="text-[10px] text-zinc-400 font-mono tracking-tighter truncate opacity-70">
                        {item.href}
                    </div>
                </div>
            </div>

            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all transform translate-x-2 group-hover:translate-x-0">
                {onAddChild && !isProtected && level < 1 && (
                    <button
                        onClick={onAddChild}
                        className="p-2 text-zinc-400 hover:text-emerald-500 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 rounded-xl transition-all"
                    >
                        <Plus size={16} />
                    </button>
                )}
                <button
                    onClick={onEdit}
                    className="p-2 text-zinc-400 hover:text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-xl transition-all"
                >
                    <Edit2 size={16} />
                </button>
                {!isProtected && (
                    <button
                        onClick={onRemove}
                        className="p-2 text-zinc-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition-all"
                    >
                        <Trash2 size={16} />
                    </button>
                )}
            </div>
        </div>
    );
}
