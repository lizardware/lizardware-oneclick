import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { verifyToken } from '@/lib/auth-local';

export async function GET() {
    const cookieStore = await cookies();
    const token = cookieStore.get('lizard_session')?.value;

    if (!token) {
        return NextResponse.json({ user: null }, { status: 401 });
    }

    const user = verifyToken(token);
    if (!user) {
        return NextResponse.json({ user: null }, { status: 401 });
    }

    // Return user info sans sensitive data (token already contains minimal info)
    return NextResponse.json({
        user: {
            id: user.id,
            username: user.username,
            role: user.role
        }
    });
}
