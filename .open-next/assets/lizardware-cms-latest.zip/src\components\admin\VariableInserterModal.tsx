'use client';

import { useState, useEffect, useRef } from 'react';
import { getAllVariables, getCategories, type Variable } from '@/lib/variables';
import { Search, X } from 'lucide-react';

interface VariableInserterModalProps {
    isOpen: boolean;
    onClose: () => void;
    onInsert: (variableName: string) => void;
}

export default function VariableInserterModal({
    isOpen,
    onClose,
    onInsert
}: VariableInserterModalProps) {
    const [search, setSearch] = useState('');
    const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
    const [selectedIndex, setSelectedIndex] = useState(0);
    const modalRef = useRef<HTMLDivElement>(null);
    const searchRef = useRef<HTMLInputElement>(null);

    const variables = getAllVariables();
    const categories = getCategories();

    const filtered = variables.filter(v => {
        const matchesSearch =
            v.label.toLowerCase().includes(search.toLowerCase()) ||
            v.description.toLowerCase().includes(search.toLowerCase()) ||
            v.key.toLowerCase().includes(search.toLowerCase());
        const matchesCategory = !selectedCategory || v.category === selectedCategory;
        return matchesSearch && matchesCategory;
    });

    // Focus management and keyboard navigation
    useEffect(() => {
        if (isOpen) {
            searchRef.current?.focus();

            const handleKeyDown = (e: KeyboardEvent) => {
                if (e.key === 'Escape') {
                    e.preventDefault();
                    onClose();
                } else if (e.key === 'ArrowDown') {
                    e.preventDefault();
                    setSelectedIndex(i => Math.min(i + 1, filtered.length - 1));
                } else if (e.key === 'ArrowUp') {
                    e.preventDefault();
                    setSelectedIndex(i => Math.max(i - 1, 0));
                } else if (e.key === 'Enter' && filtered.length > 0) {
                    e.preventDefault();
                    const variable = filtered[selectedIndex];
                    onInsert(variable.key);
                    onClose();
                }
            };

            document.addEventListener('keydown', handleKeyDown);
            return () => document.removeEventListener('keydown', handleKeyDown);
        } else {
            // Reset state when closed
            setSearch('');
            setSelectedCategory(null);
            setSelectedIndex(0);
        }
    }, [isOpen, filtered, selectedIndex, onInsert, onClose]);

    if (!isOpen) return null;

    return (
        <div
            className="fixed inset-0 z-[200] flex items-center justify-center bg-black/50 backdrop-blur-sm"
            onClick={onClose}
            role="dialog"
            aria-modal="true"
            aria-labelledby="variable-modal-title"
        >
            <div
                ref={modalRef}
                className="bg-white dark:bg-zinc-900 rounded-xl shadow-xl w-full max-w-lg max-h-[70vh] flex flex-col mx-4"
                onClick={e => e.stopPropagation()}
            >
                {/* Header */}
                <div className="p-4 border-b border-gray-200 dark:border-zinc-800">
                    <div className="flex items-center justify-between mb-3">
                        <h2 id="variable-modal-title" className="text-lg font-bold">
                            Insert Variable
                        </h2>
                        <button
                            onClick={onClose}
                            className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-lg transition-colors"
                            aria-label="Close modal"
                        >
                            <X size={20} />
                        </button>
                    </div>

                    {/* Search */}
                    <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                        <input
                            ref={searchRef}
                            type="text"
                            value={search}
                            onChange={e => setSearch(e.target.value)}
                            placeholder="Search variables..."
                            className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-zinc-700 rounded-lg bg-white dark:bg-zinc-800 focus:outline-none focus:ring-2 focus:ring-purple-500"
                            aria-label="Search variables"
                        />
                    </div>

                    {/* Category Filter */}
                    <div className="flex gap-2 mt-3 flex-wrap">
                        <button
                            onClick={() => setSelectedCategory(null)}
                            className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${!selectedCategory
                                ? 'bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300'
                                : 'bg-gray-100 dark:bg-zinc-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-zinc-700'
                                }`}
                        >
                            All ({variables.length})
                        </button>
                        {categories.map(cat => {
                            const count = variables.filter(v => v.category === cat).length;
                            return (
                                <button
                                    key={cat}
                                    onClick={() => setSelectedCategory(cat)}
                                    className={`px-3 py-1 rounded-full text-xs font-medium transition-colors capitalize ${selectedCategory === cat
                                        ? 'bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300'
                                        : 'bg-gray-100 dark:bg-zinc-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-zinc-700'
                                        }`}
                                >
                                    {cat} ({count})
                                </button>
                            );
                        })}
                    </div>
                </div>

                {/* Variable List */}
                <div className="flex-1 overflow-y-auto p-4">
                    {filtered.length === 0 ? (
                        <div className="text-center py-12 text-gray-400">
                            <Search size={48} className="mx-auto mb-4 opacity-20" />
                            <p className="text-sm">No variables found matching "{search}"</p>
                        </div>
                    ) : (
                        <div className="space-y-2">
                            {filtered.map((variable, index) => (
                                <button
                                    key={variable.key}
                                    onClick={() => {
                                        onInsert(variable.key);
                                        onClose();
                                    }}
                                    onMouseEnter={() => setSelectedIndex(index)}
                                    className={`w-full text-left p-2.5 rounded-lg transition-all ${index === selectedIndex
                                        ? 'bg-purple-50 dark:bg-purple-900/20 border-2 border-purple-200 dark:border-purple-800 shadow-sm'
                                        : 'hover:bg-gray-50 dark:hover:bg-zinc-800 border-2 border-transparent'
                                        }`}
                                >
                                    <div className="flex items-start gap-2.5">
                                        <span className="text-xl flex-shrink-0">{variable.icon}</span>
                                        <div className="flex-1 min-w-0">
                                            <div className="font-semibold text-xs flex items-center gap-2">
                                                {variable.label}
                                                <span className="text-[10px] px-1.5 py-0.5 bg-gray-100 dark:bg-zinc-800 text-gray-500 dark:text-gray-400 rounded-full capitalize">
                                                    {variable.category}
                                                </span>
                                            </div>
                                            <div className="text-[11px] text-gray-500 dark:text-gray-400 mt-0.5">
                                                {variable.description}
                                            </div>
                                            <div className="mt-1.5 flex items-center gap-2 text-[10px]">
                                                <code className="px-1.5 py-0.5 bg-gray-100 dark:bg-zinc-800 rounded font-mono text-purple-600 dark:text-purple-400">
                                                    {`{{${variable.key}}}`}
                                                </code>
                                                <span className="text-gray-400">→</span>
                                                <span className="text-gray-600 dark:text-gray-300 italic">
                                                    "{variable.example}"
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </button>
                            ))}
                        </div>
                    )}
                </div>

                {/* Footer Hint */}
                <div className="px-4 py-2 border-t border-gray-200 dark:border-zinc-800 bg-gray-50 dark:bg-zinc-900/50 text-[10px] text-gray-500 dark:text-gray-400 flex items-center justify-between rounded-b-xl">
                    <div className="flex items-center gap-4">
                        <span>↑↓ Navigate</span>
                        <span>↵ Select</span>
                        <span>Esc Close</span>
                    </div>
                    <div>
                        {filtered.length} variable{filtered.length !== 1 ? 's' : ''}
                    </div>
                </div>
            </div>
        </div>
    );
}
