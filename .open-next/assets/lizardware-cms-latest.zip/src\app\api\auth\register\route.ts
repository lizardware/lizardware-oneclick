import { NextRequest, NextResponse } from 'next/server';
import { hashPassword, validateUsername, validateEmail, validatePassword, sanitizeUser, generateToken } from '@/lib/auth';
import { getD1Database } from '@/lib/cloudflare';

export async function POST(request: NextRequest) {
    try {
        const { username, email, password, displayName }: {
            username: string;
            email: string;
            password: string;
            displayName?: string;
        } = await request.json();

        // Validate inputs
        const usernameValidation = validateUsername(username);
        if (!usernameValidation.valid) {
            return NextResponse.json({ error: usernameValidation.error }, { status: 400 });
        }

        const emailValidation = validateEmail(email);
        if (!emailValidation.valid) {
            return NextResponse.json({ error: emailValidation.error }, { status: 400 });
        }

        const passwordValidation = validatePassword(password);
        if (!passwordValidation.valid) {
            return NextResponse.json({ error: passwordValidation.error }, { status: 400 });
        }

        // Get database
        const db = await getD1Database();
        if (!db) {
            return NextResponse.json({ error: 'Database unavailable' }, { status: 500 });
        }

        // Check if username already exists
        const existingUsername = await db.prepare(
            'SELECT id FROM forum_users WHERE username = ?'
        ).bind(username).first();

        if (existingUsername) {
            return NextResponse.json({ error: 'Username already taken' }, { status: 409 });
        }

        // Check if email already exists
        const existingEmail = await db.prepare(
            'SELECT id FROM forum_users WHERE email = ?'
        ).bind(email).first();

        if (existingEmail) {
            return NextResponse.json({ error: 'Email already registered' }, { status: 409 });
        }

        // Hash password
        const passwordHash = await hashPassword(password);

        // Insert new user
        const result = await db.prepare(`
      INSERT INTO forum_users (username, email, password_hash, display_name, reputation)
      VALUES (?, ?, ?, ?, 0)
    `).bind(username, email, passwordHash, displayName || username).run();

        // Fetch the created user
        const newUser = await db.prepare(
            'SELECT * FROM forum_users WHERE id = ?'
        ).bind(result.meta.last_row_id).first();

        if (!newUser) {
            return NextResponse.json({ error: 'Failed to create user' }, { status: 500 });
        }

        // Generate JWT token
        const token = generateToken(newUser as any);

        // Set cookie
        const response = NextResponse.json({
            success: true,
            user: sanitizeUser(newUser as any),
            token,
        }, { status: 201 });

        response.cookies.set('forum_token', token, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'lax',
            maxAge: 60 * 60 * 24 * 7, // 7 days
            path: '/',
        });

        return response;

    } catch (error) {
        console.error('Registration error:', error);
        return NextResponse.json({ error: 'Registration failed' }, { status: 500 });
    }
}
