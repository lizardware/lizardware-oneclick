'use client';

import { usePathname, useSearchParams } from 'next/navigation';
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { ThemePreferenceModal } from "@/components/ui/ThemePreferenceModal";
import { SiteConfig } from '@/types/site-config';
import { EnvironmentBanner } from "@/components/layout/EnvironmentBanner";
import { Suspense } from 'react';

function AdminHeaderHiderContent({ children, siteConfig }: { children: React.ReactNode, siteConfig: SiteConfig }) {
    const pathname = usePathname();
    const isAdmin = pathname?.startsWith('/admin');
    const isSetup = pathname === '/setup' || pathname?.startsWith('/setup/');

    if (isAdmin) {
        return <>{children}</>;
    }

    if (isSetup) {
        return (
            <div className="flex flex-col min-h-screen bg-site-background text-page-text transition-colors duration-300">
                <div className="sticky top-0 z-50 shadow-sm bg-site-background">
                    <EnvironmentBanner position="top" />
                </div>
                <main className="flex-grow">
                    {children}
                </main>
                <EnvironmentBanner position="bottom" />
                <ThemePreferenceModal />
            </div>
        );
    }

    return (
        <div className="flex flex-col min-h-screen bg-site-background text-page-text transition-colors duration-300">
            <div className="sticky top-0 z-50 shadow-sm bg-site-background">
                <EnvironmentBanner position="top" />
                <Header siteName={siteConfig.name} logoUrl={siteConfig.logoUrl} />
            </div>
            <main className="flex-grow">
                {children}
            </main>
            <Footer siteName={siteConfig.name} whiteLabel={siteConfig.whiteLabel} />
            <ThemePreferenceModal />
        </div>
    );
}

export function AdminHeaderHider(props: { children: React.ReactNode, siteConfig: SiteConfig }) {
    return (
        <Suspense fallback={null}>
            <AdminHeaderHiderContent {...props} />
        </Suspense>
    );
}
