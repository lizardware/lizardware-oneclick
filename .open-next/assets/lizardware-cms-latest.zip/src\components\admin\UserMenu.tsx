'use client';

import { SafeUserButton } from "@/components/auth/SafeUserButton";
import { useAuth } from "@/context/AuthContext";
import { Shield } from "lucide-react";

type UserRole = 'owner' | 'admin' | 'editor' | 'viewer';

function getRoleDisplay(role: string | null | undefined): { label: string; color: string } {
    const roleMap: Record<string, { label: string; color: string }> = {
        owner: { label: 'Owner', color: 'text-purple-500' },
        admin: { label: 'Admin', color: 'text-emerald-500' },
        editor: { label: 'Editor', color: 'text-blue-500' },
        viewer: { label: 'Viewer', color: 'text-zinc-500' },
    };

    return roleMap[role as string] || { label: 'Editor', color: 'text-blue-500' };
}

export function UserMenu() {
    const { user, isLoaded } = useAuth();

    if (!isLoaded || !user) return null;

    const role = user.role;
    const { label: roleLabel, color: roleColor } = getRoleDisplay(role);

    return (
        <div className="flex items-center gap-4 pl-4 border-l border-gray-200 dark:border-zinc-800">
            <div className="hidden md:flex flex-col items-end mr-1">
                <span className="text-[10px] font-black uppercase tracking-wider text-page-title leading-none mb-0.5">
                    {user.name || 'Administrator'}
                </span>
                <div className="flex items-center gap-1">
                    <Shield size={8} className={roleColor} />
                    <span className={`text-[8px] font-bold ${roleColor} uppercase tracking-widest leading-none`}>
                        {roleLabel}
                    </span>
                </div>
            </div>

            <SafeUserButton
                appearance={{
                    elements: {
                        rootBox: "hover:scale-105 transition-transform",
                        userButtonAvatarBox: "w-8 h-8 rounded-lg border border-primary/20 shadow-sm",
                        userButtonTrigger: "focus:shadow-none focus:outline-none"
                    }
                }}
                userProfileMode="navigation"
                userProfileUrl="/admin/profile"
            />
        </div>
    );
}


export function UserIdentityMobile() {
    const { user, isLoaded } = useAuth();

    if (!isLoaded || !user) return null;

    const role = user.role;
    const { label: roleLabel, color: roleColor } = getRoleDisplay(role);

    return (
        <div className="flex items-center gap-3 px-4 mb-6">
            <div className="w-10 h-10 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center text-primary font-black overflow-hidden">
                {user.imageUrl ? (
                    <img src={user.imageUrl} alt="Avatar" className="w-full h-full object-cover" />
                ) : (
                    'LZ'
                )}
            </div>
            <div>
                <div className="text-xs font-black text-page-title uppercase">
                    {user.name || 'Admin'}
                </div>
                <div className="flex items-center gap-1">
                    <Shield size={8} className={roleColor} />
                    <div className={`text-[10px] ${roleColor} font-bold uppercase tracking-widest`}>
                        {roleLabel}
                    </div>
                </div>
            </div>
        </div>
    );
}

