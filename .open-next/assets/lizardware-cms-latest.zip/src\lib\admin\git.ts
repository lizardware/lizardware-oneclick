import { fromByteArray } from 'base64-js';

/**
 * GitHub API utilities for committing content changes back to the repository.
 * Phase 1: Basic commit functionality for blog posts.
 */

export interface CommitOptions {
  filePath: string;
  content: string;
  message: string;
  branch?: string;
}

/**
 * Commit a file change to GitHub.
 * Requires GITHUB_TOKEN env var (from Cloudflare Pages env settings).
 * @param options Commit details
 * @returns GitHub commit details or error
 */
export async function commitFileToGitHub(options: CommitOptions) {
  const {
    filePath,
    content,
    message,
    branch = process.env.GITHUB_BRANCH || "main",
  } = options;

  const owner = process.env.GITHUB_REPO_OWNER || "Lizardware";
  const repo = process.env.GITHUB_REPO_NAME || "CMSDev1";
  const token = process.env.GITHUB_TOKEN;

  if (!token) {
    throw new Error("GITHUB_TOKEN env var not set");
  }

  // Get current file SHA (needed for update)
  const getResponse = await fetch(
    `https://api.github.com/repos/${owner}/${repo}/contents/${filePath}?ref=${branch}`,
    {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/vnd.github+json",
      },
    }
  );

  let sha: string | undefined;
  if (getResponse.ok) {
    const data = (await getResponse.json()) as { sha: string };
    sha = data.sha;
  }

  // Commit the file
  const payload = {
    message,
    content: fromByteArray(new TextEncoder().encode(content)),
    branch,
    ...(sha && { sha }),
  };

  const commitResponse = await fetch(
    `https://api.github.com/repos/${owner}/${repo}/contents/${filePath}`,
    {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    }
  );

  if (!commitResponse.ok) {
    const error = await commitResponse.text();
    throw new Error(`GitHub API error: ${commitResponse.status} ${error}`);
  }

  return commitResponse.json();
}

/**
 * Fetch a file from GitHub.
 * @param filePath Relative path in repo (e.g., "src/content/blog/example.mdx")
 * @param branch Git branch (default: "main")
 * @returns File content as string
 */
export async function fetchFileFromGitHub(
  filePath: string,
  branch = "main"
) {
  const owner = process.env.GITHUB_REPO_OWNER || "Lizardware";
  const repo = process.env.GITHUB_REPO_NAME || "CMSDev1";

  const response = await fetch(
    `https://api.github.com/repos/${owner}/${repo}/contents/${filePath}?ref=${branch}`,
    {
      headers: {
        Accept: "application/vnd.github.raw+json",
      },
    }
  );

  if (!response.ok) {
    throw new Error(
      `Failed to fetch file from GitHub: ${response.status}`
    );
  }

  return response.text();
}

/**
 * List files in a GitHub directory (e.g., blog posts).
 * @param dirPath Directory path in repo
 * @param branch Git branch (default: "main")
 * @returns Array of file entries
 */
export async function listFilesInGitHub(
  dirPath: string,
  branch = "main"
) {
  const owner = process.env.GITHUB_REPO_OWNER || "Lizardware";
  const repo = process.env.GITHUB_REPO_NAME || "CMSDev1";

  const response = await fetch(
    `https://api.github.com/repos/${owner}/${repo}/contents/${dirPath}?ref=${branch}`,
    {
      headers: {
        Accept: "application/vnd.github+json",
      },
    }
  );

  if (!response.ok) {
    throw new Error(
      `Failed to list files in GitHub: ${response.status}`
    );
  }

  return response.json();
}
