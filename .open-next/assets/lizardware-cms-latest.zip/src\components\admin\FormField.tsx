"use client";

interface FormFieldProps {
    label: string;
    required?: boolean;
    error?: string;
    helpText?: string;
    children: React.ReactNode;
}

export default function FormField({
    label,
    required = false,
    error,
    helpText,
    children,
}: FormFieldProps) {
    return (
        <div className="space-y-2">
            <label className="block text-sm font-medium">
                {label}
                {required && <span className="text-red-500 ml-1">*</span>}
            </label>
            {children}
            {helpText && !error && (
                <p className="text-xs text-gray-500 dark:text-gray-400">{helpText}</p>
            )}
            {error && <p className="text-xs text-red-600 dark:text-red-400">{error}</p>}
        </div>
    );
}
