-- Migration: Create authors table for Clerk sync
-- Created: 2025-12-30

CREATE TABLE IF NOT EXISTS authors (
    id TEXT PRIMARY KEY, -- Clerk User ID
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    image_url TEXT,
    role TEXT DEFAULT 'editor',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_authors_email ON authors(email);
