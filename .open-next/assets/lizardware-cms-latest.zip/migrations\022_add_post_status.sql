-- Add status column to posts table
ALTER TABLE posts ADD COLUMN status TEXT DEFAULT 'published';
-- Create index for status queries
CREATE INDEX idx_posts_status ON posts(status);
