'use client';

import { useState, useRef } from 'react';
import { VariableText } from './VariableText';
import { Zap } from 'lucide-react';
import VariableInserterModal from './VariableInserterModal';

interface VariableInputProps {
    value: string;
    onChange: (value: string) => void;
    placeholder?: string;
    label?: string;
    rows?: number;
    className?: string;
}

/**
 * A plain text input/textarea that supports variable insertion 
 * and displays visual pills when not focused.
 */
export default function VariableInput({
    value,
    onChange,
    placeholder,
    label,
    rows = 1,
    className = ""
}: VariableInputProps) {
    const [isEditing, setIsEditing] = useState(false);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const inputRef = useRef<HTMLTextAreaElement | HTMLInputElement>(null);

    const handleInsert = (variableName: string) => {
        const textToInsert = `{{${variableName}}}`;
        const ref = inputRef.current;
        if (!ref) return;

        const start = ref.selectionStart || 0;
        const end = ref.selectionEnd || 0;
        const newValue = value.substring(0, start) + textToInsert + value.substring(end);

        onChange(newValue);

        // Return focus and set cursor position
        setTimeout(() => {
            ref.focus();
            const newPos = start + textToInsert.length;
            ref.setSelectionRange(newPos, newPos);
        }, 10);
    };

    const isTextArea = rows > 1;

    return (
        <div className={`space-y-1 ${className}`}>
            <div className="flex items-center justify-between">
                {label && <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{label}</label>}
                <button
                    type="button"
                    onClick={() => setIsModalOpen(true)}
                    tabIndex={-1}
                    className="p-1 text-purple-500 hover:bg-purple-100 dark:hover:bg-purple-900/20 rounded transition-colors group flex items-center gap-1"
                    title="Insert Variable"
                >
                    <Zap size={12} className="group-hover:fill-purple-500" />
                    <span className="text-[10px] font-bold uppercase tracking-wider">Insert</span>
                </button>
            </div>

            <div
                className={`relative border rounded-lg transition-all shadow-sm ${isEditing
                    ? 'border-purple-500 ring-2 ring-purple-500/10 bg-white dark:bg-zinc-800'
                    : 'border-gray-200 dark:border-zinc-800 bg-gray-50 dark:bg-zinc-950/50'
                    }`}
            >
                {isTextArea ? (
                    <textarea
                        ref={inputRef as any}
                        value={value}
                        onChange={(e) => onChange(e.target.value)}
                        onFocus={() => setIsEditing(true)}
                        onBlur={() => setIsEditing(false)}
                        rows={rows}
                        placeholder={placeholder}
                        className="w-full px-3 py-2 bg-transparent outline-none resize-none text-sm dark:text-zinc-100"
                    />
                ) : (
                    <input
                        type="text"
                        ref={inputRef as any}
                        value={value}
                        onChange={(e) => onChange(e.target.value)}
                        onFocus={() => setIsEditing(true)}
                        onBlur={() => setIsEditing(false)}
                        placeholder={placeholder}
                        className="w-full px-3 py-2 bg-transparent outline-none text-sm dark:text-zinc-100"
                    />
                )}

                {/* Visual Overlay when not editing to show pills */}
                {!isEditing && value.includes('{{') && (
                    <div
                        className="absolute inset-0 px-3 py-2 pointer-events-none bg-white dark:bg-zinc-900 rounded-lg overflow-hidden whitespace-pre-wrap break-all text-sm animate-in fade-in duration-200"
                        aria-hidden="true"
                    >
                        <VariableText text={value} />
                    </div>
                )}
            </div>

            <VariableInserterModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onInsert={handleInsert}
            />
        </div>
    );
}
