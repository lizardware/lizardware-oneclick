-- Migration: Add missing columns to site_config
-- Created: 2026-01-04
-- Purpose: Sync site_config schema with KV-to-D1 sync logic

-- Add columns if they don't exist
ALTER TABLE site_config ADD COLUMN name TEXT;
ALTER TABLE site_config ADD COLUMN description TEXT;
ALTER TABLE site_config ADD COLUMN updated_at TEXT DEFAULT (datetime('now'));

-- Ensure row 1 exists
INSERT OR IGNORE INTO site_config (id, template_id, setup_completed) VALUES (1, 'custom', 0);
