import { NextResponse } from 'next/server';
import { getD1Database } from '@/lib/cloudflare';

export async function GET() {
    try {
        const db = await getD1Database();
        if (!db) {
            return NextResponse.json({ error: 'DB binding not found' }, { status: 500 });
        }

        const { results } = await db.prepare('SELECT * FROM posts').all();
        return NextResponse.json({
            count: results.length,
            tables: await db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all(),
            posts: results
        });
    } catch (error) {
        return NextResponse.json({
            error: error instanceof Error ? error.message : String(error),
            stack: error instanceof Error ? error.stack : undefined
        }, { status: 500 });
    }
}
