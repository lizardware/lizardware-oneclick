import { getDocBySlug } from '@/data/docs-content';
import MarkdownViewer from '@/components/ui/MarkdownViewer';
import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';

import { BookOpen, ArrowLeft, ExternalLink } from "lucide-react";
import { AdminHeader } from "@/components/admin/AdminHeader";

export async function generateMetadata({ params }: { params: Promise<{ slug: string[] }> }): Promise<Metadata> {
    const { slug } = await params;
    const docSlug = slug.join('/');
    const doc = getDocBySlug(docSlug);

    return {
        title: `${doc?.title || 'Documentation'} | Lizardware Admin`,
    };
}

export default async function AdminDocPage({ params }: { params: Promise<{ slug: string[] }> }) {
    const { slug } = await params;
    const docSlug = slug.join('/');
    const doc = getDocBySlug(docSlug);

    if (!doc) {
        notFound();
    }

    return (
        <div className="max-w-7xl mx-auto px-6 pt-4 pb-12 space-y-8">
            <AdminHeader
                title={<>System <span className="text-blue-500">Docs</span></>}
                description={doc.title}
                breadcrumbs={[
                    { label: 'Admin', href: '/admin' },
                    { label: 'System', href: '/admin/system' },
                    { label: 'Docs', href: '/admin/system/docs' },
                    { label: doc.title }
                ]}
                badge={
                    <div className="flex items-center gap-3">
                        <div className="p-2 bg-gray-50 dark:bg-zinc-950 rounded-xl border border-gray-100 dark:border-zinc-800 flex items-center gap-3">
                            <div className="w-8 h-8 rounded-lg bg-blue-100 dark:bg-blue-900/20 flex items-center justify-center text-blue-500">
                                <BookOpen size={16} />
                            </div>
                            <div>
                                <div className="text-[9px] font-bold text-gray-400 uppercase tracking-tighter">Documentation</div>
                                <div className="text-[10px] font-bold text-blue-500 uppercase">Operational</div>
                            </div>
                        </div>
                    </div>
                }
                actions={
                    <div className="flex items-center gap-3">
                        <Link
                            href="/admin/system/docs"
                            className="px-3 py-1.5 bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 rounded-lg text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
                        >
                            <ArrowLeft size={12} /> Back
                        </Link>
                        <Link
                            href={`/docs/${docSlug}`}
                            target="_blank"
                            className="p-2 bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 rounded-xl hover:scale-105 transition-all shadow-lg flex items-center gap-2"
                        >
                            <ExternalLink size={16} />
                        </Link>
                    </div>
                }
            />

            <MarkdownViewer
                content={doc.content}
            />
        </div >
    );
}
