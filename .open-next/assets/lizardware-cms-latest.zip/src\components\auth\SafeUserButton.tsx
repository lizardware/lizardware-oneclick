'use client';

import { UserButton } from "@clerk/nextjs";
import { isClerkConfigured } from "@/lib/auth-config";
import { useAuth } from "@/context/AuthContext";
import { LogOut } from "lucide-react";

export function SafeUserButton({ userProfileMode, userProfileUrl, appearance }: any) {
    const isClerk = isClerkConfigured();
    const { signOut, user } = useAuth();

    if (isClerk) {
        return (
            <UserButton
                userProfileMode={userProfileMode}
                userProfileUrl={userProfileUrl}
                appearance={appearance}
            />
        );
    }

    // Fallback UI for Local Auth
    return (
        <button
            onClick={() => signOut()}
            className="w-8 h-8 rounded-lg bg-zinc-200 dark:bg-zinc-800 flex items-center justify-center hover:bg-red-500/10 hover:text-red-500 transition-colors"
            title="Sign Out (Local)"
        >
            {user?.imageUrl ? (
                <img src={user.imageUrl} className="w-full h-full rounded-lg object-cover" />
            ) : (
                <LogOut size={14} />
            )}
        </button>
    );
}
