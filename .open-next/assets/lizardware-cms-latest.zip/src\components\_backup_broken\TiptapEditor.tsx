"use client";

import { useEditor, EditorContent, Editor } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import { Markdown } from "@tiptap/markdown";
import { Toolbar, ToolbarGroup } from "@/components/Toolbar";
import { Button } from "@/components/Button";
import { BoldIcon } from "@/components/icons/BoldIcon";
import { ItalicIcon } from "@/components/icons/ItalicIcon";

interface TiptapEditorProps {
  content: string;
  onChange: (content: string) => void;
}

const TiptapEditor: React.FC<TiptapEditorProps> = ({ content, onChange }) => {
  const editor = useEditor({
    extensions: [StarterKit, Markdown],
    content: content,
    onUpdate: ({ editor }) => {
      onChange(editor.storage.markdown.getMarkdown());
    },
    immediatelyRender: false,
  });

  if (!editor) {
    return null;
  }

  return (
    <div>
      <Toolbar>
        <ToolbarGroup>
          <Button
            onClick={() => editor.chain().focus().toggleBold().run()}
            disabled={!editor.can().chain().focus().toggleBold().run()}
            data-style={editor.isActive("bold") ? "primary" : "ghost"}
          >
            <BoldIcon className="tiptap-button-icon" />
          </Button>
          <Button
            onClick={() => editor.chain().focus().toggleItalic().run()}
            disabled={!editor.can().chain().focus().toggleItalic().run()}
            data-style={editor.isActive("italic") ? "primary" : "ghost"}
          >
            <ItalicIcon className="tiptap-button-icon" />
          </Button>
        </ToolbarGroup>
      </Toolbar>
      <EditorContent editor={editor} />
    </div>
  );
};

export default TiptapEditor;
