import { NextResponse } from 'next/server';
import packageJson from '../../../../../../package.json';

/**
 * Lizardware CMS - Update Checker API
 * (Mock implementation for Alpha testing)
 */
export async function GET() {
    // In production, this would fetch from https://lizardware.dev/api/latest-version
    const latestVersion = "0.4.8"; // Hardcoded next version for testing
    const currentVersion = packageJson.version;

    const isUpdateAvailable = latestVersion !== currentVersion;

    return NextResponse.json({
        currentVersion,
        latestVersion,
        isUpdateAvailable,
        releaseDate: new Date().toISOString(),
        changelog: [
            "Fixed minor UI spacing on dashboard",
            "Improved ZIP packaging script stability",
            "Added update notification badges"
        ],
        migrations: [],
        critical: false
    });
}
