import { getD1Database } from './cloudflare';

export interface Author {
    id: string;
    name: string;
    bio?: string;
    avatar_url?: string;
    email?: string;
    twitter?: string;
    linkedin?: string;
    created_at?: string;
}

export async function getAllAuthors(db: D1Database): Promise<Author[]> {
    const stmt = db.prepare('SELECT * FROM authors ORDER BY name ASC');
    const result = await stmt.all<Author>();
    return result.results;
}

export async function getAuthorById(db: D1Database, id: string): Promise<Author | null> {
    const stmt = db.prepare('SELECT * FROM authors WHERE id = ? LIMIT 1').bind(id);
    return await stmt.first<Author>();
}

export async function upsertAuthor(db: D1Database, author: Author): Promise<void> {
    const stmt = db.prepare(`
        INSERT INTO authors (id, name, bio, avatar_url, email, twitter, linkedin)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
            name = excluded.name,
            bio = excluded.bio,
            avatar_url = excluded.avatar_url,
            email = excluded.email,
            twitter = excluded.twitter,
            linkedin = excluded.linkedin
    `).bind(
        author.id,
        author.name,
        author.bio || null,
        author.avatar_url || null,
        author.email || null,
        author.twitter || null,
        author.linkedin || null
    );
    await stmt.run();
}

export async function deleteAuthor(db: D1Database, id: string): Promise<void> {
    const stmt = db.prepare('DELETE FROM authors WHERE id = ?').bind(id);
    await stmt.run();
}
