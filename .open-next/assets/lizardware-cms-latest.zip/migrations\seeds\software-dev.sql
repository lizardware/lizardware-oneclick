-- Seed: Software Development Website
-- Created: 2025-12-29
-- Purpose: A fully fledged site structure for software development websites,
-- replicating a modern dev agency structure.

-- 1. Blog Posts
INSERT OR IGNORE INTO posts (slug, title, content, description, author, author_id, tags, date, status, created_at, updated_at)
VALUES (
  'building-better-software',
  'Building Better Software Faster',
  '<h1>Building Better Software Faster</h1><p>In the fast-paced world of software development, speed and quality are often seen as valid trade-offs. But with the right tools and mindset, you can have both.</p><h2>The Key Pillars</h2><h3>1. Automation</h3><p>CI/CD pipelines are not just nice-to-have; they are essential. If a human has to manually run a script to deploy your code, you have a bottleneck. Automation ensures consistency and reduces the risk of human error.</p><h3>2. Testing</h3><p>Automated testing allows you to refactor with confidence. High test coverage means you can ship new features without worrying about breaking existing functionality. It''s the safety net that every engineering team needs.</p><h3>3. Edge Deployment</h3><p>Getting your code closer to your users reduces latency and improves the overall user experience. By leveraging edge computing, you can serve content and execute logic from hundreds of locations globally, ensuring sub-100ms response times for everyone.</p><h2>Conclusion</h2><p>By focusing on these three pillars, your team can build higher-quality software at a much faster pace. The future of development is automated, tested, and distributed.</p>',
  'Strategies for modern software engineering teams to balance speed and quality.',
  'Dev Team',
  'dev-team',
  '["Engineering", "DevOps", "Best Practices"]',
  '2025-12-30',
  'published',
  datetime('now'),
  datetime('now')
);

INSERT OR IGNORE INTO posts (slug, title, content, description, author, author_id, tags, date, status, created_at, updated_at)
VALUES (
  'welcome-to-your-cms',
  'Welcome to Your New CMS',
  '<h1>Welcome to Your New CMS</h1><p>This is a modern, edge-native content management system designed for speed, security, and developer happiness. Built on the power of Cloudflare''s global network, it bridges the gap between the simplicity of static sites and the robustness of enterprise CMS platforms.</p><h2>Why Edge CMS?</h2><p>Traditional CMS architectures are showing their age. They are often slow, require constant security patching, and create bottlenecks between content teams and developers. This platform was built from the ground up to solve these problems by:</p><ul><li><strong>Deploying to the Edge:</strong> Using Cloudflare Workers and D1, your content is served from 300+ cities worldwide with sub-100ms response times.</li><li><strong>Git-Backed Reliability:</strong> Every change is version-controlled, providing an audit trail and easy rollbacks.</li><li><strong>Developer First:</strong> Built with Next.js 15 and TypeScript, it''s a joy to extend and maintain.</li><li><strong>Intuitive Writing:</strong> A powerful block-based editor (Tiptap) that gets out of the way of your creativity.</li></ul><h2>Getting Started</h2><p>Deploying your own instance takes only a few minutes. Check out our <a href="/setup">Getting Started guide</a> to launch your first edge-native site today.</p>',
  'Welcome to the future of content management. Learn why we built this platform and how it''s changing the game.',
  'Admin',
  'admin',
  '["Product", "Announcement"]',
  '2025-12-19',
  'published',
  datetime('now'),
  datetime('now')
);

INSERT OR IGNORE INTO posts (slug, title, content, description, author, author_id, tags, date, status, created_at, updated_at)
VALUES (
  'the-rise-of-the-edge-cms',
  'The Rise of the Edge CMS',
  '<h1>The Rise of the Edge CMS</h1><p>The web is changing. Centralized servers are giving way to distributed edge networks, and the CMS is evolving along with it.</p><h2>What is an Edge CMS?</h2><p>An Edge CMS is a content management system that runs its logic and serves its content from the "edge" of the network—data centers located as close to the user as possible. This is in contrast to traditional CMSs like WordPress, which typically run on a single origin server.</p><h2>Benefits of an Edge-First Approach</h2><ol><li><strong>Sub-100ms Performance:</strong> By serving content from 300+ global locations, users never have to wait for a round-trip to a distant server.</li><li><strong>Infinite Scalability:</strong> Edge networks like Cloudflare scale automatically to handle any amount of traffic without manual intervention.</li><li><strong>Enhanced Security:</strong> Running on serverless workers eliminates the attack surface associated with traditional servers.</li></ol><h2>Why It Matters for Developers</h2><p>Developers no longer need to worry about server maintenance, patching, or scaling. They can focus on building great user experiences while the infrastructure handles the rest.</p>',
  'Exploring why edge computing is the next frontier for content management systems.',
  'Cloud Architect',
  'cloud-arch',
  '["Edge Computing", "Cloudflare", "Architecture"]',
  '2025-12-28',
  'published',
  datetime('now'),
  datetime('now')
);

-- 2. Pages
-- Welcome / Home Page
INSERT OR IGNORE INTO pages (slug, title, content, description, status, is_template, template_category, sort_order, created_at, updated_at)
VALUES (
  'welcome', 
  'Welcome to {{siteName}}', 
  '<h1>Welcome to {{siteName}}</h1><h2>The Modern CMS for the Edge</h2><p>Empower your team to create exceptional digital experiences with a Git-backed CMS optimized for Cloudflare''s global edge network. Fast, secure, and developer-friendly content management for the modern web.</p><h3>⚡ Edge-First Performance</h3><p>Global CDN delivery ensures instant load times and perfect Core Web Vitals across 300+ cities. Your content is always sub-100ms away from your users.</p><h3>🔒 Git-Backed Security</h3><p>Every change is version controlled and stored in your own repository. High security by default with no traditional database vulnerabilities to patch.</p><h3>🎨 Beautiful Editor</h3><p>A modern WYSIWYG experience with live preview, making content creation a delight for your team. Switch between visual editing and MDX seamlessly.</p><p>Ready to get started? Visit our <a href="/features">Features Page</a> to see what else we can do.</p>', 
  'Home page of {{siteName}} - The Modern CMS for the Edge', 
  'published', 
  0, 
  NULL, 
  0, 
  datetime('now'), 
  datetime('now')
);

-- Features / Platform Page
INSERT OR IGNORE INTO pages (slug, title, content, description, status, is_template, template_category, sort_order, created_at, updated_at)
VALUES (
  'features', 
  'Platform Features', 
  '<h1>Powerful Features for Modern Teams</h1><p>{{siteName}} provides enterprise-grade features without the enterprise complexity. Built from the ground up for performance, security, and ease of use.</p><h2>🖋️ Advanced Content Management</h2><p>Experience a distraction-free writing environment designed for creators. Our editor provides the perfect balance between powerful structural tools and a clean interface.</p><ul><li><strong>Visual Editing:</strong> Powered by Tiptap for a familiar word-processor experience.</li><li><strong>MDX Support:</strong> Write in plain text or mix React components directly into your content.</li><li><strong>Organization:</strong> Tag-based organization and powerful search across all content.</li></ul><h2>🎨 Visual Theme Engine</h2><p>Take control of your site''s visual identity without touching code. Our Theme Transformer engine allows you to customize every aspect of your brand.</p><ul><li><strong>Live Customizer:</strong> Update colors, headers, and backgrounds in real-time.</li><li><strong>Dark Mode Native:</strong> Every element is optimized for both light and dark environments.</li><li><strong>Design Systems:</strong> Consistent CSS variables used throughout the entire platform.</li></ul><h2>⚡ Edge Performance Stack</h2><p>Speed is a core feature, not an afterthought. Running natively on the edge ensures your site is blazingly fast everywhere.</p><ul><li><strong>Global CDN:</strong> 300+ data centers serving content from the nearest location.</li><li><strong>Zero Cold Starts:</strong> Optimized serverless functions that scale instantly.</li><li><strong>Lighthouse Excellence:</strong> Perfect Core Web Vitals scores by default.</li></ul><h2>🛡️ Security & Ownership</h2><p>You own your content. Fully. We combine enterprise infrastructure with total protocol freedom.</p><ul><li><strong>Full Data Ownership:</strong> Your content lives in your Git repo and your Cloudflare account.</li><li><strong>Audit Trails:</strong> See who changed what and when with full history.</li><li><strong>DDoS Protection:</strong> Automatic mitigation from Cloudflare''s world-class network.</li></ul>', 
  'Explore the powerful edge-native features of {{siteName}} CMS.', 
  'published', 
  0, 
  NULL, 
  10, 
  datetime('now'), 
  datetime('now')
);

-- About Page
INSERT OR IGNORE INTO pages (slug, title, content, description, status, is_template, template_category, sort_order, created_at, updated_at)
VALUES (
  'about', 
  'About Us', 
  '<h1>Our Mission</h1><p>At {{siteName}}, we believe that the web should be fast, secure, and accessible to everyone. We started with a simple goal: to build the CMS we always wanted to use. One that combines the developer-friendly workflow of Git with the ease of use of a visual editor.</p><h2>The Problem</h2><p>Traditional CMS platforms are often slow, difficult to secure, and create separate silos for developers and content creators. We saw a better way.</p><h2>Our Solution</h2><p>By building on top of Cloudflare Workers and D1, we''ve created a platform specifically designed for the edge network. This allows us to provide unmatched performance and security while keeping the developer experience at the center of everything we do.</p><h2>Join Us</h2><p>We are a small team of passionate developers and designers building the future of the web. We''re excited to have you on this journey with us.</p>', 
  'Learn more about the mission and team behind {{siteName}}.', 
  'published', 
  0, 
  NULL, 
  20, 
  datetime('now'), 
  datetime('now')
);

-- Pricing Page
INSERT OR IGNORE INTO pages (slug, title, content, description, status, is_template, template_category, sort_order, created_at, updated_at)
VALUES (
  'pricing', 
  'Simple Pricing', 
  '<h1>Pricing for Every Team Size</h1><p>Choose the plan that fits your needs. No hidden fees, no complexity. All plans include our core edge-native performance.</p><hr><h3>🥚 Starter</h3><p><strong>Free Forever</strong></p><ul><li>1 Admin User</li><li>1 Site Instance</li><li>Core CMS Features</li><li>Community Support</li><li><em>Perfect for personal blogs and portfolios</em></li></ul><hr><h3>🦎 Pro</h3><p><strong>$29 / Month</strong></p><ul><li>Unlimited Admin Users</li><li>3 Site Instances</li><li>Advanced SEO Tools</li><li>Priority Support</li><li><em>Perfect for growing businesses and agencies</em></li></ul><hr><h3>🦖 Enterprise</h3><p><strong>Contact Us</strong></p><ul><li>Custom Site Limits</li><li>Custom Integrations</li><li>Dedicated Support Engineer</li><li>SLA Guarantees</li><li><em>Perfect for high-traffic platforms and large teams</em></li></ul><hr><p><strong>All plans include:</strong></p><ul><li>Global CDN Delivery</li><li>Automatic SSL</li><li>Git-Backed Reliability</li><li>Unlimited Bandwidth (via Cloudflare)</li></ul>', 
  'Simple and transparent pricing plans for {{siteName}}.', 
  'published', 
  0, 
  NULL, 
  30, 
  datetime('now'), 
  datetime('now')
);

-- 3. Forum Data (Software Dev Community)
-- Note: Forum threads and posts require authenticated users, which don't exist during initial setup.
-- Only creating categories for now.
INSERT OR IGNORE INTO forum_categories (name, slug, description, icon, color, sort_order) VALUES
('General Dev Discussion', 'general-dev', 'Talk about code, architecture, and tech stacks', '💻', '#3b82f6', 1),
('Showcase', 'showcase', 'Show off what you''ve built', '🚀', '#10b981', 2),
('Help & Support', 'help', 'Get help with integration and bugs', '🆘', '#ef4444', 3);
