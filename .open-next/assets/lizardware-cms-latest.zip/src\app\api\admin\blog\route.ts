import { NextRequest, NextResponse } from 'next/server';
import { getAllPosts } from '@/lib/blog';
import { getD1Database } from '@/lib/cloudflare';
import { upsertPostToD1 } from '@/lib/blog-storage';
import { Post } from '@/types/blog';

export const dynamic = 'force-dynamic';

export async function GET() {
    try {
        // Admin route should see all posts including drafts
        const posts = await getAllPosts({ includeDrafts: true });
        return NextResponse.json(posts);
    } catch (error) {
        console.error('[Admin API] Error fetching posts:', error);
        return NextResponse.json(
            { error: error instanceof Error ? error.message : 'Unknown error' },
            { status: 500 }
        );
    }
}

// POST /api/admin/blog - Create new post
export async function POST(request: NextRequest) {
    try {
        const post = await request.json() as Post;

        // Validate required fields
        if (!post.slug || !post.title || !post.content) {
            return NextResponse.json(
                { error: 'Missing required fields: slug, title, content' },
                { status: 400 }
            );
        }

        const db = await getD1Database();
        if (!db) {
            return NextResponse.json(
                { error: 'Database not available' },
                { status: 503 }
            );
        }

        await upsertPostToD1(db, post);

        return NextResponse.json({
            success: true,
            message: 'Post created successfully',
            slug: post.slug
        });
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error('Post creation error:', message);

        return NextResponse.json(
            { error: message },
            { status: 500 }
        );
    }
}
