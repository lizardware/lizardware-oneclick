"use client";

import { useState, useEffect } from "react";
import { Plus, Trash2, Image as ImageIcon, Link as LinkIcon, X } from "lucide-react";
import { AdminLoadingState } from "./AdminLoadingState";
import { usePopup } from "./AdminPopupProvider";

interface MediaAsset {
    id: string;
    filename: string;
    url: string;
    alt_text?: string;
    created_at: string;
}

export default function MediaLibrary({ onSelect }: { onSelect?: (asset: MediaAsset) => void }) {
    const popup = usePopup();
    const [assets, setAssets] = useState<MediaAsset[]>([]);
    const [loading, setLoading] = useState(true);
    const [showAddModal, setShowAddModal] = useState(false);
    const [newAsset, setNewAsset] = useState({ filename: "", url: "", alt_text: "" });

    const fetchAssets = async () => {
        try {
            const res = await fetch("/api/admin/media");
            if (res.ok) {
                const data = await res.json() as { media: MediaAsset[] };
                setAssets(data.media || []);
            }
        } catch (error) {
            console.error("Error fetching media:", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchAssets();
    }, []);

    const handleAddAsset = async () => {
        if (!newAsset.url || !newAsset.filename) return;
        try {
            const res = await fetch("/api/admin/media", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(newAsset)
            });
            if (res.ok) {
                setShowAddModal(false);
                setNewAsset({ filename: "", url: "", alt_text: "" });
                fetchAssets();
            }
        } catch (error) {
            console.error("Error adding asset:", error);
        }
    };

    const handleDeleteAsset = async (id: string, e: React.MouseEvent) => {
        e.stopPropagation();
        const confirmed = await popup.confirm("Delete this asset permanently?", { isDanger: true });
        if (!confirmed) return;
        try {
            const res = await fetch(`/api/admin/media?id=${id}`, { method: "DELETE" });
            if (res.ok) fetchAssets();
        } catch (error) {
            console.error("Error deleting asset:", error);
        }
    };

    if (loading) return <AdminLoadingState message="Fetching gallery..." />;

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold text-page-title flex items-center gap-2">
                    <ImageIcon className="text-purple-500" size={20} />
                    Media Library
                </h2>
                <button
                    onClick={() => setShowAddModal(true)}
                    className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-purple-500/20"
                >
                    <Plus size={16} /> Add Asset
                </button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {assets.map((asset) => (
                    <div
                        key={asset.id}
                        onClick={() => onSelect?.(asset)}
                        className={`group relative aspect-square bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-2xl overflow-hidden cursor-pointer hover:border-purple-500/50 transition-all ${onSelect ? 'hover:ring-2 hover:ring-purple-500/20' : ''}`}
                    >
                        <img
                            src={asset.url}
                            alt={asset.alt_text}
                            className="w-full h-full object-cover transition-transform group-hover:scale-110"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                        <div className="absolute bottom-0 left-0 right-0 p-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <p className="text-[10px] text-white font-medium truncate">{asset.filename}</p>
                        </div>
                        <button
                            onClick={(e) => handleDeleteAsset(asset.id, e)}
                            className="absolute top-2 right-2 p-1.5 bg-red-500/10 hover:bg-red-500 text-red-500 hover:text-white rounded-lg opacity-0 group-hover:opacity-100 transition-all"
                        >
                            <Trash2 size={12} />
                        </button>
                    </div>
                ))}
            </div>

            {/* Add Asset Modal */}
            {showAddModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
                    <div className="bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-3xl p-6 w-full max-w-md shadow-2xl animate-in fade-in zoom-in duration-200">
                        <div className="flex justify-between items-center mb-6">
                            <h3 className="text-lg font-bold text-page-title flex items-center gap-2">
                                <LinkIcon className="text-purple-500" size={18} />
                                Register External Asset
                            </h3>
                            <button onClick={() => setShowAddModal(false)} className="text-gray-400 hover:text-gray-600 transition-colors">
                                <X size={20} />
                            </button>
                        </div>

                        <div className="space-y-4">
                            <div>
                                <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1">Asset Name</label>
                                <input
                                    type="text"
                                    placeholder="e.g. Hero Image"
                                    value={newAsset.filename}
                                    onChange={(e) => setNewAsset({ ...newAsset, filename: e.target.value })}
                                    className="w-full px-4 py-2.5 bg-gray-50 dark:bg-zinc-800 border-none rounded-xl text-sm outline-none focus:ring-2 focus:ring-purple-500/20"
                                />
                            </div>
                            <div>
                                <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1">Image URL</label>
                                <input
                                    type="url"
                                    placeholder="https://images.unsplash.com/..."
                                    value={newAsset.url}
                                    onChange={(e) => setNewAsset({ ...newAsset, url: e.target.value })}
                                    className="w-full px-4 py-2.5 bg-gray-50 dark:bg-zinc-800 border-none rounded-xl text-sm outline-none focus:ring-2 focus:ring-purple-500/20"
                                />
                            </div>
                            <div>
                                <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1">Alt Text</label>
                                <input
                                    type="text"
                                    placeholder="Describe the image..."
                                    value={newAsset.alt_text}
                                    onChange={(e) => setNewAsset({ ...newAsset, alt_text: e.target.value })}
                                    className="w-full px-4 py-2.5 bg-gray-50 dark:bg-zinc-800 border-none rounded-xl text-sm outline-none focus:ring-2 focus:ring-purple-500/20"
                                />
                            </div>
                        </div>

                        <div className="mt-8 flex gap-3">
                            <button
                                onClick={() => setShowAddModal(false)}
                                className="flex-1 px-4 py-2.5 border border-gray-100 dark:border-zinc-800 rounded-xl text-xs font-bold text-gray-500 hover:bg-gray-50 transition-colors"
                            >
                                Cancel
                            </button>
                            <button
                                onClick={handleAddAsset}
                                className="flex-1 px-4 py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-purple-500/20"
                            >
                                Register Asset
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
