'use client';

import { UserProfile } from "@clerk/nextjs";
import { isClerkConfigured } from "@/lib/auth-config";
import { useAuth } from "@/context/AuthContext";

export function SafeUserProfile(props: any) {
    const isClerk = isClerkConfigured();
    const { user } = useAuth();

    if (isClerk) {
        return <UserProfile {...props} />;
    }

    // Fallback UI for Local Auth Profile
    return (
        <div className="p-8 space-y-8">
            <div className="flex items-center gap-6">
                <div className="w-20 h-20 rounded-full bg-zinc-200 dark:bg-zinc-800 flex items-center justify-center text-3xl font-bold text-zinc-500">
                    {user?.imageUrl ? <img src={user.imageUrl} className="w-full h-full rounded-full" /> : 'LZ'}
                </div>
                <div>
                    <h2 className="text-2xl font-bold">{user?.name}</h2>
                    <p className="text-zinc-500">{user?.email}</p>
                    <span className="inline-block mt-2 px-3 py-1 bg-purple-500/10 text-purple-600 text-xs font-bold uppercase tracking-wider rounded-full">
                        {user?.role || 'Owner'}
                    </span>
                </div>
            </div>

            <div className="grid gap-6 max-w-2xl">
                <div className="p-6 rounded-xl bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800">
                    <h3 className="text-lg font-bold mb-4">Local Administrator</h3>
                    <p className="text-sm text-zinc-500 mb-4">
                        You are currently signed in via Local Fallback Authentication.
                        Features related to account management, password resets, and multi-factor authentication are managed by your environment configuration, not Clerk.
                    </p>
                </div>
            </div>
        </div>
    );
}
