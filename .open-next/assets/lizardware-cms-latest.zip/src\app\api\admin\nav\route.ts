import { NextResponse } from "next/server";
import fs from "fs";
import path from "path";
import { NavConfig } from "@/types/nav";
import { getSafeCloudflareContext } from "@/lib/cloudflare";
import defaultNavData from "@/data/nav.json";

const NAV_FILE_PATH = path.join(process.cwd(), "src/data/nav.json");
const KV_KEY = "NAVIGATION_SETTINGS";

export async function GET() {
    try {
        // In production, try KV first
        if (process.env.NODE_ENV === 'production') {
            const context = await getSafeCloudflareContext();
            if (context?.env?.CONFIG_KV) {
                const kvData = await context.env.CONFIG_KV.get(KV_KEY);
                if (kvData) {
                    return NextResponse.json(JSON.parse(kvData));
                }
            }
            // Fallback to bundled data if KV is empty or context missing
            return NextResponse.json(defaultNavData);
        }

        // In development, use filesystem
        if (fs.existsSync(NAV_FILE_PATH)) {
            const fileContents = fs.readFileSync(NAV_FILE_PATH, "utf8");
            return NextResponse.json(JSON.parse(fileContents));
        }

        return NextResponse.json(defaultNavData);
    } catch (error) {
        console.error("Error reading nav config:", error);
        return NextResponse.json({ error: "Failed to read nav config" }, { status: 500 });
    }
}

export async function POST(request: Request) {
    try {
        const body = await request.json() as NavConfig;

        if (!body || !Array.isArray(body.navigation)) {
            return NextResponse.json({ error: "Invalid navigation data" }, { status: 400 });
        }

        // Production: Write to KV
        if (process.env.NODE_ENV === 'production') {
            const context = await getSafeCloudflareContext();
            if (!context?.env?.CONFIG_KV) {
                console.error("Production write failed: CONFIG_KV not available");
                return NextResponse.json(
                    { error: "KV storage not configured. Please bind CONFIG_KV to your Worker." },
                    { status: 503 }
                );
            }
            await context.env.CONFIG_KV.put(KV_KEY, JSON.stringify(body));
            return NextResponse.json({ message: "Navigation updated in KV" });
        }

        // Development: Write to filesystem
        fs.writeFileSync(NAV_FILE_PATH, JSON.stringify(body, null, 4), "utf8");

        return NextResponse.json({ message: "Navigation updated successfully" });
    } catch (error) {
        console.error("Error updating nav config:", error);
        return NextResponse.json({ error: "Failed to update nav config" }, { status: 500 });
    }
}
