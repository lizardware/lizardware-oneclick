import { ThemePreset } from '@/types/theme';

export const THEME_PRESETS: ThemePreset[] = [
    {
        id: 'classic',
        name: 'Lizardware Classic',
        description: 'The signature Lizardware look with deep forest tones and vibrant lizard green accents.',
        preview: 'bg-emerald-950',
        accent: '#22c55e',
        colors: {
            light: {
                // Tier 1: Global (Vibrant Emerald)
                bodyBackground: '#d1fae5', // emerald-100
                headerBackground: '#a7f3d0', // emerald-200
                footerBackground: '#6ee7b7', // emerald-300
                contentBackground: '#e6fffa', // slightly lighter for readability
                borders: '#34d399', // emerald-400

                // Tier 1.5: Components (Pop & Contrast)
                accordionBackground: '#a7f3d0',
                buttonBackground: '#10b981', // emerald-500 (Solid color for buttons)
                cardBackground: '#ecfdf5', // emerald-50
                inputBackground: '#d1fae5',

                // Tier 2: Page Sections
                pageBackgroundPrimary: '#ecfdf5',
                pageBackgroundSecondary: '#d1fae5',
                pageBackgroundAlternate: '#059669', // emerald-600
                heroBackground: '#6ee7b7',
                heroGradientStart: '#a7f3d0',
                heroGradientEnd: '#34d399',
                heroGradientEnabled: true,

                // Text & UI
                headerText: '#14532d',
                footerText: '#166534',
                pageTitle: '#064e3b',
                pageSubtitle: '#16a34a',
                pageText: '#374151',

                // Specific Overrides / Legacy
                infoBoxBg: '#ffffff',
                infoBoxText: '#064e3b',
                infoBoxLinkBg: '#ecfdf5',
                infoBoxLinkText: '#065f46',
                infoBoxLinkHover: '#22c55e',
                sectionHeader: '#dcfce7',
                heroText: '#064e3b'
            },
            dark: {
                // Tier 1: Global
                bodyBackground: '#020617',
                headerBackground: '#030a05',
                footerBackground: '#020617',
                contentBackground: '#0a1a0d',
                borders: '#0d2d18',

                // Tier 1.5: Components
                accordionBackground: '#0a1a0d',
                buttonBackground: '#0a1a0d',
                cardBackground: '#0a1a0d',
                inputBackground: '#05120a',

                // Tier 2: Page Sections
                pageBackgroundPrimary: '#030a05',
                pageBackgroundSecondary: '#05120a',
                pageBackgroundAlternate: '#14532d',
                heroBackground: '#064e3b',
                heroGradientStart: '#061009',
                heroGradientEnd: '#064e3b',
                heroGradientEnabled: true,

                // Text & UI
                headerText: '#ecfdf5',
                footerText: '#34d399',
                pageTitle: '#ecfdf5',
                pageSubtitle: '#22c55e',
                pageText: '#a7f3d0',

                // Specific Overrides / Legacy
                infoBoxBg: '#0a1a0d',
                infoBoxText: '#ecfdf5',
                infoBoxLinkBg: '#14532d',
                infoBoxLinkText: '#ecfdf5',
                infoBoxLinkHover: '#4ade80',
                sectionHeader: '#0a2a14',
                heroText: '#ecfdf5'
            }
        },
        typography: {
            fontSizeTitle: '60px',
            fontSizeSubtitle: '30px',
            fontSizeBase: '16px'
        }
    },
    {
        id: 'msp_orange',
        name: 'MSP Classic',
        description: 'Trustworthy enterprise slate with the high-energy signature orange.',
        preview: 'bg-slate-900',
        accent: '#f97316',
        colors: {
            light: {
                // Tier 1: Global (True Blue/Navy Tint)
                bodyBackground: '#dbeafe', // blue-100
                headerBackground: '#bfdbfe', // blue-200
                footerBackground: '#93c5fd', // blue-300
                contentBackground: '#eff6ff', // blue-50
                borders: '#60a5fa', // blue-400

                // Tier 1.5: Components
                accordionBackground: '#bfdbfe',
                buttonBackground: '#3b82f6', // blue-500
                cardBackground: '#eff6ff',
                inputBackground: '#dbeafe',

                // Tier 2: Page Sections
                pageBackgroundPrimary: '#eff6ff',
                pageBackgroundSecondary: '#dbeafe',
                pageBackgroundAlternate: '#f97316', // Orange remains
                heroBackground: '#bfdbfe',
                heroGradientStart: '#dbeafe',
                heroGradientEnd: '#93c5fd',
                heroGradientEnabled: true,

                // Text & UI
                headerText: '#0f172a',
                footerText: '#94a3b8',
                pageTitle: '#0f172a',
                pageSubtitle: '#ea580c',
                pageText: '#334155',

                // Legacy
                infoBoxBg: '#ffffff',
                infoBoxText: '#0f172a',
                infoBoxLinkBg: '#f1f5f9',
                infoBoxLinkText: '#1e293b',
                infoBoxLinkHover: '#f97316',
                sectionHeader: '#e2e8f0',
                heroText: '#0f172a'
            },
            dark: {
                // Tier 1: Global
                bodyBackground: '#020617',
                headerBackground: '#0f172a',
                footerBackground: '#020617',
                contentBackground: '#1e293b',
                borders: '#334155',

                // Tier 1.5: Components
                accordionBackground: '#1e293b',
                buttonBackground: '#1e293b',
                cardBackground: '#1e293b',
                inputBackground: '#0f172a',

                // Tier 2: Page Sections
                pageBackgroundPrimary: '#0f172a',
                pageBackgroundSecondary: '#111827',
                pageBackgroundAlternate: '#ea580c',
                heroBackground: '#020617',
                heroGradientStart: '#020617',
                heroGradientEnd: '#0f172a',
                heroGradientEnabled: true,

                // Text & UI
                headerText: '#f8fafc',
                footerText: '#64748b',
                pageTitle: '#f8fafc',
                pageSubtitle: '#f97316',
                pageText: '#94a3b8',

                // Legacy
                infoBoxBg: '#1e293b',
                infoBoxText: '#f8fafc',
                infoBoxLinkBg: '#0f172a',
                infoBoxLinkText: '#f8fafc',
                infoBoxLinkHover: '#fb923c',
                sectionHeader: '#1e293b',
                heroText: '#ffffff'
            }
        },
        typography: {
            fontSizeTitle: '60px',
            fontSizeSubtitle: '30px',
            fontSizeBase: '16px'
        }
    },
    {
        id: 'saas',
        name: 'Cloud Venture',
        description: 'Modern, tech-forward palette with futuristic gradients for SaaS and tech.',
        preview: 'bg-indigo-950',
        accent: '#818cf8',
        colors: {
            light: {
                // Tier 1: Global (Deeper indigo)
                bodyBackground: '#e0e7ff',
                headerBackground: '#c7d2fe',
                footerBackground: '#1e1b4b',
                contentBackground: '#c7d2fe',
                borders: '#a5b4fc',

                // Tier 1.5: Components (Rich indigo hierarchy)
                accordionBackground: '#c7d2fe',
                buttonBackground: '#e0e7ff',
                cardBackground: '#c7d2fe',
                inputBackground: '#e0e7ff',

                // Tier 2: Page Sections
                pageBackgroundPrimary: '#c7d2fe',
                pageBackgroundSecondary: '#e0e7ff',
                pageBackgroundAlternate: '#818cf8',
                heroBackground: '#a5b4fc',
                heroGradientStart: '#c7d2fe',
                heroGradientEnd: '#a5b4fc',
                heroGradientEnabled: true,

                // Text & UI
                headerText: '#1e1b4b',
                footerText: '#a5b4fc',
                pageTitle: '#1e1b4b',
                pageSubtitle: '#6366f1',
                pageText: '#312e81',

                // Legacy
                infoBoxBg: '#ffffff',
                infoBoxText: '#1e1b4b',
                infoBoxLinkBg: '#eef2ff',
                infoBoxLinkText: '#1e1b4b',
                infoBoxLinkHover: '#818cf8',
                sectionHeader: '#eef2ff',
                heroText: '#1e1b4b'
            },
            dark: {
                // Tier 1: Global
                bodyBackground: '#03020a',
                headerBackground: '#0b081a',
                footerBackground: '#03020a',
                contentBackground: '#1e1b4b',
                borders: '#312e81',

                // Tier 1.5: Components
                accordionBackground: '#1e1b4b',
                buttonBackground: '#1e1b4b',
                cardBackground: '#1e1b4b',
                inputBackground: '#0b081a',

                // Tier 2: Page Sections
                pageBackgroundPrimary: '#060411',
                pageBackgroundSecondary: '#0a081a',
                pageBackgroundAlternate: '#4338ca',
                heroBackground: '#03020a',
                heroGradientStart: '#03020a',
                heroGradientEnd: '#1e1b4b',
                heroGradientEnabled: true,

                // Text & UI
                headerText: '#e0e7ff',
                footerText: '#818cf8',
                pageTitle: '#e0e7ff',
                pageSubtitle: '#818cf8',
                pageText: '#a5b4fc',

                // Legacy
                infoBoxBg: '#1e1b4b',
                infoBoxText: '#e0e7ff',
                infoBoxLinkBg: '#0b081a',
                infoBoxLinkText: '#e0e7ff',
                infoBoxLinkHover: '#c7d2fe',
                sectionHeader: '#1a163d',
                heroText: '#e0e7ff'
            }
        },
        typography: {
            fontSizeTitle: '60px',
            fontSizeSubtitle: '30px',
            fontSizeBase: '16px'
        }
    },
    {
        id: 'cyber',
        name: 'Neon Purple',
        description: 'Futuristic high-contrast dark theme with electric purple and deep indigo depths.',
        preview: 'bg-black',
        accent: '#e879f9',
        colors: {
            light: {
                // Tier 1: Global (True Electric Purple tint)
                bodyBackground: '#f3e8ff', // purple-100 (Cool violet, not pink)
                headerBackground: '#e9d5ff', // purple-200
                footerBackground: '#d8b4fe', // purple-300
                contentBackground: '#faf5ff', // purple-50
                borders: '#c084fc', // purple-400

                // Tier 1.5: Components (Vibrant Violet)
                accordionBackground: '#e9d5ff',
                buttonBackground: '#a855f7', // purple-500 (True bright purple)
                cardBackground: '#faf5ff',
                inputBackground: '#f3e8ff',

                // Tier 2: Page Sections
                pageBackgroundPrimary: '#faf5ff',
                pageBackgroundSecondary: '#f3e8ff',
                pageBackgroundAlternate: '#7e22ce', // purple-700 (Deep contrast)
                heroBackground: '#d8b4fe',
                heroGradientStart: '#e9d5ff',
                heroGradientEnd: '#a855f7',
                heroGradientEnabled: true,

                // Text & UI
                headerText: '#0c0a09',
                footerText: '#f5d0fe',
                pageTitle: '#0c0a09',
                pageSubtitle: '#d946ef',
                pageText: '#57534e',

                // Legacy
                infoBoxBg: '#ffffff',
                infoBoxText: '#0c0a09',
                infoBoxLinkBg: '#fae8ff',
                infoBoxLinkText: '#701a75',
                infoBoxLinkHover: '#d946ef',
                sectionHeader: '#f5f5f4',
                heroText: '#0c0a09'
            },
            dark: {
                // Tier 1: Global (Cyberpunk Deep Violet)
                bodyBackground: '#1e052d', // Deepest violet
                headerBackground: '#2e1065', // purple-950
                footerBackground: '#1e052d',
                contentBackground: '#3b0764', // purple-900 (Rich dark purple)
                borders: '#581c87', // purple-800

                // Tier 1.5: Components (Neon Glow)
                accordionBackground: '#4c1d95', // purple-900 lighter
                buttonBackground: '#7e22ce', // purple-700
                cardBackground: '#2e1065',
                inputBackground: '#1e052d',

                // Tier 2: Page Sections
                pageBackgroundPrimary: '#07001a',
                pageBackgroundSecondary: '#0a0025',
                pageBackgroundAlternate: '#701a75',
                heroBackground: '#020014',
                heroGradientStart: '#020014',
                heroGradientEnd: '#4a044e',
                heroGradientEnabled: true,

                // Text & UI
                headerText: '#fafafa',
                footerText: '#f0abfc',
                pageTitle: '#ffffff',
                pageSubtitle: '#f0abfc',
                pageText: '#d4d4d8',

                // Legacy
                infoBoxBg: '#1e1b4b',
                infoBoxText: '#fafafa',
                infoBoxLinkBg: '#0a0025',
                infoBoxLinkText: '#f0abfc',
                infoBoxLinkHover: '#22d3ee',
                sectionHeader: '#25103a',
                heroText: '#ffffff'
            }
        },
        typography: {
            fontSizeTitle: '60px',
            fontSizeSubtitle: '30px',
            fontSizeBase: '16px'
        }
    },
    {
        id: 'blogger',
        name: 'Reading Room',
        description: 'Warm, stone-based palette optimized for long-form content reading.',
        preview: 'bg-stone-100',
        accent: '#d6d3d1',
        colors: {
            light: {
                // Tier 1: Global (Deeper stone)
                bodyBackground: '#e7e5e4',
                headerBackground: '#d6d3d1',
                footerBackground: '#292524',
                contentBackground: '#d6d3d1',
                borders: '#a8a29e',

                // Tier 1.5: Components (Rich stone hierarchy)
                accordionBackground: '#d6d3d1',
                buttonBackground: '#e7e5e4',
                cardBackground: '#d6d3d1',
                inputBackground: '#e7e5e4',

                // Tier 2: Page Sections
                pageBackgroundPrimary: '#d6d3d1',
                pageBackgroundSecondary: '#e7e5e4',
                pageBackgroundAlternate: '#a8a29e',
                heroBackground: '#a8a29e',
                heroGradientStart: '#d6d3d1',
                heroGradientEnd: '#a8a29e',
                heroGradientEnabled: true,

                // Text & UI
                headerText: '#1c1917',
                footerText: '#d6d3d1',
                pageTitle: '#1c1917',
                pageSubtitle: '#78716c',
                pageText: '#44403c',

                // Legacy
                infoBoxBg: '#ffffff',
                infoBoxText: '#1c1917',
                infoBoxLinkBg: '#e7e5e4',
                infoBoxLinkText: '#1c1917',
                infoBoxLinkHover: '#44403c',
                sectionHeader: '#e7e5e4',
                heroText: '#1c1917'
            },
            dark: {
                // Tier 1: Global
                bodyBackground: '#0c0a09',
                headerBackground: '#1c1917',
                footerBackground: '#0c0a09',
                contentBackground: '#292524',
                borders: '#44403c',

                // Tier 1.5: Components
                accordionBackground: '#292524',
                buttonBackground: '#292524',
                cardBackground: '#292524',
                inputBackground: '#1c1917',

                // Tier 2: Page Sections
                pageBackgroundPrimary: '#141210',
                pageBackgroundSecondary: '#1c1917',
                pageBackgroundAlternate: '#57534e',
                heroBackground: '#0c0a09',
                heroGradientStart: '#0c0a09',
                heroGradientEnd: '#141210',
                heroGradientEnabled: true,

                // Text & UI
                headerText: '#f5f5f4',
                footerText: '#d6d3d1',
                pageTitle: '#f5f5f4',
                pageSubtitle: '#d6d3d1',
                pageText: '#a8a29e',

                // Legacy
                infoBoxBg: '#292524',
                infoBoxText: '#f5f5f4',
                infoBoxLinkBg: '#1c1917',
                infoBoxLinkText: '#f5f5f4',
                infoBoxLinkHover: '#e7e5e4',
                sectionHeader: '#2d2a28',
                heroText: '#1c1917'
            }
        },
        typography: {
            fontSizeTitle: '60px',
            fontSizeSubtitle: '30px',
            fontSizeBase: '16px'
        }
    },
    {
        id: 'studio',
        name: 'Monolith Rose',
        description: 'Minimalist high-fashion look with deep blacks and radical rose highlights.',
        preview: 'bg-black',
        accent: '#fb7185',
        colors: {
            light: {
                // Tier 1: Global (Deeper zinc)
                bodyBackground: '#e4e4e7',
                headerBackground: '#d4d4d8',
                footerBackground: '#09090b',
                contentBackground: '#d4d4d8',
                borders: '#a1a1aa',

                // Tier 1.5: Components (Rich zinc hierarchy)
                accordionBackground: '#d4d4d8',
                buttonBackground: '#e4e4e7',
                cardBackground: '#d4d4d8',
                inputBackground: '#e4e4e7',

                // Tier 2: Page Sections
                pageBackgroundPrimary: '#d4d4d8',
                pageBackgroundSecondary: '#e4e4e7',
                pageBackgroundAlternate: '#fb7185',
                heroBackground: '#a1a1aa',
                heroGradientStart: '#d4d4d8',
                heroGradientEnd: '#a1a1aa',
                heroGradientEnabled: true,

                // Text & UI
                headerText: '#09090b',
                footerText: '#d4d4d8',
                pageTitle: '#09090b',
                pageSubtitle: '#e11d48',
                pageText: '#18181b',

                // Legacy
                infoBoxBg: '#ffffff',
                infoBoxText: '#09090b',
                infoBoxLinkBg: '#e4e4e7',
                infoBoxLinkText: '#09090b',
                infoBoxLinkHover: '#f43f5e',
                sectionHeader: '#e4e4e7',
                heroText: '#000000'
            },
            dark: {
                // Tier 1: Global
                bodyBackground: '#09090b',
                headerBackground: '#000000',
                footerBackground: '#09090b',
                contentBackground: '#18181b',
                borders: '#27272a',

                // Tier 1.5: Components
                accordionBackground: '#18181b',
                buttonBackground: '#18181b',
                cardBackground: '#18181b',
                inputBackground: '#000000',

                // Tier 2: Page Sections
                pageBackgroundPrimary: '#000000',
                pageBackgroundSecondary: '#09090b',
                pageBackgroundAlternate: '#e11d48',
                heroBackground: '#000000',
                heroGradientStart: '#000000',
                heroGradientEnd: '#18181b',
                heroGradientEnabled: true,

                // Text & UI
                headerText: '#ffffff',
                footerText: '#71717a',
                pageTitle: '#ffffff',
                pageSubtitle: '#f43f5e',
                pageText: '#a1a1aa',

                // Legacy
                infoBoxBg: '#18181b',
                infoBoxText: '#ffffff',
                infoBoxLinkBg: '#000000',
                infoBoxLinkText: '#ffffff',
                infoBoxLinkHover: '#fb7185',
                sectionHeader: '#1a1a1a',
                heroText: '#ffffff'
            }
        },
        typography: {
            fontSizeTitle: '60px',
            fontSizeSubtitle: '30px',
            fontSizeBase: '16px'
        }
    }
];
