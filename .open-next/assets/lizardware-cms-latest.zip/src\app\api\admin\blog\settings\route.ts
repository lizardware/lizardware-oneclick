import { NextRequest, NextResponse } from "next/server";
import { getD1Database } from "@/lib/cloudflare";
import { getBlogSettings, updateBlogSetting } from "@/lib/blog-settings";

export async function GET() {
    try {
        const db = await getD1Database();
        if (!db) {
            return NextResponse.json({ error: "D1 Database not available" }, { status: 503 });
        }
        const settings = await getBlogSettings(db);
        return NextResponse.json({ settings }, { status: 200 });
    } catch (error) {
        return NextResponse.json({ error: (error as Error).message }, { status: 500 });
    }
}

export async function POST(request: NextRequest) {
    try {
        const db = await getD1Database();
        if (!db) {
            return NextResponse.json({ error: "D1 Database not available" }, { status: 503 });
        }
        const body = await request.json() as { key: string, value: string };
        if (!body.key || body.value === undefined) {
            return NextResponse.json({ error: "Missing required fields: key, value" }, { status: 400 });
        }
        await updateBlogSetting(db, body.key, body.value);
        return NextResponse.json({ success: true, message: `Setting ${body.key} updated` }, { status: 200 });
    } catch (error) {
        return NextResponse.json({ error: (error as Error).message }, { status: 500 });
    }
}
