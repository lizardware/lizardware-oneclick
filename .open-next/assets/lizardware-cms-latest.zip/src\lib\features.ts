// Server-side feature flag utilities
// DO NOT use 'use server' directive - this is imported by API routes

import { getD1Database } from './cloudflare';

/**
 * Get all feature flags from database
 * Works in all environments (dev, preview, production)
 */
export async function getFeatures(): Promise<Record<string, boolean>> {
    try {
        // Development: Use JSON file fallback
        if (process.env.NODE_ENV === 'development') {
            // Dynamic import to avoid bundling fs in Workers
            const fs = await import('fs');
            const path = await import('path');
            const featuresPath = path.join(process.cwd(), 'src/data/features.json');
            const data = JSON.parse(fs.readFileSync(featuresPath, 'utf-8'));
            return data;
        }

        // Preview/Production: Use D1
        const db = await getD1Database();
        if (!db) {
            console.warn('No D1 database binding found, returning defaults');
            return getDefaultFeatures();
        }

        const result = await db
            .prepare('SELECT feature_name, enabled FROM feature_flags')
            .all();

        const features: Record<string, boolean> = {};
        for (const row of result.results) {
            features[(row as any).feature_name] = (row as any).enabled === 1;
        }

        return features;
    } catch (error) {
        console.error('Failed to load features:', error);
        return getDefaultFeatures();
    }
}

/**
 * Check if a specific feature is enabled
 */
export async function checkFeature(name: string): Promise<boolean> {
    const features = await getFeatures();
    return features[name] ?? false;
}

/**
 * Default feature flags fallback
 */
function getDefaultFeatures(): Record<string, boolean> {
    return {
        blog: true,
        forum: true,
        gallery: false,
        newsletter: true,
        monetization: false,
        comments: true,
        services: true,
        menu: false,
        booking: false,
        customerPortal: false,
        analytics: true
    };
}
