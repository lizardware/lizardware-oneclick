'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Settings, FileCode, Database, BookOpen, GitBranch, FileText, ArrowLeft, Zap } from 'lucide-react';
import { HubSectionCard } from '@/components/admin/HubSectionCard';
import { Breadcrumbs } from '@/components/admin/Breadcrumbs';
import { AdminHeader } from '@/components/admin/AdminHeader';
import { HUB_PAGE_STYLES, type GradientColor } from '@/lib/admin-hub-styles';

export default function SystemHubPage() {
    const [version, setVersion] = useState('0.4.7');

    useEffect(() => {
        // Could fetch actual version from package.json API if needed
    }, []);

    const sections = [
        {
            title: 'Environment & Security',
            description: 'Env variables, GitHub connection, and setup locking',
            href: '/admin/system/advanced',
            icon: <Settings className="w-6 h-6" />,
            color: 'blue' as GradientColor
        },
        {
            title: 'Legacy Config',
            description: 'Direct access to raw configuration files',
            href: '/admin/system/config',
            icon: <FileCode className="w-6 h-6" />,
            color: 'purple' as GradientColor
        },
        {
            title: 'Database Logs',
            description: 'View system logs and database activity',
            href: '/admin/system/logs',
            icon: <Database className="w-6 h-6" />,
            status: 'coming-soon' as const,
            color: 'green' as GradientColor
        },
        {
            title: 'Updates',
            description: 'Check for system updates and database migrations',
            href: '/admin/system/updates',
            icon: <Zap className="w-6 h-6" />,
            color: 'orange' as GradientColor
        },
        {
            title: 'Documentation',
            description: 'Developer guides, API references, and technical docs',
            href: '/admin/system/docs',
            icon: <BookOpen className="w-6 h-6" />,
            color: 'cyan' as GradientColor
        },
        {
            title: 'Roadmap',
            description: 'View development roadmap and planned features',
            href: '/admin/system/roadmap',
            icon: <GitBranch className="w-6 h-6" />,
            color: 'pink' as GradientColor
        },
        {
            title: 'Changelog',
            description: 'Release history and version changelog',
            href: '/admin/system/changelog',
            icon: <FileText className="w-6 h-6" />,
            color: 'blue' as GradientColor
        }
    ];

    return (
        <div className={HUB_PAGE_STYLES.container}>
            <div className={`${HUB_PAGE_STYLES.maxWidth} ${HUB_PAGE_STYLES.topPadding} space-y-8`}>
                <AdminHeader
                    title={<>System <span className="text-blue-500">Core</span> ⚙️</>}
                    description="System settings, documentation, and technical configuration."
                    breadcrumbs={[
                        { label: 'Admin', href: '/admin' },
                        { label: 'System' }
                    ]}
                    badge={
                        <div className="px-3 py-1.5 bg-blue-500/10 border border-blue-500/20 rounded-lg text-[10px] font-bold uppercase tracking-widest text-blue-600 dark:text-blue-400 flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse"></span>
                            System Operative
                        </div>
                    }
                    actions={
                        <Link
                            href="/admin"
                            className="px-3 py-1.5 bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 rounded-lg text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
                        >
                            <ArrowLeft size={12} /> Back
                        </Link>
                    }
                />

                {/* System Info */}
                <div className={HUB_PAGE_STYLES.stats.grid}>
                    <div className="p-4 bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800">
                        <div className="text-xs text-zinc-500 dark:text-zinc-400 uppercase font-bold tracking-wider mb-1">Current Version</div>
                        <div className="text-2xl font-black text-zinc-900 dark:text-white">v{version}</div>
                    </div>
                    <div className="p-4 bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800">
                        <div className="text-xs text-zinc-500 dark:text-zinc-400 uppercase font-bold tracking-wider mb-1">Deployment</div>
                        <div className="text-2xl font-black text-green-600 dark:text-green-400">Edge</div>
                    </div>
                    <div className="p-4 bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800">
                        <div className="text-xs text-zinc-500 dark:text-zinc-400 uppercase font-bold tracking-wider mb-1">Status</div>
                        <div className="text-2xl font-black text-green-600 dark:text-green-400">Operational</div>
                    </div>
                </div>

                {/* Section Cards */}
                <div className={HUB_PAGE_STYLES.sectionCards.grid}>
                    {sections.map((section) => (
                        <HubSectionCard
                            key={section.href}
                            title={section.title}
                            description={section.description}
                            icon={section.icon}
                            gradient={section.color}
                            href={section.href}
                            status={section.status}
                        />
                    ))}
                </div>

                {/* Quick Links */}
                <div className="p-6 bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800">
                    <h3 className="text-sm font-black uppercase tracking-widest text-zinc-400 mb-4">Quick Technical Links</h3>
                    <div className="flex flex-wrap gap-3">
                        <Link href="/admin/testing" className="px-4 py-2 bg-orange-600 text-white rounded-lg text-sm font-bold hover:bg-orange-700 transition-colors">
                            Testing Hub
                        </Link>
                        <Link href="/setup" className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-bold hover:bg-blue-700 transition-colors">
                            Setup Wizard
                        </Link>
                        <a href="https://github.com/Lizardministrator/Lizardware-Dev" target="_blank" rel="noopener noreferrer" className="px-4 py-2 bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 rounded-lg text-sm font-bold hover:bg-zinc-800 dark:hover:bg-zinc-100 transition-colors">
                            GitHub Repository
                        </a>
                    </div>
                </div>
            </div>
        </div>
    );
}
