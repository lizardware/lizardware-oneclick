import { getDocBySlug } from '@/data/docs-content';
import MarkdownViewer from '@/components/ui/MarkdownViewer';
import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';

import { Breadcrumbs } from "@/components/admin/Breadcrumbs";
import { History, ArrowLeft, Terminal } from "lucide-react";
import { AdminHeader } from "@/components/admin/AdminHeader";

export const metadata: Metadata = {
    title: 'Changelog | Lizardware Admin',
};

export default function ChangelogPage() {
    const doc = getDocBySlug('changelog');

    if (!doc) {
        notFound();
    }

    return (
        <div className="max-w-7xl mx-auto px-6 pt-0 pb-12 space-y-8">

            <AdminHeader
                title={<>Release <span className="text-emerald-500">History</span></>}
                description="Tracking the system evolution and updates."
                breadcrumbs={[
                    { label: 'Admin', href: '/admin' },
                    { label: 'System', href: '/admin/system' },
                    { label: 'Changelog' }
                ]}
                badge={
                    <div className="px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-[10px] font-bold uppercase tracking-widest text-emerald-600 dark:text-emerald-400">
                        Version Control
                    </div>
                }
                actions={
                    <Link
                        href="/admin/system"
                        className="px-3 py-1.5 bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 rounded-lg text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
                    >
                        <ArrowLeft size={12} /> Back
                    </Link>
                }
            />

            <MarkdownViewer
                content={doc.content}
                title="Lizardware Changelog"
                description="Tracking our evolution from v0.1.0 to the edge beyond."
            />
        </div>
    );
}
