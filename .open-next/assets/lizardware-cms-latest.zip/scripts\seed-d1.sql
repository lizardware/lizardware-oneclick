-- Seed Categories
INSERT OR IGNORE INTO categories (id, name, slug, description) VALUES 
('uncategorized', 'Uncategorized', 'uncategorized', 'Default category for transmissions.'),
('technology', 'Technology', 'technology', 'Technical deep dives and edge architecture.'),
('vision', 'Vision', 'vision', 'The philosophy and future of Lizardware.');

-- Seed Author
INSERT OR IGNORE INTO authors (id, name, bio, avatar_url) VALUES 
('lizardministrator', 'Lizardministrator', 'The primary consciousness behind the Lizardware broadcast system.', 'https://raw.githubusercontent.com/Lizardware/brand-assets/main/avatars/lizard-bot.png');

-- Seed Posts
INSERT OR REPLACE INTO posts (slug, title, content, description, author_id, tags, date, status, category_id, updated_at) VALUES 
(
  'getting-started', 
  'Getting Started with Lizardware: Your Journey to the Edge', 
  'Welcome to the **Lizardware Ecosystem**! If you''re reading this, you''re ready to leave legacy content management behind and embrace the speed of the edge. This guide will walk you through the core concepts and help you send your first transmission.\n\n## What is Lizardware CMS?\n\nLizardware is a modern, edge-native content management system built specifically for **Cloudflare Pages**, **Workers**, and **D1**. It combines the developer experience of Git-backed content (MDX) with the user-friendliness of a professional admin dashboard.\n\n### Core Pillars\n*   **Speed:** Sub-100ms response times globally.\n*   **Security:** Edge-native protection and Git-backed auditing.\n*   **Ownership:** You own your data, your database, and your code.\n\n---\n\n## Your Management Suite\n\nOnce you log into the **Lizardware Command Center** (the admin dashboard), you have access to several powerful tools:\n\n### 1. The Blazing Blogger 🔥\nThis is where you''re writing right now. A high-performance editor designed for speed and SEO.\n*   **Drafts/Published:** Work in private until your signal is ready.\n*   **Metadata Control:** Fine-tune slugs, tags, and categories.\n\n### 2. Taxonomy & Personnel\nOrganize your site with precision:\n*   **Classifications:** Group posts into categories for better discovery.\n*   **Personnel Profiles:** Manage the identities of your contributors.\n\n### 3. Theme Transformer ✨\nInstantly change the "atmosphere" of your site.\n*   **Artstyles:** Switch between presets or create your own.\n*   **Fluid Layouts:** Adjust spacing and architecture in real-time.\n\n---\n\n## Next Steps to Mastery\n\nTo get the most out of your new platform, we recommend exploring these resources:\n\n1.  **[Core Features Guide](/features):** See what''s possible under the hood.\n2.  **[Developer Documentation](/docs):** Dive into the technical setup and Cloudflare bindings.\n3.  **[Theme Customization](/docs/10-customizing-appearance):** Learn how to make the site truly yours.\n\n> **Signal Tip:** Use the SEO Preview widget in the editor to ensure your transmissions look perfect on search engines and social media.\n\n---\n\n*This is a live transmission from the Lizardware Team. You can edit or delete this post anytime via your [Dashboard](/admin/blog).*', 
  'Everything you need to know to start broadcasting your signal using Lizardware CMS.', 
  'lizardministrator', 
  '["Guide","Quick Start","Lizardware"]', 
  '2025-01-13', 
  'published', 
  'uncategorized',
  datetime('now')
),
(
  'modern-content-management-on-the-edge', 
  'Modern Content Management on the Edge: A Technical Deep Dive', 
  'Speed isn''t just a vanity metric—it''s the foundation of a great user experience. In this post, we''re going under the hood to see how **Lizardware CMS** achieves industry-leading performance by moving compute and data to the edge.\n\n## The Stack: Next.js 15 + Cloudflare Workers\n\nLizardware CMS is built on **Next.js 15**, utilizing the latest features of the App Router. However, unlike traditional Next.js deployments that rely on a central Node.js server, we deploy to **Cloudflare Workers**.\n\n### Why Workers?\nCloudflare Workers provide a serverless execution environment that:\n*   **Starts in Milliseconds:** Zero cold starts mean your site is always ready.\n*   **Runs Globally:** Executes in 300+ cities around the world.\n*   **Edge Native:** Built on Chrome''s V8 engine for maximum efficiency.\n\nBy matching this with Next.js''s static and dynamic rendering capabilities, we get the best of both worlds: the flexibility of dynamic content with the speed of static delivery.\n\n---\n\n## Persistence with D1 Database\n\nOne of the biggest challenges with edge computing is database latency. If your compute is in London but your database is in New York, you''ve lost the edge advantage.\n\n**Cloudflare D1** changes that. As a globally distributed SQL database, D1 co-locates data with the compute engine. When your Worker runs, its data is already there.\n\n### Key Benefits of D1:\n1.  **Zero Latency:** Queries run in the same data center as the code.\n2.  **SQL Power:** Full SQLite compatibility for complex content relationships.\n3.  **Scalability:** Handles thousands of concurrent requests without breaking a sweat.\n\n> **Note:** We use a hybrid approach where post metadata is stored in D1 for fast searching and filtering, while the content itself remains Git-backed for version control.\n\n## Git-Backed Content for Ultimate Control\n\nWhile D1 handles our persistent metadata, the core content lives in your Git repository as MDX files. This **Git-based CMS** approach offers several critical advantages:\n\n*   **Version Control Everywhere:** Every change to a post is a commit.\n*   **Branching Workflows:** Work on new content in a feature branch before merging to production.\n*   **CI/CD Integration:** Content changes trigger automatic builds and global deployments.\n\n---\n\n## The Result: Sub-100ms Everywhere\n\nBy combining edge compute, distributed data, and optimized static delivery, Lizardware CMS delivers **sub-100ms Time to First Byte (TTFB)** to users anywhere in the world. This doesn''t just feel fast; it improves your bottom line:\n\n*   **SEO Rankings:** Google explicitly prioritizes fast-loading mobile sites.\n*   **Conversion Rates:** Users stay longer and engage more on sites that respond instantly.\n*   **Developer Happiness:** No more managing complex server clusters or horizontal scaling.\n\n## Build the Future with Us\n\nLizardware CMS is more than just a publishing tool—it''s a demonstration of what''s possible when you stop building for servers and start building for the **edge**.\n\n---\n\n*Questions about our architecture? [Check out our developer docs](/docs/developers/roadmap) or [contact us](/contact).*', 
  'How we leveraged Next.js, Cloudflare Workers, and D1 database to build the fastest CMS on the planet.', 
  'lizardministrator', 
  '["Technology","Cloudflare","Next.js","D1","Architecture"]', 
  '2025-12-19', 
  'published', 
  'technology',
  datetime('now')
),
(
  'why-we-built-lizardware-cms', 
  'Why We Built Lizardware CMS: Rethinking Content for the Edge', 
  'Writing on the web used to be simple. You had a server, a database, and a template. But as the web evolved, so did the complexity. Traditional CMS platforms became bloated, slow, and increasingly difficult to manage without a dedicated development team.\n\n> "The web is moving faster than ever, yet our content management tools are stuck in the synchronous past. We decided to build a bridge to the future."\n\nThat''s why we built **Lizardware CMS**.\n\n---\n\n## The Problem with Legacy Systems\n\nTraditional content management systems (like WordPress or Drupal) were designed for a different era. They rely on centralized servers and complex databases that introduce latency every time someone clicks a link. For modern businesses, this means:\n\n*   **Slow Page Loads:** Every request has to travel to a central server and back, often across oceans.\n*   **Security Vulnerabilities:** Large codebases and active databases are constant targets for SQL injection and XSS attacks.\n*   **Maintenance Overhead:** Constant updates, security patches, and server management distract you from your core mission.\n*   **Developer Bottlenecks:** Simple content changes often require code deployments or complex staging environments.\n\n## A New Approach: Edge-First Transmission\n\nLizardware CMS is built from the ground up to leverage the power of the **Edge**. By using Cloudflare Workers and D1 database, your content is distributed across **300+ global locations** instantly.\n\n### Why the Edge Matters\nWhen someone visits your site, their request is handled by the nearest data center. This results in **sub-100ms response times** globally. \n\n**No more waiting** for a server in Virginia to respond to a user in Tokyo. The signal is local, strong, and immediate.\n\n### Git-Backed & Developer Friendly\nWe believe content should be version-controlled. Lizardware keeps your content in sync with your code:\n1.  **Full Audit Trail:** Every change is recorded in Git.\n2.  **Instant Rollbacks:** One click to return to a previous state.\n3.  **Modern DX:** Build with Next.js 15 and Tailwind CSS 4.\n\n## Empowering Content Creators\n\nPerformance is important, but so is the experience of the people using the tool. Our intuitive block editor means marketing teams and writers can publish beautiful, SEO-optimized content without ever touching a line of code.\n\n### Creative Freedom\n*   **Rich Text Editor:** A focus-driven writing experience.\n*   **Live Previews:** See exactly how your "signal" looks before broadcasting.\n*   **Media Library:** Centralized asset management for all your transmissions.\n\n## The Lizard Philosophy\n\nLizardware CMS isn''t just a tool; it''s a philosophy of **speed, simplicity, and data ownership**. Your content is yours, stored in open standards, and delivered with unmatched performance.\n\nStay tuned as we continue to push the boundaries of what''s possible on the edge.\n\n---\n\n*Ready to join the revolution? [Explore our features](/features) or [Read the documentation](/docs).*', 
  'The story behind Lizardware CMS and why traditional content management systems are no longer enough for the modern web.', 
  'lizardministrator', 
  '["CMS","Edge Computing","Performance","Vision"]', 
  '2025-12-19', 
  'published', 
  'vision',
  datetime('now')
),
(
  'example-post', 
  'Draft Transmission: Formatting Reference', 
  'This is a **draft** transmission used to demonstrate the formatting capabilities of the Lizardware blogging engine.\n\n## Text Elements\n\nYou can use standard Markdown to style your text:\n*   **Bold text** for extreme emphasis.\n*   *Italic text* for subtle emphasis.\n*   ~~Strikethrough~~ for deprecated thoughts.\n*   `Inline code` for technical snippets.\n\n### Lists of Information\n\n1.  **Ordered Item One:** First in the sequence.\n2.  **Ordered Item Two:** Followed by the second.\n\n*   **Unordered Bullet:** For general points.\n*   **Another Bullet:** Highlighting features.\n\n---\n\n## Blockquotes & Callouts\n\n> "The edge is not just a location; it''s a performance state of mind." \n> — Anonymous Lizard\n\n## Technical Snippets\n\n```javascript\n// Example code block\nfunction broadcast(signal) {\n  console.log(`Sending: ${signal}`);\n  return true;\n}\n```\n\n---\n\n*This post is a draft and only visible to administrators.*', 
  'A reference guide for available markdown formatting in Lizardware CMS.', 
  'lizardministrator', 
  '["Template","Draft"]', 
  '2025-12-27', 
  'draft', 
  'uncategorized',
  datetime('now')
);
