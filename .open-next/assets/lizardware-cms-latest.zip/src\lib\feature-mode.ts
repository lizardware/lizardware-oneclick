export type FeatureMode = 'generic' | 'msp' | 'developer';

/**
 * Get current feature mode from environment variables
 * Checks FEATURE_MODE first, then NEXT_PUBLIC_FEATURE_MODE, defaults to 'generic'
 * 
 * @returns The current feature mode
 */
export function getFeatureMode(): FeatureMode {
    const mode = process.env.FEATURE_MODE || process.env.NEXT_PUBLIC_FEATURE_MODE || 'generic';
    return mode as FeatureMode;
}

/**
 * Check if the CMS is running in MSP mode
 * MSP mode enables MSP-specific features like "Services" instead of "Features"
 */
export function isMSPMode(): boolean {
    return getFeatureMode() === 'msp';
}

/**
 * Check if the CMS is running in developer mode
 * Developer mode shows additional developer-only features and documentation
 */
export function isDeveloperMode(): boolean {
    return getFeatureMode() === 'developer';
}

/**
 * Determines if developer-only features should be visible
 * Shows in dev/preview branches OR if FEATURE_MODE=developer explicitly set
 */
export function shouldShowDeveloperDocs(): boolean {
    // In development, allow developer docs
    if (process.env.NODE_ENV === 'development') {
        return true;
    }

    // Check Cloudflare Pages branch
    const branch = process.env.CF_PAGES_BRANCH;

    // Hide on main branch unless developer mode explicitly enabled
    if (branch === 'main') {
        return isDeveloperMode();
    }

    // Show on all other branches (preview, develop, feature branches)
    return true;
}

/**
 * Get feature mode for display purposes
 */
export function getFeatureModeLabel(): string {
    const mode = getFeatureMode();
    const labels: Record<FeatureMode, string> = {
        generic: 'Lizardware CMS',
        msp: 'MSP Edition',
        developer: 'Developer Mode'
    };
    return labels[mode];
}
