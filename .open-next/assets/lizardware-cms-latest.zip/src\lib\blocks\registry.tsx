import { BlockDefinition, BlockType } from '@/types/blocks';
import { Type, Grid, MessageSquare, HelpCircle, Mail, LayoutTemplate, Columns as ColumnsIcon, Box, Square, Minus } from 'lucide-react';
import Hero from '@/components/blocks/Hero';
import FeatureGrid from '@/components/blocks/FeatureGrid';
import Testimonial from '@/components/blocks/Testimonial';
import FAQ from '@/components/blocks/FAQ';
import ContactForm from '@/components/blocks/ContactForm';
import Columns from '@/components/blocks/Columns';
import Column from '@/components/blocks/Column';
import RichText from '@/components/blocks/RichText';
import Card from '@/components/blocks/Card';
import Spacer from '@/components/blocks/Spacer';

export const BLOCK_REGISTRY: Record<BlockType, BlockDefinition> = {
    'hero': {
        type: 'hero',
        label: 'Hero Section',
        icon: LayoutTemplate,
        component: Hero,
        defaultProps: {
            title: 'Welcome to Your Site',
            subtitle: 'Build amazing digital experiences with our modern CMS.',
            ctaText: 'Get Started',
            ctaLink: '/contact',
            alignment: 'center',
            paddingY: '5rem',
            maxWidth: '64rem'
        },
        fields: [
            { name: 'title', label: 'Title', type: 'text' },
            { name: 'subtitle', label: 'Subtitle', type: 'textarea' },
            { name: 'ctaText', label: 'Button Text', type: 'text' },
            { name: 'ctaLink', label: 'Button Link', type: 'text' },
            {
                name: 'alignment',
                label: 'Alignment',
                type: 'select',
                options: [
                    { label: 'Left', value: 'left' },
                    { label: 'Center', value: 'center' },
                    { label: 'Right', value: 'right' }
                ]
            },
            { name: 'paddingY', label: 'Vertical Padding', type: 'text' },
            { name: 'maxWidth', label: 'Max Width', type: 'text' }
        ]
    },
    'feature-grid': {
        type: 'feature-grid',
        label: 'Feature Grid',
        icon: Grid,
        component: FeatureGrid,
        defaultProps: {
            title: 'Our Features',
            columns: 3,
            features: [
                { title: 'Fast', description: 'Blazing fast performance on the edge.' },
                { title: 'Secure', description: 'Enterprise-grade security built-in.' },
                { title: 'Scalable', description: 'Grow without limits.' }
            ]
        },
        fields: [
            { name: 'title', label: 'Title', type: 'text' },
            {
                name: 'columns',
                label: 'Columns',
                type: 'select',
                options: [
                    { label: '2 Columns', value: 2 },
                    { label: '3 Columns', value: 3 },
                    { label: '4 Columns', value: 4 }
                ]
            }
        ]
    },
    'columns': {
        type: 'columns',
        label: 'Columns Layout',
        icon: ColumnsIcon,
        component: Columns,
        defaultProps: {
            columns: 2,
            gap: '2rem'
        },
        fields: [
            {
                name: 'columns',
                label: 'Columns',
                type: 'select',
                options: [
                    { label: '1 Column', value: 1 },
                    { label: '2 Columns', value: 2 },
                    { label: '3 Columns', value: 3 },
                    { label: '4 Columns', value: 4 }
                ]
            },
            { name: 'gap', label: 'Gap (e.g. 2rem)', type: 'text' }
        ]
    },
    'testimonial': {
        type: 'testimonial',
        label: 'Testimonials',
        icon: MessageSquare,
        component: Testimonial,
        defaultProps: {
            quote: "This CMS transformed how we manage content. It's simply incredible.",
            author: 'Jane Doe',
            role: 'CTO, TechCorp'
        },
        fields: [
            { name: 'quote', label: 'Quote', type: 'textarea' },
            { name: 'author', label: 'Author', type: 'text' },
            { name: 'role', label: 'Role', type: 'text' }
        ]
    },
    'faq': {
        type: 'faq',
        label: 'FAQ Accordion',
        icon: HelpCircle,
        component: FAQ,
        defaultProps: {
            title: 'Frequently Asked Questions',
            items: [
                { question: 'Is it free?', answer: 'Yes, for personal use.' },
                { question: 'Do you offer support?', answer: 'We offer 24/7 premium support.' }
            ]
        },
        fields: [
            { name: 'title', label: 'Title', type: 'text' }
        ]
    },
    'contact-form': {
        type: 'contact-form',
        label: 'Contact Form',
        icon: Mail,
        component: ContactForm,
        defaultProps: {
            title: 'Get in Touch',
            emailTo: 'support@example.com'
        },
        fields: [
            { name: 'title', label: 'Title', type: 'text' },
            { name: 'emailTo', label: 'Contact Email', type: 'text' }
        ]
    },
    'column': {
        type: 'column',
        label: 'Column Slot',
        icon: Box,
        component: Column,
        defaultProps: {},
        fields: []
    },
    'richtext': {
        type: 'richtext',
        label: 'Rich Text',
        icon: Type,
        component: RichText,
        defaultProps: {
            content: '<p>Enter your content here...</p>'
        },
        fields: [
            { name: 'content', label: 'Content', type: 'textarea' }
        ]
    },
    'card': {
        type: 'card',
        label: 'Card',
        icon: Square,
        component: Card,
        defaultProps: {
            title: 'Card Title',
            description: 'This is a description for the card.'
        },
        fields: [
            { name: 'icon', label: 'Emoji/Icon', type: 'text' },
            { name: 'title', label: 'Title', type: 'text' },
            { name: 'description', label: 'Description', type: 'textarea' },
            {
                name: 'variant',
                label: 'Variant',
                type: 'select',
                options: [
                    { label: 'Default', value: 'default' },
                    { label: 'Outlined', value: 'outlined' }
                ]
            }
        ]
    },
    'spacer': {
        type: 'spacer',
        label: 'Spacer',
        icon: Minus,
        component: Spacer,
        defaultProps: {
            height: '2rem'
        },
        fields: [
            { name: 'height', label: 'Height (e.g. 2rem)', type: 'text' }
        ]
    }
};

export const getBlockDefinition = (type: BlockType): BlockDefinition | undefined => {
    return BLOCK_REGISTRY[type];
};
