export type BlockType = 'hero' | 'feature-grid' | 'testimonial' | 'faq' | 'contact-form' | 'columns' | 'column' | 'richtext' | 'card' | 'spacer';

export interface BlockField {
    name: string;
    label: string;
    type: 'text' | 'textarea' | 'number' | 'select' | 'color' | 'image';
    options?: { label: string; value: any }[];
}

export interface Block {
    id: string;
    type: BlockType;
    props: Record<string, any>;
    styleOptions?: {
        background?: 'primary' | 'secondary' | 'alternate' | 'transparent';
        customBackground?: string;
        padding?: 'none' | 'small' | 'medium' | 'large';
        maxWidth?: 'standard' | 'full' | 'narrow';
    };
    children?: Block[];
}

export interface BlockDefinition {
    type: BlockType;
    label: string;
    icon: React.ComponentType<any>;
    defaultProps: Record<string, any>;
    fields?: BlockField[];
    // We will separate the actual component import to avoid circular deps or heavy bundles in some places if needed,
    // but for now keeping it simple.
    component?: React.ComponentType<any>;
}
