"use client";

import React from "react";

/**
 * Lizardware Logo - A unique, edge-first inspired lizard icon.
 * Features a geometric lizard tail wrapping a hexagonal node,
 * representing the connectivity and structure of the CMS.
 */
export const LizardLogo = ({ className = "h-10 w-10" }: { className?: string }) => {
    return (
        <svg
            viewBox="0 0 100 100"
            className={className}
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
        >
            <defs>
                <linearGradient id="logo-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#3b82f6" /> {/* Blue 500 */}
                    <stop offset="100%" stopColor="#10b981" /> {/* Emerald 500 */}
                </linearGradient>
                <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
                    <feGaussianBlur stdDeviation="1" result="blur" />
                    <feOffset dx="0" dy="1" result="offsetBlur" />
                    <feComponentTransfer>
                        <feFuncA type="linear" slope="0.4" />
                    </feComponentTransfer>
                    <feMerge>
                        <feMergeNode />
                        <feMergeNode in="SourceGraphic" />
                    </feMerge>
                </filter>
            </defs>

            {/* Hexagon Base - Pointy Top/Bottom */}
            <path
                d="M50 5 L90 27.5 V72.5 L50 95 L10 72.5 V27.5 L50 5 Z"
                fill="url(#logo-gradient)"
                fillOpacity="0.08"
                stroke="url(#logo-gradient)"
                strokeWidth="1.5"
            />

            {/* The "Branding" Lizard */}
            <g filter="url(#shadow)">
                {/* Main Body & Tail (Slimmed down) */}
                <path
                    d="M50 20 
                       C52 30, 52 40, 50 50 
                       C48 65, 60 70, 55 85 
                       C52 95, 45 92, 40 88"
                    stroke="url(#logo-gradient)"
                    strokeWidth="7"
                    strokeLinecap="round"
                    fill="none"
                />

                {/* Head (Connected) */}
                <path
                    d="M50 20 L44 24 Q50 12 56 24 Z"
                    fill="url(#logo-gradient)"
                />

                {/* Front Legs - Integrated Connection */}
                <path
                    d="M47 32 L34 26 M34 26 L30 29"
                    stroke="url(#logo-gradient)" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"
                />
                <path
                    d="M53 32 L66 26 M66 26 L70 29"
                    stroke="url(#logo-gradient)" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"
                />

                {/* Back Legs - Integrated Connection */}
                <path
                    d="M48 55 L36 62 M36 62 L32 60"
                    stroke="url(#logo-gradient)" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"
                />
                <path
                    d="M52 55 L64 62 M64 62 L68 60"
                    stroke="url(#logo-gradient)" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"
                />

                {/* Eyes */}
                <circle cx="48.5" cy="20.5" r="1" fill="white" />
                <circle cx="51.5" cy="20.5" r="1" fill="white" />
            </g>

            {/* Connectivity Nodes */}
            <circle cx="50" cy="5" r="2.5" fill="#3b82f6" />
            <circle cx="50" cy="95" r="2.5" fill="#10b981" />
        </svg>
    );
};
