import { Block } from '@/types/blocks';
import { arrayMove } from '@dnd-kit/sortable';

export function findBlockById(blocks: Block[], id: string): Block | null {
    for (const block of blocks) {
        if (block.id === id) return block;
        if (block.children) {
            const found = findBlockById(block.children, id);
            if (found) return found;
        }
    }
    return null;
}

export function updateBlockInTree(blocks: Block[], id: string, updates: Partial<Block>): Block[] {
    return blocks.map(block => {
        if (block.id === id) {
            return { ...block, ...updates };
        }
        if (block.children) {
            return { ...block, children: updateBlockInTree(block.children, id, updates) };
        }
        return block;
    });
}

export function deleteBlockFromTree(blocks: Block[], id: string): Block[] {
    return blocks.filter(block => block.id !== id).map(block => {
        if (block.children) {
            return { ...block, children: deleteBlockFromTree(block.children, id) };
        }
        return block;
    });
}

export function moveBlockInTree(blocks: Block[], id: string, direction: 'up' | 'down'): Block[] {
    const index = blocks.findIndex(b => b.id === id);
    if (index !== -1) {
        const newIndex = direction === 'up' ? index - 1 : index + 1;
        if (newIndex >= 0 && newIndex < blocks.length) {
            return arrayMove(blocks, index, newIndex);
        }
        return blocks;
    }

    return blocks.map(block => {
        if (block.children) {
            return { ...block, children: moveBlockInTree(block.children, id, direction) };
        }
        return block;
    });
}

export function insertBlockInTree(blocks: Block[], overId: string, newBlock: Block): Block[] {
    // Top-level check
    if (overId === 'canvas-droppable') {
        return [...blocks, newBlock];
    }

    // Check if overId is a block in this level
    const overIndex = blocks.findIndex(b => b.id === overId);
    if (overIndex !== -1) {
        const overBlock = blocks[overIndex];

        // Special case: If dropping OVER a 'column' or 'columns' block, 
        // we might want to append to its children instead of inserting AFTER it.
        // But for now, let's keep it simple: insert after.
        return [
            ...blocks.slice(0, overIndex + 1),
            newBlock,
            ...blocks.slice(overIndex + 1)
        ];
    }

    // Recurse into children
    return blocks.map(block => {
        if (block.children) {
            // Check if overId is the parent block itself (meaning we want to append to children)
            if (overId === `droppable-${block.id}`) {
                return { ...block, children: [...block.children, newBlock] };
            }
            return { ...block, children: insertBlockInTree(block.children, overId, newBlock) };
        }

        // If block is a potential container but has no children array yet
        if (overId === `droppable-${block.id}`) {
            return { ...block, children: [newBlock] };
        }

        return block;
    });
}

/**
 * Deep clones a block and all its children with new unique IDs
 */
export function duplicateBlockInTree(blocks: Block[], id: string): Block[] {
    const index = blocks.findIndex(b => b.id === id);
    if (index !== -1) {
        const blockToDuplicate = blocks[index];
        const newBlock = cloneBlockWithNewIds(blockToDuplicate);
        return [
            ...blocks.slice(0, index + 1),
            newBlock,
            ...blocks.slice(index + 1)
        ];
    }

    return blocks.map(block => {
        if (block.children) {
            return { ...block, children: duplicateBlockInTree(block.children, id) };
        }
        return block;
    });
}

function cloneBlockWithNewIds(block: Block): Block {
    return {
        ...block,
        id: crypto.randomUUID(),
        children: block.children?.map(child => cloneBlockWithNewIds(child))
    };
}
