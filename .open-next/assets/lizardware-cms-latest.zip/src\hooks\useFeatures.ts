'use client';

import { useState, useEffect } from 'react';

/**
 * Client-side hook to check feature flags
 * Fetches from /api/admin/features
 */
export function useFeature(name: string): boolean {
    const [enabled, setEnabled] = useState(true); // Optimistic default

    useEffect(() => {
        fetch('/api/admin/features')
            .then(res => res.json())
            .then(data => setEnabled((data as Record<string, boolean>)[name] ?? false))
            .catch(() => setEnabled(false));
    }, [name]);

    return enabled;
}

/**
 * Client-side hook to get all feature flags
 */
export function useFeatures(): Record<string, boolean> {
    const [features, setFeatures] = useState<Record<string, boolean>>({
        blog: true,
        forum: true,
        gallery: false,
        newsletter: true,
        monetization: false,
        comments: true,
        services: true,
        menu: false,
        booking: false,
        customerPortal: false,
        analytics: true
    });

    useEffect(() => {
        fetch('/api/admin/features')
            .then(res => res.json())
            .then(data => setFeatures(prev => ({ ...prev, ...(data as Record<string, boolean>) })))
            .catch(err => console.error('Failed to load features:', err));
    }, []);

    return features;
}
