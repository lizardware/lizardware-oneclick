import { NextResponse } from 'next/server';

export async function GET() {
    // Check for build-time/system tokens
    const hasToken = !!process.env.CLOUDFLARE_API_TOKEN;
    const accountId = process.env.CLOUDFLARE_ACCOUNT_ID || null;

    // Check multiple project name sources
    const projectName = process.env.CF_PROJECT_NAME ||
        process.env.CF_PAGES_PROJECT_NAME ||
        process.env.CLOUDFLARE_PROJECT_NAME ||
        null;

    return NextResponse.json({
        hasToken,
        accountId,
        projectName
    });
}
