'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { createPortal } from 'react-dom';
import { Save, Search, Share2, Twitter, Layout, Shield, Info, Globe, ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import { Breadcrumbs } from "@/components/admin/Breadcrumbs";
import { AdminLoadingState } from "@/components/admin/AdminLoadingState";
import AdminCommandBar, { CommandBarButton } from "@/components/admin/AdminCommandBar";
import VariableInput from '@/components/admin/VariableInput';
import { AdminHeader } from '@/components/admin/AdminHeader';

export default function SEOSettingsPage() {
    const router = useRouter();
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle');
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        setMounted(true);
    }, []);

    // State matching seo_global_settings table
    const [settings, setSettings] = useState({
        title_template: '{page_title} | {site_name}',
        meta_description_template: '',
        og_image_default: '',
        twitter_card_type: 'summary_large_image',
        google_search_console_code: '',
        bing_webmaster_code: '',
    });

    useEffect(() => {
        fetch('/api/admin/seo/wizard')
            .then(res => res.json())
            .then((data: any) => {
                if (data.settings) {
                    setSettings({
                        title_template: data.settings.title_template || '{page_title} | {site_name}',
                        meta_description_template: data.settings.meta_description_template || '',
                        og_image_default: data.settings.og_image_default || '',
                        twitter_card_type: data.settings.twitter_card_type || 'summary_large_image',
                        google_search_console_code: data.settings.google_search_console_code || '',
                        bing_webmaster_code: data.settings.bing_webmaster_code || '',
                    });
                }
                setLoading(false);
            })
            .catch(() => setLoading(false));
    }, []);

    const handleSave = async () => {
        setSaving(true);
        setStatus('idle');
        try {
            const res = await fetch('/api/admin/seo/wizard', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    titleTemplate: settings.title_template,
                    metaDescriptionTemplate: settings.meta_description_template,
                    defaultOgImage: settings.og_image_default,
                    twitterCardType: settings.twitter_card_type,
                    googleSearchConsoleCode: settings.google_search_console_code,
                    bingWebmasterCode: settings.bing_webmaster_code,
                }),
            });

            if (res.ok) {
                setStatus('success');
                setTimeout(() => setStatus('idle'), 3000);
            } else {
                setStatus('error');
            }
        } catch (error) {
            setStatus('error');
        } finally {
            setSaving(false);
        }
    };

    if (loading) return (
        <div className="max-w-7xl mx-auto px-6 pt-4 pb-12 space-y-8">
            <AdminLoadingState message="Connecting to meta server..." />
        </div>
    );

    return (
        <div className="max-w-7xl mx-auto px-6 pt-4 pb-12 space-y-8">

            <AdminHeader
                title={<>Global <span className="text-green-500 text-shadow-glow">Meta</span></>}
                description="Configure site-wide meta tags, search appearance templates, and social sharing defaults."
                breadcrumbs={[
                    { label: 'Admin', href: '/admin' },
                    { label: 'Growth', href: '/admin/growth' },
                    { label: 'SEO', href: '/admin/growth/seo' },
                    { label: 'Meta' }
                ]}
                badge={
                    <div className="px-3 py-1.5 bg-green-500/10 border border-green-500/20 rounded-lg text-[10px] font-bold uppercase tracking-widest text-green-600 dark:text-green-400 flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
                        Indexable & Social Ready
                    </div>
                }
                actions={
                    <Link
                        href="/admin/growth/seo"
                        className="px-4 py-2 bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 rounded-xl text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
                    >
                        <ArrowLeft size={12} />
                        Back
                    </Link>
                }
            />

            <div className="grid grid-cols-1 gap-6">
                {/* Search Appearance */}
                <div className="bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-2xl p-6 shadow-sm space-y-6">
                    <div className="flex items-center gap-3 mb-2">
                        <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
                            <Search className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                        </div>
                        <h3 className="font-bold text-lg dark:text-white">Search Appearance</h3>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                        <VariableInput
                            label="Title Template"
                            value={settings.title_template}
                            onChange={(val) => setSettings({ ...settings, title_template: val })}
                            placeholder="{page_title} | {site_name}"
                        />

                        <VariableInput
                            label="Default Meta Description"
                            value={settings.meta_description_template}
                            onChange={(val) => setSettings({ ...settings, meta_description_template: val })}
                            rows={3}
                            placeholder="A brief summary of your site..."
                        />
                    </div>
                </div>

                {/* Social Sharing */}
                <div className="bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-2xl p-6 shadow-sm space-y-6">
                    <div className="flex items-center gap-3 mb-2">
                        <div className="p-2 bg-purple-100 dark:bg-purple-900/30 rounded-lg">
                            <Share2 className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                        </div>
                        <h3 className="font-bold text-lg dark:text-white">Social Sharing (Open Graph)</h3>
                    </div>

                    <div className="space-y-4">
                        <div className="space-y-2">
                            <label className="text-sm font-bold dark:text-slate-300">Default Share Image (URL)</label>
                            <input
                                type="text"
                                value={settings.og_image_default}
                                onChange={(e) => setSettings({ ...settings, og_image_default: e.target.value })}
                                className="w-full p-3 border border-slate-200 dark:border-zinc-800 rounded-xl bg-slate-50 dark:bg-zinc-950 focus:ring-2 focus:ring-primary/20 outline-none"
                                placeholder="https://example.com/og-image.jpg"
                            />
                        </div>

                        <div className="space-y-2">
                            <label className="text-sm font-bold dark:text-slate-300 flex items-center gap-2">
                                <Twitter size={14} /> Twitter Card Type
                            </label>
                            <select
                                value={settings.twitter_card_type}
                                onChange={(e) => setSettings({ ...settings, twitter_card_type: e.target.value })}
                                className="w-full p-3 border border-slate-200 dark:border-zinc-800 rounded-xl bg-slate-50 dark:bg-zinc-950 focus:ring-2 focus:ring-primary/20 outline-none"
                            >
                                <option value="summary">Summary (Small Image)</option>
                                <option value="summary_large_image">Summary with Large Image</option>
                                <option value="app">App Store / Play Store</option>
                            </select>
                        </div>
                    </div>
                </div>

                {/* Verification Codes */}
                <div className="bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-2xl p-6 shadow-sm space-y-6">
                    <div className="flex items-center gap-3 mb-2">
                        <div className="p-2 bg-emerald-100 dark:bg-emerald-900/30 rounded-lg">
                            <Shield className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                        </div>
                        <h3 className="font-bold text-lg dark:text-white">Webmaster Verification</h3>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                            <label className="text-sm font-bold dark:text-slate-300">Google Search Console</label>
                            <input
                                type="text"
                                value={settings.google_search_console_code}
                                onChange={(e) => setSettings({ ...settings, google_search_console_code: e.target.value })}
                                className="w-full p-3 border border-slate-200 dark:border-zinc-800 rounded-xl bg-slate-50 dark:bg-zinc-950 focus:ring-2 focus:ring-primary/20 outline-none font-mono text-xs"
                                placeholder="Verification code or meta tag content"
                            />
                        </div>

                        <div className="space-y-2">
                            <label className="text-sm font-bold dark:text-slate-300">Bing Webmaster Tools</label>
                            <input
                                type="text"
                                value={settings.bing_webmaster_code}
                                onChange={(e) => setSettings({ ...settings, bing_webmaster_code: e.target.value })}
                                className="w-full p-3 border border-slate-200 dark:border-zinc-800 rounded-xl bg-slate-50 dark:bg-zinc-950 focus:ring-2 focus:ring-primary/20 outline-none font-mono text-xs"
                                placeholder="Verification code"
                            />
                        </div>
                    </div>
                </div>
            </div>

            <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-2xl p-6 flex gap-4">
                <Info className="text-blue-600 shrink-0" size={24} />
                <p className="text-sm text-blue-800 dark:text-blue-300 leading-relaxed">
                    These settings are applied site-wide. Individual pages and blog posts can override these values in their respective editors.
                    <strong> Changes take effect immediately </strong> across the global edge network.
                </p>
            </div>

            {/* Admin Actions Portal */}
            {mounted && (() => {
                const portalTarget = document.getElementById('admin-actions-portal');
                if (!portalTarget) return null;

                return createPortal(
                    <div className="flex items-center gap-2 pointer-events-auto">
                        <CommandBarButton
                            onClick={handleSave}
                            disabled={saving}
                            label={saving ? "Saving..." : status === 'success' ? "Saved!" : "Save Settings"}
                            variant="primary"
                            icon={<Save size={14} />}
                        />
                    </div>,
                    portalTarget
                );
            })()}
        </div>
    );
}
