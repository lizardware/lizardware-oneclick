import { Plus } from 'lucide-react';

interface FAQItem {
    question: string;
    answer: string;
}

interface FAQBlockProps {
    title?: string;
    items: FAQItem[];
}

export default function FAQ({ title = 'Pool FAQ', items = [] }: FAQBlockProps) {
    return (
        <div className="w-full">
            {title && (
                <h2 className="text-3xl font-bold text-center mb-12 text-page-title">
                    {title}
                </h2>
            )}

            <div className="space-y-4">
                {items.map((item, idx) => (
                    <details
                        key={idx}
                        className="group bg-card-background rounded-2xl border border-borders overflow-hidden"
                    >
                        <summary className="flex items-center justify-between p-6 cursor-pointer list-none">
                            <span className="font-semibold text-page-title">{item.question}</span>
                            <span className="bg-header-background/50 p-2 rounded-full text-page-subtitle group-open:rotate-45 transition-transform">
                                <Plus size={16} />
                            </span>
                        </summary>
                        <div className="px-6 pb-6 text-page-text leading-relaxed border-t border-borders pt-4">
                            {item.answer}
                        </div>
                    </details>
                ))}
            </div>
        </div>
    );
}
