import { NextResponse } from 'next/server';
import { getD1Database } from '@/lib/cloudflare';

export async function GET() {
    try {
        // In local development, we ignore D1 check
        if (process.env.NODE_ENV === 'development') {
            return NextResponse.json({ initialized: true });
        }

        const db = await getD1Database();
        if (!db) {
            return NextResponse.json({ initialized: false });
        }

        const result = await db.prepare(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='site_config'"
        ).first();

        return NextResponse.json({ initialized: !!result });
    } catch (error) {
        console.error('Database check error:', error);
        return NextResponse.json({ initialized: false });
    }
}
