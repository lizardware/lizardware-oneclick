'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { ChevronRight, ChevronLeft, Check, Sparkles, Globe, Share2, Search } from 'lucide-react';
import { SERPPreview } from '@/components/seo/SERPPreview';
import { usePopup } from '@/components/admin/AdminPopupProvider';

type WizardStep = 'welcome' | 'identity' | 'meta-defaults' | 'search-console' | 'social' | 'complete';

interface WizardData {
    businessName: string;
    businessType:
    | 'Organization'
    | 'LocalBusiness'
    | 'Person'
    | 'OnlineBusiness'
    | 'Restaurant'
    | 'Store'
    | 'ProfessionalService'
    | 'MedicalBusiness'
    | 'HealthAndBeautyBusiness'
    | 'HomeAndConstructionBusiness'
    | 'RealEstateAgent'
    | 'NewsMediaOrganization'
    | 'EducationalOrganization';
    logoUrl: string;
    socialProfiles: {
        facebook: string;
        twitter: string;
        linkedin: string;
        instagram: string;
    };
    titleTemplate: string;
    metaDescriptionTemplate: string;
    googleSearchConsoleCode: string;
    bingWebmasterCode: string;
    defaultOgImage: string;
    twitterCardType: 'summary' | 'summary_large_image';
}

const STEPS: Record<WizardStep, { title: string; description: string; icon: any }> = {
    welcome: { title: 'Welcome', description: 'Get started with SEO', icon: Sparkles },
    identity: { title: 'Site Identity', description: 'Who you are', icon: Globe },
    'meta-defaults': { title: 'Meta Tags', description: 'Search appearance', icon: Search },
    'search-console': { title: 'Search Console', description: 'Verification', icon: Check },
    social: { title: 'Social Sharing', description: 'How links look', icon: Share2 },
    complete: { title: 'Complete', description: 'All set!', icon: Check },
};

const STEP_ORDER: WizardStep[] = ['welcome', 'identity', 'meta-defaults', 'search-console', 'social', 'complete'];

export default function SEOSetupWizard() {
    const router = useRouter();
    const popup = usePopup();
    const [currentStep, setCurrentStep] = useState<WizardStep>('welcome');
    const [saving, setSaving] = useState(false);

    const [data, setData] = useState<WizardData>({
        businessName: '',
        businessType: 'Organization',
        logoUrl: '',
        socialProfiles: {
            facebook: '',
            twitter: '',
            linkedin: '',
            instagram: '',
        },
        titleTemplate: '{page_title} | {site_name}',
        metaDescriptionTemplate: '',
        googleSearchConsoleCode: '',
        bingWebmasterCode: '',
        defaultOgImage: '',
        twitterCardType: 'summary_large_image',
    });

    const currentStepIndex = STEP_ORDER.indexOf(currentStep);
    const progress = ((currentStepIndex + 1) / STEP_ORDER.length) * 100;

    const goNext = () => {
        if (currentStepIndex < STEP_ORDER.length - 1) {
            setCurrentStep(STEP_ORDER[currentStepIndex + 1]);
        }
    };

    const goBack = () => {
        if (currentStepIndex > 0) {
            setCurrentStep(STEP_ORDER[currentStepIndex - 1]);
        }
    };

    const handleComplete = async () => {
        setSaving(true);
        try {
            // Save settings to database
            await fetch('/api/admin/seo/wizard', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data),
            });

            // Mark wizard as completed
            router.push('/admin/growth/seo?wizardComplete=true');
        } catch (error) {
            console.error('Failed to save wizard data:', error);
            popup.error('Failed to commit SEO configurations. Please retry.');
        } finally {
            setSaving(false);
        }
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-zinc-950 dark:to-zinc-900 flex items-center justify-center p-4">
            <div className="w-full max-w-3xl">
                {/* Progress Bar */}
                <div className="mb-8">
                    <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-bold text-slate-600 dark:text-slate-400">
                            Step {currentStepIndex + 1} of {STEP_ORDER.length}
                        </span>
                        <span className="text-sm font-bold text-primary">
                            {Math.round(progress)}% Complete
                        </span>
                    </div>
                    <div className="h-2 bg-slate-200 dark:bg-zinc-800 rounded-full overflow-hidden">
                        <div
                            className="h-full bg-gradient-to-r from-primary to-purple-500 transition-all duration-500 ease-out"
                            style={{ width: `${progress}%` }}
                        />
                    </div>
                </div>

                {/* Main Card */}
                <div className="bg-white dark:bg-zinc-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-zinc-800 overflow-hidden">
                    {/* Step Content */}
                    <div className="p-8">
                        {currentStep === 'welcome' && (
                            <WelcomeStep onNext={goNext} />
                        )}

                        {currentStep === 'identity' && (
                            <IdentityStep data={data} setData={setData} />
                        )}

                        {currentStep === 'meta-defaults' && (
                            <MetaDefaultsStep data={data} setData={setData} />
                        )}

                        {currentStep === 'search-console' && (
                            <SearchConsoleStep data={data} setData={setData} />
                        )}

                        {currentStep === 'social' && (
                            <SocialStep data={data} setData={setData} />
                        )}

                        {currentStep === 'complete' && (
                            <CompleteStep onComplete={handleComplete} saving={saving} />
                        )}
                    </div>

                    {/* Navigation */}
                    {currentStep !== 'welcome' && currentStep !== 'complete' && (
                        <div className="border-t border-slate-200 dark:border-zinc-800 p-6 flex items-center justify-between bg-slate-50 dark:bg-zinc-900/50">
                            <button
                                onClick={goBack}
                                className="flex items-center gap-2 px-4 py-2 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white font-bold transition-colors"
                            >
                                <ChevronLeft size={20} />
                                Back
                            </button>

                            <button
                                onClick={goNext}
                                className="flex items-center gap-2 px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 font-bold shadow-lg shadow-primary/20 transition-all hover:scale-105"
                            >
                                Continue
                                <ChevronRight size={20} />
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

// ===== STEP COMPONENTS =====

function WelcomeStep({ onNext }: { onNext: () => void }) {
    return (
        <div className="text-center space-y-6">
            <div className="w-20 h-20 mx-auto bg-gradient-to-br from-primary to-purple-500 rounded-full flex items-center justify-center">
                <Sparkles size={40} className="text-white" />
            </div>

            <h1 className="text-4xl font-black text-slate-900 dark:text-white">
                Welcome to SEO Setup!
            </h1>

            <p className="text-lg text-slate-600 dark:text-slate-400 max-w-xl mx-auto">
                Let's optimize your site for search engines in just a few minutes. We'll help you configure the essentials to improve your visibility on Google, Bing, and social media.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-12 max-w-2xl mx-auto">
                <div className="p-4 bg-slate-50 dark:bg-zinc-800 rounded-lg">
                    <div className="text-2xl mb-2">🎯</div>
                    <h3 className="font-bold mb-1 dark:text-white">Better Rankings</h3>
                    <p className="text-sm text-slate-600 dark:text-slate-400">Appear higher in search results</p>
                </div>
                <div className="p-4 bg-slate-50 dark:bg-zinc-800 rounded-lg">
                    <div className="text-2xl mb-2">📈</div>
                    <h3 className="font-bold mb-1 dark:text-white">More Traffic</h3>
                    <p className="text-sm text-slate-600 dark:text-slate-400">Attract organic visitors</p>
                </div>
                <div className="p-4 bg-slate-50 dark:bg-zinc-800 rounded-lg">
                    <div className="text-2xl mb-2">⚡</div>
                    <h3 className="font-bold mb-1 dark:text-white">Quick Setup</h3>
                    <p className="text-sm text-slate-600 dark:text-slate-400">Only takes 5 minutes</p>
                </div>
            </div>

            <button
                onClick={onNext}
                className="mt-8 flex items-center gap-2 px-8 py-4 bg-primary text-white rounded-lg hover:bg-primary/90 font-black text-lg shadow-lg shadow-primary/30 transition-all hover:scale-105 mx-auto"
            >
                Get Started
                <ChevronRight size={24} />
            </button>
        </div>
    );
}

function IdentityStep({ data, setData }: { data: WizardData; setData: (data: WizardData) => void }) {
    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-2">Site Identity</h2>
                <p className="text-slate-600 dark:text-slate-400">Tell search engines who you are</p>
            </div>

            <div>
                <label className="block text-sm font-bold mb-2 dark:text-slate-300">
                    Business/Site Name <span className="text-red-500">*</span>
                </label>
                <input
                    type="text"
                    value={data.businessName}
                    onChange={(e) => setData({ ...data, businessName: e.target.value })}
                    placeholder="Lizardware CMS"
                    className="w-full p-3 border border-slate-200 dark:border-zinc-700 rounded-lg bg-white dark:bg-zinc-800 dark:text-white"
                />
            </div>

            <div>
                <label className="block text-sm font-bold mb-2 dark:text-slate-300">Business Type</label>
                <select
                    value={data.businessType}
                    onChange={(e) => setData({ ...data, businessType: e.target.value as any })}
                    className="w-full p-3 border border-slate-200 dark:border-zinc-700 rounded-lg bg-white dark:bg-zinc-800 dark:text-white"
                >
                    <optgroup label="General">
                        <option value="Organization">Organization (Company/Non-profit)</option>
                        <option value="OnlineBusiness">Online Business (SaaS/E-commerce)</option>
                        <option value="Person">Person (Personal Brand/Portfolios)</option>
                    </optgroup>
                    <optgroup label="Local Business">
                        <option value="LocalBusiness">General Local Business</option>
                        <option value="Restaurant">Restaurant/Cafe</option>
                        <option value="Store">Retail Store</option>
                        <option value="ProfessionalService">Professional Service (Law/Finance)</option>
                        <option value="MedicalBusiness">Medical/Healthcare</option>
                        <option value="HealthAndBeautyBusiness">Health/Beauty (Salon/Spa)</option>
                        <option value="HomeAndConstructionBusiness">Home/Construction (Plumber/Electrician)</option>
                        <option value="RealEstateAgent">Real Estate</option>
                    </optgroup>
                    <optgroup label="Organization Subtypes">
                        <option value="NewsMediaOrganization">News/Media Organization</option>
                        <option value="EducationalOrganization">Educational Organization/School</option>
                    </optgroup>
                </select>
            </div>

            <div>
                <label className="block text-sm font-bold mb-2 dark:text-slate-300">Social Media Profiles</label>
                <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">Helps search engines connect your site to your social presence</p>

                <div className="space-y-3">
                    <input
                        type="url"
                        placeholder="Facebook URL (optional)"
                        value={data.socialProfiles.facebook}
                        onChange={(e) => setData({ ...data, socialProfiles: { ...data.socialProfiles, facebook: e.target.value } })}
                        className="w-full p-2 border border-slate-200 dark:border-zinc-700 rounded-lg bg-white dark:bg-zinc-800 dark:text-white text-sm"
                    />
                    <input
                        type="url"
                        placeholder="Twitter/X URL (optional)"
                        value={data.socialProfiles.twitter}
                        onChange={(e) => setData({ ...data, socialProfiles: { ...data.socialProfiles, twitter: e.target.value } })}
                        className="w-full p-2 border border-slate-200 dark:border-zinc-700 rounded-lg bg-white dark:bg-zinc-800 dark:text-white text-sm"
                    />
                    <input
                        type="url"
                        placeholder="LinkedIn URL (optional)"
                        value={data.socialProfiles.linkedin}
                        onChange={(e) => setData({ ...data, socialProfiles: { ...data.socialProfiles, linkedin: e.target.value } })}
                        className="w-full p-2 border border-slate-200 dark:border-zinc-700 rounded-lg bg-white dark:bg-zinc-800 dark:text-white text-sm"
                    />
                </div>
            </div>
        </div>
    );
}

function MetaDefaultsStep({ data, setData }: { data: WizardData; setData: (data: WizardData) => void }) {
    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-2">Default Meta Tags</h2>
                <p className="text-slate-600 dark:text-slate-400">Set fallback templates for pages without custom meta tags</p>
            </div>

            <div>
                <label className="block text-sm font-bold mb-2 dark:text-slate-300">Title Template</label>
                <input
                    type="text"
                    value={data.titleTemplate}
                    onChange={(e) => setData({ ...data, titleTemplate: e.target.value })}
                    placeholder="{page_title} | {site_name}"
                    className="w-full p-3 border border-slate-200 dark:border-zinc-700 rounded-lg bg-white dark:bg-zinc-800 dark:text-white font-mono text-sm"
                />
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Use <code className="px-1 bg-slate-100 dark:bg-zinc-800 rounded">{'{page_title}'}</code> and <code className="px-1 bg-slate-100 dark:bg-zinc-800 rounded">{'{site_name}'}</code> as placeholders
                </p>
            </div>

            <div>
                <label className="block text-sm font-bold mb-2 dark:text-slate-300">Default Meta Description (Optional)</label>
                <textarea
                    value={data.metaDescriptionTemplate}
                    onChange={(e) => setData({ ...data, metaDescriptionTemplate: e.target.value })}
                    placeholder="A fallback description for pages without custom meta descriptions..."
                    rows={3}
                    className="w-full p-3 border border-slate-200 dark:border-zinc-700 rounded-lg bg-white dark:bg-zinc-800 dark:text-white"
                />
                <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    {data.metaDescriptionTemplate.length} / 160 characters
                </div>
            </div>

            <div>
                <h3 className="text-sm font-bold mb-3 dark:text-slate-300">Preview in Google</h3>
                <SERPPreview
                    title={data.titleTemplate.replace('{page_title}', 'Sample Page').replace('{site_name}', data.businessName || 'Your Site')}
                    url="sample-page"
                    description={data.metaDescriptionTemplate || undefined}
                    siteName="yoursite.com"
                />
            </div>
        </div>
    );
}

function SearchConsoleStep({ data, setData }: { data: WizardData; setData: (data: WizardData) => void }) {
    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-2">Search Console Verification</h2>
                <p className="text-slate-600 dark:text-slate-400">Connect your site to Google and Bing (optional but recommended)</p>
            </div>

            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                <h4 className="font-bold text-blue-900 dark:text-blue-300 mb-2">💡 Why verify?</h4>
                <ul className="text-sm text-blue-800 dark:text-blue-400 space-y-1">
                    <li>• Submit your sitemap for faster indexing</li>
                    <li>• See how Google sees your site</li>
                    <li>• Get alerts about issues</li>
                </ul>
            </div>

            <div>
                <label className="block text-sm font-bold mb-2 dark:text-slate-300">Google Search Console Verification Code</label>
                <input
                    type="text"
                    value={data.googleSearchConsoleCode}
                    onChange={(e) => setData({ ...data, googleSearchConsoleCode: e.target.value })}
                    placeholder="google1234567890abcdef.html or meta tag code"
                    className="w-full p-3 border border-slate-200 dark:border-zinc-700 rounded-lg bg-white dark:bg-zinc-800 dark:text-white font-mono text-sm"
                />
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Optional - Get this from <a href="https://search.google.com/search-console" target="_blank" rel="noopener noreferrer" className="text-primary underline">Google Search Console</a>
                </p>
            </div>

            <div>
                <label className="block text-sm font-bold mb-2 dark:text-slate-300">Bing Webmaster Tools Code</label>
                <input
                    type="text"
                    value={data.bingWebmasterCode}
                    onChange={(e) => setData({ ...data, bingWebmasterCode: e.target.value })}
                    placeholder="Bing verification code"
                    className="w-full p-3 border border-slate-200 dark:border-zinc-700 rounded-lg bg-white dark:bg-zinc-800 dark:text-white font-mono text-sm"
                />
            </div>

            <div className="p-4 bg-slate-50 dark:bg-zinc-800 rounded-lg border border-slate-200 dark:border-zinc-700">
                <p className="text-sm text-slate-600 dark:text-slate-400">
                    <strong className="dark:text-white">Skip this step?</strong> You can verify later from the SEO dashboard.
                </p>
            </div>
        </div>
    );
}

function SocialStep({ data, setData }: { data: WizardData; setData: (data: WizardData) => void }) {
    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-2">Social Sharing</h2>
                <p className="text-slate-600 dark:text-slate-400">Control how your pages look when shared on social media</p>
            </div>

            <div>
                <label className="block text-sm font-bold mb-2 dark:text-slate-300">Twitter Card Type</label>
                <select
                    value={data.twitterCardType}
                    onChange={(e) => setData({ ...data, twitterCardType: e.target.value as any })}
                    className="w-full p-3 border border-slate-200 dark:border-zinc-700 rounded-lg bg-white dark:bg-zinc-800 dark:text-white"
                >
                    <option value="summary">Summary (square image)</option>
                    <option value="summary_large_image">Summary Large Image (wide image)</option>
                </select>
            </div>

            <div className="p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                <h4 className="font-bold text-green-900 dark:text-green-300 mb-2">✅ You're almost done!</h4>
                <p className="text-sm text-green-800 dark:text-green-400">
                    Individual pages can override these defaults. You can always update these settings later from the SEO dashboard.
                </p>
            </div>
        </div>
    );
}

function CompleteStep({ onComplete, saving }: { onComplete: () => void; saving: boolean }) {
    return (
        <div className="text-center space-y-6">
            <div className="w-20 h-20 mx-auto bg-gradient-to-br from-green-500 to-emerald-500 rounded-full flex items-center justify-center">
                <Check size={40} className="text-white" />
            </div>

            <h1 className="text-4xl font-black text-slate-900 dark:text-white">
                You're All Set!
            </h1>

            <p className="text-lg text-slate-600 dark:text-slate-400 max-w-xl mx-auto">
                Your site is now optimized for search engines. We've configured the essentials, and you can fine-tune individual pages as needed.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8 max-w-lg mx-auto">
                <div className="p-4 bg-slate-50 dark:bg-zinc-800 rounded-lg text-left">
                    <h4 className="font-bold mb-2 dark:text-white">✅ What's Configured</h4>
                    <ul className="text-sm text-slate-600 dark:text-slate-400 space-y-1">
                        <li>• Default meta tags</li>
                        <li>• Social sharing settings</li>
                        <li>• Search engine verification</li>
                        <li>• XML sitemap (automatic)</li>
                    </ul>
                </div>

                <div className="p-4 bg-slate-50 dark:bg-zinc-800 rounded-lg text-left">
                    <h4 className="font-bold mb-2 dark:text-white">📝 Next Steps</h4>
                    <ul className="text-sm text-slate-600 dark:text-slate-400 space-y-1">
                        <li>• Add meta tags to blog posts</li>
                        <li>• Submit sitemap to Google</li>
                        <li>• Monitor SEO health</li>
                        <li>• Add schema markup</li>
                    </ul>
                </div>
            </div>

            <button
                onClick={onComplete}
                disabled={saving}
                className="mt-8 px-8 py-4 bg-gradient-to-r from-primary to-purple-500 text-white rounded-lg hover:opacity-90 font-black text-lg shadow-lg shadow-primary/30 transition-all disabled:opacity-50"
            >
                {saving ? 'Saving...' : 'Go to SEO Dashboard'}
            </button>
        </div>
    );
}
