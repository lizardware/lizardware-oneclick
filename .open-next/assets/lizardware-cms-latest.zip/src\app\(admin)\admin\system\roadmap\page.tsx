import { getDocBySlug } from '@/data/docs-content';
import MarkdownViewer from '@/components/ui/MarkdownViewer';
import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';

import { Breadcrumbs } from "@/components/admin/Breadcrumbs";
import { Compass, ArrowLeft, Milestone } from "lucide-react";
import { AdminHeader } from "@/components/admin/AdminHeader";

export const metadata: Metadata = {
    title: 'Development Roadmap | Lizardware Admin',
};

export default function RoadmapPage() {
    const doc = getDocBySlug('developers/roadmap');

    if (!doc) {
        notFound();
    }

    return (
        <div className="max-w-7xl mx-auto px-6 pt-0 pb-12 space-y-8">

            <AdminHeader
                title={<>Project <span className="text-purple-500">Roadmap</span></>}
                description="Strategic vision for the future of the platform."
                breadcrumbs={[
                    { label: 'Admin', href: '/admin' },
                    { label: 'System', href: '/admin/system' },
                    { label: 'Roadmap' }
                ]}
                badge={
                    <div className="px-3 py-1.5 bg-purple-500/10 border border-purple-500/20 rounded-lg text-[10px] font-bold uppercase tracking-widest text-purple-600 dark:text-purple-400">
                        Planning Active
                    </div>
                }
                actions={
                    <Link
                        href="/admin/system"
                        className="px-3 py-1.5 bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 rounded-lg text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
                    >
                        <ArrowLeft size={12} /> Back
                    </Link>
                }
            />

            <MarkdownViewer
                content={doc.content}
                title="Lizardware Roadmap"
                description="Our vision for the future of agentic coding and CMS excellence."
            />
        </div>
    );
}
