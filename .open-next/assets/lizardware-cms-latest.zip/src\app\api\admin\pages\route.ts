import { NextRequest, NextResponse } from "next/server";
import { getAllPages, upsertPage } from "@/lib/pages";
import { Page } from "@/types/page";

// GET /api/admin/pages - List all pages
export async function GET(request: NextRequest) {
    try {
        const includeStatus = request.nextUrl.searchParams.get("status") as "draft" | "published" | undefined;
        const pages = await getAllPages(includeStatus);

        return NextResponse.json({ pages });
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error("Pages fetch error:", message);

        return NextResponse.json(
            { error: message },
            { status: 500 }
        );
    }
}

// POST /api/admin/pages - Create new page
export async function POST(request: NextRequest) {
    try {
        const page = await request.json() as Page;

        // Validate required fields
        if (!page.slug || !page.title || !page.content) {
            return NextResponse.json(
                { error: "Missing required fields: slug, title, content" },
                { status: 400 }
            );
        }

        await upsertPage(page);

        return NextResponse.json({
            success: true,
            message: "Page created successfully",
        });
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error("Page creation error:", message);

        return NextResponse.json(
            { error: message },
            { status: 500 }
        );
    }
}
