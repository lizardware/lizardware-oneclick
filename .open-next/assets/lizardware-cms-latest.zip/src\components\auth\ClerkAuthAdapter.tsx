'use client';

import { useUser, useClerk } from '@clerk/nextjs';
import { AuthProviderContext, AuthUser } from '@/context/AuthContext';
import { ReactNode } from 'react';

export function ClerkAuthAdapter({ children }: { children: ReactNode }) {
    const { user, isLoaded, isSignedIn } = useUser();
    const { signOut, openSignIn } = useClerk();

    const adaptedUser: AuthUser | null = user ? {
        id: user.id,
        email: user.primaryEmailAddress?.emailAddress,
        name: user.fullName || user.username || 'User',
        imageUrl: user.imageUrl,
        role: (user.publicMetadata?.role as string) || 'viewer',
    } : null;

    return (
        <AuthProviderContext.Provider value={{
            user: adaptedUser,
            isLoaded,
            isSignedIn: !!isSignedIn,
            signIn: () => openSignIn(),
            signOut: () => signOut(),
        }}>
            {children}
        </AuthProviderContext.Provider>
    );
}
