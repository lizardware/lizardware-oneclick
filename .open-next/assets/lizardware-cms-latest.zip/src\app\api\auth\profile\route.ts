import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser, sanitizeUser } from '@/lib/auth';
import { getD1Database } from '@/lib/cloudflare';

// Get current user profile
export async function GET(request: NextRequest) {
    try {
        const currentUser = getCurrentUser(request);

        if (!currentUser) {
            return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
        }

        const db = await getD1Database();
        if (!db) {
            return NextResponse.json({ error: 'Database unavailable' }, { status: 500 });
        }

        const user = await db.prepare(
            'SELECT * FROM forum_users WHERE id = ?'
        ).bind(currentUser.userId).first();

        if (!user) {
            return NextResponse.json({ error: 'User not found' }, { status: 404 });
        }

        return NextResponse.json({ user: sanitizeUser(user as any) });

    } catch (error) {
        console.error('Get profile error:', error);
        return NextResponse.json({ error: 'Failed to get profile' }, { status: 500 });
    }
}

// Update user profile
export async function PATCH(request: NextRequest) {
    try {
        const currentUser = getCurrentUser(request);

        if (!currentUser) {
            return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
        }

        const { displayName, bio, avatarUrl }: {
            displayName?: string;
            bio?: string;
            avatarUrl?: string;
        } = await request.json();

        const db = await getD1Database();
        if (!db) {
            return NextResponse.json({ error: 'Database unavailable' }, { status: 500 });
        }

        // Build update query dynamically
        const updates: string[] = [];
        const values: any[] = [];

        if (displayName !== undefined) {
            updates.push('display_name = ?');
            values.push(displayName);
        }

        if (bio !== undefined) {
            updates.push('bio = ?');
            values.push(bio);
        }

        if (avatarUrl !== undefined) {
            updates.push('avatar_url = ?');
            values.push(avatarUrl);
        }

        if (updates.length === 0) {
            return NextResponse.json({ error: 'No fields to update' }, { status: 400 });
        }

        values.push(currentUser.userId);

        await db.prepare(`
      UPDATE forum_users 
      SET ${updates.join(', ')} 
      WHERE id = ?
    `).bind(...values).run();

        // Fetch updated user
        const updatedUser = await db.prepare(
            'SELECT * FROM forum_users WHERE id = ?'
        ).bind(currentUser.userId).first();

        return NextResponse.json({
            success: true,
            user: sanitizeUser(updatedUser as any)
        });

    } catch (error) {
        console.error('Update profile error:', error);
        return NextResponse.json({ error: 'Failed to update profile' }, { status: 500 });
    }
}
