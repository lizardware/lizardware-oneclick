"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Search, PenLine, Calendar, ExternalLink, CheckSquare, Square, Trash2, Eye, EyeOff, X } from "lucide-react";
import { AdminLoadingState } from "./AdminLoadingState";
import { createPortal } from "react-dom";
import { CommandBarButton } from "./AdminCommandBar";
import { PostMeta as Post } from "@/types/blog";
import { usePopup } from "./AdminPopupProvider";

interface Category {
    id: string;
    name: string;
    slug: string;
}

interface MediaAsset {
    id: string;
    url: string;
}

export default function BlogList() {
    const popup = usePopup();
    const [posts, setPosts] = useState<Post[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [searchTerm, setSearchTerm] = useState("");
    const [statusFilter, setStatusFilter] = useState<'all' | 'draft' | 'published'>('all');
    const [categories, setCategories] = useState<Category[]>([]);
    const [media, setMedia] = useState<Record<string, string>>({});
    const [categoryFilter, setCategoryFilter] = useState('all');
    const [sortBy, setSortBy] = useState<'date' | 'title' | 'views'>('date');
    const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
    const [selectedSlugs, setSelectedSlugs] = useState<Set<string>>(new Set());
    const [isBulkOperating, setIsBulkOperating] = useState(false);
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        setMounted(true);
        async function fetchData() {
            try {
                const [postsRes, categoriesRes, mediaRes] = await Promise.all([
                    fetch("/api/admin/blog"),
                    fetch("/api/admin/blog/categories"),
                    fetch("/api/admin/media")
                ]);

                if (postsRes.ok) {
                    const data = await postsRes.json() as Post[];
                    setPosts(data);
                }

                if (categoriesRes.ok) {
                    const data = await categoriesRes.json() as { categories: Category[] };
                    setCategories(data.categories || []);
                }

                if (mediaRes.ok) {
                    const data = await mediaRes.json() as { media: MediaAsset[] };
                    const mediaMap: Record<string, string> = {};
                    (data.media || []).forEach((m: MediaAsset) => {
                        mediaMap[m.id] = m.url;
                    });
                    setMedia(mediaMap);
                }
            } catch (err) {
                setError(err instanceof Error ? err.message : "Unknown error");
                console.error("Error fetching data:", err);
            } finally {
                setLoading(false);
            }
        }
        fetchData();
    }, []);

    const toggleSelect = (slug: string, e?: React.MouseEvent) => {
        if (e) {
            e.preventDefault();
            e.stopPropagation();
        }
        const newSelected = new Set(selectedSlugs);
        if (newSelected.has(slug)) {
            newSelected.delete(slug);
        } else {
            newSelected.add(slug);
        }
        setSelectedSlugs(newSelected);
    };

    const toggleSelectAll = () => {
        if (selectedSlugs.size === filteredPosts.length) {
            setSelectedSlugs(new Set());
        } else {
            setSelectedSlugs(new Set(filteredPosts.map(p => p.slug)));
        }
    };

    const handleBulkAction = async (action: 'delete' | 'status', status?: 'published' | 'draft') => {
        if (selectedSlugs.size === 0) return;

        const confirmMsg = action === 'delete'
            ? `Are you sure you want to delete ${selectedSlugs.size} transmissions?`
            : `Update ${selectedSlugs.size} transmissions to ${status}?`;

        const confirmed = await popup.confirm(confirmMsg, { isDanger: action === 'delete' });
        if (!confirmed) return;

        setIsBulkOperating(true);
        try {
            const response = await fetch("/api/admin/blog/bulk", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    action,
                    slugs: Array.from(selectedSlugs),
                    status
                })
            });

            if (!response.ok) throw new Error("Bulk operation failed");

            // Refresh list
            const freshResponse = await fetch("/api/admin/blog");
            const data = await freshResponse.json() as Post[];
            setPosts(data);
            setSelectedSlugs(new Set());
            popup.success('Transmissions processed successfully.');
        } catch (err) {
            console.error(err);
            popup.error("Failed to complete bulk operation.");
        } finally {
            setIsBulkOperating(false);
        }
    };

    const filteredPosts = posts.filter(post => {
        // Status Filter
        if (statusFilter !== 'all' && post.status !== statusFilter) return false;

        // Category Filter
        if (categoryFilter !== 'all' && post.category_id !== categoryFilter) return false;

        // Search Filter
        if (searchTerm) {
            const query = searchTerm.toLowerCase();
            const matchesTitle = post.title.toLowerCase().includes(query);
            const matchesSlug = post.slug.toLowerCase().includes(query);
            const matchesDesc = post.description?.toLowerCase().includes(query);
            const matchesAuthor = post.author?.toLowerCase().includes(query);
            if (!matchesTitle && !matchesSlug && !matchesDesc && !matchesAuthor) return false;
        }

        return true;
    });

    const sortedPosts = [...filteredPosts].sort((a, b) => {
        let comparison = 0;
        if (sortBy === 'date') {
            comparison = new Date(a.date || 0).getTime() - new Date(b.date || 0).getTime();
        } else if (sortBy === 'title') {
            comparison = a.title.localeCompare(b.title);
        } else if (sortBy === 'views') {
            comparison = (a.view_count || 0) - (b.view_count || 0);
        }
        return sortOrder === 'asc' ? comparison : -comparison;
    });

    if (loading) {
        return <AdminLoadingState message="Fetching transmissions..." />;
    }

    if (error) {
        return (
            <div className="bg-red-50 dark:bg-red-900/10 border border-red-100 dark:border-red-900/30 rounded-3xl p-8 text-center">
                <div className="max-w-md mx-auto">
                    <span className="text-3xl mb-4 block">⚠️</span>
                    <h3 className="text-lg font-bold text-red-600 dark:text-red-400 mb-2">Signal Interrupted</h3>
                    <p className="text-xs text-red-500/70 mb-6 font-mono">{error}</p>
                    <button onClick={() => window.location.reload()} className="px-6 py-2 bg-red-500 hover:bg-red-600 text-white font-bold rounded-xl text-xs uppercase tracking-widest transition-all">
                        Retry Connection
                    </button>
                </div>
            </div>
        );
    }

    if (posts.length === 0) {
        return (
            <div className="bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-3xl p-12 text-center shadow-sm">
                <div className="max-w-md mx-auto">
                    <span className="text-4xl mb-4 block opacity-50">📰</span>
                    <h3 className="text-lg font-bold text-page-title mb-2">The Press is Silent</h3>
                    <p className="text-sm text-gray-400 mb-6">No broadcasts discovered. Initialize your first transmission.</p>
                </div>
            </div>
        );
    }

    return (
        <div className="space-y-6">


            {/* Control Bar - Standardized */}
            <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between bg-white dark:bg-zinc-900 border border-borders p-4 rounded-2xl shadow-sm">
                <div className="flex flex-wrap items-center gap-2">
                    {/* Status Tabs */}
                    <div className="flex items-center gap-1 bg-gray-50 dark:bg-zinc-950 p-1 rounded-xl border border-borders/50">
                        {(['all', 'published', 'draft'] as const).map((filter) => (
                            <button
                                key={filter}
                                onClick={() => setStatusFilter(filter)}
                                className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${statusFilter === filter
                                    ? 'bg-purple-600 text-white shadow-sm'
                                    : 'text-gray-400 hover:text-gray-600 dark:hover:text-gray-300'
                                    }`}
                            >
                                {filter} ({filter === 'all' ? posts.length : posts.filter(p => p.status === filter).length})
                            </button>
                        ))}
                    </div>

                    {/* Category Dropdown */}
                    <div className="flex items-center gap-2">
                        <select
                            value={categoryFilter}
                            onChange={(e) => setCategoryFilter(e.target.value)}
                            className="bg-gray-50 dark:bg-zinc-950 border border-borders/50 rounded-xl px-3 py-1.5 text-xs font-bold text-gray-500 outline-none focus:border-purple-500 transition-colors cursor-pointer"
                        >
                            <option value="all">All Categories</option>
                            {categories.map(cat => (
                                <option key={cat.id} value={cat.id}>{cat.name}</option>
                            ))}
                        </select>
                    </div>

                    {/* Sort Dropdown */}
                    <div className="flex items-center gap-2">
                        <select
                            value={`${sortBy}-${sortOrder}`}
                            onChange={(e) => {
                                const [newSortBy, newSortOrder] = e.target.value.split('-') as [any, any];
                                setSortBy(newSortBy);
                                setSortOrder(newSortOrder);
                            }}
                            className="bg-gray-50 dark:bg-zinc-950 border border-borders/50 rounded-xl px-3 py-1.5 text-xs font-bold text-gray-500 outline-none focus:border-purple-500 transition-colors cursor-pointer"
                        >
                            <option value="date-desc">Newest First</option>
                            <option value="date-asc">Oldest First</option>
                            <option value="title-asc">Title A-Z</option>
                            <option value="title-desc">Title Z-A</option>
                            {posts.some(p => (p.view_count || 0) > 0) && (
                                <>
                                    <option value="views-desc">Most Viewed</option>
                                    <option value="views-asc">Least Viewed</option>
                                </>
                            )}
                        </select>
                    </div>
                </div>

                {/* Search Bar */}
                <div className="relative w-full md:w-64">
                    <input
                        type="text"
                        placeholder="Search posts..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full bg-gray-50 dark:bg-zinc-950 border border-borders/50 rounded-xl pl-9 pr-4 py-1.5 text-xs font-medium text-page-text placeholder:text-gray-400 outline-none focus:border-purple-500 transition-colors shadow-inner"
                    />
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={14} />
                    {searchTerm && (
                        <button
                            onClick={() => setSearchTerm("")}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                        >
                            <X size={14} />
                        </button>
                    )}
                </div>
            </div>

            {/* Selection Info Bar */}
            {selectedSlugs.size > 0 && (
                <div className="flex items-center justify-between bg-purple-500/10 border border-purple-500/20 p-3 rounded-xl animate-in fade-in slide-in-from-top-2">
                    <div className="flex items-center gap-3">
                        <button
                            onClick={toggleSelectAll}
                            className="p-1.5 hover:bg-purple-500/10 rounded-lg transition-colors"
                        >
                            {selectedSlugs.size === filteredPosts.length ? <CheckSquare size={18} className="text-purple-600" /> : <Square size={18} className="text-gray-400" />}
                        </button>
                        <span className="text-xs font-bold text-purple-600 uppercase tracking-widest">
                            {selectedSlugs.size} Items Selected
                        </span>
                    </div>
                    <button
                        onClick={() => setSelectedSlugs(new Set())}
                        className="text-gray-400 hover:text-gray-600 p-1"
                    >
                        <X size={16} />
                    </button>
                </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {sortedPosts.length === 0 ? (
                    <div className="md:col-span-2 bg-info-box-bg border border-borders border-dashed rounded-[2rem] p-12 text-center">
                        <div className="max-w-md mx-auto">
                            <span className="text-4xl mb-4 block opacity-50">🔍</span>
                            <h3 className="text-lg font-bold text-page-title mb-2">No Matching Transmissions</h3>
                            <p className="text-sm text-page-text/60 mb-6">Adjust your orbital filters or search criteria.</p>
                            <button
                                onClick={() => { setSearchTerm(""); setStatusFilter("all"); setCategoryFilter("all"); }}
                                className="text-xs font-bold uppercase tracking-widest text-purple-600 hover:underline"
                            >
                                Clear All Parameters
                            </button>
                        </div>
                    </div>
                ) : sortedPosts.map((post) => (
                    <div key={post.slug} className="relative group">
                        {/* Selector Checkbox - Floating Above Card */}
                        <button
                            onClick={(e) => toggleSelect(post.slug, e)}
                            className={`absolute -top-2 -left-2 z-20 p-2 rounded-xl border shadow-lg transition-all transform scale-0 group-hover:scale-100 active:scale-90 ${selectedSlugs.has(post.slug)
                                ? 'bg-purple-600 border-purple-600 text-white scale-100'
                                : 'bg-white dark:bg-zinc-800 border-borders text-gray-400 hover:text-gray-600'
                                }`}
                        >
                            {selectedSlugs.has(post.slug) ? <CheckSquare size={16} /> : <Square size={16} />}
                        </button>

                        <Link
                            href={`/admin/editor/blog/${post.slug}`}
                            className={`block bg-white dark:bg-zinc-900 border rounded-3xl p-6 transition-all duration-500 h-full flex flex-col group/card ${selectedSlugs.has(post.slug)
                                ? 'border-indigo-600 ring-4 ring-indigo-500/10 shadow-2xl shadow-indigo-500/20'
                                : 'border-gray-100 dark:border-zinc-800 hover:border-indigo-500/50 hover:-translate-y-2 hover:shadow-[0_20px_50px_rgba(79,70,229,0.15)] dark:hover:shadow-[0_20px_50px_rgba(79,70,229,0.1)]'
                                }`}
                        >
                            {/* Card Header: Thumbnail & Status */}
                            <div className="flex items-center gap-4 mb-4">
                                <div className="relative w-12 h-12 rounded-xl overflow-hidden bg-gray-50 dark:bg-zinc-800 flex-shrink-0 border border-gray-100 dark:border-zinc-700">
                                    {post.featured_image_id && (media[post.featured_image_id] || post.featured_image_id.startsWith('http')) ? (
                                        <img
                                            src={post.featured_image_id.startsWith('http') ? post.featured_image_id : media[post.featured_image_id]}
                                            alt=""
                                            className="w-full h-full object-cover"
                                        />
                                    ) : (
                                        <div className={`w-full h-full flex items-center justify-center text-lg ${post.status === 'published'
                                            ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-900/20'
                                            : 'bg-amber-50 text-amber-600 dark:bg-amber-900/20'
                                            }`}>
                                            {post.status === 'published' ? '📡' : '📝'}
                                        </div>
                                    )}
                                </div>

                                <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-2 mb-1">
                                        <span className={`px-2 py-0.5 text-[8px] uppercase tracking-widest font-black rounded-full ${post.status === 'published'
                                            ? 'bg-green-500/10 text-green-600 dark:text-green-400'
                                            : 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400'
                                            }`}>
                                            {post.status === 'published' ? 'Published' : 'Draft'}
                                        </span>
                                        {post.category_id && categories.find(c => c.id === post.category_id) && (
                                            <span className="px-2 py-0.5 text-[8px] uppercase tracking-widest font-black rounded-full bg-purple-500/10 text-purple-600 dark:text-purple-400">
                                                {categories.find(c => c.id === post.category_id)?.name}
                                            </span>
                                        )}
                                    </div>
                                    <div className="flex items-center gap-2 text-[10px] text-gray-400 font-bold uppercase tracking-widest">
                                        <Calendar size={10} className="mb-0.5" />
                                        {post.date ? new Date(post.date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : 'No Date'}
                                    </div>
                                </div>

                                <div className="hidden sm:block">
                                    <button
                                        onClick={(e) => {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            window.open(`/blog/${post.slug}`, '_blank');
                                        }}
                                        className="text-[9px] font-black uppercase tracking-widest text-purple-600 hover:bg-purple-600/10 px-2 py-1 rounded transition-colors"
                                    >
                                        View →
                                    </button>
                                </div>
                            </div>

                            {/* Post Title */}
                            <h3 className="text-xl font-black text-page-title group-hover:text-purple-600 transition-colors mb-2 line-clamp-2 leading-tight">
                                {post.title}
                            </h3>

                            {/* Post Excerpt */}
                            {post.description && (
                                <p className="text-sm text-page-text/70 line-clamp-2 mb-4 font-medium leading-relaxed">
                                    {post.description}
                                </p>
                            )}

                            {/* Card Footer */}
                            <div className="flex items-center justify-between mt-auto pt-4 border-t border-borders/50">
                                <div className="flex items-center gap-3">
                                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest bg-gray-50 dark:bg-zinc-950 px-2 py-1 rounded-md">
                                        /{post.slug}
                                    </p>
                                    {post.view_count !== undefined && post.view_count > 0 && (
                                        <span className="text-[10px] text-purple-500 font-bold flex items-center gap-1">
                                            <ExternalLink size={10} /> {post.view_count}
                                        </span>
                                    )}
                                </div>
                                <span className="text-[10px] font-black uppercase tracking-widest text-page-text/50 group-hover:text-purple-600 flex items-center gap-1.5 transition-all">
                                    Edit Broadcast <span className="transform group-hover:translate-x-1 transition-transform">→</span>
                                </span>
                            </div>
                        </Link>
                    </div>
                ))}
            </div>

            {/* Bulk Actions Portal */}
            {mounted && selectedSlugs.size > 0 && (() => {
                const portalTarget = document.getElementById('admin-actions-portal');
                if (!portalTarget) return null;

                return createPortal(
                    <div className="flex items-center gap-2 pointer-events-auto bg-white dark:bg-zinc-800 p-2 rounded-2xl border border-borders shadow-2xl animate-in fade-in slide-in-from-bottom-4 ring-4 ring-black/5">
                        <CommandBarButton
                            onClick={() => handleBulkAction('status', 'published')}
                            label="Publish"
                            variant="secondary"
                            disabled={isBulkOperating}
                            icon={<Eye size={18} />}
                        />
                        <CommandBarButton
                            onClick={() => handleBulkAction('status', 'draft')}
                            label="Draft"
                            variant="secondary"
                            disabled={isBulkOperating}
                            icon={<EyeOff size={18} />}
                        />
                        <div className="w-[1px] h-6 bg-borders mx-1"></div>
                        <CommandBarButton
                            onClick={() => handleBulkAction('delete')}
                            label="Delete"
                            variant="danger"
                            disabled={isBulkOperating}
                            icon={<Trash2 size={18} />}
                        />
                        <div className="w-[1px] h-6 bg-borders mx-1"></div>
                        <button
                            onClick={() => setSelectedSlugs(new Set())}
                            className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
                        >
                            <X size={18} />
                        </button>
                    </div>,
                    portalTarget
                );
            })()}
        </div>
    );
}
