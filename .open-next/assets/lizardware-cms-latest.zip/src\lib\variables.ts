/**
 * Central registry for all dynamic variables available in the CMS
 * Variables are replaced at render time with actual values from site config
 */

export interface Variable {
    key: string;
    label: string;
    description: string;
    icon: string;
    category: 'site' | 'date' | 'user' | 'custom';
    getValue: (config?: any) => string;
    example: string;
}

export const SITE_VARIABLES: Record<string, Variable> = {
    siteName: {
        key: 'siteName',
        label: 'Site Name',
        description: "Your site's name from settings",
        icon: '🏢',
        category: 'site',
        getValue: (config) => config?.name || config?.siteName || 'My Site',
        example: 'Acme Corporation'
    },
    siteUrl: {
        key: 'siteUrl',
        label: 'Site URL',
        description: "Your site's base URL",
        icon: '🌐',
        category: 'site',
        getValue: (config) => config?.url || config?.siteUrl || 'https://example.com',
        example: 'https://acme.com'
    },
    contactEmail: {
        key: 'contactEmail',
        label: 'Contact Email',
        description: 'Primary contact email address',
        icon: '📧',
        category: 'site',
        getValue: (config) => config?.email || config?.contactEmail || 'hello@example.com',
        example: 'contact@acme.com'
    },
    currentYear: {
        key: 'currentYear',
        label: 'Current Year',
        description: 'Automatically updates to current year',
        icon: '📅',
        category: 'date',
        getValue: () => new Date().getFullYear().toString(),
        example: '2025'
    }
};

export type VariableKey = keyof typeof SITE_VARIABLES;

/**
 * Get list of all available variables
 */
export function getAllVariables(): Variable[] {
    return Object.values(SITE_VARIABLES);
}

/**
 * Get a specific variable by key
 */
export function getVariable(key: string): Variable | undefined {
    return SITE_VARIABLES[key];
}

/**
 * Get unique categories
 */
export function getCategories(): string[] {
    return [...new Set(Object.values(SITE_VARIABLES).map(v => v.category))];
}

/**
 * Replace variables in text with actual values
 * @param text Text containing {{variableName}} placeholders
 * @param config Site configuration object
 */
export function replaceVariables(text: string, config?: any): string {
    return text.replace(/\{\{(\w+)\}\}/g, (match, key) => {
        const variable = SITE_VARIABLES[key];
        return variable ? variable.getValue(config) : match;
    });
}
