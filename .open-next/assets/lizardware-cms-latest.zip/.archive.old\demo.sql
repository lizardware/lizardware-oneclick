-- Seed: Demo Content (Lizardware Showcase)
-- Created: 2025-12-28
-- Decision A2: Full sample content for showcases

-- Introduction Posts
INSERT INTO posts (slug, title, content, description, author, author_id, tags, date, status, created_at, updated_at)
VALUES (
  'introducing-lizardware-cms',
  'Introducing Lizardware CMS',
  '<h1>Introducing Lizardware CMS</h1><p>Lizardware CMS is a modern, edge-native content management system designed for speed, security, and developer happiness. Built on the power of Cloudflare''s global network, it bridges the gap between the simplicity of static sites and the robustness of enterprise CMS platforms.</p><h2>Why Lizardware?</h2><p>Traditional CMS architectures are showing their age. They are often slow, require constant security patching, and create bottlenecks between content teams and developers. Lizardware was built from the ground up to solve these problems by:</p><ul><li><strong>Deploying to the Edge:</strong> Using Cloudflare Workers and D1, your content is served from 300+ cities worldwide with sub-100ms response times.</li><li><strong>Git-Backed Reliability:</strong> Every change is version-controlled, providing an audit trail and easy rollbacks.</li><li><strong>Developer First:</strong> Built with Next.js 15 and TypeScript, it''s a joy to extend and maintain.</li><li><strong>Intuitive Writing:</strong> A powerful block-based editor (Tiptap) that gets out of the way of your creativity.</li></ul><h2>Getting Started</h2><p>Deploying your own instance of Lizardware CMS takes only a few minutes. Check out our <a href="/setup">Getting Started guide</a> to launch your first edge-native site today.</p>',
  'Welcome to the future of content management. Learn why we built Lizardware and how it''s changing the game for edge-native sites.',
  'Lizardministrator',
  'lizardministrator',
  '["Product", "Announcement"]',
  '2025-12-19',
  'published',
  datetime('now'),
  datetime('now')
) ON CONFLICT(slug) DO UPDATE SET
  title = excluded.title,
  content = excluded.content,
  description = excluded.description,
  author = excluded.author,
  author_id = excluded.author_id,
  tags = excluded.tags,
  date = excluded.date,
  status = excluded.status,
  updated_at = datetime('now');

INSERT INTO posts (slug, title, content, description, author, author_id, tags, date, status, created_at, updated_at)
VALUES (
  'why-edge-computing-matters',
  'Why Edge Computing Matters for Content',
  '<h1>Why Edge Computing Matters for Content</h1><p>The internet is moving away from centralized servers and toward the edge. For content creators and businesses, this shift represents a massive leap forward in user experience and performance.</p><h2>The Performance Gap</h2><p>In a traditional hosting model, a user in Tokyo might have to wait for a server in New York to process their request. This latency leads to slow load times, poor SEO, and frustrated users.</p><p>With <strong>Edge Computing</strong>, the processing happens at the network''s perimeter—much closer to the user. Lizardware CMS leverages this by:</p><ol><li><strong>Sub-100ms Responses:</strong> Content is delivered from the closest point of presence (PoP).</li><li><strong>Zero Global Cold Starts:</strong> Optimized serverless functions that scale instantly.</li><li><strong>Co-located Data:</strong> D1 database instances are distributed alongside compute.</li></ol><h2>Real-World Impact</h2><p>Sites using edge-native architectures consistently see higher engagement rates and better search rankings. By removing the distance between your content and your audience, you''re not just making your site faster—you''re making it more accessible.</p>',
  'Discover why the future of the web is at the edge and how it directly impacts your search rankings and user engagement.',
  'Lizardministrator',
  'lizardministrator',
  '["Performance", "Cloudflare"]',
  '2025-12-19',
  'published',
  datetime('now'),
  datetime('now')
) ON CONFLICT(slug) DO UPDATE SET
  title = excluded.title,
  content = excluded.content,
  description = excluded.description,
  author = excluded.author,
  author_id = excluded.author_id,
  tags = excluded.tags,
  date = excluded.date,
  status = excluded.status,
  updated_at = datetime('now');

-- IT Consulting Posts
INSERT OR IGNORE INTO posts (slug, title, content, description, author, date, status)
VALUES (
  'it-consulting-services-overview',
  'IT Consulting Services: Strategic Technology Guidance',
  '<h1>IT Consulting Services: Strategic Technology Guidance</h1><p>In today''s rapidly evolving technology landscape, businesses need expert guidance to make informed decisions about their IT infrastructure. Lizardware''s IT consulting services provide comprehensive technology strategy and implementation support.</p><h2>What We Offer</h2><h3>Technology Assessment</h3><p>We analyze your current stack and identify areas for improvement.</p><h3>Strategic Planning</h3><p>We help you build a roadmap for digital transformation.</p><h3>Vendor Selection</h3><p>We assist in choosing the right tools and partners for your needs.</p><h3>Implementation Support</h3><p>Our team works alongside yours to ensure successful deployment.</p>',
  'Expert IT consulting services to guide your technology strategy and implementations with 25+ years of experience.',
  'Lizardware Team',
  '2025-01-15',
  'published'
);

-- Forum Data
INSERT INTO forum_categories (name, slug, description, icon, color, sort_order) VALUES
('General Discussion', 'general', 'Talk about anything and everything', '💬', '#3b82f6', 1),
('Questions & Answers', 'qa', 'Get help from the community', '❓', '#10b981', 2),
('Feature Requests', 'feature-requests', 'Suggest new features for Lizardware', '💡', '#f59e0b', 3),
('Bug Reports', 'bug-reports', 'Report issues and bugs', '🐛', '#ef4444', 4),
('Announcements', 'announcements', 'Official updates and news', '📢', '#8b5cf6', 0);

INSERT INTO forum_threads (category_id, user_id, title, slug, content, is_pinned)
VALUES (
  1,
  1,
  'Welcome to the Lizardware Community Forum!',
  'welcome-to-lizardware-community',
  '<h2>Welcome! 🎉</h2><p>This is the official Lizardware Community Forum. Here you can:</p><ul><li>Ask questions and get help</li><li>Share your projects and ideas</li><li>Suggest new features</li><li>Report bugs</li><li>Connect with other Lizardware users</li></ul><p>Please be respectful and follow our community guidelines. Happy discussing!</p>',
  1
);
