"use client";

import Link from "next/link";
import AdminCommandBar, { CommandBarButton } from "@/components/admin/AdminCommandBar";
import { ExternalLink, ChevronRight, AlertCircle } from "lucide-react";
import { VERSION } from "@/lib/version";
import { Accordion } from "@/components/ui/Accordion";
import { DashboardBanner, QuickLinkRow, MediaCountsRow } from "@/components/admin/DashboardHeader";
import { useState, useEffect } from "react";
import { useSearchParams } from "next/navigation";


export default function AdminDashboard() {
  const searchParams = useSearchParams();
  const disabledFeature = searchParams?.get('feature');
  const isDisabled = searchParams?.get('disabled') === 'true';

  const [counts, setCounts] = useState({ pages: 0, posts: 0, media: 0 });

  useEffect(() => {
    async function fetchCounts() {
      try {
        const [pagesRes, blogRes, mediaRes] = await Promise.all([
          fetch("/api/admin/pages"),
          fetch("/api/admin/blog"),
          fetch("/api/admin/media")
        ]);

        if (pagesRes.ok && blogRes.ok && mediaRes.ok) {
          const pagesData = (await pagesRes.json()) as any;
          const blogData = (await blogRes.json()) as any;
          const mediaData = (await mediaRes.json()) as any;

          setCounts({
            pages: pagesData.pages?.length || 0,
            posts: Array.isArray(blogData) ? blogData.length : (blogData.posts?.length || 0),
            media: mediaData.media?.length || 0
          });
        }
      } catch (err) {
        console.error("Error fetching dashboard counts:", err);
      }
    }
    fetchCounts();
  }, []);

  return (
    <div className="bg-site-background">
      <div className="max-w-7xl mx-auto px-6 pt-0 -mt-4 space-y-6">

        {/* Thinner, Integrated Header */}
        <div className="flex flex-col md:flex-row gap-4">
          <DashboardBanner />
          <MediaCountsRow pages={counts.pages} posts={counts.posts} media={counts.media} />
          <QuickLinkRow />
        </div>

        {/* Feature Disabled Warning */}
        {isDisabled && disabledFeature && (
          <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-2xl p-5 flex items-start gap-4 animate-in fade-in slide-in-from-top-2 duration-300">
            <div className="w-10 h-10 rounded-xl bg-yellow-500/20 flex items-center justify-center flex-shrink-0">
              <AlertCircle className="text-yellow-600 dark:text-yellow-500" size={20} />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-sm text-yellow-900 dark:text-yellow-100 mb-1">
                Feature Disabled
              </h3>
              <p className="text-xs text-yellow-800 dark:text-yellow-200/90 leading-relaxed">
                The <strong className="font-bold capitalize">{disabledFeature}</strong> feature is currently disabled.
                You can enable it in{" "}
                <Link
                  href="/admin/system/advanced"
                  className="underline font-bold hover:text-yellow-600 dark:hover:text-yellow-400 transition-colors"
                >
                  Design Hub
                </Link>
                {" "}under the Feature Flags section.
              </p>
            </div>
          </div>
        )}

        <div className="flex flex-col lg:flex-row gap-6 items-start">
          {/* Left Sidebar - System DNA */}
          <aside className="w-full lg:w-64 space-y-4 shrink-0">
            {/* System Status */}
            <Accordion
              title="System Profile"
              variant="card"
              defaultOpen={true}
              persistenceKey="side_profile"
              icon={<span className="text-sm">🧪</span>}
            >
              <div className="space-y-4 pt-2 pb-2">
                <StatusRow label="Environment" value="Production" color="text-indigo-500" />
                <StatusRow label="Database" value="D1 Global" color="text-emerald-500" />
                <StatusRow label="CDN Edge" value="Cloudflare" />
                <StatusRow label="Analytics" value="Operational" color="text-emerald-500" />
              </div>
            </Accordion>


            {/* Support/Links */}
            <Accordion
              title={
                <div className="flex items-center gap-2 text-white">
                  <span className="text-sm">📚</span>
                  <h3 className="font-bold text-[10px] uppercase tracking-widest">Support & Docs</h3>
                </div>
              }
              variant="card"
              defaultOpen={false}
              persistenceKey="side_support"
              className="!bg-gradient-to-br !from-primary !to-blue-600 !rounded-[2rem] !border-none !shadow-xl !shadow-primary/20 !p-2"
              contentClassName="!pt-0"
            >
              <div className="relative overflow-hidden p-4 pt-2">
                <div className="relative z-10">
                  <p className="text-[10px] text-white/70 mb-4 font-medium leading-relaxed">Access full documentation for the Lizardware framework.</p>
                  <Link
                    href="/admin/system/docs"
                    className="inline-flex items-center gap-2 px-4 py-2 bg-white/20 hover:bg-white/30 backdrop-blur-md rounded-xl text-[10px] font-black uppercase tracking-widest transition-all text-white"
                  >
                    Read Docs →
                  </Link>
                </div>
                {/* Decorative */}
                <div className="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full -mr-12 -mt-12 blur-2xl transition-transform"></div>
              </div>
            </Accordion>
          </aside>

          {/* Main Dashboard Hubs */}
          <div className="flex-1 min-w-0">
            {/* Interactive Timeline Container */}
            <div className="relative space-y-12 before:absolute before:left-[27px] before:top-4 before:bottom-4 before:w-0.5 before:bg-gradient-to-b before:from-primary/50 before:via-borders before:to-transparent before:z-0">

              {/* Sector 1: Content & Community */}
              <TimelineSection
                title="Content & Community"
                description="Manage your high-velocity content streams"
                icon="📝"
                color="from-amber-500 to-orange-600"
                persistenceKey="hub_content"
                defaultOpen={true}
              >
                <DashboardLink
                  href="/admin/content/blog"
                  title="Blazing Blogger"
                  description="Write and publish blog posts at lightning speed"
                  icon="🔥"
                  color="from-orange-500 to-red-500"
                />
                <DashboardLink
                  href="/admin/content/pages"
                  title="Page Playground"
                  description="Create and customize static pages with ease"
                  icon="🎪"
                  color="from-blue-500 to-cyan-500"
                />
              </TimelineSection>

              {/* Sector 2: Structure & Design */}
              <TimelineSection
                title="Structure & Design"
                description="Sculpt your brand's digital presence"
                icon="🎨"
                color="from-purple-500 to-indigo-600"
                persistenceKey="hub_design"
              >
                <DashboardLink
                  href="/admin/design/identity"
                  title="Visual Identity"
                  description="Logo, brand assets, and global theme presets"
                  icon="🖼️"
                  color="from-indigo-500 to-blue-600"
                />
                <DashboardLink
                  href="/admin/design/theme"
                  title="Theme Transformer"
                  description="Morph colors and styles with granular controls"
                  icon="✨"
                  color="from-pink-500 to-purple-600"
                />
                <DashboardLink
                  href="/admin/design/nav"
                  title="Nifty Navigation"
                  description="Craft the perfect menu hierarchy and structure"
                  icon="🧭"
                  color="from-emerald-500 to-teal-600"
                />
              </TimelineSection>

              {/* Sector 3: Platform & Growth */}
              <TimelineSection
                title="Platform & Growth"
                description="Monitor performance, revenue, and users"
                icon="📊"
                color="from-emerald-500 to-green-600"
                persistenceKey="hub_growth"
              >
                <DashboardLink
                  href="/admin/growth/monetization"
                  title="Revenue Reactor"
                  description="Subscriptions, AdSense, and sponsor links"
                  icon="💸"
                  color="from-green-500 to-emerald-600"
                />
                <DashboardLink
                  href="/admin/growth"
                  title="Growth Hub"
                  description="Optimize reach, revenue, and engagement across channels"
                  icon="🚀"
                  color="from-emerald-500 to-green-600"
                />
              </TimelineSection>

              {/* Sector 4: System Core */}
              <TimelineSection
                title="System Core"
                description="Configure the foundation of your environment"
                icon="⚙️"
                color="from-gray-600 to-slate-800"
                persistenceKey="hub_system"
              >
                <DashboardLink
                  href="/admin/system/config"
                  title="Settings Studio"
                  description="Fine-tune site metadata and SEO targets"
                  icon="🎛️"
                  color="from-slate-500 to-slate-700"
                />
                <DashboardLink
                  href="/admin/system/advanced"
                  title="Advanced Forge"
                  description="Environment variables and setup configuration"
                  icon="🛠️"
                  color="from-zinc-600 to-zinc-900"
                />
              </TimelineSection>
            </div>

            {/* System Intelligence / Footer Hub */}
            <div className="mt-12 bg-zinc-900 text-zinc-400 p-8 rounded-[2rem] border border-zinc-800 flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden group/footer">
              <div className="flex items-center gap-4 relative z-10">
                <div className="w-14 h-14 rounded-2xl bg-zinc-800 flex items-center justify-center text-3xl shadow-xl group-hover/footer:scale-110 transition-transform">🔒</div>
                <div>
                  <h3 className="font-black text-zinc-100 uppercase tracking-widest text-sm">Hardened Perimeter</h3>
                  <p className="text-[10px] font-medium opacity-60">Verified End-to-End Encryption via Cloudflare Tunnel</p>
                </div>
              </div>
              <div className="flex flex-wrap justify-center gap-6 text-[10px] font-black uppercase tracking-[0.2em] relative z-10">
                <Link href="/" className="px-4 py-2 bg-white/5 hover:bg-primary hover:text-white rounded-xl transition-all">← Exit Terminal</Link>
                <a href="https://github.com" target="_blank" className="px-4 py-2 bg-white/5 hover:bg-zinc-700 rounded-xl transition-all">GitHub Control</a>
                <a href="https://cloudflare.com" target="_blank" className="px-4 py-2 bg-white/5 hover:bg-blue-600 hover:text-white rounded-xl transition-all">Edge Infra</a>
              </div>
              {/* Decorative Scanline */}
              <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-primary/30 to-transparent animate-scan"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

interface TimelineSectionProps {
  title: string;
  description: string;
  icon: string;
  color: string;
  children: React.ReactNode;
  persistenceKey?: string;
  defaultOpen?: boolean;
}

function TimelineSection({ title, description, icon, color, children, persistenceKey, defaultOpen = false }: TimelineSectionProps) {
  return (
    <section className="relative z-10 pl-[88px] group/section">
      {/* Icon Circle */}
      <div className={`absolute left-0 top-0 w-14 h-14 rounded-full bg-white dark:bg-zinc-900 border-4 border-page-background flex items-center justify-center text-2xl shadow-xl transition-all duration-500 group-hover/section:scale-110 group-hover/section:rotate-6 group-hover/section:border-primary/50`}>
        <div className={`w-full h-full rounded-full bg-gradient-to-br ${color} opacity-[0.1] absolute`}></div>
        <span className="relative z-10">{icon}</span>
        {/* Step Connector Line Segment (Mobile) */}
        <div className="absolute left-full top-1/2 -translate-y-1/2 w-8 h-0.5 bg-borders hidden md:block opacity-0 group-hover/section:opacity-100 transition-opacity"></div>
      </div>

      <Accordion
        title={
          <div className="flex flex-col text-left">
            <span className="text-xl font-black text-page-title group-hover:text-primary transition-colors tracking-tight uppercase">
              {title}
            </span>
            <span className="text-xs font-medium text-page-text opacity-50 lowercase tracking-tight">
              {description}
            </span>
          </div>
        }
        variant="hub"
        defaultOpen={defaultOpen}
        persistenceKey={persistenceKey}
        className="!p-0"
        accentColor={color}
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-4">
          {children}
        </div>
      </Accordion>
    </section>
  );
}

interface DashboardLinkProps {
  href: string;
  title: string;
  description: string;
  icon: string;
  color: string;
  status?: "active" | "coming-soon";
}

function DashboardLink({ href, title, description, icon, color, status = "active" }: DashboardLinkProps) {
  const isActive = status === "active";

  if (!isActive) {
    return (
      <div className="flex items-center gap-4 p-5 bg-white/30 dark:bg-black/20 border border-gray-100/50 dark:border-white/5 rounded-3xl opacity-50 grayscale select-none">
        <div className="text-2xl">{icon}</div>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-page-title text-sm">{title}</h3>
            <span className="text-[8px] px-1.5 py-0.5 bg-zinc-200 dark:bg-zinc-800 text-zinc-500 rounded-md font-black uppercase">Coming Soon</span>
          </div>
          <p className="text-[10px] text-page-text leading-tight">{description}</p>
        </div>
      </div>
    );
  }

  return (
    <Link
      href={href}
      className="group flex items-center gap-4 p-5 bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-3xl transition-all duration-500 hover:border-primary/50 hover:shadow-[0_20px_50px_rgba(79,70,229,0.15)] dark:hover:shadow-[0_20px_50px_rgba(79,70,229,0.1)] hover:-translate-y-2 ring-primary/0 hover:ring-4 ring-primary/5"
    >
      <div className={`w-12 h-12 bg-gradient-to-br ${color} bg-opacity-10 rounded-xl flex items-center justify-center text-2xl shadow-sm group-hover:scale-110 transition-transform`}>
        {icon}
      </div>
      <div className="flex-1">
        <h3 className="font-black text-page-title group-hover:text-primary transition-colors text-sm uppercase tracking-tight">
          {title}
        </h3>
        <p className="text-[10px] text-page-text opacity-70 leading-relaxed font-medium">
          {description}
        </p>
      </div>
      <ChevronRight className="text-primary opacity-0 group-hover:opacity-100 transform group-hover:translate-x-1 transition-all" size={16} />
    </Link>
  );
}

function StatusRow({ label, value, color = "text-zinc-600 dark:text-zinc-400" }: { label: string, value: string, color?: string }) {
  return (
    <div className="flex justify-between items-center text-[11px] font-bold">
      <span className="text-gray-400 uppercase tracking-tighter">{label}</span>
      <span className={`${color} tracking-tight`}>{value}</span>
    </div>
  );
}

function SidebarLink({ href, icon, label }: { href: string, icon: string, label: string }) {
  return (
    <Link
      href={href}
      className="flex items-center gap-3 p-3 bg-white/50 dark:bg-zinc-950/50 hover:bg-primary/10 border border-gray-100/50 dark:border-zinc-800/50 rounded-2xl transition-all group shadow-sm"
    >
      <span className="text-lg group-hover:scale-110 transition-transform">{icon}</span>
      <span className="text-xs font-bold text-page-text group-hover:text-primary transition-colors">{label}</span>
    </Link>
  );
}
