'use client';

import React from 'react';

interface ColumnProps {
    children?: React.ReactNode;
    className?: string;
}

export default function Column({ children, className = '' }: ColumnProps) {
    return (
        <div className={`flex flex-col gap-4 p-6 bg-header-background/20 rounded-2xl border border-borders min-h-[200px] ${className}`}>
            {children}
        </div>
    );
}
