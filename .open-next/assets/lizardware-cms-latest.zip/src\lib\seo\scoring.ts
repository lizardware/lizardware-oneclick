// SEO Scoring Engine for Lizardware CMS
// Calculates SEO health score (0-100) and provides actionable feedback

export interface SEOIssue {
    type: 'error' | 'warning' | 'info';
    message: string;
    field?: string;
    suggestion?: string;
}

export interface SEOScore {
    score: number; // 0-100
    grade: 'excellent' | 'good' | 'needs-work' | 'poor';
    issues: SEOIssue[];
    breakdown: {
        metaTitle: number;
        metaDescription: number;
        images: number;
        schema: number;
        links: number;
    };
}

export interface PageContent {
    title?: string;
    metaTitle?: string;
    metaDescription?: string;
    slug?: string;
    content?: string; // HTML content
    schemaMarkup?: any;
    featuredImage?: string;
}

/**
 * Calculate comprehensive SEO score for a page
 */
export function calculateSEOScore(page: PageContent): SEOScore {
    let score = 0;
    const issues: SEOIssue[] = [];
    const breakdown = {
        metaTitle: 0,
        metaDescription: 0,
        images: 0,
        schema: 0,
        links: 0,
    };

    // === META TITLE CHECK (30 points max) ===
    if (page.metaTitle) {
        breakdown.metaTitle = 15;
        score += 15;

        const titleLength = page.metaTitle.length;
        if (titleLength >= 50 && titleLength <= 60) {
            breakdown.metaTitle += 15;
            score += 15;
        } else if (titleLength < 50) {
            issues.push({
                type: 'warning',
                field: 'metaTitle',
                message: `Meta title is short (${titleLength} chars)`,
                suggestion: 'Aim for 50-60 characters for optimal display in search results',
            });
            breakdown.metaTitle += 5;
            score += 5;
        } else if (titleLength > 60 && titleLength <= 70) {
            issues.push({
                type: 'warning',
                field: 'metaTitle',
                message: `Meta title may be truncated (${titleLength} chars)`,
                suggestion: 'Keep it under 60 characters to avoid truncation',
            });
            breakdown.metaTitle += 8;
            score += 8;
        } else {
            issues.push({
                type: 'error',
                field: 'metaTitle',
                message: `Meta title is too long (${titleLength} chars)`,
                suggestion: 'Shorten to 50-60 characters for better visibility',
            });
            breakdown.metaTitle += 3;
            score += 3;
        }
    } else {
        issues.push({
            type: 'error',
            field: 'metaTitle',
            message: 'Missing meta title',
            suggestion: 'Add a unique, descriptive title (50-60 characters)',
        });
    }

    // === META DESCRIPTION CHECK (25 points max) ===
    if (page.metaDescription) {
        breakdown.metaDescription = 12;
        score += 12;

        const descLength = page.metaDescription.length;
        if (descLength >= 140 && descLength <= 160) {
            breakdown.metaDescription += 13;
            score += 13;
        } else if (descLength < 140) {
            issues.push({
                type: 'warning',
                field: 'metaDescription',
                message: `Meta description is short (${descLength} chars)`,
                suggestion: 'Aim for 140-160 characters for better CTR',
            });
            breakdown.metaDescription += 6;
            score += 6;
        } else if (descLength > 160 && descLength <= 180) {
            issues.push({
                type: 'warning',
                field: 'metaDescription',
                message: `Meta description may be truncated (${descLength} chars)`,
                suggestion: 'Keep it under 160 characters',
            });
            breakdown.metaDescription += 8;
            score += 8;
        } else {
            issues.push({
                type: 'error',
                field: 'metaDescription',
                message: `Meta description is too long (${descLength} chars)`,
                suggestion: 'Shorten to 140-160 characters',
            });
            breakdown.metaDescription += 4;
            score += 4;
        }
    } else {
        issues.push({
            type: 'error',
            field: 'metaDescription',
            message: 'Missing meta description',
            suggestion: 'Add a compelling description (140-160 characters) to improve click-through rate',
        });
    }

    // === IMAGE ALT TEXT CHECK (15 points max) ===
    if (page.content) {
        const { totalImages, imagesWithoutAlt } = analyzeImages(page.content);

        if (totalImages === 0) {
            // No images, give partial credit
            breakdown.images = 10;
            score += 10;
            issues.push({
                type: 'info',
                field: 'images',
                message: 'No images found in content',
                suggestion: 'Consider adding relevant images to improve engagement',
            });
        } else if (imagesWithoutAlt === 0) {
            breakdown.images = 15;
            score += 15;
        } else {
            const coverage = ((totalImages - imagesWithoutAlt) / totalImages) * 15;
            breakdown.images = Math.round(coverage);
            score += Math.round(coverage);
            issues.push({
                type: 'warning',
                field: 'images',
                message: `${imagesWithoutAlt} of ${totalImages} images missing alt text`,
                suggestion: 'Add descriptive alt text to all images for accessibility and SEO',
            });
        }
    } else {
        breakdown.images = 5;
        score += 5;
    }

    // === SCHEMA MARKUP CHECK (15 points max) ===
    if (page.schemaMarkup && Object.keys(page.schemaMarkup).length > 0) {
        breakdown.schema = 15;
        score += 15;
    } else {
        breakdown.schema = 0;
        issues.push({
            type: 'warning',
            field: 'schema',
            message: 'No schema markup configured',
            suggestion: 'Add schema markup to help search engines understand your content',
        });
    }

    // === INTERNAL LINKS CHECK (15 points max) ===
    if (page.content) {
        const internalLinks = countInternalLinks(page.content);

        if (internalLinks >= 3) {
            breakdown.links = 15;
            score += 15;
        } else if (internalLinks >= 1) {
            breakdown.links = 8;
            score += 8;
            issues.push({
                type: 'info',
                field: 'links',
                message: `Only ${internalLinks} internal link(s) found`,
                suggestion: 'Add 2-3 more internal links to related content',
            });
        } else {
            breakdown.links = 0;
            issues.push({
                type: 'warning',
                field: 'links',
                message: 'No internal links found',
                suggestion: 'Add 2-5 internal links to related pages to improve site structure',
            });
        }
    }

    const grade = getGrade(score);

    return {
        score: Math.min(100, score),
        grade,
        issues,
        breakdown,
    };
}

/**
 * Analyze images in HTML content
 */
function analyzeImages(content: string): { totalImages: number; imagesWithoutAlt: number } {
    const imgRegex = /<img[^>]*>/gi;
    const images = content.match(imgRegex) || [];
    const totalImages = images.length;

    let imagesWithoutAlt = 0;
    for (const img of images) {
        // Check if alt attribute exists and is not empty
        const altMatch = img.match(/alt=["']([^"']*)["']/i);
        if (!altMatch || !altMatch[1] || altMatch[1].trim() === '') {
            imagesWithoutAlt++;
        }
    }

    return { totalImages, imagesWithoutAlt };
}

/**
 * Count internal links in HTML content
 */
function countInternalLinks(content: string): number {
    const linkRegex = /<a[^>]+href=["']([^"']+)["'][^>]*>/gi;
    const links = content.match(linkRegex) || [];

    let internalCount = 0;
    for (const link of links) {
        const hrefMatch = link.match(/href=["']([^"']+)["']/i);
        if (hrefMatch && hrefMatch[1]) {
            const href = hrefMatch[1];
            // Internal link if starts with / or doesn't include http/https
            if (href.startsWith('/') || (!href.startsWith('http://') && !href.startsWith('https://'))) {
                internalCount++;
            }
        }
    }

    return internalCount;
}

/**
 * Convert numerical score to letter grade
 */
function getGrade(score: number): 'excellent' | 'good' | 'needs-work' | 'poor' {
    if (score >= 90) return 'excellent';
    if (score >= 70) return 'good';
    if (score >= 50) return 'needs-work';
    return 'poor';
}

/**
 * Get traffic light color for score
 */
export function getTrafficLight(score: number): 'green' | 'yellow' | 'red' {
    if (score >= 80) return 'green';
    if (score >= 50) return 'yellow';
    return 'red';
}

/**
 * Get traffic light emoji for score
 */
export function getTrafficLightEmoji(score: number): '🟢' | '🟡' | '🔴' {
    const light = getTrafficLight(score);
    if (light === 'green') return '🟢';
    if (light === 'yellow') return '🟡';
    return '🔴';
}
