'use client';

interface CardProps {
    icon?: string;
    title: string;
    description: string;
    variant?: 'default' | 'outlined';
}

export default function Card({
    icon,
    title,
    description,
    variant = 'default'
}: CardProps) {
    return (
        <div className={`p-6 rounded-2xl ${variant === 'outlined'
            ? 'border-2 border-borders bg-transparent'
            : 'bg-card-background border border-borders shadow-sm'
            }`}>
            {icon && <div className="text-4xl mb-4">{icon}</div>}
            <h3 className="text-xl font-bold mb-2 text-page-title">{title}</h3>
            <div className="text-page-text opacity-80" dangerouslySetInnerHTML={{ __html: description }} />
        </div>
    );
}
