export const BoldIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M14.2 12.6c1-1.2 1.8-2.2 1.8-3.6 0-2.3-1.6-3.9-4-3.9H6v14h6.3c2.4 0 4.2-1.7 4.2-4.1 0-1.7-.9-2.8-2.3-3.4Z" />
    <path d="M6 7h4.3c1.1 0 2.1.8 2.1 2.1 0 1.3-.9 2.4-2.1 2.4H6v0Z" />
    <path d="M6 13h4.8c1.2 0 2.2 1 2.2 2.2s-1 2.3-2.2 2.3H6v0Z" />
  </svg>
);
