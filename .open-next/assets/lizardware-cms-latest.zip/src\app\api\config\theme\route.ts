import { NextRequest, NextResponse } from 'next/server';
import { updateThemeConfig, type ThemeConfig } from '@/lib/config-storage';
import { getSafeCloudflareContext } from '@/lib/cloudflare';
import themeData from '@/data/theme.json';
import fs from 'fs';
import path from 'path';

/**
 * PUT /api/config/theme
 * 
 * Update theme configuration in KV storage (instant, no rebuild!)
 * Protected by Cloudflare Access
 */
export async function PUT(request: NextRequest) {
    try {
        const context = await getSafeCloudflareContext();
        const kv = context?.env?.CONFIG_KV as KVNamespace;
        const theme = await request.json() as ThemeConfig;

        // Validate theme structure
        if (!theme.colors || !theme.colors.light || !theme.colors.dark) {
            return NextResponse.json(
                { error: 'Invalid theme structure' },
                { status: 400 }
            );
        }

        if (!kv) {
            // Development fallback: Write to local JSON file
            if (process.env.NODE_ENV === 'development') {
                const themePath = path.join(process.cwd(), 'src', 'data', 'theme.json');

                // Read existing theme to merge
                let existingTheme = themeData as any;
                try {
                    if (fs.existsSync(themePath)) {
                        existingTheme = JSON.parse(fs.readFileSync(themePath, 'utf-8'));
                    }
                } catch (err) {
                    console.warn('[Theme API] Failed to read existing theme for merge:', err);
                }

                const mergedTheme = {
                    ...existingTheme,
                    ...theme,
                    // Deep merge colors if they exist
                    colors: theme.colors ? {
                        light: { ...(existingTheme.colors?.light || {}), ...theme.colors.light },
                        dark: { ...(existingTheme.colors?.dark || {}), ...theme.colors.dark }
                    } : existingTheme.colors
                };

                await fs.promises.writeFile(themePath, JSON.stringify(mergedTheme, null, 2));

                return NextResponse.json({
                    success: true,
                    message: 'Theme merged and saved to local file system (Development Mode)',
                });
            }

            return NextResponse.json(
                { error: 'KV storage not available' },
                { status: 503 }
            );
        }

        // Save to KV (instant!)
        await updateThemeConfig(kv, theme);

        return NextResponse.json({
            success: true,
            message: 'Theme updated successfully (changes visible immediately!)',
        });
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error('Theme update error:', message);

        return NextResponse.json(
            { error: message },
            { status: 500 }
        );
    }
}

/**
 * GET /api/config/theme
 * 
 * Get current theme configuration from KV
 */
export async function GET() {
    try {
        const context = await getSafeCloudflareContext();
        const kv = context?.env?.CONFIG_KV as KVNamespace;

        if (!kv) {
            // Development fallback: Read from local JSON file to ensure freshness
            if (process.env.NODE_ENV === 'development') {
                try {
                    const themePath = path.join(process.cwd(), 'src', 'data', 'theme.json');
                    const fileContent = await fs.promises.readFile(themePath, 'utf-8');
                    return NextResponse.json(JSON.parse(fileContent));
                } catch (err) {
                    console.warn('Could not read local theme file, falling back to import:', err);
                }
            }

            // Fallback to imported default theme
            return NextResponse.json(themeData);
        }

        const theme = await kv.get('theme', 'json');

        if (!theme) {
            // Return default if not in KV yet
            return NextResponse.json(themeData);
        }

        return NextResponse.json(theme);
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error('Theme fetch error:', message);

        return NextResponse.json(
            { error: message },
            { status: 500 }
        );
    }
}
