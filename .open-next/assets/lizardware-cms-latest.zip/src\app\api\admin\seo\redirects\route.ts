import { NextRequest, NextResponse } from 'next/server';

// GET: List all redirects
export async function GET(request: NextRequest) {
    const env = getEnv(request);

    if (!env.DB) {
        return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }

    const { results } = await env.DB.prepare('SELECT * FROM redirects ORDER BY created_at DESC').all();

    return NextResponse.json({ redirects: results });
}

// POST: Create new redirect
export async function POST(request: NextRequest) {
    const env = getEnv(request);

    if (!env.DB) {
        return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }

    const { source_path, destination_path, type } = await request.json() as any;

    if (!source_path || !destination_path) {
        return NextResponse.json({ error: 'source_path and destination_path are required' }, { status: 400 });
    }

    try {
        const result = await env.DB.prepare(
            'INSERT INTO redirects (source_path, destination_path, type) VALUES (?, ?, ?)'
        ).bind(source_path, destination_path, type || 301).run();

        return NextResponse.json({
            success: true,
            id: result.meta.last_row_id
        });
    } catch (error: any) {
        if (error.message?.includes('UNIQUE constraint')) {
            return NextResponse.json({ error: 'A redirect for this source path already exists' }, { status: 409 });
        }
        return NextResponse.json({ error: 'Failed to create redirect' }, { status: 500 });
    }
}

function getEnv(request: NextRequest): any {
    return (request as any).env || process.env;
}
