'use client';

import React, { useState, useEffect } from 'react';
import { Block } from '@/types/blocks';
import { BLOCK_REGISTRY } from '@/lib/blocks/registry';

interface BlockRendererProps {
  content: string; // The JSON string from the DB
}

interface RecursiveRendererProps {
  blocks: Block[];
}

function RecursiveRenderer({ blocks }: RecursiveRendererProps) {
  if (!Array.isArray(blocks) || blocks.length === 0) return null;

  return (
    <>
      {blocks.map((block) => {
        const def = BLOCK_REGISTRY[block.type];
        if (!def) return null;

        const Component = def.component;
        if (!Component) return null;

        const { styleOptions } = block;

        // Background mapping
        const bgClasses = {
          primary: 'bg-page-bg-primary',
          secondary: 'bg-page-bg-secondary',
          alternate: 'bg-page-bg-alternate',
          transparent: 'bg-transparent',
        };
        const bgClass = styleOptions?.background ? bgClasses[styleOptions.background] || '' : '';

        // Padding mapping
        const paddingClasses = {
          none: 'py-0',
          small: 'py-8',
          medium: 'py-16 lg:py-24', // py-section standard
          large: 'py-24 lg:py-32',
        };
        const paddingClass = styleOptions?.padding ? paddingClasses[styleOptions.padding] || '' : '';

        // Max Width mapping
        const maxWidthClasses = {
          standard: 'max-w-[1024px]',
          full: 'max-w-none',
          narrow: 'max-w-3xl',
        };
        const maxWidthClass = styleOptions?.maxWidth ? maxWidthClasses[styleOptions.maxWidth] || 'max-w-[1024px]' : '';

        // For column blocks, render directly without an extra wrapper div
        if (block.type === 'column') {
          return (
            <Component key={block.id} {...block.props}>
              {block.children && block.children.length > 0 && (
                <RecursiveRenderer blocks={block.children} />
              )}
            </Component>
          );
        }

        // For all other blocks, use the wrapper for proper spacing and background
        return (
          <section
            key={block.id}
            id={`block-${block.id}`}
            className={`${bgClass} ${paddingClass} w-full transition-colors duration-300`}
            style={{ backgroundColor: styleOptions?.customBackground }}
          >
            <div className={`mx-auto px-4 ${maxWidthClass}`}>
              <Component {...block.props}>
                {block.children && block.children.length > 0 && (
                  <RecursiveRenderer blocks={block.children} />
                )}
              </Component>
            </div>
          </section>
        );
      })}
    </>
  );
}

export default function BlockRenderer({ content: initialContent }: BlockRendererProps) {
  // Use state to allow live updates from the editor
  const [blocks, setBlocks] = useState<Block[]>([]);

  useEffect(() => {
    try {
      if (!initialContent) return;
      const parsed = JSON.parse(initialContent);
      if (Array.isArray(parsed)) {
        setBlocks(parsed);
      }
    } catch (e) {
      console.error('Failed to parse initial block content', e);
    }
  }, [initialContent]);

  // Listen for live updates from iframe parent (UnifiedEditor)
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'UPDATE_CONTENT') {
        const { content, metadata_json } = event.data.payload;
        // If we have direct block JSON (metadata_json), use it
        if (metadata_json) {
          try {
            const parsed = JSON.parse(metadata_json);
            if (Array.isArray(parsed)) setBlocks(parsed);
          } catch (e) { }
        }
        // Fallback to trying to parse content if it might be JSON (legacy or mixed)
        else if (content) {
          try {
            const parsed = JSON.parse(content);
            if (Array.isArray(parsed)) setBlocks(parsed);
          } catch (e) {
            // Normal HTML/MDX content, ignore
          }
        }
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  if (!Array.isArray(blocks) || blocks.length === 0) {
    return null;
  }

  return (
    <div className="w-full">
      <RecursiveRenderer blocks={blocks} />
    </div>
  );
}
