-- Migration 023: Add Template System to Pages
-- Enables customizable page templates for white-label deployments

-- Add template-related columns to pages table
ALTER TABLE pages ADD COLUMN is_template INTEGER DEFAULT 0 NOT NULL;
ALTER TABLE pages ADD COLUMN template_category TEXT;
ALTER TABLE pages ADD COLUMN sort_order INTEGER DEFAULT 0;

-- Add indexes for performance
CREATE INDEX IF NOT EXISTS idx_pages_is_template ON pages(is_template);
CREATE INDEX IF NOT EXISTS idx_pages_template_category ON pages(template_category);
CREATE INDEX IF NOT EXISTS idx_pages_sort_order ON pages(sort_order);

-- Template Pages Seeds
-- Use {{siteName}} placeholders for white-label support

-- Company Templates
INSERT INTO pages (slug, title, content, description, status, is_template, template_category, sort_order, created_at, updated_at)
VALUES 
  ('about', 'About {{siteName}}', '<h1>About {{siteName}}</h1><p>This is a template page. Customize it to tell your story!</p>', 'Learn more about our company', 'published', 1, 'company', 10, datetime('now'), datetime('now')),
  ('contact', 'Contact {{siteName}}', '<h1>Contact Us</h1><p>Get in touch with our team.</p>', 'Contact information', 'published', 1, 'company', 20, datetime('now'), datetime('now')),
  ('platform', 'Platform Features', '<h1>Platform Features</h1><p>Discover what makes our platform unique.</p>', 'Platform overview', 'published', 1, 'company', 30, datetime('now'), datetime('now'));

-- Legal Templates  
INSERT INTO pages (slug, title, content, description, status, is_template, template_category, sort_order, created_at, updated_at)
VALUES 
  ('terms', 'Terms of Service', '<h1>Terms of Service</h1><p>Please read these terms carefully.</p>', 'Terms and conditions', 'published', 1, 'legal', 40, datetime('now'), datetime('now')),
  ('privacy', 'Privacy Policy', '<h1>Privacy Policy</h1><p>Your privacy matters to us.</p>', 'Privacy policy', 'published', 1, 'legal', 50, datetime('now'), datetime('now'));

-- Support Templates
INSERT INTO pages (slug, title, content, description, status, is_template, template_category, sort_order, created_at, updated_at)
VALUES 
  ('support', 'Support Center', '<h1>Support</h1><p>Need help? We''re here for you.</p>', 'Get support', 'published', 1, 'support', 60, datetime('now'), datetime('now'));

-- Add comments
-- is_template: 1 = template page (About, Contact, etc), 0 = custom page
-- template_category: 'company', 'legal', 'support', null for custom pages
-- sort_order: Custom ordering for navigation (lower = higher priority)

