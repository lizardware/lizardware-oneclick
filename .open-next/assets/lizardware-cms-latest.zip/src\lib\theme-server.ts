import { getThemeConfig } from './config-storage';
import themeData from '@/data/theme.json';
import { getSafeCloudflareContext } from './cloudflare';

export async function getTheme() {
    try {
        const cfContext = await getSafeCloudflareContext();
        const kv = cfContext?.env?.CONFIG_KV as unknown as KVNamespace;

        if (!kv) {
            // Development fallback: Read from local JSON file to ensure freshness
            if (process.env.NODE_ENV === 'development') {
                try {
                    const fs = await import('fs');
                    const path = await import('path');
                    const themePath = path.join(process.cwd(), 'src', 'data', 'theme.json');
                    if (fs.existsSync(themePath)) {
                        const fileContent = fs.readFileSync(themePath, 'utf-8');
                        return JSON.parse(fileContent);
                    }
                } catch (err) {
                    console.warn('Could not read local theme file in getTheme, falling back to import:', err);
                }
            }
            return themeData;
        }

        const theme = await getThemeConfig(kv);
        return theme || themeData;
    } catch (error) {
        console.error('Failed to load theme, using default:', error);
        return themeData;
    }
}
