import { NextRequest, NextResponse } from "next/server";
import { getPostBySlugFromD1, upsertPostToD1, deletePostFromD1 } from "@/lib/blog-storage";
import { getD1Database, dbUnavailableResponse } from '@/lib/cloudflare';

// GET /api/blog/[slug] - Get single post
export async function GET(
    request: NextRequest,
    { params }: { params: Promise<{ slug: string }> }
) {
    try {
        const db = await getD1Database();

        if (!db) {
            return dbUnavailableResponse();
        }

        const { slug } = await params;
        const post = await getPostBySlugFromD1(db, slug);

        if (!post) {
            return NextResponse.json(
                { error: "Post not found" },
                { status: 404 }
            );
        }

        return NextResponse.json({ post });
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error("Post fetch error:", message);

        return NextResponse.json(
            { error: message },
            { status: 500 }
        );
    }
}

// PUT /api/blog/[slug] - Update post
export async function PUT(
    request: NextRequest,
    { params }: { params: Promise<{ slug: string }> }
) {
    try {
        const db = await getD1Database();

        if (!db) {
            return dbUnavailableResponse();
        }

        const { slug } = await params;
        const post = await request.json() as { slug: string;[key: string]: unknown };
        post.slug = slug; // Ensure slug matches URL

        const fullPost = {
            ...post,
            date: (post as any).date || new Date().toISOString(),
            status: (post as any).status || 'draft'
        } as any;

        await upsertPostToD1(db, fullPost);

        return NextResponse.json({
            success: true,
            message: "Post updated successfully",
        });
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error("Post update error:", message);

        return NextResponse.json(
            { error: message },
            { status: 500 }
        );
    }
}

// DELETE /api/blog/[slug] - Delete post
export async function DELETE(
    request: NextRequest,
    { params }: { params: Promise<{ slug: string }> }
) {
    try {
        const db = await getD1Database();

        if (!db) {
            return dbUnavailableResponse();
        }

        const { slug } = await params;
        await deletePostFromD1(db, slug);

        return NextResponse.json({
            success: true,
            message: "Post deleted successfully",
        });
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error("Post deletion error:", message);

        return NextResponse.json(
            { error: message },
            { status: 500 }
        );
    }
}
