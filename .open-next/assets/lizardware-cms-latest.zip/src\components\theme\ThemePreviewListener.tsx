"use client";

import { useEffect } from "react";

export function ThemePreviewListener() {
    useEffect(() => {
        // Only run in iframe
        if (window.self === window.top) return;

        const handleMessage = (event: MessageEvent) => {
            // Handle legacy theme updates (colors, borderRadius)
            // AND new variable updates (spacing, shadows)

            if (event.data?.type === 'UPDATE_THEME') {
                console.log('ThemePreviewListener received UPDATE_THEME', event.data.payload);
                const theme = event.data.payload;
                if (!theme) return;

                const root = document.documentElement;

                // 1. Spacing
                if (theme.spacing) {
                    if (theme.spacing.section) root.style.setProperty('--space-section', theme.spacing.section);
                    if (theme.spacing.container) root.style.setProperty('--space-container', theme.spacing.container);
                    if (theme.spacing.gap) root.style.setProperty('--space-gap', theme.spacing.gap);
                    if (theme.spacing.header) root.style.setProperty('--space-header', theme.spacing.header);
                }

                // 2. Radius
                if (theme.borderRadius) {
                    root.style.setProperty('--space-radius-base', theme.borderRadius);
                }

                // 3. Typography
                if (theme.typography) {
                    if (theme.typography.fontSizeTitle) root.style.setProperty('--typo-title', theme.typography.fontSizeTitle);
                    if (theme.typography.fontSizeSubtitle) root.style.setProperty('--typo-subtitle', theme.typography.fontSizeSubtitle);
                    if (theme.typography.fontSizeDescription) root.style.setProperty('--typo-description', theme.typography.fontSizeDescription);
                    if (theme.typography.fontSizeBase) root.style.setProperty('--typo-base', theme.typography.fontSizeBase);
                }

                // 4. Shadows
                if (theme.shadows?.strength) {
                    root.style.setProperty('--shadow-strength', theme.shadows.strength);
                }

                // 5. Colors & Full Re-render (Only if colors exist)
                if (theme.colors && theme.colors.light && theme.colors.dark) {
                    const styleId = 'theme-live-preview-styles';
                    let styleEl = document.getElementById(styleId);
                    if (!styleEl) {
                        styleEl = document.createElement('style');
                        styleEl.id = styleId;
                        document.head.appendChild(styleEl);
                    }

                    const colors = theme.colors;

                    const css = `
               :root {
                 /* Tier 1: Global */
                 --body-background: ${colors.light.bodyBackground};
                 --header-background: ${colors.light.headerBackground};
                 --footer-background: ${colors.light.footerBackground};
                 --content-background: ${colors.light.contentBackground};
                 --borders: ${colors.light.borders};

                 /* Tier 2: Page Sections */
                 --page-bg-primary: ${colors.light.pageBackgroundPrimary};
                 --page-bg-secondary: ${colors.light.pageBackgroundSecondary};
                 --page-bg-alternate: ${colors.light.pageBackgroundAlternate};
                 --hero-background: ${colors.light.heroBackground};

                 /* Text & UI */
                 --header-text: ${colors.light.headerText};
                 --footer-text: ${colors.light.footerText};
                 --page-title: ${colors.light.pageTitle};
                 --page-subtitle: ${colors.light.pageSubtitle};
                 --page-text: ${colors.light.pageText};
                 
                 /* Legacy & Computed */
                 --header-bg: var(--header-background);
                 --site-background: var(--body-background);
                 --page-background: var(--page-bg-primary);
                 --info-box-bg: var(--content-background);
                 --info-box-text: ${colors.light.infoBoxText};
                 --info-box-link-bg: ${colors.light.infoBoxLinkBg};
                 --info-box-link-text: ${colors.light.infoBoxLinkText};
                 --info-box-link-hover: ${colors.light.infoBoxLinkHover};
                 --section-header-bg: ${colors.light.sectionHeader || '#f3f4f6'};
                 --hero-bg: ${colors.light.heroGradientEnabled ? `linear-gradient(to bottom right, ${colors.light.heroGradientStart}, ${colors.light.heroGradientEnd})` : colors.light.heroBackground};
                 --hero-text: ${colors.light.heroText || '#0f172a'};
                 --hero-gradient-start: ${colors.light.heroGradientStart || '#f8fafc'};
                 --hero-gradient-end: ${colors.light.heroGradientEnd || '#f1f5f9'};
                 
                 /* Design Architecture */
                 --space-section: ${theme.spacing?.section || '4rem'};
                 --space-container: ${theme.spacing?.container || '1.5rem'};
                 --space-gap: ${theme.spacing?.gap || '1.25rem'};
                 --space-header: ${theme.spacing?.header || '3rem'};
                 --radius-base: ${theme.borderRadius || '0.5rem'};
                 --shadow-strength: ${theme.shadows?.strength || '0.1'};
                 
                 /* Typography */
                 --typo-title: ${theme.typography?.fontSizeTitle || '60px'};
                 --typo-subtitle: ${theme.typography?.fontSizeSubtitle || '30px'};
                 --typo-description: ${theme.typography?.fontSizeDescription || '24px'};
                 --typo-base: ${theme.typography?.fontSizeBase || '16px'};
               }
               
               .dark {
                 /* Tier 1: Global */
                 --body-background: ${colors.dark.bodyBackground};
                 --header-background: ${colors.dark.headerBackground};
                 --footer-background: ${colors.dark.footerBackground};
                 --content-background: ${colors.dark.contentBackground};
                 --borders: ${colors.dark.borders};

                 /* Tier 2: Page Sections */
                 --page-bg-primary: ${colors.dark.pageBackgroundPrimary};
                 --page-bg-secondary: ${colors.dark.pageBackgroundSecondary};
                 --page-bg-alternate: ${colors.dark.pageBackgroundAlternate};
                 --hero-background: ${colors.dark.heroBackground};

                 /* Text & UI */
                 --header-text: ${colors.dark.headerText};
                 --footer-text: ${colors.dark.footerText};
                 --page-title: ${colors.dark.pageTitle};
                 --page-subtitle: ${colors.dark.pageSubtitle};
                 --page-text: ${colors.dark.pageText};

                 /* Legacy & Computed */
                 --header-bg: var(--header-background);
                 --site-background: var(--body-background);
                 --page-background: var(--page-bg-primary);
                 --info-box-bg: var(--content-background);
                 --info-box-text: ${colors.dark.infoBoxText};
                 --info-box-link-bg: ${colors.dark.infoBoxLinkBg};
                 --info-box-link-text: ${colors.dark.infoBoxLinkText};
                 --info-box-link-hover: ${colors.dark.infoBoxLinkHover};
                 --section-header-bg: ${colors.dark.sectionHeader || '#3f3f46'};
                 --hero-bg: ${colors.dark.heroGradientEnabled ? `linear-gradient(to bottom right, ${colors.dark.heroGradientStart}, ${colors.dark.heroGradientEnd})` : colors.dark.heroBackground};
                 --hero-text: ${colors.dark.heroText || '#ffffff'};
                 --hero-gradient-start: ${colors.dark.heroGradientStart || '#000000'};
                 --hero-gradient-end: ${colors.dark.heroGradientEnd || '#f97316'};
                 
                 --shadow-strength: ${theme.shadows?.strength ? parseFloat(theme.shadows.strength) * 2.5 : '0.25'};

                 /* Typography */
                 --typo-title: ${theme.typography?.fontSizeTitle || '60px'};
                 --typo-subtitle: ${theme.typography?.fontSizeSubtitle || '30px'};
                 --typo-description: ${theme.typography?.fontSizeDescription || '24px'};
                 --typo-base: ${theme.typography?.fontSizeBase || '16px'};
               }
             `;

                    styleEl.textContent = css;
                }
            }

            if (event.data?.type === 'SET_THEME') {
                const mode = event.data.theme;
                if (mode === 'dark') document.documentElement.classList.add('dark');
                else document.documentElement.classList.remove('dark');
            }
        };

        window.addEventListener('message', handleMessage);
        return () => window.removeEventListener('message', handleMessage);
    }, []);

    return null;
}
