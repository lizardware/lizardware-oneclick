"use client";

import * as React from "react";
import { useTheme } from "next-themes";
import { Moon, Sun } from "lucide-react";

export function ThemePreferenceModal() {
    const [isOpen, setIsOpen] = React.useState(false);
    const { setTheme } = useTheme();

    React.useEffect(() => {
        // Check if user has already made a choice
        const hasPreference = localStorage.getItem("theme-preference");
        if (!hasPreference) {
            // Small delay to ensure smooth entry
            const timer = setTimeout(() => setIsOpen(true), 1000);
            return () => clearTimeout(timer);
        }
    }, []);

    const handleSelect = (theme: "light" | "dark") => {
        setTheme(theme);
        localStorage.setItem("theme-preference", theme);
        setIsOpen(false);
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm transition-opacity duration-300">
            <div className="bg-background rounded-lg shadow-xl p-container max-w-sm w-full mx-4 border border-border transform transition-all scale-100">
                <h2 className="text-xl font-semibold mb-2 text-center text-slate-900 dark:text-white">
                    Choose Your Appearance
                </h2>
                <p className="text-slate-500 dark:text-slate-400 text-center mb-6 text-sm">
                    Select your preferred theme for the best experience. You can change this later.
                </p>

                <div className="grid grid-cols-2 gap-4">
                    <button
                        onClick={() => handleSelect("light")}
                        className="flex flex-col items-center gap-3 p-4 rounded-lg border-2 border-border hover:border-primary hover:bg-muted transition-all group"
                    >
                        <div className="p-3 bg-slate-100 dark:bg-slate-800 rounded-full group-hover:bg-blue-100 dark:group-hover:bg-blue-900/30 transition-colors">
                            <Sun className="w-6 h-6 text-slate-700 dark:text-slate-200 group-hover:text-blue-600 dark:group-hover:text-blue-400" />
                        </div>
                        <span className="font-medium text-slate-700 dark:text-slate-200">Light</span>
                    </button>

                    <button
                        onClick={() => handleSelect("dark")}
                        className="flex flex-col items-center gap-3 p-4 rounded-lg border-2 border-border hover:border-primary hover:bg-muted transition-all group"
                    >
                        <div className="p-3 bg-slate-100 dark:bg-slate-800 rounded-full group-hover:bg-blue-100 dark:group-hover:bg-blue-900/30 transition-colors">
                            <Moon className="w-6 h-6 text-slate-700 dark:text-slate-200 group-hover:text-blue-600 dark:group-hover:text-blue-400" />
                        </div>
                        <span className="font-medium text-slate-700 dark:text-slate-200">Dark</span>
                    </button>
                </div>
            </div>
        </div>
    );
}
