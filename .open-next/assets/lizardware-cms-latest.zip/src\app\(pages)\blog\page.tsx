'use client';

import { Post } from "@/lib/blog";
import Link from "next/link";
import { useEffect, useState } from "react";
import Image from "next/image";
import MonetizationWrapper from "@/components/ui/MonetizationWrapper";
import BlogCard from "@/components/blog/BlogCard";
import authorsData from "@/data/authors.json";

export default function BlogPage() {
  const [posts, setPosts] = useState<Omit<Post, 'content'>[]>([]);
  const [media, setMedia] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch posts client-side (avoids Cloudflare Worker CPU timeout)
    // Server-side fetch in Workers exceeds 10ms CPU limit
    fetch('/api/posts')
      .then(res => res.json())
      .then(data => {
        // Check if data is an array (successful response) or error object
        if (Array.isArray(data)) {
          setPosts(data as Omit<Post, 'content'>[]);
        } else {
          console.error('API returned non-array data:', data);
          setPosts([]);
        }
        setLoading(false);
      })
      .catch(err => {
        console.error('Error fetching posts:', err);
        setPosts([]);
        setLoading(false);
      });
    // Fetch media library
    fetch('/api/admin/media')
      .then(res => res.json())
      .then(data => {
        const typedData = data as { media: any[] };
        const mediaMap: Record<string, string> = {};
        typedData.media.forEach(m => mediaMap[m.id] = m.url);
        setMedia(mediaMap);
      })
      .catch(err => console.error('Error fetching media:', err));
  }, []);

  return (
    <div className="bg-page-background">
      <div className="max-w-[1024px] mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-16 space-y-4">
          <h1 className="text-title font-bold tracking-tight text-page-title">
            Blog
          </h1>
          <h2 className="text-subtitle font-semibold text-page-subtitle">
            Industry Insights & Technology Updates
          </h2>
          <p className="text-lg text-page-text max-w-2xl mx-auto">
            Stay informed with the latest in IT, cybersecurity, and business technology solutions.
          </p>
        </div>

        {/* Loading State */}
        {loading ? (
          <div className="text-center py-16">
            <div className="bg-info-box-bg border border-borders rounded-lg p-12 max-w-md mx-auto">
              <p className="text-info-box-text text-lg">Loading posts...</p>
            </div>
          </div>
        ) : posts.length === 0 ? (
          <div className="text-center py-16">
            <div className="bg-info-box-bg border border-borders rounded-lg p-12 max-w-md mx-auto">
              <p className="text-info-box-text text-lg mb-4">No blog posts yet.</p>
              <p className="text-info-box-text/70">Check back soon for updates!</p>
            </div>
          </div>
        ) : (
          <div className="flex flex-col lg:flex-row gap-12">
            {/* Main Content */}
            <div className="lg:w-2/3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {posts.map((post) => (
                  <BlogCard
                    key={post.slug}
                    post={post}
                    imageUrl={
                      post.featured_image_id
                        ? (post.featured_image_id.startsWith('http') ? post.featured_image_id : media[post.featured_image_id])
                        : undefined
                    }
                  />
                ))}
              </div>
            </div>

            {/* Sidebar */}
            <aside className="lg:w-1/3">
              <div className="sticky top-24 space-y-8">
                <div className="p-6 bg-info-box-bg border border-borders rounded-xl">
                  <h3 className="text-lg font-bold text-page-title mb-4">Search & Filter</h3>
                  <div className="text-sm text-page-text/60 italic">
                    Feature coming soon: Category filtering and full-text search.
                  </div>
                </div>

                <MonetizationWrapper placement="sidebar" />

                <div className="p-6 bg-info-box-bg border border-borders rounded-xl">
                  <h3 className="text-lg font-bold text-page-title mb-4">Newsletter</h3>
                  <p className="text-sm text-page-text mb-4">
                    Get the latest IT strategy insights delivered to your inbox.
                  </p>
                  <div className="flex flex-col gap-2">
                    <input
                      type="email"
                      placeholder="your@email.com"
                      className="px-4 py-2 bg-white dark:bg-zinc-800 border border-borders rounded-lg text-sm"
                      disabled
                    />
                    <button className="w-full px-4 py-2 bg-primary text-white rounded-lg text-sm font-bold opacity-50 cursor-not-allowed">
                      Subscribe (Soon)
                    </button>
                  </div>
                </div>
              </div>
            </aside>
          </div>
        )}
      </div>
    </div>
  );
}
