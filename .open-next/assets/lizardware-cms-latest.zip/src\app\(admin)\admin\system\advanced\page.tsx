'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { createPortal } from 'react-dom';
import { getAllBusinessTypes, getBusinessType } from '@/data/business-types';
import type { BusinessType } from '@/data/business-types';
import AdminCommandBar, { CommandBarButton } from "@/components/admin/AdminCommandBar";
import { Save, RotateCcw, Cpu, Trash2, Settings, ArrowLeft } from 'lucide-react';
import { usePopup } from '@/components/admin/AdminPopupProvider';
import { AdminHeader } from "@/components/admin/AdminHeader";
import { AdminLoadingState } from "@/components/admin/AdminLoadingState";

import { useAdminActions } from "@/hooks/useAdminActions";

export default function AdvancedSettingsPage() {
    const router = useRouter();
    const searchParams = useSearchParams();
    const popup = usePopup();
    const [currentBusinessTypeId, setCurrentBusinessTypeId] = useState<string>('');
    // Features moving to /admin/features
    const [siteConfig, setSiteConfig] = useState<any>({ name: '', description: '', url: '' });
    const [envConfig, setEnvConfig] = useState<any>({
        siteUrl: '',
        cloudflareAccountId: '',
        mediaStorageProvider: 'github',
        githubToken: '',
        githubRepo: ''
    });
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [setupLocked, setSetupLocked] = useState(false);

    // Placeholder functions for hook context - actual logic is inside useAdminActions now?
    // Wait, useAdminActions needs to call functions defined in the component scope.
    // So we define functions first, then call the hook.

    const saveEnvConfig = async () => {
        setSaving(true);
        try {
            const res = await fetch('/api/admin/env', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(envConfig)
            });
            if (res.ok) popup.success('Environment settings updated! Please restart the server to apply changes.');
            else popup.error('Failed to update environment settings');
        } catch (e) {
            console.error(e);
            popup.error('Error updating environment settings');
        } finally {
            setSaving(false);
        }
    };

    const handleResetToDefaults = async () => {
        const confirmed = await popup.confirm('EXTREME WARNING: This will reset all features, navigation, and theme to Lizardware factory defaults. This cannot be undone. Are you sure?', { isDanger: true });
        if (!confirmed) {
            return;
        }

        setSaving(true);
        try {
            // 1. Reset Features (now default fetch to internal api handled by reset handler?)
            // Actually, reset API might handle this. Let's keep the API call but simplify front-end state.
            await fetch('/api/admin/features', {
                method: 'POST',
                body: JSON.stringify({
                    blog: true,
                    gallery: false,
                    newsletter: true,
                    monetization: false,
                    comments: true,
                    servicePages: true,
                    menu: false,
                    booking: false,
                    customerPortal: false,
                    analytics: true
                })
            });

            // 2. Reset Site Config
            await fetch('/api/config/site', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    ...siteConfig,
                    template_id: 'custom',
                    business_type: 'custom'
                })
            });

            await popup.alert('Site has been reset to defaults. Refreshing system runtime...');
            window.location.reload();
        } catch (e) {
            console.error(e);
            popup.error('Error resetting site protocol.');
        } finally {
            setSaving(false);
        }
    };

    const loadData = async () => {
        try {
            const [configRes, featuresRes, envRes, lockRes] = await Promise.all([
                fetch('/api/config/site'),
                fetch('/api/admin/features'),
                fetch('/api/admin/env'),
                fetch('/api/admin/setup-lock')
            ]);

            const config = await configRes.json() as any;
            // Features loaded by separate page now
            const env = await envRes.json();
            const lock = await lockRes.json() as { locked: boolean };

            setCurrentBusinessTypeId(config.business_type || config.template_id || 'custom');
            setSiteConfig(config);
            setEnvConfig(env);
            setSetupLocked(lock.locked);
        } catch (e) {
            console.error('Failed to load settings', e);
        } finally {
            setLoading(false);
        }
    };

    useAdminActions([
        {
            id: 'save-settings',
            label: saving ? 'Saving...' : 'Save System Settings',
            onClick: saveEnvConfig,
            variant: 'primary',
            disabled: saving,
            icon: <Save size={14} />,
            showOnMobile: true
        },
        {
            id: 'hard-reset',
            label: 'Hard Reset',
            onClick: handleResetToDefaults,
            variant: 'danger',
            disabled: saving,
            icon: <Trash2 size={14} />
        }
    ]);

    useEffect(() => {
        loadData();
    }, []);

    const businessTypes = getAllBusinessTypes();
    const currentBT = getBusinessType(currentBusinessTypeId);

    const handleSwitchTemplate = async (templateId: string) => {
        const confirmed = await popup.confirm('Warning: Switching business types will overwrite your navigation, features, and theme settings. Site content will be seeded with starter data. Continue?');
        if (confirmed) {
            router.push(`/setup?template=${templateId}&returnTo=/admin/system/advanced`);
        }
    };

    const handleUnlockSetup = async () => {
        const confirmed = await popup.confirm('🔓 Unlock Setup Wizard?\n\nThis will allow you to re-run the initial setup process. Your current configuration won\'t be deleted, but may be overwritten if you complete the wizard.\n\nContinue?');
        if (!confirmed) {
            return;
        }

        setSaving(true);
        try {
            const res = await fetch('/api/admin/setup-lock', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ unlock: true })
            });

            if (res.ok) {
                setSetupLocked(false);
                popup.success('✅ Setup wizard unlocked! You can now access /setup to re-run the wizard.');
            } else {
                popup.error('❌ Failed to unlock setup wizard');
            }
        } catch (e) {
            console.error(e);
            popup.error('❌ Error unlocking setup wizard');
        } finally {
            setSaving(false);
        }
    };

    const handleLockSetup = async () => {
        setSaving(true);
        try {
            const res = await fetch('/api/admin/setup-lock', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ unlock: false })
            });

            if (res.ok) {
                setSetupLocked(true);
                popup.success('🔒 Setup wizard is now secured. Shields active.');
            } else {
                popup.error('❌ Failed to lock setup wizard');
            }
        } catch (e) {
            console.error(e);
            popup.error('❌ Error locking setup wizard');
        } finally {
            setSaving(false);
        }
    };



    if (loading) return (
        <div className="max-w-7xl mx-auto px-6 pt-20">
            <AdminLoadingState message="Connecting to system core..." />
        </div>
    );

    return (
        <div className="max-w-7xl mx-auto px-6 pt-0 space-y-8">
            <AdminHeader
                title={<>Advanced <span className="text-orange-500">Forge</span></>}
                description="Core protocols and system engine configuration."
                breadcrumbs={[
                    { label: 'Admin', href: '/admin' },
                    { label: 'System', href: '/admin/system' },
                    { label: 'Advanced' }
                ]}
                badge={
                    <div className="px-3 py-1.5 bg-orange-500/10 border border-orange-500/20 rounded-lg text-[10px] font-bold uppercase tracking-widest text-orange-600 dark:text-orange-400">
                        System Engine
                    </div>
                }
                actions={
                    <Link
                        href="/admin/system"
                        className="px-3 py-1.5 bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 rounded-lg text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
                    >
                        <ArrowLeft size={12} /> Back
                    </Link>
                }
            />

            {/* Security Status Banners */}
            {searchParams.get('setup_locked') === 'true' && setupLocked && (
                // Locked Banner (Shielded Mode) - Now Warning Yellow
                <div className="relative group overflow-hidden bg-white dark:bg-zinc-900 border-2 border-yellow-500/20 rounded-[2rem] p-6 shadow-[0_20px_60px_-10px_rgba(234,179,8,0.3)] animate-in fade-in slide-in-from-top-4 duration-700">
                    <div className="absolute inset-0 bg-gradient-to-r from-yellow-500/10 via-transparent to-yellow-500/10 animate-pulse-slow pointer-events-none" />
                    <div className="relative z-10 flex flex-col md:flex-row items-center gap-6">
                        <div className="relative">
                            <div className="w-16 h-16 bg-yellow-500 rounded-2xl flex items-center justify-center text-white shadow-[0_10px_40px_-5px_rgba(234,179,8,0.5)] animate-breathing text-3xl">
                                🔒
                            </div>
                        </div>
                        <div className="flex-1 text-center md:text-left space-y-1">
                            <h2 className="text-xl font-black text-page-title uppercase tracking-tight flex items-center justify-center md:justify-start gap-2">
                                System Configuration Locked
                                <span className="inline-block w-2 h-2 rounded-full bg-yellow-500 animate-ping" />
                            </h2>
                            <p className="text-sm text-gray-500 font-medium max-w-2xl">
                                The setup wizard has been hardened to prevent accidental overwrites. You are currently in <b className="text-yellow-600 dark:text-yellow-400">Shielded Mode</b>. To re-run the wizard or change core templates, use the unlock protocol below.
                            </p>
                        </div>
                        <div className="flex flex-col items-center gap-2">
                            <div className="flex items-center gap-2">
                                <div className="w-1 h-8 bg-yellow-500/20 rounded-full hidden md:block" />
                                <div className="text-[10px] font-black text-yellow-600 uppercase tracking-[0.2em] animate-pulse">
                                    Action Required Below
                                </div>
                                <div className="w-1 h-8 bg-yellow-500/20 rounded-full hidden md:block" />
                            </div>
                            <svg className="w-6 h-6 text-yellow-600 animate-bounce mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                            </svg>
                        </div>
                    </div>
                </div>
            )}

            {!setupLocked && (
                // Unlocked Banner (Vulnerable Mode) - Now Danger Red
                <div className="relative group overflow-hidden bg-white dark:bg-zinc-900 border-2 border-red-500/30 rounded-[2rem] p-6 shadow-[0_20px_60px_-10px_rgba(220,38,38,0.4)] animate-in fade-in slide-in-from-top-4 duration-700">
                    <div className="absolute inset-0 bg-gradient-to-r from-red-500/10 via-transparent to-red-500/10 animate-pulse-slow pointer-events-none" />
                    <div className="relative z-10 flex flex-col md:flex-row items-center gap-6">
                        <div className="relative">
                            <div className="w-16 h-16 bg-red-600 rounded-2xl flex items-center justify-center text-white shadow-[0_10px_40px_-5px_rgba(220,38,38,0.6)] animate-breathing-red text-3xl">
                                🔓
                            </div>
                        </div>
                        <div className="flex-1 text-center md:text-left space-y-1">
                            <h2 className="text-xl font-black text-page-title uppercase tracking-tight flex items-center justify-center md:justify-start gap-2">
                                System Vulnerable
                                <span className="inline-block w-2 h-2 rounded-full bg-red-600 animate-ping" />
                            </h2>
                            <p className="text-sm text-gray-500 font-medium max-w-2xl">
                                The setup wizard is publicly accessible. Anyone can re-configure the site or overwrite data. <b className="text-red-600 dark:text-red-400 font-black">Lock immediately</b> if maintenance is complete.
                            </p>
                        </div>
                        <div className="flex items-center gap-3">
                            <button
                                onClick={handleLockSetup}
                                disabled={saving}
                                className="px-6 py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black uppercase tracking-widest shadow-lg shadow-red-600/30 hover:scale-105 active:scale-95 transition-all flex items-center gap-2"
                            >
                                <span className="animate-pulse">🔒</span> Secure Now
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Business Type Section */}
            <section className="space-y-6">
                <div className="flex items-center justify-between">
                    <h2 className="text-xl font-semibold">Business Type</h2>
                    <div className="flex items-center gap-4 mr-12">
                        {setupLocked ? (
                            <>
                                <span className="text-xs font-black uppercase tracking-wider text-green-600 dark:text-green-400 px-4 py-2 bg-green-500/10 dark:bg-green-500/5 rounded-2xl border border-green-500/20 flex items-center gap-2 shadow-sm">
                                    <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                                    System Locked
                                </span>
                                <button
                                    onClick={handleUnlockSetup}
                                    disabled={saving}
                                    className="text-[10px] px-3 py-1.5 bg-yellow-500/10 hover:bg-yellow-500/20 text-yellow-600 dark:text-yellow-400 border border-yellow-500/30 font-bold uppercase tracking-widest rounded-xl transition-all disabled:opacity-50"
                                >
                                    🔓 Unlock Setup
                                </button>
                            </>
                        ) : (
                            <>
                                <button
                                    onClick={() => router.push('/setup')}
                                    className="text-xs px-3 py-1.5 bg-gray-100 dark:bg-zinc-800 hover:bg-gray-200 dark:hover:bg-zinc-700 text-gray-600 dark:text-gray-300 rounded-lg font-bold uppercase tracking-wide transition-colors"
                                >
                                    Re-run Wizard
                                </button>
                                <button
                                    onClick={handleLockSetup}
                                    disabled={saving}
                                    className="text-xs px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-lg font-bold uppercase tracking-wide transition-colors shadow-lg shadow-red-600/20"
                                >
                                    🔒 Lock Setup
                                </button>
                            </>
                        )}
                    </div>
                </div>

                <div className="p-6 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700">
                    <div className="flex items-center gap-4">
                        <div className="text-4xl">
                            {currentBT?.icon || '🔧'}
                        </div>
                        <div>
                            <h3 className="font-bold text-lg">
                                {currentBT?.name || 'Custom Configuration'}
                            </h3>
                            <p className="text-gray-500 text-sm">
                                {currentBT?.description || 'Manually configured settings'}
                            </p>
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {businessTypes.filter(t => t.id !== currentBusinessTypeId).map(t => (
                        <div key={t.id} className="p-4 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-900 transition-colors flex justify-between items-center group">
                            <div className="flex items-center gap-3">
                                <span className="text-2xl">{t.icon}</span>
                                <span className="font-medium">{t.name}</span>
                            </div>
                            <button
                                onClick={() => handleSwitchTemplate(t.id)}
                                className="opacity-0 group-hover:opacity-100 px-3 py-1 text-xs bg-white dark:bg-black border rounded shadow-sm hover:bg-gray-100"
                            >
                                Switch
                            </button>
                        </div>
                    ))}
                </div>
            </section>

            <hr className="dark:border-gray-800" />


            {/* Environment Settings */}
            <section className="p-6 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl">
                <h2 className="text-xl font-bold mb-4">🔐 Environment Settings</h2>
                <p className="text-sm text-gray-500 mb-4">
                    Configure deployment variables. Changes require server restart to take effect locally.
                </p>

                <div className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium mb-1">Site URL</label>
                        <input
                            type="url"
                            value={envConfig.siteUrl}
                            onChange={(e) => setEnvConfig({ ...envConfig, siteUrl: e.target.value })}
                            placeholder="https://your-site.com"
                            className="w-full px-4 py-2 border rounded-lg dark:bg-gray-900 dark:border-gray-700"
                        />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium mb-1">Media Storage Provider</label>
                            <select
                                value={envConfig.mediaStorageProvider}
                                onChange={(e) => setEnvConfig({ ...envConfig, mediaStorageProvider: e.target.value })}
                                className="w-full px-4 py-2 border rounded-lg dark:bg-gray-900 dark:border-gray-700"
                            >
                                <option value="github">GitHub Repository (Free)</option>
                                <option value="r2">Cloudflare R2 (Scale)</option>
                            </select>
                        </div>

                        <div>
                            <label className="block text-sm font-medium mb-1">Cloudflare Account ID</label>
                            <input
                                type="text"
                                value={envConfig.cloudflareAccountId}
                                onChange={(e) => setEnvConfig({ ...envConfig, cloudflareAccountId: e.target.value })}
                                className="w-full px-4 py-2 border rounded-lg font-mono text-sm dark:bg-gray-900 dark:border-gray-700"
                            />
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium mb-1">GitHub Token</label>
                            <input
                                type="password"
                                value={envConfig.githubToken}
                                onChange={(e) => setEnvConfig({ ...envConfig, githubToken: e.target.value })}
                                placeholder="ghp_xxxxxxxxxxxx"
                                className="w-full px-4 py-2 border rounded-lg font-mono text-sm dark:bg-gray-900 dark:border-gray-700"
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-medium mb-1">GitHub Repository</label>
                            <input
                                type="text"
                                value={envConfig.githubRepo}
                                onChange={(e) => setEnvConfig({ ...envConfig, githubRepo: e.target.value })}
                                placeholder="username/repo"
                                className="w-full px-4 py-2 border rounded-lg font-mono text-sm dark:bg-gray-900 dark:border-gray-700"
                            />
                        </div>
                    </div>
                </div>
            </section>

            <hr className="dark:border-gray-800" />




            <style jsx global>{`
                @keyframes breathing {
                    0%, 100% { transform: scale(1); box-shadow: 0 10px 40px -5px rgba(234, 119, 8, 0.4); }
                    50% { transform: scale(1.05); box-shadow: 0 20px 60px 0px rgba(234, 119, 8, 0.6); }
                }
                @keyframes breathing-red {
                    0%, 100% { transform: scale(1); box-shadow: 0 10px 40px -5px rgba(220, 38, 38, 0.5); }
                    50% { transform: scale(1.05); box-shadow: 0 20px 60px 0px rgba(220, 38, 38, 0.7); }
                }
                .animate-breathing {
                    animation: breathing 4s ease-in-out infinite;
                }
                .animate-breathing-red {
                    animation: breathing-red 4s ease-in-out infinite;
                }
                .animate-spin-slow {
                    animation: spin 8s linear infinite;
                }
                .animate-pulse-slow {
                    animation: pulse 6s cubic-bezier(0.4, 0, 0.6, 1) infinite;
                }
            `}</style>
        </div>
    );
}
