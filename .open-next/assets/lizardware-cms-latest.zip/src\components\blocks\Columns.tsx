'use client';

import React from 'react';

interface ColumnsProps {
    blocks: any[]; // Recursive block rendering is handled by the PageRenderer usually
    columns?: number;
    gap?: string;
    className?: string;
    children?: React.ReactNode;
}

export default function Columns({ columns = 2, gap = '1.5rem', className = '', children }: ColumnsProps) {
    const gridCols = {
        1: 'grid-cols-1',
        2: 'grid-cols-1 md:grid-cols-2',
        3: 'grid-cols-1 md:grid-cols-3',
        4: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4'
    }[columns as 1 | 2 | 3 | 4] || 'grid-cols-1 md:grid-cols-2';

    return (
        <div
            className={`grid ${gridCols} ${className} items-start`}
            style={{ gap: gap }}
        >
            {children}
        </div>
    );
}
