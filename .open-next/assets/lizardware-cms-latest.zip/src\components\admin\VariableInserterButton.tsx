'use client';

import { useState } from 'react';
import { Editor } from '@tiptap/react';
import { Zap } from 'lucide-react';
import VariableInserterModal from './VariableInserterModal';

interface VariableInserterButtonProps {
    editor: Editor | null;
}

export default function VariableInserterButton({ editor }: VariableInserterButtonProps) {
    const [isOpen, setIsOpen] = useState(false);

    const handleInsert = (variableName: string) => {
        if (!editor) return;

        editor
            .chain()
            .focus()
            .insertVariable(variableName)
            .run();
    };

    if (!editor) return null;

    return (
        <>
            <button
                onClick={() => setIsOpen(true)}
                className="p-2 hover:bg-purple-50 dark:hover:bg-purple-900/20 rounded-lg transition-colors group"
                title="Insert Variable (dynamic content)"
                type="button"
                tabIndex={-1}
            >
                <Zap size={16} className="text-gray-600 dark:text-gray-400 group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors" />
            </button>

            <VariableInserterModal
                isOpen={isOpen}
                onClose={() => setIsOpen(false)}
                onInsert={handleInsert}
            />
        </>
    );
}
