"use client";

import { useState, useEffect } from "react";
import { Plus, Trash2, Edit2, Layout, X, Check, Tag } from "lucide-react";
import { AdminLoadingState } from "./AdminLoadingState";
import { usePopup } from "./AdminPopupProvider";

interface Category {
    id: string;
    name: string;
    slug: string;
    description?: string;
}

export default function CategoryManager() {
    const popup = usePopup();
    const [categories, setCategories] = useState<Category[]>([]);
    const [loading, setLoading] = useState(true);
    const [isEditing, setIsEditing] = useState(false);
    const [currentCategory, setCurrentCategory] = useState<Category>({ id: "", name: "", slug: "", description: "" });
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        fetchCategories();
    }, []);

    const fetchCategories = async () => {
        try {
            const res = await fetch("/api/admin/blog/categories");
            if (res.ok) {
                const data = await res.json() as { categories: Category[] };
                setCategories(data.categories || []);
            }
        } catch (err) {
            console.error("Error fetching categories:", err);
        } finally {
            setLoading(false);
        }
    };

    const handleSave = async () => {
        if (!currentCategory.name || !currentCategory.slug) {
            setError("Name and Slug are required");
            return;
        }

        try {
            const categoryToSave = {
                ...currentCategory,
                id: currentCategory.id || currentCategory.slug
            };

            const res = await fetch("/api/admin/blog/categories", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(categoryToSave)
            });

            if (res.ok) {
                setIsEditing(false);
                setCurrentCategory({ id: "", name: "", slug: "", description: "" });
                fetchCategories();
            } else {
                const data = await res.json() as { error?: string };
                setError(data.error || "Failed to save category");
            }
        } catch (err) {
            setError("Failed to save category");
        }
    };

    const handleDelete = async (id: string) => {
        const confirmed = await popup.confirm("Delete this category? Posts using it will become uncategorized.", { isDanger: true });
        if (!confirmed) return;

        try {
            const res = await fetch(`/api/admin/blog/categories?id=${id}`, { method: "DELETE" });
            if (res.ok) {
                fetchCategories();
            }
        } catch (err) {
            console.error("Error deleting category:", err);
        }
    };

    const handleEdit = (cat: Category) => {
        setCurrentCategory(cat);
        setIsEditing(true);
    };

    const generateSlug = (name: string) => {
        return name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    };

    if (loading) return <AdminLoadingState message="Scanning classifications..." />;

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-xl font-black text-page-title flex items-center gap-2">
                    <Layout className="text-purple-500" size={20} />
                    Classification Hub
                </h2>
                {!isEditing && (
                    <button
                        onClick={() => {
                            setCurrentCategory({ id: "", name: "", slug: "", description: "" });
                            setIsEditing(true);
                        }}
                        className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-purple-500/20"
                    >
                        <Plus size={16} /> New Category
                    </button>
                )}
            </div>

            {isEditing && (
                <div className="bg-gray-50 dark:bg-zinc-800/50 rounded-2xl p-6 border-2 border-dashed border-purple-500/20 animate-in fade-in slide-in-from-top-4 duration-300">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-sm font-bold text-page-title uppercase tracking-wider">
                            {currentCategory.id ? "Edit Classification" : "New Classification"}
                        </h3>
                        <button onClick={() => setIsEditing(false)} className="text-gray-400 hover:text-gray-600">
                            <X size={18} />
                        </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Category Name</label>
                            <input
                                type="text"
                                value={currentCategory.name}
                                onChange={(e) => {
                                    const name = e.target.value;
                                    setCurrentCategory({
                                        ...currentCategory,
                                        name,
                                        slug: currentCategory.id ? currentCategory.slug : generateSlug(name)
                                    });
                                }}
                                className="w-full px-4 py-2 bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-xl text-sm"
                                placeholder="e.g. Technology"
                            />
                        </div>
                        <div className="space-y-2">
                            <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">URL Slug</label>
                            <input
                                type="text"
                                value={currentCategory.slug}
                                onChange={(e) => setCurrentCategory({ ...currentCategory, slug: e.target.value })}
                                className="w-full px-4 py-2 bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-xl text-sm font-mono"
                                placeholder="technology"
                            />
                        </div>
                        <div className="md:col-span-2 space-y-2">
                            <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Description (Optional)</label>
                            <textarea
                                value={currentCategory.description}
                                onChange={(e) => setCurrentCategory({ ...currentCategory, description: e.target.value })}
                                className="w-full px-4 py-2 bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-xl text-sm min-h-[80px]"
                                placeholder="What kind of transmissions go here?"
                            />
                        </div>
                    </div>

                    {error && <p className="text-red-500 text-[10px] font-bold mt-2 uppercase">{error}</p>}

                    <div className="mt-6 flex justify-end gap-3">
                        <button
                            onClick={() => setIsEditing(false)}
                            className="px-4 py-2 text-xs font-bold text-gray-400 hover:text-gray-600 transition-colors"
                        >
                            Cancel
                        </button>
                        <button
                            onClick={handleSave}
                            className="flex items-center gap-2 px-6 py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-emerald-500/20"
                        >
                            <Check size={16} /> Save Classification
                        </button>
                    </div>
                </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {categories.map((cat) => (
                    <div
                        key={cat.id}
                        className="group relative bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-2xl p-5 hover:border-purple-500/30 hover:shadow-xl hover:shadow-purple-500/5 transition-all duration-300"
                    >
                        <div className="flex justify-between items-start mb-2">
                            <div className="bg-purple-50 dark:bg-purple-900/20 p-2 rounded-xl text-purple-500">
                                <Tag size={16} />
                            </div>
                            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button
                                    onClick={() => handleEdit(cat)}
                                    className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-lg text-gray-400 hover:text-purple-500 transition-colors"
                                >
                                    <Edit2 size={14} />
                                </button>
                                <button
                                    onClick={() => handleDelete(cat.id)}
                                    className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-lg text-gray-400 hover:text-red-500 transition-colors"
                                >
                                    <Trash2 size={14} />
                                </button>
                            </div>
                        </div>
                        <h3 className="text-base font-bold text-page-title">{cat.name}</h3>
                        <p className="text-[10px] font-mono text-gray-400 mb-2">/{cat.slug}</p>
                        {cat.description && (
                            <p className="text-xs text-gray-500 line-clamp-2 leading-relaxed">
                                {cat.description}
                            </p>
                        )}
                    </div>
                ))}

                {categories.length === 0 && !isEditing && (
                    <div className="md:col-span-3 py-20 text-center space-y-4 bg-gray-50 dark:bg-zinc-900/50 rounded-3xl border-2 border-dashed border-gray-200 dark:border-zinc-800">
                        <div className="w-16 h-16 bg-white dark:bg-zinc-900 rounded-2xl border border-gray-100 dark:border-zinc-800 flex items-center justify-center mx-auto text-gray-300">
                            <Layout size={32} />
                        </div>
                        <div>
                            <p className="text-sm font-bold text-page-title">No Classifications Found</p>
                            <p className="text-xs text-gray-400">Start by creating your first category for transmissions.</p>
                        </div>
                        <button
                            onClick={() => setIsEditing(true)}
                            className="px-6 py-2 bg-purple-600 text-white rounded-xl text-xs font-bold hover:bg-purple-700 transition-all"
                        >
                            Create One Now
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
}
