import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export const runtime = 'nodejs';

export async function GET() {
    try {
        const wranglerPath = path.join(process.cwd(), 'wrangler.jsonc');

        if (!fs.existsSync(wranglerPath)) {
            return NextResponse.json({ error: 'wrangler.jsonc not found' }, { status: 404 });
        }

        const content = fs.readFileSync(wranglerPath, 'utf8');

        // Parse JSONC (remove comments)
        const jsonContent = content
            .split('\n')
            .filter(line => !line.trim().startsWith('//'))
            .join('\n')
            .replace(/\/\*[\s\S]*?\*\//g, ''); // Remove block comments

        const config = JSON.parse(jsonContent);

        // Extract binding info
        const result: any = {};

        if (config.kv_namespaces && config.kv_namespaces.length > 0) {
            result.kv = config.kv_namespaces[0];
        }

        if (config.d1_databases && config.d1_databases.length > 0) {
            result.d1 = config.d1_databases[0];
        }

        if (config.r2_buckets && config.r2_buckets.length > 0) {
            result.r2 = config.r2_buckets[0];
        }

        return NextResponse.json(result);
    } catch (error: any) {
        console.error('[Diagnostics] Error reading wrangler.jsonc:', error);
        return NextResponse.json(
            { error: 'Failed to read configuration', details: error.message },
            { status: 500 }
        );
    }
}
