'use client';

import { ReactNode } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { ChevronDown, ExternalLink, Menu } from "lucide-react";
import { ThemeToggle } from '@/components/ui/ThemeToggle';
import { UserMenu } from '@/components/admin/UserMenu';
import { useFeatures } from '@/hooks/useFeatures';
import { useAdminActionsContext, AdminAction } from '@/context/AdminActionsContext';

interface NavItem {
    label: string | ReactNode;
    href: string;
    target?: string;
    feature?: string;
}

interface NavDropdownProps {
    label: ReactNode;
    href: string;
    items: NavItem[];
    hubLabel?: string;
    showHubLink?: boolean;
    align?: 'left' | 'right';
    side?: 'top' | 'bottom';
}

export function NavDropdown({
    label,
    href,
    items,
    hubLabel,
    showHubLink = true,
    align = 'left',
    side = 'bottom'
}: NavDropdownProps) {
    const pathname = usePathname();
    const active = pathname === href || (href !== '/admin' && pathname?.startsWith(href));
    const dropUp = side === 'top';

    return (
        <div className="relative group/dropdown z-[120] hover:z-[150]">
            <div className="py-2 px-0.5">
                <div
                    className={`text-[10px] font-bold uppercase tracking-tight px-3 py-1.5 transition-all flex items-center gap-1.5 relative z-[160] cursor-default ${active
                        ? "bg-white dark:bg-zinc-700 text-primary shadow-sm ring-1 ring-black/5 rounded-t rounded-b-none border-b-transparent"
                        : "text-gray-500 group-hover/dropdown:text-primary group-hover/dropdown:bg-white dark:group-hover/dropdown:bg-zinc-700 group-hover/dropdown:shadow-sm group-hover/dropdown:ring-1 group-hover/dropdown:ring-black/5 rounded group-hover/dropdown:rounded-b-none"
                        }`}
                >
                    {label}
                    <ChevronDown size={10} className={`opacity-80 transition-transform ${dropUp ? 'rotate-180 group-hover/dropdown:rotate-0' : 'group-hover/dropdown:rotate-180'}`} />
                </div>
            </div>

            <div
                className={`absolute ${dropUp ? 'bottom-full' : 'top-full'} ${align === 'left' ? 'left-0.5' : 'right-0.5'} opacity-0 invisible group-hover/dropdown:opacity-100 group-hover/dropdown:visible transition-all duration-200 ease-out z-[150] min-w-[240px] ${dropUp ? '-mb-6 pb-4' : '-mt-6 pt-4'}`}
            >
                {/* Clear space to prevent hover loss */}
                <div className={`absolute ${dropUp ? 'bottom-0' : 'top-0'} inset-x-0 h-6 bg-transparent cursor-default`} />

                <div className={`relative bg-white dark:bg-zinc-700 border border-gray-100 dark:border-zinc-800 rounded-lg shadow-2xl p-1.5 ring-1 ring-black/10 shadow-black/20 ${align === 'left' ? 'rounded-tl-none' : 'rounded-tr-none'
                    }`}>
                    <div className="relative z-10">
                        {showHubLink && hubLabel && (
                            <>
                                <Link
                                    href={href}
                                    className="block text-center text-[10px] font-bold uppercase tracking-wider px-4 py-3 rounded-md bg-gradient-to-r from-primary/10 to-primary/5 text-primary border border-primary/20 transition-all hover:from-primary/20 hover:to-primary/10 hover:border-primary/30 hover:shadow-sm mb-2"
                                >
                                    {hubLabel}
                                </Link>
                                <div className="h-px bg-gradient-to-r from-transparent via-gray-200 dark:via-zinc-600 to-transparent mb-2" />
                            </>
                        )}

                        {items.map((item, idx) => (
                            <Link
                                key={`${item.href}-${idx}`}
                                href={item.href}
                                target={item.target}
                                className={`block text-[10px] font-bold uppercase tracking-wider px-4 py-3 rounded-md hover:bg-gray-50 dark:hover:bg-black/20 text-zinc-500 dark:text-zinc-300 hover:text-primary dark:hover:text-white transition-colors flex items-center justify-between group/item ${align === 'right' ? 'flex-row-reverse text-right' : ''}`}
                            >
                                <span className="flex items-center gap-2">
                                    {item.label}
                                </span>
                                <span className={`opacity-0 group-hover/item:opacity-100 transition-opacity text-[8px] transform transition-transform ${align === 'right' ? '-translate-x-1 group-hover/item:translate-x-0 rotate-180' : 'translate-x-1 group-hover/item:translate-x-0'}`}>→</span>
                            </Link>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
}

function ActionButton({ action, mobile = false }: { action: AdminAction, mobile?: boolean }) {
    const baseClasses = "flex items-center gap-2 px-4 py-2 rounded-lg font-bold text-xs uppercase tracking-wider transition-all active:scale-95";

    // Variant styles
    const variants = {
        primary: "bg-primary text-white shadow-lg shadow-primary/20 hover:bg-primary/90",
        secondary: "bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700",
        ghost: "text-zinc-500 hover:text-zinc-900 dark:hover:text-white hover:bg-zinc-100 dark:hover:bg-zinc-800",
        danger: "bg-red-50 text-red-600 hover:bg-red-100 border border-red-200",
        success: "bg-green-50 text-green-600 hover:bg-green-100 border border-green-200"
    };

    const className = `${baseClasses} ${variants[action.variant || 'secondary']} ${action.disabled ? 'opacity-50 cursor-not-allowed grayscale' : ''}`;

    if (action.href) {
        return (
            <Link href={action.href} className={className}>
                {action.icon}
                {action.label}
            </Link>
        );
    }

    return (
        <button onClick={action.onClick} disabled={action.disabled} className={className}>
            {action.icon}
            {action.label}
        </button>
    );
}

interface OrbitalNavProps {
    position: 'top' | 'bottom';
    onMobileMenuOpen?: () => void;
}

export function OrbitalNav({ position, onMobileMenuOpen }: OrbitalNavProps) {
    const isBottom = position === 'bottom';
    const features = useFeatures();
    const { actions } = useAdminActionsContext();

    const filterItems = (items: NavItem[]) => {
        return items.filter(item => !item.feature || features[item.feature]);
    };

    return (
        <div className={`${isBottom ? 'fixed bottom-0 border-t shadow-[0_-4px_12px_rgba(0,0,0,0.05)]' : 'relative border-b'} w-full z-[110] bg-white dark:bg-zinc-900 border-gray-100 dark:border-zinc-800`}>
            <div className="mx-auto max-w-[1500px] px-6 h-14 flex items-center justify-between gap-4">
                {/* Left Wing */}
                <div className="flex items-center gap-3 lg:gap-8 flex-1">
                    {!isBottom && (
                        <>
                            <Link href="/admin" className="flex items-center gap-2 group shrink-0">
                                <div className="w-8 h-8 bg-zinc-900 dark:bg-white rounded flex items-center justify-center text-sm group-hover:scale-105 transition-transform shadow-lg">🦎</div>
                                <div className="hidden sm:block">
                                    <div className="text-[10px] font-black uppercase tracking-[0.2em] text-page-title leading-tight">Lizardware</div>
                                    <div className="text-[9px] font-bold text-primary tracking-widest uppercase opacity-80">Command</div>
                                </div>
                            </Link>
                            <nav className="hidden lg:flex items-center gap-3 group/nav text-gray-900 dark:text-gray-100">
                                <NavDropdown
                                    label="Content"
                                    href="/admin/content"
                                    hubLabel="📦 Content Hub 📦"
                                    items={filterItems([
                                        { label: 'Blog Dashboard', href: '/admin/content/blog', feature: 'blog' },
                                        { label: 'Pages Playground', href: '/admin/content/pages' },
                                        { label: 'Media Library', href: '/admin/content/media', feature: 'gallery' },
                                        { label: 'Categories', href: '/admin/content/blog/categories', feature: 'blog' },
                                        { label: 'Authors', href: '/admin/content/blog/authors', feature: 'blog' }
                                    ])}
                                />
                                <NavDropdown
                                    label="Growth"
                                    href="/admin/growth"
                                    hubLabel="🚀 Growth Hub 🚀"
                                    items={filterItems([
                                        { label: 'SEO Toolkit', href: '/admin/growth/seo' },
                                        { label: 'Revenue Streams', href: '/admin/growth/monetization', feature: 'monetization' },
                                        { label: 'Newsletter Hub', href: '/admin/growth/newsletter', feature: 'newsletter' },
                                        { label: 'Analytics', href: '/admin/growth/analytics', feature: 'analytics' }
                                    ])}
                                />
                            </nav>
                        </>
                    )}
                </div>

                {/* Centerpiece - Universal Action Portal */}
                <div className="flex-none flex items-center justify-center gap-2" id={isBottom ? "admin-actions-portal" : undefined}>
                    {isBottom && (
                        <>
                            {/* Mobile View: Primary Action Only */}
                            <div className="lg:hidden flex items-center justify-center w-full">
                                {actions.filter(a => a.showOnMobile).slice(0, 1).map(action => (
                                    <ActionButton key={action.id} action={action} mobile />
                                ))}
                            </div>

                            {/* Desktop View: All Actions */}
                            <div className="hidden lg:flex items-center gap-3">
                                {actions.map(action => (
                                    <ActionButton key={action.id} action={action} />
                                ))}
                            </div>
                        </>
                    )}
                </div>

                {/* Right Wing */}
                <div className="flex items-center gap-6 flex-1 justify-end">
                    {isBottom ? (
                        <div className="flex items-center">
                            <Link
                                href="/"
                                target="_blank"
                                className="flex items-center gap-2 px-3 py-1.5 bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 rounded-md text-[9px] font-black uppercase tracking-widest hover:scale-105 transition-all shadow-sm group/launch"
                            >
                                <ExternalLink size={12} className="group-hover:scale-110 transition-transform" />
                                <span className="hidden sm:inline">Launch Site</span>
                            </Link>
                        </div>
                    ) : (
                        <>
                            <nav className="hidden lg:flex items-center gap-2 text-gray-900 dark:text-gray-100">
                                <NavDropdown
                                    label="Design"
                                    href="/admin/design"
                                    hubLabel="🎨 Design Hub 🎨"
                                    align="right"
                                    items={filterItems([
                                        { label: 'Module Manager', href: '/admin/design/features' },
                                        { label: 'Visual Identity', href: '/admin/design/identity' },
                                        { label: 'Theme Transformer', href: '/admin/design/theme' },
                                        { label: 'Navigation Menu', href: '/admin/design/nav' }
                                    ])}
                                />
                                <NavDropdown
                                    label="System"
                                    href="/admin/system"
                                    hubLabel="⚙️ System Core ⚙️"
                                    align="right"
                                    items={filterItems([
                                        { label: 'Core Forge', href: '/admin/system/advanced' },
                                        { label: 'Legacy Config', href: '/admin/system/config' },
                                        { label: 'Database Logs', href: '/admin/system/logs' },
                                        { label: 'Documentation', href: '/admin/system/docs' },
                                        { label: 'Roadmap', href: '/admin/system/roadmap' },
                                        { label: 'Changelog', href: '/admin/system/changelog' }
                                    ])}
                                />
                                <NavDropdown
                                    label={<span className="text-orange-500 dark:text-orange-400">Testing</span>}
                                    href="/admin/testing"
                                    hubLabel="🧪 Testing Hub 🧪"
                                    align="right"
                                    items={filterItems([
                                        { label: 'Alpha Testing Guide', href: '/admin/testing/alpha-guide', target: '_blank' },
                                        { label: 'Alpha Tester Notes', href: '/admin/testing/alpha-tester-notes', target: '_blank' },
                                        { label: 'Beta Tester Notes', href: '/admin/testing/beta-tester-notes', target: '_blank' },
                                        { label: 'UAT Testing Procedures', href: '/admin/testing/uat' },
                                        { label: 'UAT Support Quick Reference', href: '/admin/testing/quick-reference', target: '_blank' }
                                    ])}
                                />

                                <div className="flex items-center px-2">
                                    <ThemeToggle />
                                </div>

                                <UserMenu />
                            </nav>

                            <div className="lg:hidden flex items-center ml-2">
                                <button onClick={onMobileMenuOpen} className="p-2 -mr-2 text-zinc-600 dark:text-zinc-300">
                                    <Menu size={24} />
                                </button>
                            </div>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
}

