'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { createPortal } from 'react-dom';
import { usePopup } from '@/components/admin/AdminPopupProvider';
import { SiteConfig } from '@/types/site-config';
import { Save, RotateCcw, Globe, Search, Share2, Palette, Cpu, ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import AdminCommandBar, { CommandBarButton } from "@/components/admin/AdminCommandBar";
import { AdminLoadingState } from "@/components/admin/AdminLoadingState";
import { AdminHeader } from "@/components/admin/AdminHeader";

export default function SiteConfigPage() {
    const [config, setConfig] = useState<SiteConfig | null>(null);
    const [savedConfig, setSavedConfig] = useState<SiteConfig | null>(null);
    const [loading, setLoading] = useState(true);
    const [isSaveModalOpen, setIsSaveModalOpen] = useState(false);
    const [isRevertModalOpen, setIsRevertModalOpen] = useState(false);
    const [mounted, setMounted] = useState(false);
    const router = useRouter();
    const popup = usePopup();

    useEffect(() => {
        setMounted(true);
    }, []);

    useEffect(() => {
        fetch('/api/config/site')
            .then((res) => res.json() as Promise<SiteConfig>)
            .then((data) => {
                console.log('Site config loaded:', data);
                // Ensure seo object exists with defaults
                if (!data.seo) {
                    data.seo = {
                        title: '',
                        description: '',
                        keywords: [],
                        author: '',
                        twitterHandle: ''
                    };
                }
                setConfig(data);
                setSavedConfig(data);
                setLoading(false);
            })
            .catch((err) => {
                console.error('Error fetching config:', err);
                setLoading(false);
            });
    }, []);

    const handleSaveConfirm = async () => {
        if (!config) return;
        try {
            const res = await fetch('/api/config/site', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(config)
            });
            if (res.ok) {
                setSavedConfig(config);
                popup.success('Global configuration synchronized successfully.');
                router.refresh();
            } else {
                popup.error('Failed to commit configuration.');
            }
        } catch (err) {
            console.error(err);
            popup.error('Connectivity interruption during configuration save.');
        }
    };

    const handleRevertConfirm = () => {
        if (savedConfig) {
            setConfig(JSON.parse(JSON.stringify(savedConfig)));
        }
    };

    const updateNestedField = (path: string, value: string | string[]) => {
        if (!config) return;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const newConfig = { ...config } as any;
        const keys = path.split('.');
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        let current: any = newConfig;

        // Create missing intermediate objects
        for (let i = 0; i < keys.length - 1; i++) {
            if (!current[keys[i]] || typeof current[keys[i]] !== 'object') {
                current[keys[i]] = {};
            }
            current = current[keys[i]];
        }

        current[keys[keys.length - 1]] = value;
        setConfig(newConfig);
    };

    if (loading || !config) {
        return (
            <div className="max-w-7xl mx-auto px-6 pt-20">
                <AdminLoadingState message={loading ? "Recalibrating site settings..." : "Failed to load configuration."} />
            </div>
        );
    }

    const hasChanges = JSON.stringify(config) !== JSON.stringify(savedConfig);

    return (
        <div className="max-w-7xl mx-auto px-6 pt-0 space-y-8">

            <AdminHeader
                title={<>Settings <span className="text-orange-500">Studio</span></>}
                description="Global site metadata, SEO defaults, and branding protocols."
                breadcrumbs={[
                    { label: 'Admin', href: '/admin' },
                    { label: 'System', href: '/admin/system' },
                    { label: 'Config' }
                ]}
                badge={
                    <div className="px-3 py-1.5 bg-orange-500/10 border border-orange-500/20 rounded-lg text-[10px] font-bold uppercase tracking-widest text-orange-600 dark:text-orange-400">
                        System Engine
                    </div>
                }
                actions={
                    <Link
                        href="/admin/system"
                        className="px-3 py-1.5 bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 rounded-lg text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
                    >
                        <ArrowLeft size={12} /> Back
                    </Link>
                }
            />

            <div className="space-y-6">
                {/* Basic Info */}
                <ConfigSection title="Site Identity" icon={<Globe className="text-blue-500" />}>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <InputField
                            label="Site Name"
                            value={config.name}
                            onChange={(val) => setConfig({ ...config, name: val })}
                        />
                        <InputField
                            label="Canonical URL"
                            value={config.url}
                            onChange={(val) => setConfig({ ...config, url: val })}
                            placeholder="https://yourdomain.com"
                        />
                        <div className="md:col-span-2">
                            <TextAreaField
                                label="Description"
                                value={config.description}
                                onChange={(val) => setConfig({ ...config, description: val })}
                            />
                        </div>
                    </div>
                </ConfigSection>

                {/* SEO Settings */}
                <ConfigSection title="SEO & Search" icon={<Search className="text-amber-500" />}>
                    <div className="space-y-4">
                        <InputField
                            label="SEO Title Template"
                            value={config.seo.title}
                            onChange={(val) => updateNestedField('seo.title', val)}
                        />
                        <TextAreaField
                            label="Meta Description"
                            value={config.seo.description}
                            onChange={(val) => updateNestedField('seo.description', val)}
                        />
                        <InputField
                            label="Keywords (comma separated)"
                            value={config.seo.keywords.join(', ')}
                            onChange={(val) => updateNestedField('seo.keywords', val.split(',').map(k => k.trim()))}
                        />
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <InputField
                                label="Author"
                                value={config.seo.author}
                                onChange={(val) => updateNestedField('seo.author', val)}
                            />
                            <InputField
                                label="Twitter Handle"
                                value={config.seo.twitterHandle || ''}
                                onChange={(val) => updateNestedField('seo.twitterHandle', val)}
                                placeholder="@username"
                            />
                        </div>
                    </div>
                </ConfigSection>

                {/* Social & Sharing */}
                <ConfigSection title="Social & Open Graph" icon={<Share2 className="text-purple-500" />}>
                    <div className="space-y-4">
                        <InputField
                            label="Default OG Image URL"
                            value={config.ogImage}
                            onChange={(val) => setConfig({ ...config, ogImage: val })}
                        />
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-slate-100 dark:border-zinc-800">
                            <InputField
                                label="GitHub URL"
                                value={config.links.github || ''}
                                onChange={(val) => updateNestedField('links.github', val)}
                            />
                            <InputField
                                label="Twitter URL"
                                value={config.links.twitter || ''}
                                onChange={(val) => updateNestedField('links.twitter', val)}
                            />
                            <InputField
                                label="LinkedIn URL"
                                value={config.links.linkedin || ''}
                                onChange={(val) => updateNestedField('links.linkedin', val)}
                            />
                        </div>
                    </div>
                </ConfigSection>

                {/* Branding Display Info */}
                <ConfigSection title="Site Branding Defaults" icon={<Palette className="text-emerald-500" />}>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <InputField
                            label="OG Locale"
                            value={config.openGraph.locale}
                            onChange={(val) => updateNestedField('openGraph.locale', val)}
                        />
                        <InputField
                            label="OG Site Name"
                            value={config.openGraph.siteName}
                            onChange={(val) => updateNestedField('openGraph.siteName', val)}
                        />
                    </div>
                </ConfigSection>
            </div>
        </div>
    );

    {/* Admin Actions Portal - rendered outside main flow but logically here */ }
    {
        mounted && (() => {
            const portalTarget = document.getElementById('admin-actions-portal');
            if (!portalTarget) return null;

            return createPortal(
                <div className="flex items-center gap-2 pointer-events-auto">
                    <CommandBarButton
                        onClick={async () => {
                            const confirmed = await popup.confirm('Are you sure you want to revert to the last saved configuration? All unsaved changes will be lost.', { isDanger: true });
                            if (confirmed) handleRevertConfirm();
                        }}
                        disabled={!hasChanges}
                        label="Revert Logic"
                        variant="secondary"
                        icon={<RotateCcw size={14} />}
                    />
                    <CommandBarButton
                        onClick={async () => {
                            const confirmed = await popup.confirm('Are you sure you want to save these configuration changes? These affect your site SEO and branding.');
                            if (confirmed) await handleSaveConfirm();
                        }}
                        disabled={!hasChanges}
                        label="Apply Settings"
                        variant="primary"
                        icon={<Save size={14} />}
                    />
                </div>,
                portalTarget!
            );
        })()
    }
}

function ConfigSection({ title, icon, children }: { title: string, icon: React.ReactNode, children: React.ReactNode }) {
    return (
        <div className="bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-xl shadow-sm overflow-hidden">
            <div className="p-4 border-b border-slate-100 dark:border-zinc-800 flex items-center gap-2 bg-slate-50 dark:bg-zinc-900/50">
                {icon}
                <h2 className="font-bold text-slate-800 dark:text-zinc-200 text-sm uppercase tracking-wide">{title}</h2>
            </div>
            <div className="p-6">
                {children}
            </div>
        </div>
    );
}

function InputField({ label, value, onChange, placeholder = "" }: { label: string, value: string, onChange: (val: string) => void, placeholder?: string }) {
    return (
        <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">{label}</label>
            <input
                type="text"
                value={value}
                placeholder={placeholder}
                onChange={(e) => onChange(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 dark:border-zinc-800 rounded-lg bg-white dark:bg-zinc-950 text-slate-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-transparent outline-none text-sm transition-all"
            />
        </div>
    );
}

function TextAreaField({ label, value, onChange }: { label: string, value: string, onChange: (val: string) => void }) {
    return (
        <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">{label}</label>
            <textarea
                value={value}
                rows={3}
                onChange={(e) => onChange(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 dark:border-zinc-800 rounded-lg bg-white dark:bg-zinc-950 text-slate-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-transparent outline-none text-sm transition-all"
            />
        </div>
    );
}
