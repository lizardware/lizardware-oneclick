import { NextResponse } from 'next/server';

export const runtime = 'nodejs';

export async function POST(req: Request) {
    try {
        const { apiToken } = await req.json() as { apiToken: string };

        if (!apiToken) {
            return NextResponse.json({ error: 'API Token is required' }, { status: 400 });
        }

        // Attempt to list accounts to find the ID
        // This endpoint returns a list of accounts the token has access to
        const response = await fetch('https://api.cloudflare.com/client/v4/accounts', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${apiToken}`,
                'Content-Type': 'application/json'
            }
        });

        const data = await response.json() as any;

        if (!response.ok) {
            // If the token doesn't have permissions to list accounts, we fail gracefully
            // The user will just have to enter it manually.
            return NextResponse.json({
                success: false,
                error: data.errors?.[0]?.message || 'Could not list accounts'
            });
        }

        const accounts = data.result || [];

        if (accounts.length === 0) {
            return NextResponse.json({ success: false, error: 'No accounts found for this token' });
        }

        // If explicitly one account, return it.
        // If multiple, we might return the first one but that's risky. 
        // For now, let's return the first one and let the user correct it if wrong.
        // In most single-user/setup cases, there's only one relevant account.
        const accountId = accounts[0].id;
        const accountName = accounts[0].name;

        return NextResponse.json({
            success: true,
            accountId,
            accountName
        });

    } catch (error: any) {
        console.error('[Account Lookup] Error:', error);
        return NextResponse.json({ success: false, error: error.message }, { status: 500 });
    }
}
