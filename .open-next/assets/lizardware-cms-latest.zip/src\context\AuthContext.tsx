'use client';

import { createContext, useContext, ReactNode } from 'react';

export interface AuthUser {
    id: string;
    email: string | undefined;
    name: string | null;
    imageUrl: string | null;
    role: string | null;
}

export interface AuthContextType {
    user: AuthUser | null;
    isLoaded: boolean;
    isSignedIn: boolean;
    signIn: () => void; // For local auth, just a stub or direct action
    signOut: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function useAuth() {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
}

export const AuthProviderContext = AuthContext;
