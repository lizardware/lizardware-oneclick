import { Zap } from 'lucide-react';

interface Feature {
    title: string;
    description: string;
}

interface FeatureGridProps {
    title?: string;
    columns?: number;
    features: Feature[];
}

export default function FeatureGrid({ title, columns = 3, features = [] }: FeatureGridProps) {
    return (
        <div className="w-full">
            {title && (
                <h2 className="text-3xl font-bold text-center mb-16 text-page-title">
                    {title}
                </h2>
            )}

            <div className={`grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-${columns}`}>
                {features.map((feature, idx) => (
                    <div
                        key={idx}
                        className="bg-card-background p-8 rounded-2xl shadow-sm border border-borders hover:shadow-md transition-shadow"
                    >
                        <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center text-primary mb-6">
                            <Zap size={24} />
                        </div>
                        <h3 className="text-xl font-bold mb-3 text-page-title">{feature.title}</h3>
                        <p className="text-page-text leading-relaxed">
                            {feature.description}
                        </p>
                    </div>
                ))}
            </div>
        </div>
    );
}
