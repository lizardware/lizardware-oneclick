// Blog storage utilities for Cloudflare D1
import { Post } from './blog';

export interface D1Post {
    id: number;
    slug: string;
    title: string;
    content: string;
    description: string | null;
    excerpt: string | null; // New field
    author: string | null;
    author_id: string | null;
    tags: string | null; // JSON
    date: string;
    status: 'draft' | 'published';
    featured_image_id: string | null; // New field
    category_id: string | null; // New field
    scheduled_date: string | null; // New field
    view_count: number; // New field
    created_at: string;
    updated_at: string;
    metadata: string | null; // JSON
    show_in_nav: number;     // SQLite boolean
    nav_label: string | null;
    nav_parent: string | null;
    nav_order: number;
}

// Get all posts from D1
export async function getAllPostsFromD1(
    db: D1Database,
    includeContent = false,
    includeStatus?: 'draft' | 'published'
): Promise<Omit<Post, 'content'>[]> {
    const columns = includeContent
        ? '*'
        : 'id, slug, title, description, excerpt, author, author_id, tags, date, status, featured_image_id, category_id, scheduled_date, view_count, created_at, updated_at, show_in_nav, nav_label, nav_parent, nav_order';

    let query = `SELECT ${columns} FROM posts`;
    const bindings: string[] = [];

    if (includeStatus === 'published') {
        query += ` WHERE status = 'published' AND (scheduled_date IS NULL OR scheduled_date <= datetime('now'))`;
    } else if (includeStatus === 'draft') {
        query += ` WHERE status = 'draft'`;
    }

    query += ` ORDER BY date DESC`;

    let stmt = db.prepare(query);
    if (bindings.length > 0) {
        stmt = stmt.bind(...bindings);
    }

    const result = await stmt.all<D1Post>();

    return result.results.map(dbPost => {
        let tags: string[] = [];
        try {
            if (dbPost.tags) {
                tags = JSON.parse(dbPost.tags);
            }
        } catch {
            console.error('Error parsing tags for post:', dbPost.slug);
        }

        return {
            slug: dbPost.slug,
            title: dbPost.title,
            date: dbPost.date,
            author: dbPost.author || undefined,
            author_id: dbPost.author_id || undefined,
            tags,
            description: dbPost.description || undefined,
            excerpt: dbPost.excerpt || undefined,
            status: dbPost.status,
            featured_image_id: dbPost.featured_image_id || undefined,
            category_id: dbPost.category_id || undefined,
            scheduled_date: dbPost.scheduled_date || undefined,
            view_count: dbPost.view_count,
            content: includeContent ? dbPost.content : '',
            show_in_nav: Boolean(dbPost.show_in_nav),
            nav_label: dbPost.nav_label || undefined,
            nav_parent: dbPost.nav_parent || undefined,
            nav_order: dbPost.nav_order,
        };
    });
}

// Get single post by slug
export async function getPostBySlugFromD1(
    db: D1Database,
    slug: string
): Promise<Post | null> {
    const stmt = db.prepare(
        'SELECT * FROM posts WHERE slug = ? AND (status != "published" OR scheduled_date IS NULL OR scheduled_date <= datetime("now")) LIMIT 1'
    ).bind(slug);

    const post = await stmt.first<D1Post>();

    if (!post) return null;

    let tags: string[] = [];
    try {
        if (post.tags) {
            tags = JSON.parse(post.tags);
        }
    } catch {
        console.error('Error parsing tags for post:', post.slug);
    }

    return {
        slug: post.slug,
        title: post.title,
        content: post.content,
        date: post.date,
        author: post.author || undefined,
        author_id: post.author_id || undefined,
        tags,
        description: post.description || undefined,
        excerpt: post.excerpt || undefined,
        status: post.status,
        featured_image_id: post.featured_image_id || undefined,
        category_id: post.category_id || undefined,
        scheduled_date: post.scheduled_date || undefined,
        view_count: post.view_count,
        show_in_nav: Boolean(post.show_in_nav),
        nav_label: post.nav_label || undefined,
        nav_parent: post.nav_parent || undefined,
        nav_order: post.nav_order,
    };
}

// Create or update post
export async function upsertPostToD1(
    db: D1Database,
    post: Omit<Post, 'slug'> & { slug: string }
): Promise<void> {
    const stmt = db.prepare(`
    INSERT INTO posts (slug, title, content, description, excerpt, author, author_id, tags, date, status, featured_image_id, category_id, scheduled_date, show_in_nav, nav_label, nav_parent, nav_order, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    ON CONFLICT(slug) DO UPDATE SET
      title = excluded.title,
      content = excluded.content,
      description = excluded.description,
      excerpt = excluded.excerpt,
      author = excluded.author,
      author_id = excluded.author_id,
      tags = excluded.tags,
      date = excluded.date,
      status = excluded.status,
      featured_image_id = excluded.featured_image_id,
      category_id = excluded.category_id,
      scheduled_date = excluded.scheduled_date,
      show_in_nav = excluded.show_in_nav,
      nav_label = excluded.nav_label,
      nav_parent = excluded.nav_parent,
      nav_order = excluded.nav_order,
      updated_at = datetime('now')
  `).bind(
        post.slug,
        post.title,
        post.content,
        post.description || null,
        post.excerpt || null,
        post.author || null,
        post.author_id || null,
        post.tags ? JSON.stringify(post.tags) : null,
        post.date,
        post.status || 'draft',
        post.featured_image_id || null,
        post.category_id || null,
        post.scheduled_date || null,
        post.show_in_nav ? 1 : 0,
        post.nav_label || null,
        post.nav_parent || null,
        post.nav_order || 0
    );

    await stmt.run();
}

// Delete post
export async function deletePostFromD1(
    db: D1Database,
    slug: string
): Promise<void> {
    const stmt = db.prepare('DELETE FROM posts WHERE slug = ?').bind(slug);
    await stmt.run();
}

// Seed database (used for initial setup)
export async function seedD1WithSamplePosts(db: D1Database): Promise<void> {
    const samplePosts: Array<Omit<Post, 'slug'> & { slug: string }> = [
        {
            slug: 'it-consulting-services-overview',
            title: 'IT Consulting Services: Strategic Technology Guidance',
            content: '# IT Consulting Services\\n\\nExpert guidance for your technology strategy...',
            description: 'Expert IT consulting services to guide your technology strategy',
            author: 'Site Administrator',
            date: '2025-01-15',
            status: 'published',
        },
    ];

    for (const post of samplePosts) {
        await upsertPostToD1(db, post);
    }

    console.log(`✅ Seeded D1 with ${samplePosts.length} sample posts`);
}
