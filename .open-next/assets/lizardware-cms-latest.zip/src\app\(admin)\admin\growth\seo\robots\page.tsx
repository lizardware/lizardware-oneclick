'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { createPortal } from 'react-dom';
import { Save, FileText, Shield, Info, AlertTriangle, CheckCircle, ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import { Breadcrumbs } from "@/components/admin/Breadcrumbs";
import { AdminLoadingState } from "@/components/admin/AdminLoadingState";
import AdminCommandBar, { CommandBarButton } from "@/components/admin/AdminCommandBar";
import { AdminHeader } from '@/components/admin/AdminHeader';

export default function RobotsEditorPage() {
    const router = useRouter();
    const [robotsTxt, setRobotsTxt] = useState('');
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [status, setStatus] = useState<'idle' | 'success' | 'error' | 'db-unavailable'>('idle');
    const [error, setError] = useState('');
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        setMounted(true);
    }, []);

    useEffect(() => {
        fetch('/api/admin/seo/robots')
            .then(async res => {
                if (res.status === 503) {
                    setStatus('db-unavailable');
                    setError('Database not available in dev mode. Please use `npm run preview` to test this feature.');
                    setLoading(false);
                    return null;
                }
                return res.json() as Promise<{ robots_txt: string }>;
            })
            .then(data => {
                if (data) {
                    setRobotsTxt(data.robots_txt || '');
                }
                setLoading(false);
            })
            .catch(() => {
                setError('Failed to load robots.txt configuration');
                setLoading(false);
            });
    }, []);

    const handleSave = async () => {
        setSaving(true);
        setStatus('idle');
        try {
            const res = await fetch('/api/admin/seo/robots', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ robots_txt: robotsTxt }),
            });

            if (res.ok) {
                setStatus('success');
                setTimeout(() => setStatus('idle'), 3000);
            } else {
                setStatus('error');
            }
        } catch (error) {
            setStatus('error');
        } finally {
            setSaving(false);
        }
    };

    if (loading) return (
        <div className="max-w-7xl mx-auto px-6 pt-4 pb-12 space-y-8">
            <AdminLoadingState message="Connecting to crawler mainframe..." />
        </div>
    );

    return (
        <div className="max-w-7xl mx-auto px-6 pt-4 pb-12 space-y-8">

            <AdminHeader
                title={<>Robots <span className="text-green-500 text-shadow-glow">Forge</span></>}
                description="Configure your robots.txt file to control how search engine crawlers interact with your site."
                breadcrumbs={[
                    { label: 'Admin', href: '/admin' },
                    { label: 'Growth', href: '/admin/growth' },
                    { label: 'SEO', href: '/admin/growth/seo' },
                    { label: 'Robots' }
                ]}
                badge={
                    <div className="px-3 py-1.5 bg-green-500/10 border border-green-500/20 rounded-lg text-[10px] font-bold uppercase tracking-widest text-green-600 dark:text-green-400 flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
                        Access Control Active
                    </div>
                }
                actions={
                    <Link
                        href="/admin/growth/seo"
                        className="px-4 py-2 bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 rounded-xl text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
                    >
                        <ArrowLeft size={12} />
                        Back
                    </Link>
                }
            />

            {error && status === 'db-unavailable' && (
                <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-2xl p-6">
                    <div className="flex items-start gap-3">
                        <AlertTriangle className="text-amber-600 dark:text-amber-400 shrink-0" size={24} />
                        <div>
                            <h3 className="font-bold text-amber-900 dark:text-amber-300 mb-2">Development Mode Limitation</h3>
                            <p className="text-sm text-amber-800 dark:text-amber-400 leading-relaxed mb-3">
                                {error}
                            </p>
                            <p className="text-xs text-amber-700 dark:text-amber-500">
                                The robots.txt editor requires D1 database access, which is only available when running with Wrangler.
                                Run <code className="bg-amber-900/20 px-2 py-1 rounded font-mono">npm run preview</code> to access this feature.
                            </p>
                        </div>
                    </div>
                </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-4">
                    <div className="bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-2xl overflow-hidden shadow-sm">
                        <div className="bg-slate-50 dark:bg-zinc-800/50 px-4 py-2 border-b border-slate-200 dark:border-zinc-800 flex items-center justify-between">
                            <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Plaintext Configuration</span>
                            <span className="text-[10px] font-bold text-slate-400">robots.txt</span>
                        </div>
                        <textarea
                            value={robotsTxt}
                            onChange={(e) => setRobotsTxt(e.target.value)}
                            spellCheck={false}
                            className="w-full h-[500px] p-6 font-mono text-sm bg-transparent border-none focus:ring-0 resize-none dark:text-zinc-300"
                            placeholder="User-agent: *..."
                        />
                    </div>
                </div>

                <div className="space-y-6">
                    <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-2xl p-6">
                        <div className="flex items-center gap-2 mb-3">
                            <Info className="text-blue-600 dark:text-blue-400" size={20} />
                            <h3 className="font-bold text-blue-900 dark:text-blue-300">Guide</h3>
                        </div>
                        <ul className="text-xs text-blue-800 dark:text-blue-400 space-y-3 leading-relaxed">
                            <li>
                                <strong className="block text-blue-900 dark:text-blue-200 mb-1">User-agent</strong>
                                Specifies which crawler the rule applies to (use * for all).
                            </li>
                            <li>
                                <strong className="block text-blue-900 dark:text-blue-200 mb-1">Disallow</strong>
                                The path(s) you want to hide from search results.
                            </li>
                            <li>
                                <strong className="block text-blue-900 dark:text-blue-200 mb-1">Allow</strong>
                                Explicitly allow subfolders of a disallowed path.
                            </li>
                            <li>
                                <strong className="block text-blue-900 dark:text-blue-200 mb-1">Sitemap</strong>
                                The full URL to your sitemap file.
                            </li>
                        </ul>
                    </div>

                    <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-2xl p-6">
                        <div className="flex items-center gap-2 mb-3 text-amber-600 dark:text-amber-400">
                            <AlertTriangle size={20} />
                            <h3 className="font-bold text-amber-900 dark:text-amber-300">Warning</h3>
                        </div>
                        <p className="text-xs text-amber-800 dark:text-amber-400 leading-relaxed">
                            Incorrectly configuring your robots.txt can prevent search engines from indexing your entire site. Be extremely careful when adding <code>Disallow: /</code> rules.
                        </p>
                    </div>

                    <div className="bg-slate-50 dark:bg-zinc-800/50 border border-slate-200 dark:border-zinc-800 rounded-2xl p-6">
                        <h3 className="font-bold text-slate-900 dark:text-white mb-4 text-sm">Security Policy</h3>
                        <div className="flex items-start gap-3">
                            <div className="p-2 bg-emerald-500/10 rounded-lg shrink-0">
                                <Shield className="w-4 h-4 text-emerald-500" />
                            </div>
                            <p className="text-[11px] text-slate-500 dark:text-slate-400">
                                By default, Lizardware protects your sensitive admin and API routes from being crawled to minimize security surface area.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Admin Actions Portal */}
            {mounted && (() => {
                const portalTarget = document.getElementById('admin-actions-portal');
                if (!portalTarget) return null;

                return createPortal(
                    <div className="flex items-center gap-2 pointer-events-auto">
                        <CommandBarButton
                            onClick={handleSave}
                            disabled={saving}
                            label={saving ? "Saving..." : status === 'success' ? "Saved!" : "Save Changes"}
                            variant="primary"
                            icon={<Save size={14} />}
                        />
                    </div>,
                    portalTarget
                );
            })()}
        </div>
    );
}
