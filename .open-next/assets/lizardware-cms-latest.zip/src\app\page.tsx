import Link from "next/link";
import { Metadata } from "next";
import { getDynamicSiteConfig } from "@/lib/site-server";
import { getPageBySlug } from "@/lib/pages";
import { getPostBySlug } from "@/lib/blog";
import PageRenderer from "@/components/PageRenderer";

export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  const siteConfig = await getDynamicSiteConfig();

  if (siteConfig.homePageSlug) {
    const slug = siteConfig.homePageSlug.replace(/^\//, '');

    // Check if it's a blog post
    if (siteConfig.homePageSlug.startsWith('/blog/')) {
      const postSlug = siteConfig.homePageSlug.replace('/blog/', '');
      const post = await getPostBySlug(postSlug);
      if (post) {
        return {
          title: `${post.title} | ${siteConfig.name}`,
          description: post.description || siteConfig.seo.description,
        };
      }
    } else {
      const page = await getPageBySlug(slug);
      if (page) {
        return {
          title: `${page.title} | ${siteConfig.name}`,
          description: page.description || siteConfig.seo.description,
        };
      }
    }
  }

  return {
    title: `${siteConfig.name || "Lizardware"} | The Modern CMS for the Edge`,
    description: siteConfig.description || "Empower your team to create exceptional digital experiences with Lizardware CMS.",
  };
}

export default async function Home() {
  const siteConfig = await getDynamicSiteConfig();

  if (siteConfig.homePageSlug) {
    const slug = siteConfig.homePageSlug.replace(/^\//, '');

    // Check if it's a blog post
    if (siteConfig.homePageSlug.startsWith('/blog/')) {
      const postSlug = siteConfig.homePageSlug.replace('/blog/', '');
      const post = await getPostBySlug(postSlug);
      if (post) {
        // Find existing PostContentRenderer or similar. 
        // Actually, let's just use a simple wrapper or the same logic as BlogPostPage but without breadcrumbs/back link.
        return (
          <div className="bg-page-background py-12">
            <div className="max-w-4xl mx-auto px-4">
              <article className="prose prose-lg dark:prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: post.content }} />
            </div>
          </div>
        );
      }
    } else {
      const page = await getPageBySlug(slug);
      if (page) {
        return <PageRenderer page={page} />;
      }
    }
  }

  return (
    <div className="bg-page-background">
      {/* Hero Section */}
      <section className="hero bg-hero-gradient text-hero-text py-section">
        <div className="max-w-[1024px] mx-auto px-4 text-center">
          <h1 className="text-title font-bold mb-6 leading-tight">
            {siteConfig.name || "Modern Content Management"}
            <span className="block text-description text-primary mt-2">{siteConfig.description || "Built for the Edge"}</span>
          </h1>
          <p className="text-subtitle opacity-80 mb-10 max-w-3xl mx-auto leading-relaxed">
            A Git-backed CMS optimized for Cloudflare's edge network.
            Fast, secure, and developer-friendly content management for the modern web.
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Link href="/docs/01-quick-start" className="px-10 py-5 bg-primary text-white rounded-xl font-bold text-lg hover:bg-primary/90 transition shadow-xl hover:shadow-primary/25">
              Get Started Free
            </Link>
            <Link href="/features" className="px-10 py-5 border-2 border-hero-text text-hero-text rounded-xl font-bold text-lg hover:bg-hero-text/10 transition">
              Explore Features
            </Link>
          </div>
        </div>
      </section>

      {/* Core Value Props */}
      <section className="py-section bg-page-bg-primary border-b border-borders">
        <div className="max-w-[1024px] mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="text-5xl mb-6">⚡</div>
              <h3 className="text-xl font-bold mb-4">Edge-First Performance</h3>
              <p className="text-page-text text-body">
                Global CDN delivery ensuring instant load times and perfect Core Web Vitals across 300+ cities.
              </p>
            </div>
            <div className="text-center">
              <div className="text-5xl mb-6">🔒</div>
              <h3 className="text-xl font-bold mb-4">Git-Backed Security</h3>
              <p className="text-page-text text-body">
                Every change is version controlled. High security by default with no traditional database vulnerabilities.
              </p>
            </div>
            <div className="text-center">
              <div className="text-5xl mb-6">🎨</div>
              <h3 className="text-xl font-bold mb-4">Beautiful Editor</h3>
              <p className="text-page-text text-body">
                Modern WYSIWYG experience with live preview, making content creation a delight for your team.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Use Cases Section */}
      <section className="py-section bg-page-bg-secondary border-b border-borders">
        <div className="max-w-[1024px] mx-auto px-4">
          <h2 className="text-subtitle font-bold text-center mb-16 text-header-text">Perfect For Every Content Need</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { title: 'Bloggers & Creators', icon: '✍️', desc: 'Focus on writing while we handle the technical optimization.' },
              { title: 'Marketing Teams', icon: '📈', desc: 'Launch landing pages and campaigns in minutes, not days.' },
              { title: 'Documentation Sites', icon: '📚', desc: 'Clean, organized technical docs with perfect performance.' },
              { title: 'Small Businesses', icon: '🏪', desc: 'Professional online presence without the maintenance headache.' },
              { title: 'Agencies', icon: '🏢', desc: 'The perfect foundation for client sites that need speed and ease of use.' },
              { title: 'SaaS Platforms', icon: '☁️', desc: 'Integrated blog and help centers that match your app performance.' }
            ].map((useCase) => (
              <div key={useCase.title} className="p-container bg-card-background rounded-2xl border border-borders shadow-sm">
                <div className="flex items-center gap-3 mb-4">
                  <span className="text-3xl p-2 bg-card-background rounded-lg">
                    {useCase.icon}
                  </span>
                  <h3 className="text-xl font-bold text-info-box-text">{useCase.title}</h3>
                </div>
                <p className="text-info-box-text/70">{useCase.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Technology Stack */}
      <section className="py-section bg-page-bg-secondary">
        <div className="max-w-[1024px] mx-auto px-4 text-center">
          <h2 className="text-subtitle font-bold mb-4 text-header-text">Built on Modern Edge Technology</h2>
          <p className="text-body text-page-text mb-10">
            Performance and reliability, baked into every line of code
          </p>
          <div className="flex flex-wrap justify-center gap-4 items-center">
            {[
              { name: 'Next.js 15', href: 'https://nextjs.org' },
              { name: 'Cloudflare Workers', href: 'https://workers.cloudflare.com' },
              { name: 'TypeScript', href: 'https://www.typescriptlang.org' },
              { name: 'D1 Database', href: 'https://developers.cloudflare.com/d1' },
              { name: 'Edge Runtime', href: 'https://edge-runtime.vercel.app' },
              { name: 'Git-Backed', href: 'https://github.com' }
            ].map((tech) => (
              <a
                key={tech.name}
                href={tech.href}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-button-background px-6 py-3 rounded-lg font-bold border border-borders shadow-sm text-header-text hover:border-primary hover:text-primary transition-all hover:shadow-md hover:shadow-primary/10"
              >
                {tech.name}
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-section bg-page-bg-alternate text-white">
        <div className="max-w-[1024px] mx-auto px-4 text-center">
          <h2 className="text-subtitle font-bold mb-6">Ready to Experience the Future of CMS?</h2>
          <p className="text-body mb-8 text-white/90">
            Start building your modern edge-first web application today
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Link href="/docs/01-quick-start" className="px-8 py-4 bg-white text-primary rounded-lg font-bold hover:bg-slate-100 transition shadow-lg">
              Get Started for Free
            </Link>
            <Link href="/docs" className="px-8 py-4 border-2 border-white text-white rounded-lg font-bold hover:bg-white/10 transition">
              Read Documentation
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
