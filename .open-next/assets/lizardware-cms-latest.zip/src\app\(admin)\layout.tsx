"use client";

import { ReactNode, useState, useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  Globe, ChevronDown, Activity, ExternalLink, Menu, Home, FileText,
  PenTool, Settings, User, LayoutDashboard, Palette, X, Book,
  Database, Briefcase, Layout, Command, Sun, Moon, Layers,
  List, TrendingUp, Cpu
} from "lucide-react";
import { EnvironmentBanner } from "@/components/layout/EnvironmentBanner";
import ShortcutsHint from "@/components/admin/ShortcutsHint";
import { VERSION } from "@/lib/version";
import { OrbitalNav } from "@/components/admin/OrbitalNav";
import { UserIdentityMobile } from "@/components/admin/UserMenu";
import { SyncUser } from "@/components/admin/SyncUser";

import { AdminActionsProvider } from "@/context/AdminActionsContext";

export default function AdminLayout({ children }: { children: ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isShortcutsOpen, setIsShortcutsOpen] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Toggle hint: ALT + /
      if (e.altKey && e.key === '/') {
        e.preventDefault();
        setIsShortcutsOpen(prev => !prev);
      }

      // Quick Nav: ALT + [Key]
      if (e.altKey) {
        switch (e.key.toLowerCase()) {
          case 'p': e.preventDefault(); router.push('/admin/content/pages'); break;
          case 'b': e.preventDefault(); router.push('/admin/content/blog'); break;
          case 's': e.preventDefault(); router.push('/admin/system/advanced'); break;
          case 'a': e.preventDefault(); router.push('/admin/design/identity'); break;
        }
      }

      // Close all: ESC
      if (e.key === 'Escape') {
        setIsShortcutsOpen(false);
        setMobileMenuOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [router]);

  const isFullScreenEditor = pathname === "/admin/design/theme" || pathname?.startsWith("/admin/editor");

  const MobileLink = ({ href, icon: Icon, label, onClick }: { href: string, icon?: any, label: string, onClick?: () => void }) => (
    <Link
      href={href}
      onClick={onClick}
      className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${pathname === href || (href !== '/admin' && pathname?.startsWith(href))
        ? "bg-zinc-100 dark:bg-zinc-800 text-primary"
        : "text-zinc-600 dark:text-zinc-400 hover:bg-zinc-50 dark:hover:bg-zinc-800/50 hover:text-zinc-900 dark:hover:text-zinc-200"
        }`}
    >
      {Icon && <Icon size={18} />}
      {label}
    </Link>
  );

  const MobileSection = ({ title, children }: { title: string, children: ReactNode }) => (
    <div className="mb-6">
      <h3 className="px-4 text-[10px] font-black uppercase tracking-widest text-zinc-400 dark:text-zinc-600 mb-2">{title}</h3>
      <div className="space-y-1">
        {children}
      </div>
    </div>
  );

  return (
    <AdminActionsProvider>
      <div className="min-h-screen bg-body-background flex flex-col font-sans">
        <SyncUser />
        {!isFullScreenEditor && (
          <div className="sticky top-0 z-[110] shadow-sm bg-header-background">
            <EnvironmentBanner />
            <OrbitalNav position="top" onMobileMenuOpen={() => setMobileMenuOpen(true)} />
          </div>
        )}

        <main className={`flex-1 w-full mx-auto ${isFullScreenEditor ? 'max-w-none' : 'max-w-[1400px] p-4 lg:p-8 pt-1 pb-24'}`}>
          {children}
        </main>

        {!isFullScreenEditor && (
          <>
            <footer className="mx-auto max-w-7xl px-8 py-12 mb-14">
              <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-center text-zinc-600 dark:text-zinc-500">
                System Core v{VERSION} • Edge Native • Source Encrypted
              </p>
            </footer>
            <OrbitalNav position="bottom" />
          </>
        )}

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="relative z-[200] lg:hidden">
            <div
              className="fixed inset-0 bg-black/50 backdrop-blur-sm transition-opacity"
              onClick={() => setMobileMenuOpen(false)}
            />

            <div className="fixed inset-y-0 right-0 w-80 bg-white/90 dark:bg-zinc-900/90 backdrop-blur-xl shadow-[0_0_50px_rgba(0,0,0,0.3)] transform transition-transform border-l border-white/20 dark:border-zinc-800/50 overflow-y-auto">
              <div className="p-6 flex items-center justify-between border-b border-zinc-100/50 dark:border-zinc-800/50 sticky top-0 bg-transparent backdrop-blur-md z-10">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 bg-primary rounded-lg flex items-center justify-center text-[10px] shadow-lg shadow-primary/20">🦎</div>
                  <span className="text-[10px] font-black uppercase tracking-[0.3em] text-zinc-900 dark:text-white">Terminal</span>
                </div>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-2 -mr-2 text-zinc-500 hover:text-zinc-900 dark:hover:text-white bg-zinc-100 dark:bg-zinc-800 rounded-full transition-colors"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="p-6 pb-20 space-y-8">
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => {
                      setMobileMenuOpen(false);
                      setIsShortcutsOpen(true);
                    }}
                    className="flex flex-col items-center justify-center gap-2 p-4 bg-purple-500/10 border border-purple-500/20 rounded-2xl text-purple-600 dark:text-purple-400 group active:scale-95 transition-all"
                  >
                    <Command size={20} />
                    <span className="text-[9px] font-black uppercase tracking-widest text-center">Shortcuts</span>
                  </button>
                  <Link
                    href="/"
                    target="_blank"
                    className="flex flex-col items-center justify-center gap-2 p-4 bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 rounded-2xl active:scale-95 transition-all"
                  >
                    <ExternalLink size={20} />
                    <span className="text-[9px] font-black uppercase tracking-widest text-center">Launch Site</span>
                  </Link>
                </div>

                <MobileSection title="Content Core">
                  <MobileLink href="/admin/content" icon={List} label="Content Hub" onClick={() => setMobileMenuOpen(false)} />
                  <MobileLink href="/admin/content/blog" icon={PenTool} label="Blogger Transmissions" onClick={() => setMobileMenuOpen(false)} />
                  <MobileLink href="/admin/content/pages" icon={FileText} label="Pages Playground" onClick={() => setMobileMenuOpen(false)} />
                  <MobileLink href="/admin/content/media" icon={Layout} label="Asset Vault" onClick={() => setMobileMenuOpen(false)} />
                </MobileSection>

                <MobileSection title="Growth & SEO">
                  <MobileLink href="/admin/growth" icon={TrendingUp} label="Growth Hub" onClick={() => setMobileMenuOpen(false)} />
                  <MobileLink href="/admin/growth/seo" icon={Activity} label="SEO Marketplace" onClick={() => setMobileMenuOpen(false)} />
                  <MobileLink href="/admin/growth/monetization" icon={Briefcase} label="Revenue Streams" onClick={() => setMobileMenuOpen(false)} />
                </MobileSection>

                <MobileSection title="Visual Forge">
                  <MobileLink href="/admin/design" icon={Palette} label="Design Hub" onClick={() => setMobileMenuOpen(false)} />
                  <MobileLink href="/admin/design/features" icon={Layers} label="Module Manager" onClick={() => setMobileMenuOpen(false)} />
                  <MobileLink href="/admin/design/identity" icon={Palette} label="Identity Matrix" onClick={() => setMobileMenuOpen(false)} />
                  <MobileLink href="/admin/design/theme" icon={LayoutDashboard} label="Theme Transformer" onClick={() => setMobileMenuOpen(false)} />
                  <MobileLink href="/admin/design/nav" icon={Menu} label="Orbital Navigation" onClick={() => setMobileMenuOpen(false)} />
                </MobileSection>

                <MobileSection title="System Protocols">
                  <MobileLink href="/admin/system" icon={Settings} label="System Hub" onClick={() => setMobileMenuOpen(false)} />
                  <MobileLink href="/admin/system/advanced" icon={Cpu} label="Core Forge" onClick={() => setMobileMenuOpen(false)} />
                  <MobileLink href="/admin/system/docs" icon={Book} label="Documentation" onClick={() => setMobileMenuOpen(false)} />
                  <MobileLink href="/admin/system/roadmap" icon={Book} label="Project Roadmap" onClick={() => setMobileMenuOpen(false)} />
                </MobileSection>

                <div className="mt-8 pt-8 border-t border-zinc-100 dark:border-zinc-800">
                  <UserIdentityMobile />
                  <MobileLink href="/admin/profile" icon={User} label="My Profile" onClick={() => setMobileMenuOpen(false)} />
                </div>
              </div>
            </div>
          </div>
        )}
        <ShortcutsHint
          isOpen={isShortcutsOpen}
          onClose={() => setIsShortcutsOpen(false)}
        />
      </div>
    </AdminActionsProvider>
  );
}
