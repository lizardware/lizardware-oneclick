'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { ChevronRight, Home } from 'lucide-react';

interface BreadcrumbItem {
    label: string;
    href?: string;
}

export function Breadcrumbs({ items: manualItems }: { items?: BreadcrumbItem[] }) {
    const pathname = usePathname();

    const generateItems = (): BreadcrumbItem[] => {
        if (manualItems) return manualItems;

        const segments = pathname?.split('/').filter(Boolean) || [];
        const items: BreadcrumbItem[] = [];
        let currentHref = '';

        // Skip 'admin' as it's the root home link
        segments.forEach((segment, index) => {
            if (segment === 'admin') return;

            currentHref += `/${segment}`;

            // Format label: capitalize, replace hyphens/underscores with spaces
            const label = segment
                .replace(/[-_]/g, ' ')
                .replace(/\b\w/g, (l) => l.toUpperCase());

            items.push({
                label,
                href: index === segments.length - 1 ? undefined : `/admin${currentHref}`
            });
        });

        return items;
    };

    const items = generateItems();

    return (
        <nav className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-6 px-2">
            <Link
                href="/admin"
                className="hover:text-primary transition-colors flex items-center gap-1"
            >
                <Home size={10} />
                Admin
            </Link>

            {items.map((item, index) => (
                <div key={index} className="flex items-center gap-2">
                    <ChevronRight size={10} className="text-gray-300" />
                    {item.href ? (
                        <Link
                            href={item.href}
                            className="hover:text-primary transition-colors"
                        >
                            {item.label}
                        </Link>
                    ) : (
                        <span className="text-gray-600 dark:text-gray-300">
                            {item.label}
                        </span>
                    )}
                </div>
            ))}
        </nav>
    );
}
