-- Seed: Blank Canvas
-- Created: 2026-01-03
-- Strategy: Minimal structure to prevent 404s, but no demo content.

-- 1. Minimal Home Page (Required for routing)
INSERT OR IGNORE INTO pages (slug, title, content, description, status, sort_order, created_at, updated_at)
VALUES (
  'welcome',
  'Welcome',
  '<h1>Under Construction</h1><p>This site has been initialized with the Blank Canvas preset.</p><p>Go to <a href="/admin">/admin</a> to start building.</p>',
  'New site placeholder',
  'published',
  0,
  datetime('now'),
  datetime('now')
);
