"use client";

import { useEffect, useState } from "react";
import { X, Command, MoveUp, MoveDown, Search, Plus, Save, Hash } from "lucide-react";

export default function ShortcutsHint({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
    if (!isOpen) return null;

    const shortcuts = [
        { key: "ALT + P", label: "Pages Playground", icon: <Search size={14} /> },
        { key: "ALT + B", label: "Blog transmissions", icon: <Hash size={14} /> },
        { key: "ALT + S", label: "Advanced System Calibration", icon: <Save size={14} /> },
        { key: "ALT + A", label: "Visual Identity Forge", icon: <Plus size={14} /> },
        { key: "ALT + /", label: "Toggle this panel", icon: <Command size={14} /> },
        { key: "ESC", label: "Close Panel / Cancel", icon: <X size={14} /> },
    ];

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="w-full max-w-md bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl border border-borders overflow-hidden animate-in zoom-in-95 duration-200">
                <div className="p-6 border-b border-borders flex items-center justify-between">
                    <div>
                        <h3 className="text-lg font-black text-page-title uppercase tracking-tight">
                            System <span className="text-primary">Shortcuts</span>
                        </h3>
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-1">
                            Operational Hotkeys
                        </p>
                    </div>
                    <button
                        onClick={onClose}
                        className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-xl transition-colors"
                    >
                        <X size={20} className="text-gray-400" />
                    </button>
                </div>

                <div className="p-4 space-y-1">
                    {shortcuts.map((s, i) => (
                        <div key={i} className="flex items-center justify-between p-3 rounded-2xl hover:bg-gray-50 dark:hover:bg-zinc-950 transition-colors group">
                            <div className="flex items-center gap-3">
                                <div className="p-2 bg-gray-100 dark:bg-zinc-800 rounded-xl text-gray-400 group-hover:text-primary transition-colors">
                                    {s.icon}
                                </div>
                                <span className="text-xs font-bold text-zinc-600 dark:text-zinc-400 uppercase tracking-wide">
                                    {s.label}
                                </span>
                            </div>
                            <kbd className="px-2 py-1 bg-gray-50 dark:bg-zinc-950 border border-borders rounded-lg text-[10px] font-black font-mono text-gray-400 group-hover:text-primary group-hover:border-primary/30 transition-all">
                                {s.key}
                            </kbd>
                        </div>
                    ))}
                </div>

                <div className="p-4 bg-gray-50 dark:bg-zinc-950 border-t border-borders text-center">
                    <p className="text-[9px] font-bold text-gray-400 uppercase tracking-[0.2em]">
                        Lizardware Operational Efficiency Module
                    </p>
                </div>
            </div>
        </div>
    );
}
