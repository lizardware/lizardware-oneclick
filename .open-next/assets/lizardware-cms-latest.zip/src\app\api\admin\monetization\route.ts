import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";
import { getSafeCloudflareContext } from "@/lib/cloudflare";
import defaultMonetizationData from "@/data/monetization.json";

const DATA_FILE = path.join(process.cwd(), "src/data/monetization.json");
const KV_KEY = "MONETIZATION_SETTINGS";

/**
 * GET /api/admin/monetization
 * Fetch monetization configuration
 */
export async function GET() {
    try {
        // Production: Try KV first
        if (process.env.NODE_ENV === 'production') {
            const context = await getSafeCloudflareContext();
            if (context?.env?.CONFIG_KV) {
                const kvData = await context.env.CONFIG_KV.get(KV_KEY);
                if (kvData) {
                    return NextResponse.json(JSON.parse(kvData));
                }
            }
            return NextResponse.json(defaultMonetizationData);
        }

        // Development: Filesystem
        if (fs.existsSync(DATA_FILE)) {
            const data = await fs.promises.readFile(DATA_FILE, "utf-8");
            return NextResponse.json(JSON.parse(data));
        }

        return NextResponse.json(defaultMonetizationData);
    } catch {
        return NextResponse.json({ error: "Failed to read monetization data" }, { status: 500 });
    }
}

/**
 * POST /api/admin/monetization
 * Update monetization configuration
 */
export async function POST(request: NextRequest) {
    try {
        const body = await request.json();

        // Production: Write to KV
        if (process.env.NODE_ENV === 'production') {
            const context = await getSafeCloudflareContext();
            if (context?.env?.CONFIG_KV) {
                await context.env.CONFIG_KV.put(KV_KEY, JSON.stringify(body));
                return NextResponse.json({ success: true });
            }
            console.warn("Production write warning: CONFIG_KV not available");
        }

        // Development: Filesystem
        if (process.env.NODE_ENV !== 'production') {
            await fs.promises.writeFile(DATA_FILE, JSON.stringify(body, null, 4), "utf-8");
        }

        return NextResponse.json({ success: true });
    } catch {
        return NextResponse.json({ error: "Failed to save monetization data" }, { status: 500 });
    }
}
