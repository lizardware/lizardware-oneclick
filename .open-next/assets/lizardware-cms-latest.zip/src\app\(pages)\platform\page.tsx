import { Metadata } from 'next';
import Link from 'next/link';
import { getPageBySlug } from '@/lib/pages';
import PageRenderer from '@/components/PageRenderer';
import { servicesData } from '@/data/services';

export const metadata: Metadata = {
    title: 'Platform Features | Edge CMS',
    description: 'Comprehensive CMS platform with edge-native performance, enterprise security, and developer-friendly tools',
};

export default async function PlatformPage() {
    const page = await getPageBySlug("platform");

    if (page && page.status === "published") {
        return <PageRenderer page={page} />;
    }

    return (
        <div className="bg-page-background">
            <div className="max-w-[1024px] mx-auto px-4 py-section space-y-20">

                {/* Hero */}
                <section className="text-center">
                    <h1 className="text-title font-bold mb-6 text-header-text">
                        Built for Modern Content Creators
                    </h1>
                    <p className="text-subtitle text-page-text max-w-3xl mx-auto">
                        From content creation to global delivery, our platform provides enterprise-grade
                        features without the enterprise complexity.
                    </p>
                </section>

                {/* Core Features Overview */}
                <section>
                    <h2 className="text-subtitle font-bold mb-8 text-header-text">Core Platform Capabilities</h2>
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {Object.entries(servicesData).map(([slug, feature]) => (
                            <Link key={slug} href={`/features/${slug}`} className="group block p-container border border-borders rounded-xl hover:border-primary transition bg-page-background hover:shadow-lg">
                                <div className="text-4xl mb-3">{feature.icon}</div>
                                <h3 className="text-xl font-bold mb-2 text-header-text group-hover:text-primary transition-colors">{feature.title}</h3>
                                <p className="text-page-text text-body mb-4">{feature.intro}</p>
                                <span className="text-primary font-semibold text-sm">Explore feature →</span>
                            </Link>
                        ))}
                    </div>
                </section>

                {/* Content Management */}
                <section>
                    <h2 className="text-subtitle font-bold mb-8 text-header-text">Content Management</h2>
                    <div className="grid md:grid-cols-2 gap-8">

                        <FeatureCard
                            icon="✍️"
                            title="WYSIWYG Editor"
                            description="Intuitive drag-and-drop editor with live preview. Create beautiful content without touching code."
                        />

                        <FeatureCard
                            icon="📸"
                            title="Media Library"
                            description="Manage images and videos with Cloudflare Images integration. Automatic optimization and global CDN delivery."
                        />

                        <FeatureCard
                            icon="📝"
                            title="Version Control"
                            description="Every change is tracked in Git. Rollback to any previous version instantly, with full history."
                        />

                        <FeatureCard
                            icon="⏰"
                            title="Scheduled Publishing"
                            description="Plan your content calendar. Schedule posts for future publication with timezone support."
                        />

                        <FeatureCard
                            icon="👥"
                            title="Collaborative Workflows"
                            description="Draft, review, and approve content with team collaboration. Role-based permissions included."
                        />

                        <FeatureCard
                            icon="🔍"
                            title="Full-Text Search"
                            description="Built-in search powered by D1 FTS5. Find content instantly across your entire site."
                        />
                    </div>
                </section>

                {/* Performance */}
                <section className="bg-slate-50 dark:bg-zinc-800 -mx-4 px-4 md:-mx-8 md:px-8 py-12 rounded-2xl border border-borders">
                    <h2 className="text-subtitle font-bold mb-8 text-header-text">Performance & Scale</h2>
                    <div className="grid md:grid-cols-2 gap-8">

                        <FeatureCard
                            icon="⚡"
                            title="Edge-Native Architecture"
                            description="Deploy to 300+ global locations instantly. Content delivered from the nearest edge node."
                            highlight
                        />

                        <FeatureCard
                            icon="📊"
                            title="Sub-100ms Response Times"
                            description="Worldwide. Every time. Powered by Cloudflare's global network."
                            highlight
                        />

                        <FeatureCard
                            icon="♾️"
                            title="Automatic Scaling"
                            description="Handle traffic spikes effortlessly. No configuration, no downtime, no stress."
                            highlight
                        />

                        <FeatureCard
                            icon="🎯"
                            title="Perfect Core Web Vitals"
                            description="Lighthouse scores of 95+ out of the box. SEO optimized by default."
                            highlight
                        />
                    </div>
                </section>

                {/* Developer Tools */}
                <section>
                    <h2 className="text-subtitle font-bold mb-8 text-header-text">Developer Experience</h2>
                    <div className="grid md:grid-cols-3 gap-6">

                        <FeatureCard
                            icon="🔗"
                            title="API-First Design"
                            description="RESTful APIs for all operations. Integrate with any platform or service."
                        />

                        <FeatureCard
                            icon="📘"
                            title="TypeScript SDK"
                            description="Fully typed SDK with IntelliSense. Catch errors before deployment."
                        />

                        <FeatureCard
                            icon="🏗️"
                            title="Framework Agnostic"
                            description="Use Next.js, React, Vue, or any framework. We don't dictate your stack."
                        />

                        <FeatureCard
                            icon="🔄"
                            title="Git-Backed"
                            description="All content stored in Git. Full version history and rollback capability."
                        />

                        <FeatureCard
                            icon="🚀"
                            title="CI/CD Ready"
                            description="Deploy from GitHub Actions, GitLab CI, or any workflow you choose."
                        />

                        <FeatureCard
                            icon="💻"
                            title="Local Development"
                            description="Perfect local dev experience with Wrangler. Preview matches production."
                        />
                    </div>
                </section>

                {/* Security */}
                <section className="bg-slate-50 dark:bg-zinc-800 -mx-4 px-4 md:-mx-8 md:px-8 py-12 rounded-2xl border border-borders">
                    <h2 className="text-subtitle font-bold mb-8 text-header-text">Security & Compliance</h2>
                    <div className="grid md:grid-cols-2 gap-8">

                        <FeatureCard
                            icon="🔒"
                            title="Zero-Trust Architecture"
                            description="Decoupled frontend eliminates attack surface. No database exposure, no server vulnerabilities."
                        />

                        <FeatureCard
                            icon="🛡️"
                            title="Cloudflare Access"
                            description="Enterprise SSO with Google, Okta, Azure AD. IP whitelisting and 2FA built-in."
                        />

                        <FeatureCard
                            icon="🔐"
                            title="Encrypted at Rest"
                            description="All data encrypted in D1 and KV storage. SOC 2 compliant infrastructure."
                        />

                        <FeatureCard
                            icon="📋"
                            title="Audit Logging"
                            description="Complete audit trail of all content changes. Who did what, when."
                        />

                        <FeatureCard
                            icon="🌍"
                            title="Data Sovereignty"
                            description="Choose your data regions. GDPR and privacy regulation compliant."
                        />

                        <FeatureCard
                            icon="⚔️"
                            title="DDoS Protection"
                            description="Automatic DDoS mitigation from Cloudflare. Layer 3, 4, and 7 protection."
                        />
                    </div>
                </section>

                {/* Integrations */}
                <section>
                    <h2 className="text-subtitle font-bold mb-8 text-header-text">Integrations & Extensibility</h2>
                    <div className="grid md:grid-cols-3 gap-6">

                        <FeatureCard
                            icon="🎨"
                            title="Headless Delivery"
                            description="Deliver content to web, mobile, IoT—anywhere with an API."
                        />

                        <FeatureCard
                            icon="🔌"
                            title="Webhook Support"
                            description="Trigger actions on content changes. Connect to Zapier, Make, or custom endpoints."
                        />

                        <FeatureCard
                            icon="📈"
                            title="Analytics Integration"
                            description="Works with Google Analytics, Plausible, Fathom, and custom solutions."
                        />

                        <FeatureCard
                            icon="📧"
                            title="Email Services"
                            description="Integrate with Resend, SendGrid, Mailgun for notifications."
                        />

                        <FeatureCard
                            icon="💳"
                            title="Commerce Ready"
                            description="Connect to Stripe, Shopify, or any payment platform via APIs."
                        />

                        <FeatureCard
                            icon="🤖"
                            title="Automation Tools"
                            description="Build workflows with n8n, Pipedream, or custom scripts."
                        />
                    </div>
                </section>

                {/* CTA */}
                <section className="text-center bg-gradient-to-r from-primary to-primary/80 text-white -mx-4 px-4 py-section rounded-2xl mt-12">
                    <h2 className="text-subtitle font-bold mb-6">Ready to Experience the Difference?</h2>
                    <p className="text-xl mb-8 text-white/90 max-w-2xl mx-auto">
                        See why businesses are migrating from legacy CMSs to the modern web
                    </p>
                    <div className="flex gap-4 justify-center flex-wrap">
                        <Link href="/features" className="px-8 py-4 bg-white text-primary rounded-lg font-bold hover:bg-slate-100 transition shadow-lg">
                            Explore All Features
                        </Link>
                        <Link href="/docs" className="px-8 py-4 border-2 border-white text-white rounded-lg font-bold hover:bg-white/10 transition">
                            Read Documentation
                        </Link>
                    </div>
                </section>
            </div>
        </div>
    );
}

// Reusable FeatureCard component
function FeatureCard({
    icon,
    title,
    description,
    highlight = false
}: {
    icon: string;
    title: string;
    description: string;
    highlight?: boolean;
}) {
    return (
        <div className={`p-container rounded-xl border ${highlight ? 'bg-primary/5 border-primary shadow-sm' : 'border-borders'} bg-page-background`}>
            <div className="text-4xl mb-3">{icon}</div>
            <h3 className="text-xl font-bold mb-2 text-header-text">{title}</h3>
            <p className="text-page-text text-body">{description}</p>
        </div>
    );
}
