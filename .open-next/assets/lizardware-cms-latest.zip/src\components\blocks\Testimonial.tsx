import { Quote } from 'lucide-react';

interface TestimonialProps {
    quote: string;
    author: string;
    role?: string;
}

export default function Testimonial({ quote, author, role }: TestimonialProps) {
    return (
        <div className="w-full text-center">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-8 text-primary">
                <Quote size={32} />
            </div>
            <blockquote className="text-2xl md:text-4xl font-medium text-page-title leading-tight mb-8">
                <div dangerouslySetInnerHTML={{ __html: quote }} />
            </blockquote>
            <div>
                <div className="font-bold text-lg text-page-title">{author}</div>
                {role && <div className="text-page-text opacity-70">{role}</div>}
            </div>
        </div>
    );
}
