import Link from "next/link";
import React from "react";

interface ServiceCardProps {
    href: string;
    icon: React.ReactNode;
    title: string;
    description: string;
}

export default function ServiceCard({ href, icon, title, description }: ServiceCardProps) {
    return (
        <Link
            href={href}
            className="group block p-container border border-borders rounded-xl bg-info-box-link-bg hover:border-info-box-link-hover transition-all duration-300 hover:shadow-xl hover:shadow-info-box-link-hover/10"
        >
            <div className="flex items-center gap-3 mb-4">
                <span className="text-3xl p-2 bg-info-box-bg rounded-lg group-hover:bg-info-box-link-hover/10 transition-colors">
                    {icon}
                </span>
                <h3 className="text-xl font-bold text-info-box-link-text group-hover:text-info-box-link-hover transition-colors">
                    {title}
                </h3>
            </div>
            <p className="text-info-box-link-text/70 leading-relaxed group-hover:text-info-box-link-text transition-colors">
                {description}
            </p>
        </Link>
    );
}
