"use client";

import { useState, useEffect } from "react";
import { X, Image as ImageIcon } from "lucide-react";
import { AdminLoadingState } from "./AdminLoadingState";

export interface MediaAsset {
    id: string;
    filename: string;
    url: string;
    alt_text?: string;
    created_at: string;
}

interface MediaPickerModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSelect: (url: string) => void;
}

export default function MediaPickerModal({ isOpen, onClose, onSelect }: MediaPickerModalProps) {
    const [assets, setAssets] = useState<MediaAsset[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (isOpen) {
            setLoading(true);
            fetch("/api/admin/media")
                .then(res => res.json() as Promise<{ media: MediaAsset[] }>)
                .then(data => {
                    setAssets(data.media || []);
                })
                .catch(err => console.error("Error fetching media:", err))
                .finally(() => setLoading(false));
        }
    }, [isOpen]);

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-3xl w-full max-w-4xl max-h-[80vh] flex flex-col shadow-2xl animate-in zoom-in-95 duration-200">
                {/* Header */}
                <div className="p-6 border-b border-gray-100 dark:border-zinc-800 flex justify-between items-center bg-gray-50/50 dark:bg-zinc-900/50 rounded-t-3xl">
                    <div>
                        <h3 className="text-lg font-bold text-page-title flex items-center gap-2">
                            <ImageIcon className="text-purple-500" size={20} />
                            Select Asset
                        </h3>
                        <p className="text-xs text-gray-400">Choose an image from your library</p>
                    </div>
                    <button
                        onClick={onClose}
                        className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-full transition-colors"
                    >
                        <X size={20} className="text-gray-400" />
                    </button>
                </div>

                {/* Content */}
                <div className="flex-1 overflow-y-auto p-6 bg-white dark:bg-zinc-950/50">
                    {loading ? (
                        <div className="py-20">
                            <AdminLoadingState message="Loading assets..." />
                        </div>
                    ) : assets.length === 0 ? (
                        <div className="text-center py-20 opacity-50">
                            <ImageIcon size={48} className="mx-auto mb-4 text-gray-300" />
                            <p>No assets found in library.</p>
                        </div>
                    ) : (
                        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
                            {assets.map((asset) => (
                                <button
                                    key={asset.id}
                                    onClick={() => onSelect(asset.url)}
                                    className="group relative aspect-square bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-xl overflow-hidden hover:ring-2 hover:ring-purple-500 hover:border-transparent transition-all text-left"
                                >
                                    <img
                                        src={asset.url}
                                        alt={asset.alt_text || asset.filename}
                                        className="w-full h-full object-cover transition-transform group-hover:scale-105"
                                    />
                                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-3 pt-8 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <p className="text-[10px] text-white font-medium truncate">{asset.filename}</p>
                                    </div>
                                </button>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
