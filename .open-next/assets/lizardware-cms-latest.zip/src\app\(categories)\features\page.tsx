import ServiceCard from "@/components/ui/ServiceCard";
import { servicesData } from "@/data/services";
import { Metadata } from "next";
import { getDynamicSiteConfig } from "@/lib/site-server";

export async function generateMetadata(): Promise<Metadata> {
    const siteConfig = await getDynamicSiteConfig();
    const siteName = siteConfig.name || "Lizardware CMS";
    return {
        title: `Features | ${siteName}`,
        description: `Discover the powerful features of ${siteName}, built for speed, simplicity, and the modern edge.`,
    };
}

export default async function Features() {
    const siteConfig = await getDynamicSiteConfig();
    const siteName = siteConfig.name || "Lizardware CMS";

    return (
        <div className="bg-page-background">
            {/* Hero Section */}
            <section className="bg-hero-gradient text-hero-text py-section border-b border-borders">
                <div className="max-w-[1024px] mx-auto px-4">
                    <div className="text-center space-y-4">
                        <h1 className="text-title font-bold tracking-tight">
                            Powerful Features for Modern Content Creators
                        </h1>
                        <h2 className="text-subtitle font-semibold opacity-90">
                            Everything You Need to Build, Manage, and Scale
                        </h2>
                        <p className="text-lg opacity-80 max-w-2xl mx-auto">
                            {siteName} combines the power of the edge with a developer-friendly experience to give you ultimate control over your content.
                        </p>
                    </div>
                </div>
            </section>

            <div className="max-w-[1024px] mx-auto px-4 py-section">

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {Object.entries(servicesData).map(([slug, feature]) => (
                        <ServiceCard
                            key={slug}
                            href={`/features/${slug}`}
                            icon={feature.icon}
                            title={feature.title}
                            description={feature.intro.replace(/{{siteName}}/g, siteName)}
                        />
                    ))}
                </div>
            </div>
        </div>
    );
}
