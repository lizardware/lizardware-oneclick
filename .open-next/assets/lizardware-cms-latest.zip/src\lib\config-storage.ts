// Configuration storage utilities for Cloudflare Workers KV
import themeData from '@/data/theme.json';
import { siteConfig as defaultSiteConfig } from '@/config/site';

import { ThemeConfig } from '@/types/theme';
export type { ThemeConfig };

export interface SiteConfig {
    name: string;
    description: string;
    url: string;
    ogImage: string;
    links: Record<string, string>;
    navItems: Array<{ label: string; href: string }>;
    seo: {
        title: string;
        description: string;
        keywords: string[];
        author: string;
        twitterHandle: string;
    };
    openGraph: {
        type: string;
        locale: string;
        siteName: string;
    };
    favicon?: string;
    logoUrl?: string;
    homePageSlug?: string;
}

// Get theme config from KV (with fallback to default)
export async function getThemeConfig(kv?: KVNamespace): Promise<ThemeConfig> {
    if (!kv) {
        // Fallback for non-Workers environment (dev mode without wrangler)
        return themeData as unknown as ThemeConfig;
    }

    const stored = await kv.get('theme', 'json');
    if (stored) return stored as ThemeConfig;

    // Return default if not in KV
    return themeData as unknown as ThemeConfig;
}

// Get site config from KV (with fallback to default)
export async function getSiteConfig(kv?: KVNamespace): Promise<SiteConfig> {
    if (!kv) {
        // Fallback for non-Workers environment
        return defaultSiteConfig as SiteConfig;
    }

    const stored = await kv.get('site', 'json');
    if (stored) return stored as SiteConfig;

    // Return default if not in KV
    return defaultSiteConfig as SiteConfig;
}

// Update theme config in KV
export async function updateThemeConfig(kv: KVNamespace, theme: ThemeConfig): Promise<void> {
    await kv.put('theme', JSON.stringify(theme));
}

// Update site config in KV
export async function updateSiteConfig(kv: KVNamespace, site: SiteConfig): Promise<void> {
    await kv.put('site', JSON.stringify(site));
}

// Seed KV with default values (run once on first deploy)
export async function seedConfigKV(kv: KVNamespace): Promise<void> {
    // Check if already seeded
    const existing = await kv.get('theme');
    if (existing) return; // Already seeded

    // Seed theme config
    await kv.put('theme', JSON.stringify(themeData));

    // Seed site config
    await kv.put('site', JSON.stringify(defaultSiteConfig));

    console.log('✅ Seeded CONFIG_KV with default values');
}
