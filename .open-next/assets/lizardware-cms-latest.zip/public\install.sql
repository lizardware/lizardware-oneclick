-- Lizardware CMS Database Structure
-- Generated automatically.
-- Generated at: 2026-01-05T18:19:57.096Z


-- File: 001_create_posts.sql
-- Migration: Create posts table for blog
-- Created: 2025-12-17
-- Phase 2: Blog Migration to D1

CREATE TABLE IF NOT EXISTS posts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slug TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  description TEXT,
  excerpt TEXT,
  author TEXT,
  author_id TEXT,
  tags TEXT,
  date TEXT NOT NULL,
  status TEXT DEFAULT 'draft' CHECK(status IN ('draft', 'published')),
  featured_image_id TEXT,
  category_id TEXT,
  scheduled_date TEXT,
  view_count INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now')),
  metadata TEXT
);

-- Indexes for common queries
CREATE INDEX IF NOT EXISTS idx_posts_slug ON posts(slug);
CREATE INDEX IF NOT EXISTS idx_posts_status ON posts(status);
CREATE INDEX IF NOT EXISTS idx_posts_date ON posts(date DESC);
CREATE INDEX IF NOT EXISTS idx_posts_status_date ON posts(status, date DESC);


-- File: 002_seed_sample_posts.sql
-- Migration: 002 Seed Sample Posts (EMPTY - Content moved to seeds/)
-- Original content preserved in migrations/seeds/demo.sql or production.sql


-- File: 003_add_author_id_and_tags.sql
-- Migration: Add author_id and tags to posts table
-- Created: 2025-12-17

-- ALTER TABLE posts ADD COLUMN author_id TEXT;
-- ALTER TABLE posts ADD COLUMN tags TEXT; -- Stored as JSON string

-- Add index for author filtering
CREATE INDEX IF NOT EXISTS idx_posts_author_id ON posts(author_id);
-- Index for tags is harder in SQLite/D1 without FTS or specific extensions, 
-- but we can still index the column for exact matches or prefix searches if needed.
CREATE INDEX IF NOT EXISTS idx_posts_tags ON posts(tags);


-- File: 004_create_pages.sql
-- Migration: Create pages table
-- Created: 2024-12-19

CREATE TABLE IF NOT EXISTS pages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slug TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  description TEXT,
  status TEXT DEFAULT 'draft' CHECK(status IN ('draft', 'published')),
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now')),
  metadata_json TEXT
);

-- Indexes for common queries
CREATE INDEX IF NOT EXISTS idx_pages_slug ON pages(slug);
CREATE INDEX IF NOT EXISTS idx_pages_status ON pages(status);


-- File: 005_add_template_system.sql
-- Create site_config table if it doesn't exist (fixing missing table error)
CREATE TABLE IF NOT EXISTS site_config (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  template_id TEXT DEFAULT 'custom',
  setup_completed INTEGER DEFAULT 0
);

-- Initialize default row
INSERT OR IGNORE INTO site_config (id, template_id, setup_completed) VALUES (1, 'custom', 0);

-- Feature flags table
CREATE TABLE IF NOT EXISTS feature_flags (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  feature_name TEXT NOT NULL UNIQUE,
  enabled INTEGER DEFAULT 1,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Default feature flags
INSERT OR IGNORE INTO feature_flags (feature_name, enabled) VALUES
  ('blog', 1),
  ('gallery', 0),
  ('newsletter', 0),
  ('monetization', 0),
  ('comments', 0),
  ('servicePages', 0),
  ('menu', 0),
  ('booking', 0),
  ('customerPortal', 0),
  ('analytics', 0);


-- File: 0006_feature_content_posts.sql
-- Migration: 0006 Feature Content Posts (EMPTY - Content moved to seeds/)
-- Original content preserved in migrations/seeds/demo.sql


-- File: 007_add_setup_lock.sql
-- Column 'setup_completed' already exists from migration 005
-- This UPDATE is for existing installs upgrading from pre-005 versions
UPDATE site_config 
SET setup_completed = 1 
WHERE template_id IS NOT NULL AND template_id != '';



-- File: 010_create_redirects_table.sql
-- Migration: Create redirects table for 301/302 URL redirects
-- Version: 0.3.0
-- Purpose: Enable SEO-friendly URL redirects for moved or renamed content

CREATE TABLE IF NOT EXISTS redirects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_path TEXT NOT NULL UNIQUE,
  destination_path TEXT NOT NULL,
  type INTEGER NOT NULL DEFAULT 301,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_redirects_source ON redirects(source_path);


-- File: 011_create_seo_config_table.sql
-- Migration: Create SEO configuration table
-- Version: 0.3.0
-- Purpose: Store SEO settings like robots.txt rules and meta configurations

CREATE TABLE IF NOT EXISTS seo_config (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Default robots.txt configuration (single-line to avoid D1 API parsing issues)
INSERT INTO seo_config (key, value) VALUES ('robots_txt', 'User-agent: *\nAllow: /\nDisallow: /admin/\nDisallow: /api/\nDisallow: /setup/\n\nSitemap: {{site_url}}/sitemap.xml');


-- File: 012_create_seo_global_settings.sql
-- Migration: Create SEO global settings table
-- Version: 0.3.1
-- Purpose: Store user-configurable SEO defaults and wizard completion status

CREATE TABLE IF NOT EXISTS seo_global_settings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title_template TEXT DEFAULT '{page_title} | {site_name}',
  meta_description_template TEXT,
  og_image_default TEXT,
  organization_schema TEXT,
  setup_wizard_completed BOOLEAN DEFAULT 0,
  google_search_console_code TEXT,
  bing_webmaster_code TEXT,
  twitter_card_type TEXT DEFAULT 'summary_large_image',
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Insert default settings
INSERT INTO seo_global_settings (id, title_template) VALUES (1, '{page_title} | {site_name}');


-- File: 013_create_seo_checkups.sql
-- Migration: Create SEO checkups table
-- Version: 0.3.1
-- Purpose: Store automated SEO audit results for tracking page health over time

CREATE TABLE IF NOT EXISTS seo_checkups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  page_type TEXT NOT NULL, -- 'blog' or 'page'
  page_id INTEGER NOT NULL,
  score INTEGER NOT NULL, -- 0-100
  grade TEXT NOT NULL, -- 'excellent', 'good', 'needs-work', 'poor'
  issues TEXT, -- JSON array of issues
  checked_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_seo_checkups_page ON seo_checkups(page_type, page_id);
CREATE INDEX IF NOT EXISTS idx_seo_checkups_score ON seo_checkups(score);


-- File: 014_create_forum_users.sql
-- Migration 014: Create forum users table
-- Version: 0.6.0
-- Purpose: User authentication and profiles for forum system

CREATE TABLE IF NOT EXISTS forum_users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  display_name TEXT,
  avatar_url TEXT,
  bio TEXT,
  reputation INTEGER DEFAULT 0,
  is_moderator BOOLEAN DEFAULT 0,
  is_banned BOOLEAN DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  last_seen_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_forum_users_email ON forum_users(email);
CREATE INDEX idx_forum_users_username ON forum_users(username);
CREATE INDEX idx_forum_users_reputation ON forum_users(reputation DESC);


-- File: 015_create_forum_categories.sql
-- Migration 015: Create forum categories table
-- Version: 0.6.0
-- Purpose: Forum discussion categories

CREATE TABLE IF NOT EXISTS forum_categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  icon TEXT, -- Emoji
  color TEXT DEFAULT '#3b82f6',
  sort_order INTEGER DEFAULT 0,
  is_visible BOOLEAN DEFAULT 1,
  thread_count INTEGER DEFAULT 0,
  post_count INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_forum_categories_slug ON forum_categories(slug);
CREATE INDEX idx_forum_categories_visible ON forum_categories(is_visible);
CREATE INDEX idx_forum_categories_sort ON forum_categories(sort_order);


-- File: 016_create_forum_threads.sql
-- Migration 016: Create forum threads table
-- Version: 0.6.0
-- Purpose: Discussion threads within categories

CREATE TABLE IF NOT EXISTS forum_threads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  content TEXT NOT NULL, -- First post content (HTML from Tiptap)
  is_pinned BOOLEAN DEFAULT 0,
  is_locked BOOLEAN DEFAULT 0,
  view_count INTEGER DEFAULT 0,
  reply_count INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  last_post_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  last_post_user_id INTEGER,
  FOREIGN KEY (category_id) REFERENCES forum_categories(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES forum_users(id) ON DELETE CASCADE,
  FOREIGN KEY (last_post_user_id) REFERENCES forum_users(id) ON DELETE SET NULL
);

CREATE INDEX idx_forum_threads_category ON forum_threads(category_id);
CREATE INDEX idx_forum_threads_user ON forum_threads(user_id);
CREATE INDEX idx_forum_threads_pinned ON forum_threads(is_pinned);
CREATE INDEX idx_forum_threads_last_post ON forum_threads(last_post_at DESC);
CREATE INDEX idx_forum_threads_slug ON forum_threads(slug);


-- File: 017_create_forum_posts.sql
-- Migration 017: Create forum posts table
-- Version: 0.6.0
-- Purpose: Replies and nested comments on forum threads

CREATE TABLE IF NOT EXISTS forum_posts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  thread_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  parent_post_id INTEGER, -- For nested replies
  content TEXT NOT NULL, -- HTML from Tiptap
  is_edited BOOLEAN DEFAULT 0,
  edited_at DATETIME,
  is_hidden BOOLEAN DEFAULT 0, -- For moderation
  hidden_reason TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (thread_id) REFERENCES forum_threads(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES forum_users(id) ON DELETE CASCADE,
  FOREIGN KEY (parent_post_id) REFERENCES forum_posts(id) ON DELETE CASCADE
);

CREATE INDEX idx_forum_posts_thread ON forum_posts(thread_id);
CREATE INDEX idx_forum_posts_user ON forum_posts(user_id);
CREATE INDEX idx_forum_posts_parent ON forum_posts(parent_post_id);
CREATE INDEX idx_forum_posts_created ON forum_posts(created_at DESC);


-- File: 018_create_forum_reactions.sql
-- Migration 018: Create forum reactions table
-- Version: 0.6.0
-- Purpose: User reactions (likes, helpful, etc.) on posts and threads

CREATE TABLE IF NOT EXISTS forum_reactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id INTEGER, -- Can be NULL if reacting to thread
  thread_id INTEGER, -- Can be NULL if reacting to post
  user_id INTEGER NOT NULL,
  reaction_type TEXT NOT NULL, -- 'like', 'helpful', 'love', 'laugh'
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (post_id) REFERENCES forum_posts(id) ON DELETE CASCADE,
  FOREIGN KEY (thread_id) REFERENCES forum_threads(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES forum_users(id) ON DELETE CASCADE,
  UNIQUE(post_id, user_id, reaction_type),
  UNIQUE(thread_id, user_id, reaction_type),
  CHECK ((post_id IS NOT NULL AND thread_id IS NULL) OR (post_id IS NULL AND thread_id IS NOT NULL))
);

CREATE INDEX idx_forum_reactions_post ON forum_reactions(post_id);
CREATE INDEX idx_forum_reactions_thread ON forum_reactions(thread_id);
CREATE INDEX idx_forum_reactions_user ON forum_reactions(user_id);
CREATE INDEX idx_forum_reactions_type ON forum_reactions(reaction_type);


-- File: 019_create_forum_moderation.sql
-- Migration 019: Create forum moderation tables
-- Version: 0.6.0
-- Purpose: Content moderation, reports, and user management

CREATE TABLE IF NOT EXISTS forum_reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id INTEGER,
  thread_id INTEGER,
  reporter_user_id INTEGER NOT NULL,
  reason TEXT NOT NULL, -- 'spam', 'offensive', 'off-topic', 'harassment', 'other'
  details TEXT,
  status TEXT DEFAULT 'pending', -- 'pending', 'resolved', 'dismissed'
  resolved_by_user_id INTEGER,
  resolved_at DATETIME,
  moderator_notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (post_id) REFERENCES forum_posts(id) ON DELETE CASCADE,
  FOREIGN KEY (thread_id) REFERENCES forum_threads(id) ON DELETE CASCADE,
  FOREIGN KEY (reporter_user_id) REFERENCES forum_users(id) ON DELETE CASCADE,
  FOREIGN KEY (resolved_by_user_id) REFERENCES forum_users(id) ON DELETE SET NULL,
  CHECK ((post_id IS NOT NULL AND thread_id IS NULL) OR (post_id IS NULL AND thread_id IS NOT NULL))
);

CREATE INDEX idx_forum_reports_status ON forum_reports(status);
CREATE INDEX idx_forum_reports_post ON forum_reports(post_id);
CREATE INDEX idx_forum_reports_thread ON forum_reports(thread_id);
CREATE INDEX idx_forum_reports_reporter ON forum_reports(reporter_user_id);
CREATE INDEX idx_forum_reports_created ON forum_reports(created_at DESC);

-- User bans and restrictions
CREATE TABLE IF NOT EXISTS forum_user_bans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  banned_by_user_id INTEGER NOT NULL,
  reason TEXT NOT NULL,
  expires_at DATETIME, -- NULL for permanent ban
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES forum_users(id) ON DELETE CASCADE,
  FOREIGN KEY (banned_by_user_id) REFERENCES forum_users(id) ON DELETE SET NULL
);

CREATE INDEX idx_forum_user_bans_user ON forum_user_bans(user_id);
CREATE INDEX idx_forum_user_bans_expires ON forum_user_bans(expires_at);


-- File: 020_seed_forum_data.sql
-- Migration: 020 Seed Forum Data (EMPTY - Content moved to seeds/)
-- Original content preserved in migrations/seeds/demo.sql or production.sql


-- File: 021_add_robots_txt.sql
-- Migration: Add robots_txt to seo_global_settings
-- Version: 0.3.2

ALTER TABLE seo_global_settings ADD COLUMN robots_txt TEXT DEFAULT 'User-agent: *\nAllow: /\nDisallow: /admin/\nDisallow: /api/\nDisallow: /setup/\n\nSitemap: https://example.com/sitemap.xml';


-- File: 022_add_post_status.sql
-- Add status column to posts table
ALTER TABLE posts ADD COLUMN status TEXT DEFAULT 'published';
-- Create index for status queries
CREATE INDEX idx_posts_status ON posts(status);


-- File: 023_add_page_templates.sql
-- Migration 023: Add Template System to Pages
-- Enables customizable page templates for white-label deployments

-- Add template-related columns to pages table
ALTER TABLE pages ADD COLUMN is_template INTEGER DEFAULT 0 NOT NULL;
ALTER TABLE pages ADD COLUMN template_category TEXT;
ALTER TABLE pages ADD COLUMN sort_order INTEGER DEFAULT 0;

-- Add indexes for performance
CREATE INDEX IF NOT EXISTS idx_pages_is_template ON pages(is_template);
CREATE INDEX IF NOT EXISTS idx_pages_template_category ON pages(template_category);
CREATE INDEX IF NOT EXISTS idx_pages_sort_order ON pages(sort_order);

-- Template Pages Seeds
-- Use {{siteName}} placeholders for white-label support

-- Company Templates
INSERT INTO pages (slug, title, content, description, status, is_template, template_category, sort_order, created_at, updated_at)
VALUES 
  ('about', 'About {{siteName}}', '<h1>About {{siteName}}</h1><p>This is a template page. Customize it to tell your story!</p>', 'Learn more about our company', 'published', 1, 'company', 10, datetime('now'), datetime('now')),
  ('contact', 'Contact {{siteName}}', '<h1>Contact Us</h1><p>Get in touch with our team.</p>', 'Contact information', 'published', 1, 'company', 20, datetime('now'), datetime('now')),
  ('platform', 'Platform Features', '<h1>Platform Features</h1><p>Discover what makes our platform unique.</p>', 'Platform overview', 'published', 1, 'company', 30, datetime('now'), datetime('now'));

-- Legal Templates  
INSERT INTO pages (slug, title, content, description, status, is_template, template_category, sort_order, created_at, updated_at)
VALUES 
  ('terms', 'Terms of Service', '<h1>Terms of Service</h1><p>Please read these terms carefully.</p>', 'Terms and conditions', 'published', 1, 'legal', 40, datetime('now'), datetime('now')),
  ('privacy', 'Privacy Policy', '<h1>Privacy Policy</h1><p>Your privacy matters to us.</p>', 'Privacy policy', 'published', 1, 'legal', 50, datetime('now'), datetime('now'));

-- Support Templates
INSERT INTO pages (slug, title, content, description, status, is_template, template_category, sort_order, created_at, updated_at)
VALUES 
  ('support', 'Support Center', '<h1>Support</h1><p>Need help? We''re here for you.</p>', 'Get support', 'published', 1, 'support', 60, datetime('now'), datetime('now'));

-- Add comments
-- is_template: 1 = template page (About, Contact, etc), 0 = custom page
-- template_category: 'company', 'legal', 'support', null for custom pages
-- sort_order: Custom ordering for navigation (lower = higher priority)



-- File: 024_fix_posts_schema.sql
-- Migration: Fix missing columns in posts table
-- Created: 2025-12-29
-- Purpose: Patch existing databases that were initialized with incomplete schema
-- Note: 'init-database' route ignores "duplicate column name" errors, so it's safe to run blindly.

ALTER TABLE posts ADD COLUMN excerpt TEXT;
ALTER TABLE posts ADD COLUMN author_id TEXT;
ALTER TABLE posts ADD COLUMN tags TEXT;
ALTER TABLE posts ADD COLUMN featured_image_id TEXT;
ALTER TABLE posts ADD COLUMN category_id TEXT;
ALTER TABLE posts ADD COLUMN scheduled_date TEXT;
ALTER TABLE posts ADD COLUMN view_count INTEGER DEFAULT 0;


-- File: 025_pages_nav_metadata.sql
-- Add navigation control columns to pages table
ALTER TABLE pages ADD COLUMN show_in_nav INTEGER DEFAULT 0;
ALTER TABLE pages ADD COLUMN nav_label TEXT;
ALTER TABLE pages ADD COLUMN nav_parent TEXT;
ALTER TABLE pages ADD COLUMN nav_order INTEGER DEFAULT 0;


-- File: 026_posts_nav_metadata.sql
-- Add navigation control columns to posts table
ALTER TABLE posts ADD COLUMN show_in_nav INTEGER DEFAULT 0;
ALTER TABLE posts ADD COLUMN nav_label TEXT;
ALTER TABLE posts ADD COLUMN nav_parent TEXT;
ALTER TABLE posts ADD COLUMN nav_order INTEGER DEFAULT 0;


-- File: 027_create_authors_table.sql
-- Migration: Create authors table for Clerk sync
-- Created: 2025-12-30

CREATE TABLE IF NOT EXISTS authors (
    id TEXT PRIMARY KEY, -- Clerk User ID
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    image_url TEXT,
    role TEXT DEFAULT 'editor',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_authors_email ON authors(email);


-- File: 028_create_categories_table.sql
-- Migration: Create categories table
-- Created: 2026-01-04
-- Purpose: Fix missing table error for Blog & Publishing business type

CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    description TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_categories_slug ON categories(slug);

-- Seed default category if empty
INSERT OR IGNORE INTO categories (name, slug, description) 
VALUES ('General', 'general', 'Uncategorized posts');


-- File: 029_fix_site_config_schema.sql
-- Migration: Add missing columns to site_config
-- Created: 2026-01-04
-- Purpose: Sync site_config schema with KV-to-D1 sync logic

-- Add columns if they don't exist
ALTER TABLE site_config ADD COLUMN name TEXT;
ALTER TABLE site_config ADD COLUMN description TEXT;
ALTER TABLE site_config ADD COLUMN updated_at TEXT DEFAULT (datetime('now'));

-- Ensure row 1 exists
INSERT OR IGNORE INTO site_config (id, template_id, setup_completed) VALUES (1, 'custom', 0);


-- File: 030_create_users_table.sql
CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY, -- uuid
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT DEFAULT 'admin',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);

