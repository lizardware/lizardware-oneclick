import fs from "fs";
import path from "path";
import { glob } from "glob";
import matter from "gray-matter";
import { getAllPagesFromD1, getPageBySlugFromD1, upsertPageToD1, deletePageFromD1 } from './page-storage';
import { getD1Database } from './cloudflare';
import { Page } from '../types/page';

const PAGES_DIR = path.join(process.cwd(), "src/content/pages");

export async function getAllPages(includeStatus?: 'draft' | 'published'): Promise<Page[]> {
    let pages: Page[] = [];
    let d1Available = false;

    // Try D1 first (production/preview)
    try {
        const db = await getD1Database();

        if (db) {
            d1Available = true;
            pages = await getAllPagesFromD1(db, false, includeStatus);
            if (pages.length > 0) {
                console.log(`[Pages] Loaded ${pages.length} pages from D1`);
                return pages; // Return D1 results if found
            }
            console.log('[Pages] D1 available but returned 0 pages');
        }
    } catch (error) {
        console.error('D1 fetch error for pages:', error);
    }

    // Fallback to filesystem (dev mode only, or if D1 returned no pages)
    if (process.env.NODE_ENV === 'development') {
        console.log('[Pages] Attempting filesystem fallback...');
        try {
            if (fs.existsSync(PAGES_DIR)) {
                const files = await glob(`${PAGES_DIR}/**/*.mdx`);
                console.log(`[Pages] Found ${files.length} MDX files in ${PAGES_DIR}`);
                const filePages = await Promise.all(
                    files.map(async (file) => {
                        const content = await fs.promises.readFile(file, "utf-8");
                        const slug = path.basename(file, ".mdx");
                        const { data, content: rawContent } = matter(content);
                        return {
                            slug,
                            content: rawContent,
                            title: data.title || slug,
                            description: data.description,
                            status: data.status || 'draft',
                            created_at: data.created_at,
                            updated_at: data.updated_at,
                            metadata_json: data.metadata_json,
                            is_template: data.is_template || false,
                            template_category: data.template_category,
                            sort_order: data.sort_order || 0,
                            show_in_nav: data.show_in_nav || false,
                            nav_label: data.nav_label,
                            nav_parent: data.nav_parent,
                            nav_order: data.nav_order || 0,
                        } as Page;
                    })
                );
                pages = filePages;
                console.log(`[Pages] Loaded ${pages.length} pages from filesystem`);
            } else {
                console.log(`[Pages] Directory ${PAGES_DIR} does not exist`);
            }
        } catch (error) {
            console.error('Failed to read page MDX files:', error);
        }
    } else if (d1Available && pages.length === 0) {
        console.warn('[Pages] Production mode: D1 returned 0 pages. This may indicate missing data.');
    }

    // Apply status filter if requested
    if (includeStatus) {
        return pages.filter(p => p.status === includeStatus);
    }

    return pages;
}

export async function getPageBySlug(slug: string): Promise<Page | null> {
    // Try D1 first
    try {
        const db = await getD1Database();

        if (db) {
            const page = await getPageBySlugFromD1(db, slug);
            if (page) {
                return page;
            }
        }
    } catch (error) {
        console.error('D1 fetch error for page slug:', slug, error);
    }

    // Fallback to filesystem (dev mode only)
    if (process.env.NODE_ENV === 'development') {
        try {
            const file = path.join(PAGES_DIR, `${slug}.mdx`);
            if (fs.existsSync(file)) {
                const fileContent = await fs.promises.readFile(file, "utf-8");
                const { data, content } = matter(fileContent);
                return {
                    slug,
                    content: content,
                    title: data.title || slug,
                    description: data.description,
                    status: data.status || 'draft',
                    created_at: data.created_at,
                    updated_at: data.updated_at,
                    metadata_json: data.metadata_json,
                    is_template: data.is_template || false,
                    template_category: data.template_category,
                    sort_order: data.sort_order || 0,
                    show_in_nav: data.show_in_nav || false,
                    nav_label: data.nav_label,
                    nav_parent: data.nav_parent,
                    nav_order: data.nav_order || 0,
                } as Page;
            }
        } catch {
            // Fall through
        }
    }

    return null;
}

export async function upsertPage(page: Page): Promise<void> {
    // Try D1 first
    try {
        const db = await getD1Database();

        if (db) {
            await upsertPageToD1(db, page);
            return;
        } else if (process.env.NODE_ENV === 'production') {
            throw new Error('Database not available');
        }
    } catch (error) {
        console.error('D1 upsert error for page:', page.slug, error);
        // In production, propagate the error so the UI can notify the user
        if (process.env.NODE_ENV === 'production') {
            throw error;
        }
    }

    // Fallback to filesystem (dev mode only)
    if (process.env.NODE_ENV === 'development') {
        try {
            if (!fs.existsSync(PAGES_DIR)) {
                await fs.promises.mkdir(PAGES_DIR, { recursive: true });
            }

            const filePath = path.join(PAGES_DIR, `${page.slug}.mdx`);
            const now = new Date().toISOString();

            const frontmatter = {
                title: page.title,
                description: page.description,
                status: page.status || 'draft',
                created_at: page.created_at || now,
                updated_at: now,
                metadata_json: page.metadata_json,
                is_template: page.is_template,
                template_category: page.template_category,
                sort_order: page.sort_order,
                show_in_nav: page.show_in_nav,
                nav_label: page.nav_label,
                nav_parent: page.nav_parent,
                nav_order: page.nav_order,
            };

            const fileContent = matter.stringify(page.content, frontmatter);
            await fs.promises.writeFile(filePath, fileContent, 'utf-8');
        } catch (error) {
            console.error('Failed to write page MDX file:', error);
            throw new Error('Failed to save page locally');
        }
    }
}

export async function deletePage(slug: string): Promise<void> {
    // Try D1 first
    try {
        const db = await getD1Database();

        if (db) {
            await deletePageFromD1(db, slug);
            return;
        } else if (process.env.NODE_ENV === 'production') {
            throw new Error('Database not available');
        }
    } catch (error) {
        console.error('D1 delete error for page:', slug, error);
        // In production, propagate the error so the UI can notify the user
        if (process.env.NODE_ENV === 'production') {
            throw error;
        }
    }

    // Fallback to filesystem (dev mode only)
    if (process.env.NODE_ENV === 'development') {
        try {
            const file = path.join(PAGES_DIR, `${slug}.mdx`);
            if (fs.existsSync(file)) {
                await fs.promises.unlink(file);
            }
        } catch (error) {
            console.error('Failed to delete page MDX file:', error);
            throw new Error('Failed to delete page locally');
        }
    }
}
export async function getPagesByType(type: 'all' | 'templates' | 'custom'): Promise<Page[]> {
    const pages = await getAllPages();
    if (type === 'templates') return pages.filter(p => p.is_template);
    if (type === 'custom') return pages.filter(p => !p.is_template);
    return pages;
}
