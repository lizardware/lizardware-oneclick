export interface NavItem {
    id: string;
    label: string;
    href: string;
    children?: NavItem[];
}

export interface SiteTemplate {
    id: string;
    name: string;
    description: string;
    icon: string; // Emoji
    category: 'business' | 'content' | 'service' | 'healthcare';

    config: {
        navigation: NavItem[];
        theme: {
            primaryColor: string;
            style: 'professional' | 'vibrant' | 'minimal' | 'elegant' | 'clean';
            layout: 'sidebar' | 'full-width' | 'centered';
        };
        features: {
            blog: boolean;
            gallery: boolean;
            newsletter: boolean;
            monetization: boolean;
            comments: boolean;
            servicePages: boolean;
            menu: boolean;
            booking: boolean;
            customerPortal: boolean;
            analytics: boolean;
        };
        homepage: {
            heroTitle: string;
            heroSubtitle: string;
            sections: string[];
        };
    };

    // Optional theme properties for full theme application
    colors?: {
        light: Record<string, string | boolean>;
        dark: Record<string, string | boolean>;
    };
    borderRadius?: string;
    fontFamily?: string;
    spacing?: {
        section: string;
        container: string;
        gap: string;
        header: string;
    };
    shadows?: {
        strength: string;
    };
    typography?: {
        fontSizeTitle: string;
        fontSizeSubtitle: string;
        fontSizeDescription: string;
        fontSizeBase: string;
    };
}
