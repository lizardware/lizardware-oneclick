# Phase 2 Verification - Blog Core Features

This document outlines the steps to verify the implementation of Phase 2 features.

## 1. Categories Management
- Navigate to `/admin/blog/categories`.
- **Test:** Verify default "Uncategorized" exists.
- **Test:** Create a new category (e.g., "Technology", slug: "tech").
- **Test:** Edit the category description.
- **Test:** Delete a test category.

## 2. Personnel (Author) Management
- Navigate to `/admin/blog/authors`.
- **Test:** Create a new profile (e.g., "Edward Lizard", id: "edward").
- **Test:** Upload/link an avatar URL.
- **Test:** Add social handles (Twitter/LinkedIn).
- **Test:** Edit and save the profile.

## 3. Blog Editor Enhancements
- Navigate to `/admin/blog/new`.
- **Test:** Verify the "Personnel" dropdown fetches from D1 (should see "Edward Lizard").
- **Test:** Verify the "Category" dropdown fetches from D1.
- **Test:** Select a featured image from the Media Library.
- **Test:** Observe the **SEO Preview** (Signal Simulation) update in real-time as you type the title/description and pick an image.
- **Test:** Set a `Scheduled Date` in the future and save as `Published`.

## 4. Public Blog Verification
- Navigate to `/blog/[slug]` of a published post.
- **Test:** Verify the featured image is displayed at the top.
- **Test:** Verify the category link is visible.
- **Test:** Verify the view count incremented (should show "1 views" or more).
- **Test:** Navigate to a post scheduled for the future. **Result:** Should return 404/Not Found for public users.

## 5. View Tracking
- Visit a post multiple times.
- **Test:** Go back to `/admin/blog`.
- **Test:** Verify the "Views" column in the post list has updated.
- **Test:** Sort the list by "Views" to verify the signal strength ranking.

## 6. Migration Verification
- Check `public/install.sql`.
- **Test:** Verify migration `023_blog_overhaul_foundation.sql` is present at the end of the file.
