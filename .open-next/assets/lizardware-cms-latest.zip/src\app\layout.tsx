import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { siteConfig } from "@/config/site";
import { ThemeProvider } from "@/components/theme/ThemeProvider";
import { ThemePreferenceModal } from "@/components/ui/ThemePreferenceModal";
import { CustomThemeManager } from "@/components/theme/CustomThemeManager";
import { ThemePreviewListener } from "@/components/theme/ThemePreviewListener";
import { ContentPreviewListener } from "@/components/admin/ContentPreviewListener";
import { getTheme } from "@/lib/theme-server";
import { getDynamicSiteConfig } from "@/lib/site-server";
import { AdminHeaderHider } from "@/components/layout/AdminHeaderHider";
import { PopupProvider } from "@/components/admin/AdminPopupProvider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export async function generateMetadata(): Promise<Metadata> {
  const siteConfig = await getDynamicSiteConfig();

  const favicon = siteConfig.favicon || "🦎";
  const iconUrl = favicon.startsWith('http')
    ? favicon
    : `data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>${favicon}</text></svg>`;

  return {
    title: {
      default: siteConfig.name || "Lizardware",
      template: `%s | ${siteConfig.name || "Lizardware"}`,
    },
    description: siteConfig.description,
    metadataBase: new URL(siteConfig.url || "http://localhost:3000"),
    icons: {
      icon: iconUrl,
    },
  };
}

export const dynamic = "force-dynamic";

import { AuthProvider } from "@/components/auth/AuthProvider";

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const [theme, siteConfigData] = await Promise.all([
    getTheme(),
    getDynamicSiteConfig(),
  ]);

  return (
    <AuthProvider>
      <html lang="en" suppressHydrationWarning>
        <head>
          <script
            dangerouslySetInnerHTML={{
              __html: `var __name = (target, value) => (Object.defineProperty(target, 'name', { value: value, configurable: true }), target);`
            }}
          />
        </head>
        <body
          className={`${geistSans.variable} ${geistMono.variable} antialiased font-sans text-body`}
        >
          <ThemeProvider
            attribute="class"
            defaultTheme="dark"
            enableSystem={false}
            disableTransitionOnChange
          >
            {/* eslint-disable-next-line @typescript-eslint/no-explicit-any */}
            <CustomThemeManager initialTheme={theme as any} />
            <ThemePreviewListener />
            <ContentPreviewListener />
            <PopupProvider>
              <AdminHeaderHider siteConfig={siteConfigData}>
                {children}
              </AdminHeaderHider>
            </PopupProvider>
          </ThemeProvider>
        </body>
      </html>
    </AuthProvider>
  );
}
