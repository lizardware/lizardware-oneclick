import type { MediaStorage, MediaAsset } from './MediaStorage';

export class GitHubStorage implements MediaStorage {
    getName(): string {
        return 'GitHub Repository';
    }

    async upload(file: File, metadata?: { altText?: string; caption?: string }): Promise<string> {
        // TODO: Implement GitHub upload
        // 1. Convert file to base64
        // 2. Commit to /public/media/ directory
        // 3. Return public URL
        throw new Error('GitHub storage not yet implemented');
    }

    async delete(url: string): Promise<void> {
        // TODO: Implement GitHub delete
        throw new Error('GitHub storage not yet implemented');
    }

    async list(): Promise<MediaAsset[]> {
        // TODO: Implement GitHub list
        // Read from /public/media/ directory
        return [];
    }

    async get(id: string): Promise<MediaAsset | null> {
        // TODO: Implement GitHub get
        return null;
    }
}
