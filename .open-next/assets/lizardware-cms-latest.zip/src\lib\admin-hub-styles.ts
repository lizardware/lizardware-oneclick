// Shared design tokens for admin hub pages

export const HUB_PAGE_STYLES = {
    container: "min-h-screen bg-site-background pb-32",
    maxWidth: "max-w-7xl mx-auto px-6",
    topPadding: "pt-0",

    header: {
        card: "bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-3xl p-6 md:p-8 shadow-xl overflow-hidden group",
        spacing: "mb-8",
    },

    stats: {
        grid: "grid grid-cols-2 md:grid-cols-4 gap-4",
        spacing: "mb-8",
    },

    sectionCards: {
        grid: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
    },
} as const;

// Multi-color gradient presets (from Content Hub)
export const CARD_GRADIENTS = {
    blue: 'from-blue-500/10 to-blue-500/5 border-blue-500/20 hover:border-blue-500/40',
    purple: 'from-purple-500/10 to-purple-500/5 border-purple-500/20 hover:border-purple-500/40',
    green: 'from-green-500/10 to-green-500/5 border-green-500/20 hover:border-green-500/40',
    orange: 'from-orange-500/10 to-orange-500/5 border-orange-500/20 hover:border-orange-500/40',
    pink: 'from-pink-500/10 to-pink-500/5 border-pink-500/20 hover:border-pink-500/40',
    emerald: 'from-emerald-500/10 to-emerald-500/5 border-emerald-500/20 hover:border-emerald-500/40',
    amber: 'from-amber-500/10 to-amber-500/5 border-amber-500/20 hover:border-amber-500/40',
    cyan: 'from-cyan-500/10 to-cyan-500/5 border-cyan-500/20 hover:border-cyan-500/40',
    indigo: 'from-indigo-500/10 to-indigo-500/5 border-indigo-500/20 hover:border-indigo-500/40',
} as const;

export type GradientColor = keyof typeof CARD_GRADIENTS;
