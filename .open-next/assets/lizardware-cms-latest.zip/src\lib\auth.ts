// Authentication utilities for Forum user system
// Handles password hashing, JWT tokens, and session management

import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const SALT_ROUNDS = 10;
const JWT_SECRET = process.env.JWT_SECRET || 'lizardware-dev-secret-change-in-production';
const JWT_EXPIRES_IN = '7d'; // 7 days

export interface ForumUser {
    id: number;
    username: string;
    email: string;
    display_name: string | null;
    avatar_url: string | null;
    bio: string | null;
    reputation: number;
    is_moderator: boolean;
    is_banned: boolean;
    created_at: string;
    last_seen_at: string;
}

export interface JWTPayload {
    userId: number;
    username: string;
    email: string;
    isModerator: boolean;
}

/**
 * Hash a plain text password using bcrypt
 */
export async function hashPassword(password: string): Promise<string> {
    return bcrypt.hash(password, SALT_ROUNDS);
}

/**
 * Verify a plain text password against a bcrypt hash
 */
export async function verifyPassword(password: string, hash: string): Promise<boolean> {
    return bcrypt.compare(password, hash);
}

/**
 * Generate a JWT token for a user
 */
export function generateToken(user: ForumUser): string {
    const payload: JWTPayload = {
        userId: user.id,
        username: user.username,
        email: user.email,
        isModerator: user.is_moderator,
    };

    return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
}

/**
 * Verify and decode a JWT token
 * Returns null if token is invalid or expired
 */
export function verifyToken(token: string): JWTPayload | null {
    try {
        return jwt.verify(token, JWT_SECRET) as JWTPayload;
    } catch (error) {
        console.error('JWT verification failed:', error);
        return null;
    }
}

/**
 * Extract JWT token from request cookies or Authorization header
 */
export function extractToken(request: Request): string | null {
    // Check Authorization header first (Bearer token)
    const authHeader = request.headers.get('Authorization');
    if (authHeader?.startsWith('Bearer ')) {
        return authHeader.substring(7);
    }

    // Check cookies
    const cookieHeader = request.headers.get('Cookie');
    if (cookieHeader) {
        const cookies = cookieHeader.split(';').map(c => c.trim());
        const tokenCookie = cookies.find(c => c.startsWith('forum_token='));
        if (tokenCookie) {
            return tokenCookie.substring('forum_token='.length);
        }
    }

    return null;
}

/**
 * Get current authenticated user from request
 * Returns null if not authenticated
 */
export function getCurrentUser(request: Request): JWTPayload | null {
    const token = extractToken(request);
    if (!token) return null;

    return verifyToken(token);
}

/**
 * Validate username format
 * Rules: 3-20 characters, alphanumeric + underscore, no spaces
 */
export function validateUsername(username: string): { valid: boolean; error?: string } {
    if (!username || username.length < 3) {
        return { valid: false, error: 'Username must be at least 3 characters long' };
    }

    if (username.length > 20) {
        return { valid: false, error: 'Username must be 20 characters or less' };
    }

    if (!/^[a-zA-Z0-9_]+$/.test(username)) {
        return { valid: false, error: 'Username can only contain letters, numbers, and underscores' };
    }

    return { valid: true };
}

/**
 * Validate email format
 */
export function validateEmail(email: string): { valid: boolean; error?: string } {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!email || !emailRegex.test(email)) {
        return { valid: false, error: 'Invalid email address' };
    }

    return { valid: true };
}

/**
 * Validate password strength
 * Rules: At least 8 characters, contains letter and number
 */
export function validatePassword(password: string): { valid: boolean; error?: string } {
    if (!password || password.length < 8) {
        return { valid: false, error: 'Password must be at least 8 characters long' };
    }

    if (!/[a-zA-Z]/.test(password)) {
        return { valid: false, error: 'Password must contain at least one letter' };
    }

    if (!/[0-9]/.test(password)) {
        return { valid: false, error: 'Password must contain at least one number' };
    }

    return { valid: true };
}

/**
 * Sanitize user object for client response (remove sensitive data)
 */
export function sanitizeUser(user: ForumUser & { password_hash?: string }): Omit<ForumUser, 'password_hash'> {
    const { password_hash, ...safeUser } = user as any;
    return safeUser;
}
