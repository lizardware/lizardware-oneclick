"use client";

import { useState, useEffect } from "react";
import { Plus, Trash2, Edit2, User, X, Check, Globe, Github, Twitter, Linkedin, Link as LinkIcon } from "lucide-react";
import { AdminLoadingState } from "./AdminLoadingState";
import { usePopup } from '@/components/admin/AdminPopupProvider';

interface Author {
    id: string;
    name: string;
    bio?: string;
    avatar_url?: string;
    email?: string;
    twitter?: string;
    linkedin?: string;
}

export default function AuthorManager() {
    const [authors, setAuthors] = useState<Author[]>([]);
    const popup = usePopup();
    const [loading, setLoading] = useState(true);
    const [isEditing, setIsEditing] = useState(false);
    const [currentAuthor, setCurrentAuthor] = useState<Author>({ id: "", name: "", bio: "", avatar_url: "", email: "", twitter: "", linkedin: "" });
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        fetchAuthors();
    }, []);

    const fetchAuthors = async () => {
        try {
            const res = await fetch("/api/admin/blog/authors");
            if (res.ok) {
                const data = await res.json() as { authors: Author[] };
                setAuthors(data.authors || []);
            }
        } catch (err) {
            console.error("Error fetching authors:", err);
        } finally {
            setLoading(false);
        }
    };

    const handleSave = async () => {
        if (!currentAuthor.name || !currentAuthor.id) {
            setError("ID and Name are required");
            return;
        }

        try {
            const res = await fetch("/api/admin/blog/authors", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(currentAuthor)
            });

            if (res.ok) {
                setIsEditing(false);
                setCurrentAuthor({ id: "", name: "", bio: "", avatar_url: "", email: "", twitter: "", linkedin: "" });
                fetchAuthors();
            } else {
                const data = await res.json() as { error?: string };
                setError(data.error || "Failed to save profile");
            }
        } catch (err) {
            setError("Failed to save profile");
        }
    };

    const handleDelete = async (id: string) => {
        const confirmed = await popup.confirm("Delete this author profile?", { isDanger: true });
        if (!confirmed) return;

        try {
            const res = await fetch(`/api/admin/blog/authors?id=${id}`, { method: "DELETE" });
            if (res.ok) {
                fetchAuthors();
            }
        } catch (err) {
            console.error("Error deleting author:", err);
        }
    };

    const handleEdit = (author: Author) => {
        setCurrentAuthor(author);
        setIsEditing(true);
    };

    if (loading) return <AdminLoadingState message="Connecting to mission control..." />;

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-xl font-black text-page-title flex items-center gap-2">
                    <User className="text-purple-500" size={20} />
                    Personnel Files
                </h2>
                {!isEditing && (
                    <button
                        onClick={() => {
                            setCurrentAuthor({ id: "", name: "", bio: "", avatar_url: "", email: "", twitter: "", linkedin: "" });
                            setIsEditing(true);
                        }}
                        className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-purple-500/20"
                    >
                        <Plus size={16} /> New Profile
                    </button>
                )}
            </div>

            {isEditing && (
                <div className="bg-gray-50 dark:bg-zinc-800/50 rounded-2xl p-6 border-2 border-dashed border-purple-500/20 animate-in fade-in slide-in-from-top-4 duration-300">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-sm font-bold text-page-title uppercase tracking-wider">
                            {authors.find(a => a.id === currentAuthor.id) ? "Update Transmission Profile" : "Register New Broadcaster"}
                        </h3>
                        <button onClick={() => setIsEditing(false)} className="text-gray-400 hover:text-gray-600">
                            <X size={18} />
                        </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Profile ID</label>
                            <input
                                type="text"
                                value={currentAuthor.id}
                                onChange={(e) => setCurrentAuthor({ ...currentAuthor, id: e.target.value.toLowerCase().replace(/\s+/g, "-") })}
                                className="w-full px-4 py-2 bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-xl text-sm font-mono"
                                placeholder="e.g. lizard-tech"
                                disabled={authors.some(a => a.id === currentAuthor.id && currentAuthor.id !== "")}
                            />
                        </div>
                        <div className="space-y-2">
                            <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Full Name</label>
                            <input
                                type="text"
                                value={currentAuthor.name}
                                onChange={(e) => setCurrentAuthor({ ...currentAuthor, name: e.target.value })}
                                className="w-full px-4 py-2 bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-xl text-sm"
                                placeholder="e.g. Edward Lizard"
                            />
                        </div>
                        <div className="md:col-span-2 space-y-2">
                            <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Bio / Transmission History</label>
                            <textarea
                                value={currentAuthor.bio}
                                onChange={(e) => setCurrentAuthor({ ...currentAuthor, bio: e.target.value })}
                                className="w-full px-4 py-2 bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-xl text-sm min-h-[80px]"
                                placeholder="Briefly describe the broadcaster..."
                            />
                        </div>

                        <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div className="space-y-2">
                                <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Avatar URL</label>
                                <input
                                    type="text"
                                    value={currentAuthor.avatar_url}
                                    onChange={(e) => setCurrentAuthor({ ...currentAuthor, avatar_url: e.target.value })}
                                    className="w-full px-4 py-2 bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-xl text-sm"
                                    placeholder="https://..."
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Twitter (X)</label>
                                <input
                                    type="text"
                                    value={currentAuthor.twitter}
                                    onChange={(e) => setCurrentAuthor({ ...currentAuthor, twitter: e.target.value })}
                                    className="w-full px-4 py-2 bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-xl text-sm"
                                    placeholder="username"
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">LinkedIn</label>
                                <input
                                    type="text"
                                    value={currentAuthor.linkedin}
                                    onChange={(e) => setCurrentAuthor({ ...currentAuthor, linkedin: e.target.value })}
                                    className="w-full px-4 py-2 bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-xl text-sm"
                                    placeholder="id"
                                />
                            </div>
                        </div>
                    </div>

                    {error && <p className="text-red-500 text-[10px] font-bold mt-2 uppercase">{error}</p>}

                    <div className="mt-6 flex justify-end gap-3">
                        <button
                            onClick={() => setIsEditing(false)}
                            className="px-4 py-2 text-xs font-bold text-gray-400 hover:text-gray-600 transition-colors"
                        >
                            Cancel
                        </button>
                        <button
                            onClick={handleSave}
                            className="flex items-center gap-2 px-6 py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-emerald-500/20"
                        >
                            <Check size={16} /> Update Profile
                        </button>
                    </div>
                </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {authors.map((author) => (
                    <div
                        key={author.id}
                        className="group relative bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-3xl p-6 hover:border-purple-500/30 hover:shadow-2xl hover:shadow-purple-500/5 transition-all duration-500"
                    >
                        <div className="flex items-start gap-5">
                            <div className="relative flex-shrink-0">
                                <div className="w-20 h-20 rounded-2xl overflow-hidden bg-gray-50 dark:bg-zinc-800 border border-gray-100 dark:border-zinc-700 shadow-inner">
                                    {author.avatar_url ? (
                                        <img src={author.avatar_url} alt={author.name} className="w-full h-full object-cover" />
                                    ) : (
                                        <div className="w-full h-full flex items-center justify-center text-gray-300">
                                            <User size={32} />
                                        </div>
                                    )}
                                </div>
                                <div className="absolute -bottom-2 -right-2 bg-white dark:bg-zinc-900 p-1.5 rounded-lg border border-gray-100 dark:border-zinc-800 shadow-sm text-purple-500">
                                    <Globe size={12} />
                                </div>
                            </div>

                            <div className="flex-1 min-w-0">
                                <div className="flex justify-between items-start mb-1">
                                    <h3 className="text-lg font-bold text-page-title truncate">{author.name}</h3>
                                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all transform translate-x-2 group-hover:translate-x-0">
                                        <button
                                            onClick={() => handleEdit(author)}
                                            className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-lg text-gray-400 hover:text-purple-500 transition-colors"
                                        >
                                            <Edit2 size={14} />
                                        </button>
                                        <button
                                            onClick={() => handleDelete(author.id)}
                                            className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-lg text-gray-400 hover:text-red-500 transition-colors"
                                        >
                                            <Trash2 size={14} />
                                        </button>
                                    </div>
                                </div>
                                <p className="text-[10px] font-mono text-gray-400 mb-3 uppercase tracking-widest">ID: {author.id}</p>
                                <p className="text-xs text-gray-500 line-clamp-2 leading-relaxed mb-4">
                                    {author.bio || "No mission brief provided."}
                                </p>

                                <div className="flex items-center gap-3">
                                    {author.twitter && (
                                        <a href={`https://twitter.com/${author.twitter}`} target="_blank" className="text-gray-400 hover:text-blue-400 transition-colors">
                                            <Twitter size={14} />
                                        </a>
                                    )}
                                    {author.linkedin && (
                                        <a href={`https://linkedin.com/in/${author.linkedin}`} target="_blank" className="text-gray-400 hover:text-blue-600 transition-colors">
                                            <Linkedin size={14} />
                                        </a>
                                    )}
                                    {author.email && (
                                        <a href={`mailto:${author.email}`} className="text-gray-400 hover:text-purple-500 transition-colors">
                                            <Globe size={14} />
                                        </a>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                ))}

                {authors.length === 0 && !isEditing && (
                    <div className="md:col-span-2 py-20 text-center space-y-4 bg-gray-50 dark:bg-zinc-900/50 rounded-3xl border-2 border-dashed border-gray-200 dark:border-zinc-800">
                        <User size={48} className="mx-auto text-gray-300" />
                        <div>
                            <p className="text-sm font-bold text-page-title">No Personnel Records</p>
                            <p className="text-xs text-gray-400">Register the first broadcaster to start transmissions.</p>
                        </div>
                        <button
                            onClick={() => setIsEditing(true)}
                            className="px-6 py-2 bg-purple-600 text-white rounded-xl text-xs font-bold hover:bg-purple-700 transition-all"
                        >
                            Add Personnel
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
}
