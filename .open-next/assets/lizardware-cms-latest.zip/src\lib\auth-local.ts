import bcrypt from 'bcryptjs';
import { getD1Database } from '@/lib/cloudflare';
// Re-export JWT functions for convenience in server components
export * from './auth-jwt';

// Password hashing remains here as it's not needed in middleware
export async function hashPassword(password: string): Promise<string> {
    return await bcrypt.hash(password, 10);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
    return await bcrypt.compare(password, hash);
}

export async function createLocalUser(db: D1Database, username: string, passwordHash: string): Promise<void> {
    const id = crypto.randomUUID();
    await db.prepare(
        'INSERT INTO users (id, username, password_hash) VALUES (?, ?, ?)'
    ).bind(id, username, passwordHash).run();
}

export async function getLocalUserByUsername(db: D1Database, username: string) {
    return await db.prepare(
        'SELECT * FROM users WHERE username = ?'
    ).bind(username).first<{ id: string, username: string, password_hash: string, role: string }>();
}
