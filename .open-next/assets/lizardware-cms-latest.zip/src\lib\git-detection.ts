/**
 * Lizardware CMS - Git Detection Utility
 */

import fs from 'fs';
import path from 'path';

export type RepoMode = 'fork' | 'direct' | 'unknown';

export interface GitInfo {
    mode: RepoMode;
    branch?: string;
    remoteUrl?: string;
    hasGit: boolean;
}

/**
 * Detects if the current environment is running from a Git repository
 * and attempts to identify if it's a fork or direct install.
 */
export function getGitInfo(): GitInfo {
    const rootDir = process.cwd();
    const gitDir = path.join(rootDir, '.git');
    const hasGit = fs.existsSync(gitDir);

    if (!hasGit) {
        return { mode: 'direct', hasGit: false };
    }

    try {
        // We'll peek at the git config if possible to find the remote
        // In Cloudflare Workers, we won't have the .git folder 
        // So this utility is primarily for LOCAL PREVIEW / BUILD TIME
        const configPath = path.join(gitDir, 'config');
        if (fs.existsSync(configPath)) {
            const config = fs.readFileSync(configPath, 'utf8');
            const hasUpstream = config.includes('[remote "upstream"]');
            const mode: RepoMode = hasUpstream ? 'fork' : 'direct';

            return {
                mode,
                hasGit: true,
                // Simple regex extraction for display
                remoteUrl: config.match(/url = (.*)/)?.[1] || undefined
            };
        }
    } catch (e) {
        console.error('Failed to read git info:', e);
    }

    return { mode: 'unknown', hasGit: true };
}
