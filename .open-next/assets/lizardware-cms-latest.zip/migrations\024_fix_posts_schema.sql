-- Migration: Fix missing columns in posts table
-- Created: 2025-12-29
-- Purpose: Patch existing databases that were initialized with incomplete schema
-- Note: 'init-database' route ignores "duplicate column name" errors, so it's safe to run blindly.

ALTER TABLE posts ADD COLUMN excerpt TEXT;
ALTER TABLE posts ADD COLUMN author_id TEXT;
ALTER TABLE posts ADD COLUMN tags TEXT;
ALTER TABLE posts ADD COLUMN featured_image_id TEXT;
ALTER TABLE posts ADD COLUMN category_id TEXT;
ALTER TABLE posts ADD COLUMN scheduled_date TEXT;
ALTER TABLE posts ADD COLUMN view_count INTEGER DEFAULT 0;
