import { NextResponse } from 'next/server';
import { getPagesByType, upsertPage } from '@/lib/pages';
import { Page } from '@/types/page';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
    try {
        const { slug, direction } = await request.json() as {
            slug: string,
            direction: 'up' | 'down'
        };

        if (!slug || !direction) {
            return NextResponse.json({ error: 'Missing parameters' }, { status: 400 });
        }

        const pages = await getPagesByType('all');
        const currentIndex = pages.findIndex((p: Page) => p.slug === slug);

        if (currentIndex === -1) {
            return NextResponse.json({ error: 'Page not found' }, { status: 404 });
        }

        const targetIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;

        if (targetIndex < 0 || targetIndex >= pages.length) {
            return NextResponse.json({ error: 'Cannot move in that direction' }, { status: 400 });
        }

        const currentPage = pages[currentIndex];
        const targetPage = pages[targetIndex];

        // Ensure both have a sort_order
        const currentOrder = currentPage.sort_order ?? currentIndex;
        const targetOrder = targetPage.sort_order ?? targetIndex;

        // Swap sort_order
        currentPage.sort_order = targetOrder;
        targetPage.sort_order = currentOrder;

        // If they were same, force a difference
        if (currentPage.sort_order === targetPage.sort_order) {
            if (direction === 'up') {
                currentPage.sort_order--;
            } else {
                currentPage.sort_order++;
            }
        }

        await Promise.all([
            upsertPage(currentPage),
            upsertPage(targetPage)
        ]);

        return NextResponse.json({ success: true });
    } catch (error) {
        console.error('Reorder failed:', error);
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
    }
}
