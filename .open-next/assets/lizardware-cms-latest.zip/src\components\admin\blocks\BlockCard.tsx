'use client';

import { useDraggable } from '@dnd-kit/core';
import { BlockDefinition } from '@/types/blocks';
import { GripVertical } from 'lucide-react';

interface BlockCardProps {
    block: BlockDefinition;
}

export default function BlockCard({ block }: BlockCardProps) {
    const { attributes, listeners, setNodeRef, isDragging } = useDraggable({
        id: `lib-${block.type}`,
        data: {
            type: block.type,
            isNew: true
        }
    });

    const Icon = block.icon;

    if (isDragging) {
        return (
            <div
                ref={setNodeRef}
                className="p-3 rounded-xl border-2 border-primary/50 bg-primary/5 opacity-50 cursor-grabbing"
                style={{ width: '100%', height: '80px' }} // Approximate size
            />
        );
    }

    return (
        <div
            ref={setNodeRef}
            {...listeners}
            {...attributes}
            className="flex items-center gap-3 p-3 rounded-xl border border-gray-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 shadow-sm hover:border-primary/50 hover:shadow-md transition-all cursor-grab active:cursor-grabbing group select-none"
        >
            <div className="p-2 rounded-lg bg-gray-50 dark:bg-zinc-800 text-gray-500 group-hover:text-primary transition-colors">
                <Icon size={20} />
            </div>

            <div className="flex-1">
                <div className="text-sm font-semibold">{block.label}</div>
            </div>

            <GripVertical size={16} className="text-gray-300 group-hover:text-gray-500 transition-colors" />
        </div>
    );
}
