-- Add navigation control columns to posts table
ALTER TABLE posts ADD COLUMN show_in_nav INTEGER DEFAULT 0;
ALTER TABLE posts ADD COLUMN nav_label TEXT;
ALTER TABLE posts ADD COLUMN nav_parent TEXT;
ALTER TABLE posts ADD COLUMN nav_order INTEGER DEFAULT 0;
