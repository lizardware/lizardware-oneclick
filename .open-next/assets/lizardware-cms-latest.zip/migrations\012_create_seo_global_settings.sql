-- Migration: Create SEO global settings table
-- Version: 0.3.1
-- Purpose: Store user-configurable SEO defaults and wizard completion status

CREATE TABLE IF NOT EXISTS seo_global_settings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title_template TEXT DEFAULT '{page_title} | {site_name}',
  meta_description_template TEXT,
  og_image_default TEXT,
  organization_schema TEXT,
  setup_wizard_completed BOOLEAN DEFAULT 0,
  google_search_console_code TEXT,
  bing_webmaster_code TEXT,
  twitter_card_type TEXT DEFAULT 'summary_large_image',
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Insert default settings
INSERT INTO seo_global_settings (id, title_template) VALUES (1, '{page_title} | {site_name}');
