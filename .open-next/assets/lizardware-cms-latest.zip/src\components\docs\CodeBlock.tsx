"use client";

import React, { useState } from "react";
import { Check, Copy } from "lucide-react";

interface CodeBlockProps {
    code: string;
    language?: string;
    className?: string;
}

export const CodeBlock = ({ code, language = "bash", className = "" }: CodeBlockProps) => {
    const [copied, setCopied] = useState(false);

    const handleCopy = async () => {
        try {
            if (navigator?.clipboard?.writeText) {
                await navigator.clipboard.writeText(code);
            } else {
                // Fallback for non-secure contexts (e.g., local network dev)
                const textArea = document.createElement("textarea");
                textArea.value = code;
                textArea.style.position = "fixed"; // Avoid scrolling to bottom
                textArea.style.left = "-9999px";
                textArea.style.top = "0";
                document.body.appendChild(textArea);
                textArea.focus();
                textArea.select();
                try {
                    document.execCommand('copy');
                } catch (err) {
                    console.error('Fallback: Oops, unable to copy', err);
                }
                document.body.removeChild(textArea);
            }
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        } catch (err) {
            console.error("Failed to copy text:", err);
        }
    };

    return (
        <div className={`relative group rounded-xl overflow-hidden bg-[#0d1117] border border-gray-800 my-4 ${className}`}>
            <div className="flex items-center justify-between px-4 py-2 bg-[#161b22] border-b border-gray-800">
                <span className="text-xs font-mono text-gray-400">{language}</span>
                <button
                    onClick={handleCopy}
                    className="flex items-center gap-1.5 px-2 py-1 text-xs font-medium text-gray-400 hover:text-white transition-colors rounded-md hover:bg-gray-800"
                    title="Copy to clipboard"
                >
                    {copied ? (
                        <>
                            <Check size={14} className="text-green-500" />
                            <span className="text-green-500">Copied!</span>
                        </>
                    ) : (
                        <>
                            <Copy size={14} />
                            <span>Copy</span>
                        </>
                    )}
                </button>
            </div>
            <div className="p-4 overflow-x-auto">
                <pre className="text-sm font-mono leading-relaxed text-gray-300">
                    <code>{code}</code>
                </pre>
            </div>
        </div>
    );
};
