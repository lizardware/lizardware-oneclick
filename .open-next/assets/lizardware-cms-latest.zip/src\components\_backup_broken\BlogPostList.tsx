"use client";

import { useState, useEffect } from "react";
import Link from "next/link";

type Post = {
  title: string;
  slug: string;
};

export default function BlogPostList() {
  const [posts, setPosts] = useState<Post[]>([]);

  useEffect(() => {
    async function fetchPosts() {
      const response = await fetch("/api/posts");
      const allPosts = await response.json();
      setPosts(allPosts as Post[]);
    }
    fetchPosts();
  }, []);

  return (
    <div className="border rounded-lg p-6 bg-white dark:bg-gray-800">
      <h3 className="font-semibold mb-4">Existing Posts</h3>
      <ul>
        {posts.map((post) => (
          <li key={post.slug}>
            <Link href={`/admin/editor/blog/${post.slug}`} className="text-blue-600 hover:underline">
              {post.title}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
