import { NextRequest, NextResponse } from "next/server";
import { getD1Database } from "@/lib/cloudflare";
import { getAllAuthors, upsertAuthor, deleteAuthor } from "@/lib/blog-authors";

export async function GET() {
    try {
        const db = await getD1Database();
        if (!db) {
            return NextResponse.json({ error: "D1 Database not available" }, { status: 503 });
        }
        const authors = await getAllAuthors(db);
        return NextResponse.json({ authors }, { status: 200 });
    } catch (error) {
        return NextResponse.json({ error: (error as Error).message }, { status: 500 });
    }
}

export async function POST(request: NextRequest) {
    try {
        const db = await getD1Database();
        if (!db) {
            return NextResponse.json({ error: "D1 Database not available" }, { status: 503 });
        }
        const body = await request.json() as any;
        if (!body.id || !body.name) {
            return NextResponse.json({ error: "Missing required fields: id, name" }, { status: 400 });
        }
        await upsertAuthor(db, body);
        return NextResponse.json({ success: true, message: "Author saved successfully" }, { status: 200 });
    } catch (error) {
        return NextResponse.json({ error: (error as Error).message }, { status: 500 });
    }
}

export async function DELETE(request: NextRequest) {
    try {
        const db = await getD1Database();
        if (!db) {
            return NextResponse.json({ error: "D1 Database not available" }, { status: 503 });
        }
        const { searchParams } = new URL(request.url);
        const id = searchParams.get('id');
        if (!id) {
            return NextResponse.json({ error: "Missing required field: id" }, { status: 400 });
        }
        await deleteAuthor(db, id);
        return NextResponse.json({ success: true, message: "Author deleted successfully" }, { status: 200 });
    } catch (error) {
        return NextResponse.json({ error: (error as Error).message }, { status: 500 });
    }
}
