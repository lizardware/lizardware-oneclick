import msp from './msp.json';
import restaurant from './restaurant.json';
import blogger from './blogger.json';
import service from './service.json';
import healthcare from './healthcare.json';
import type { SiteTemplate } from '@/types/template';

// Force cast JSON imports to SiteTemplate to ensure type safety 
// (in a real app, we might use Zod to validate these at runtime)
const templatesMap: Record<string, SiteTemplate> = {
    msp: msp as unknown as SiteTemplate,
    restaurant: restaurant as unknown as SiteTemplate,
    blogger: blogger as unknown as SiteTemplate,
    service: service as unknown as SiteTemplate,
    healthcare: healthcare as unknown as SiteTemplate,
};

export const templates = templatesMap;

export const getTemplate = (id: string): SiteTemplate | undefined => {
    return templates[id];
};

export const getAllTemplates = (): SiteTemplate[] => {
    return Object.values(templates);
};
