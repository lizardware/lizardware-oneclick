import { NextRequest, NextResponse } from "next/server";
import { getAllPostsFromD1, upsertPostToD1 } from "@/lib/blog-storage";
import { getD1Database, dbUnavailableResponse } from '@/lib/cloudflare';

// GET /api/blog - List all posts
export async function GET(request: NextRequest) {
    try {
        const db = await getD1Database();

        if (!db) {
            return dbUnavailableResponse();
        }

        const includeStatus = request.nextUrl.searchParams.get("status") as "draft" | "published" | undefined;
        const posts = await getAllPostsFromD1(db, false, includeStatus || "published");

        return NextResponse.json({ posts });
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error("Blog fetch error:", message);

        return NextResponse.json(
            { error: message },
            { status: 500 }
        );
    }
}

// POST /api/blog - Create new post
export async function POST(request: NextRequest) {
    try {
        const db = await getD1Database();

        if (!db) {
            return dbUnavailableResponse();
        }

        const post = await request.json() as { slug?: string; title?: string; content?: string;[key: string]: unknown };

        // Validate required fields
        if (!post.slug || !post.title || !post.content) {
            return NextResponse.json(
                { error: "Missing required fields: slug, title, content" },
                { status: 400 }
            );
        }

        const fullPost = {
            ...post,
            date: (post as any).date || new Date().toISOString(),
            status: (post as any).status || 'draft'
        } as any;

        await upsertPostToD1(db, fullPost);

        return NextResponse.json({
            success: true,
            message: "Post created successfully",
        });
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error("Post creation error:", message);

        return NextResponse.json(
            { error: message },
            { status: 500 }
        );
    }
}
