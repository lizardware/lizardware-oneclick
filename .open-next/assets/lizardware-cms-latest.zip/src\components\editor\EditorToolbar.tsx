"use client";

import { Editor } from "@tiptap/react";
import { useState } from "react";
import {
    Undo, Redo, ChevronDown, Heading1, Heading2, Heading3, Heading4, Heading5, Heading6,
    List, ListOrdered, CheckSquare, Quote, Code, Bold, Italic,
    Underline as UnderlineIcon, Strikethrough, Highlighter, Link as LinkIcon,
    Link2Off, Superscript as SuperscriptIcon, Subscript as SubscriptIcon,
    AlignLeft, AlignCenter, AlignRight, AlignJustify, Image as ImageIcon,
    Sun, Moon, Minus, CornerDownLeft, Eraser, RemoveFormatting, FileCode,
    Plus, MoreHorizontal
} from "lucide-react";
import VariableInserterButton from "../admin/VariableInserterButton";

interface EditorToolbarProps {
    editor: Editor;
    theme: "light" | "dark";
    onThemeToggle: () => void;
}

export default function EditorToolbar({ editor, theme, onThemeToggle }: EditorToolbarProps) {
    const [showLinkInput, setShowLinkInput] = useState(false);
    const [linkUrl, setLinkUrl] = useState("");
    const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

    const toggleDropdown = (name: string) => {
        setActiveDropdown(activeDropdown === name ? null : name);
    };

    const addImage = () => {
        const url = window.prompt("Image URL:");
        if (url) {
            editor.chain().focus().setImage({ src: url }).run();
        }
    };

    const setLink = () => {
        if (linkUrl) {
            editor
                .chain()
                .focus()
                .extendMarkRange("link")
                .setLink({ href: linkUrl })
                .run();
            setShowLinkInput(false);
            setLinkUrl("");
        }
    };

    const removeLink = () => {
        editor.chain().focus().unsetLink().run();
        setShowLinkInput(false);
    };

    if (!editor) {
        return null;
    }

    return (
        <div className="border-b border-borders bg-info-box-bg px-1 py-1 sticky top-0 z-10">
            <div className="flex flex-wrap items-center gap-1">
                {/* Section 1: History */}
                <div className="flex items-center">
                    <ToolbarButton
                        onClick={() => editor.chain().focus().undo().run()}
                        disabled={!editor.can().undo()}
                        title="Undo"
                    >
                        <Undo className="w-3.5 h-3.5" />
                    </ToolbarButton>
                    <ToolbarButton
                        onClick={() => editor.chain().focus().redo().run()}
                        disabled={!editor.can().redo()}
                        title="Redo"
                    >
                        <Redo className="w-3.5 h-3.5" />
                    </ToolbarButton>
                </div>

                <Separator />

                {/* Section 2: Headings & Lists */}
                <div className="flex items-center">
                    {/* Headings */}
                    <div className="relative">
                        <ToolbarButton
                            onClick={() => toggleDropdown("heading")}
                            isActive={editor.isActive("heading")}
                            title="Headings"
                            hasDropdown
                        >
                            <span className="text-[10px] font-black mr-0.5">H</span>
                            <ChevronDown className={`w-2.5 h-2.5 transition-transform ${activeDropdown === "heading" ? "rotate-180" : ""}`} />
                        </ToolbarButton>
                        {activeDropdown === "heading" && (
                            <DropdownMenu onClose={() => setActiveDropdown(null)}>
                                {[1, 2, 3, 4, 5, 6].map((level) => (
                                    <DropdownItem
                                        key={level}
                                        onClick={() => editor.chain().focus().toggleHeading({ level: level as any }).run()}
                                        isActive={editor.isActive("heading", { level })}
                                        onClose={() => setActiveDropdown(null)}
                                    >
                                        <span className="font-bold mr-2 text-xs">H{level}</span> Heading {level}
                                    </DropdownItem>
                                ))}
                            </DropdownMenu>
                        )}
                    </div>

                    {/* Lists Dropdown */}
                    <div className="relative">
                        <ToolbarButton
                            onClick={() => toggleDropdown("list")}
                            isActive={editor.isActive("bulletList") || editor.isActive("orderedList") || editor.isActive("taskList")}
                            title="Lists"
                            hasDropdown
                        >
                            <List className="w-3.5 h-3.5 mr-0.5" />
                            <ChevronDown className={`w-2.5 h-2.5 transition-transform ${activeDropdown === "list" ? "rotate-180" : ""}`} />
                        </ToolbarButton>
                        {activeDropdown === "list" && (
                            <DropdownMenu onClose={() => setActiveDropdown(null)}>
                                <DropdownItem
                                    onClick={() => editor.chain().focus().toggleBulletList().run()}
                                    isActive={editor.isActive("bulletList")}
                                    onClose={() => setActiveDropdown(null)}
                                >
                                    <List className="w-4 h-4 mr-2" /> Bullet List
                                </DropdownItem>
                                <DropdownItem
                                    onClick={() => editor.chain().focus().toggleOrderedList().run()}
                                    isActive={editor.isActive("orderedList")}
                                    onClose={() => setActiveDropdown(null)}
                                >
                                    <ListOrdered className="w-4 h-4 mr-2" /> Numbered List
                                </DropdownItem>
                                <DropdownItem
                                    onClick={() => editor.chain().focus().toggleTaskList().run()}
                                    isActive={editor.isActive("taskList")}
                                    onClose={() => setActiveDropdown(null)}
                                >
                                    <CheckSquare className="w-4 h-4 mr-2" /> Task List
                                </DropdownItem>
                            </DropdownMenu>
                        )}
                    </div>
                </div>

                <Separator />

                {/* Section 3: Essential Formatting */}
                <div className="flex items-center">
                    <ToolbarButton
                        onClick={() => editor.chain().focus().toggleBold().run()}
                        isActive={editor.isActive("bold")}
                        title="Bold"
                    >
                        <Bold className="w-3.5 h-3.5" />
                    </ToolbarButton>
                    <ToolbarButton
                        onClick={() => editor.chain().focus().toggleItalic().run()}
                        isActive={editor.isActive("italic")}
                        title="Italic"
                    >
                        <Italic className="w-3.5 h-3.5" />
                    </ToolbarButton>
                    <ToolbarButton
                        onClick={() => setShowLinkInput(!showLinkInput)}
                        isActive={editor.isActive("link")}
                        title="Link"
                    >
                        <LinkIcon className="w-3.5 h-3.5" />
                    </ToolbarButton>

                    {/* Advanced Formatting Dropdown */}
                    <div className="relative">
                        <ToolbarButton
                            onClick={() => toggleDropdown("formatting")}
                            isActive={
                                editor.isActive("underline") ||
                                editor.isActive("strike") ||
                                editor.isActive("highlight") ||
                                editor.isActive("superscript") ||
                                editor.isActive("subscript") ||
                                editor.isActive("code")
                            }
                            title="More Formatting"
                            hasDropdown
                        >
                            <MoreHorizontal className="w-3.5 h-3.5 mr-0.5" />
                            <ChevronDown className={`w-2.5 h-2.5 transition-transform ${activeDropdown === "formatting" ? "rotate-180" : ""}`} />
                        </ToolbarButton>
                        {activeDropdown === "formatting" && (
                            <DropdownMenu onClose={() => setActiveDropdown(null)}>
                                <DropdownItem
                                    onClick={() => editor.chain().focus().toggleUnderline().run()}
                                    isActive={editor.isActive("underline")}
                                    onClose={() => setActiveDropdown(null)}
                                >
                                    <UnderlineIcon className="w-4 h-4 mr-2" /> Underline
                                </DropdownItem>
                                <DropdownItem
                                    onClick={() => editor.chain().focus().toggleStrike().run()}
                                    isActive={editor.isActive("strike")}
                                    onClose={() => setActiveDropdown(null)}
                                >
                                    <Strikethrough className="w-4 h-4 mr-2" /> Strikethrough
                                </DropdownItem>
                                <DropdownItem
                                    onClick={() => editor.chain().focus().toggleCode().run()}
                                    isActive={editor.isActive("code")}
                                    onClose={() => setActiveDropdown(null)}
                                >
                                    <Code className="w-4 h-4 mr-2" /> Inline Code
                                </DropdownItem>
                                <DropdownItem
                                    onClick={() => editor.chain().focus().toggleHighlight().run()}
                                    isActive={editor.isActive("highlight")}
                                    onClose={() => setActiveDropdown(null)}
                                >
                                    <Highlighter className="w-4 h-4 mr-2" /> Highlight
                                </DropdownItem>
                                <DropdownItem
                                    onClick={() => editor.chain().focus().toggleSuperscript().run()}
                                    isActive={editor.isActive("superscript")}
                                    onClose={() => setActiveDropdown(null)}
                                >
                                    <SuperscriptIcon className="w-4 h-4 mr-2" /> Superscript
                                </DropdownItem>
                                <DropdownItem
                                    onClick={() => editor.chain().focus().toggleSubscript().run()}
                                    isActive={editor.isActive("subscript")}
                                    onClose={() => setActiveDropdown(null)}
                                >
                                    <SubscriptIcon className="w-4 h-4 mr-2" /> Subscript
                                </DropdownItem>
                            </DropdownMenu>
                        )}
                    </div>
                </div>

                <Separator />

                {/* Section 4: Alignment Dropdown */}
                <div className="relative">
                    <ToolbarButton
                        onClick={() => toggleDropdown("alignment")}
                        isActive={
                            editor.isActive({ textAlign: "center" }) ||
                            editor.isActive({ textAlign: "right" }) ||
                            editor.isActive({ textAlign: "justify" })
                        }
                        title="Text Alignment"
                        hasDropdown
                    >
                        {editor.isActive({ textAlign: "center" }) ? <AlignCenter className="w-3.5 h-3.5 mr-0.5" /> :
                            editor.isActive({ textAlign: "right" }) ? <AlignRight className="w-3.5 h-3.5 mr-0.5" /> :
                                editor.isActive({ textAlign: "justify" }) ? <AlignJustify className="w-3.5 h-3.5 mr-0.5" /> :
                                    <AlignLeft className="w-3.5 h-3.5 mr-0.5" />}
                        <ChevronDown className={`w-2.5 h-2.5 transition-transform ${activeDropdown === "alignment" ? "rotate-180" : ""}`} />
                    </ToolbarButton>
                    {activeDropdown === "alignment" && (
                        <DropdownMenu onClose={() => setActiveDropdown(null)}>
                            <DropdownItem
                                onClick={() => editor.chain().focus().setTextAlign("left").run()}
                                isActive={editor.isActive({ textAlign: "left" })}
                                onClose={() => setActiveDropdown(null)}
                            >
                                <AlignLeft className="w-4 h-4 mr-2" /> Align Left
                            </DropdownItem>
                            <DropdownItem
                                onClick={() => editor.chain().focus().setTextAlign("center").run()}
                                isActive={editor.isActive({ textAlign: "center" })}
                                onClose={() => setActiveDropdown(null)}
                            >
                                <AlignCenter className="w-4 h-4 mr-2" /> Align Center
                            </DropdownItem>
                            <DropdownItem
                                onClick={() => editor.chain().focus().setTextAlign("right").run()}
                                isActive={editor.isActive({ textAlign: "right" })}
                                onClose={() => setActiveDropdown(null)}
                            >
                                <AlignRight className="w-4 h-4 mr-2" /> Align Right
                            </DropdownItem>
                            <DropdownItem
                                onClick={() => editor.chain().focus().setTextAlign("justify").run()}
                                isActive={editor.isActive({ textAlign: "justify" })}
                                onClose={() => setActiveDropdown(null)}
                            >
                                <AlignJustify className="w-4 h-4 mr-2" /> Align Justify
                            </DropdownItem>
                        </DropdownMenu>
                    )}
                </div>

                <Separator />

                {/* Section 5: Blocks & Utilities */}
                <div className="relative">
                    <ToolbarButton
                        onClick={() => toggleDropdown("insert")}
                        title="Insert Blocks"
                        hasDropdown
                    >
                        <Plus className="w-3.5 h-3.5 mr-0.5" />
                        <ChevronDown className={`w-2.5 h-2.5 transition-transform ${activeDropdown === "insert" ? "rotate-180" : ""}`} />
                    </ToolbarButton>
                    {activeDropdown === "insert" && (
                        <DropdownMenu onClose={() => setActiveDropdown(null)}>
                            <DropdownItem
                                onClick={() => editor.chain().focus().toggleBlockquote().run()}
                                isActive={editor.isActive("blockquote")}
                                onClose={() => setActiveDropdown(null)}
                            >
                                <Quote className="w-4 h-4 mr-2" /> Blockquote
                            </DropdownItem>
                            <DropdownItem
                                onClick={() => editor.chain().focus().toggleCodeBlock().run()}
                                isActive={editor.isActive("codeBlock")}
                                onClose={() => setActiveDropdown(null)}
                            >
                                <FileCode className="w-4 h-4 mr-2" /> Code Block
                            </DropdownItem>
                            <DropdownItem
                                onClick={() => editor.chain().focus().setHorizontalRule().run()}
                                isActive={false}
                                onClose={() => setActiveDropdown(null)}
                            >
                                <Minus className="w-4 h-4 mr-2" /> Horizontal Rule
                            </DropdownItem>
                            <DropdownItem
                                onClick={() => editor.chain().focus().setHardBreak().run()}
                                isActive={false}
                                onClose={() => setActiveDropdown(null)}
                            >
                                <CornerDownLeft className="w-4 h-4 mr-2" /> Hard Break
                            </DropdownItem>
                        </DropdownMenu>
                    )}
                </div>

                <Separator />

                {/* Section 6: Specific Media/Variables */}
                <div className="flex items-center">
                    <VariableInserterButton editor={editor} />
                    <ToolbarButton onClick={addImage} title="Add Image">
                        <ImageIcon className="w-3.5 h-3.5" />
                    </ToolbarButton>
                </div>

                <div className="flex-1" />

                {/* Section 7: Clear & Theme */}
                <div className="flex items-center">
                    {/* Clear Dropdown */}
                    <div className="relative">
                        <ToolbarButton
                            onClick={() => toggleDropdown("clear")}
                            title="Clear Formatting"
                            hasDropdown
                        >
                            <Eraser className="w-3.5 h-3.5 mr-0.5" />
                            <ChevronDown className={`w-2.5 h-2.5 transition-transform ${activeDropdown === "clear" ? "rotate-180" : ""}`} />
                        </ToolbarButton>
                        {activeDropdown === "clear" && (
                            <DropdownMenu onClose={() => setActiveDropdown(null)}>
                                <DropdownItem
                                    onClick={() => editor.chain().focus().unsetAllMarks().run()}
                                    isActive={false}
                                    onClose={() => setActiveDropdown(null)}
                                >
                                    <Eraser className="w-4 h-4 mr-2" /> Clear All Marks
                                </DropdownItem>
                                <DropdownItem
                                    onClick={() => editor.chain().focus().clearNodes().run()}
                                    isActive={false}
                                    onClose={() => setActiveDropdown(null)}
                                >
                                    <RemoveFormatting className="w-4 h-4 mr-2" /> Reset to Paragraph
                                </DropdownItem>
                            </DropdownMenu>
                        )}
                    </div>

                    <Separator />

                    <ToolbarButton onClick={onThemeToggle} title="Toggle Theme">
                        {theme === "light" ? <Moon className="w-3.5 h-3.5" /> : <Sun className="w-3.5 h-3.5 text-amber-400" />}
                    </ToolbarButton>
                    <span className="text-[9px] tabular-nums font-bold text-gray-400 px-1.5 opacity-50">
                        {editor.storage.characterCount?.words() || 0}W
                    </span>
                </div>
            </div>

            {/* Link Input Overlay */}
            {
                showLinkInput && (
                    <div className="absolute left-2 right-2 mt-2 z-20 flex gap-2 items-center p-2 bg-page-background rounded-lg border border-borders shadow-xl animate-in slide-in-from-top-2 duration-200">
                        <input
                            type="url"
                            value={linkUrl}
                            onChange={(e) => setLinkUrl(e.target.value)}
                            placeholder="https://example.com"
                            className="flex-1 px-3 py-1.5 text-sm bg-info-box-bg border border-borders rounded-md focus:outline-none focus:ring-2 focus:ring-page-subtitle/50"
                            autoFocus
                            onKeyDown={(e) => {
                                if (e.key === "Enter") setLink();
                                else if (e.key === "Escape") setShowLinkInput(false);
                            }}
                        />
                        <div className="flex gap-1">
                            <button
                                onClick={setLink}
                                className="px-3 py-1.5 text-sm bg-page-subtitle text-white rounded-md hover:bg-page-subtitle/90 transition-colors font-medium"
                            >
                                Set
                            </button>
                            {editor.isActive("link") && (
                                <button
                                    onClick={removeLink}
                                    className="p-1.5 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-md transition-colors"
                                    title="Remove Link"
                                >
                                    <Link2Off className="w-4 h-4" />
                                </button>
                            )}
                            <button
                                onClick={() => setShowLinkInput(false)}
                                className="px-3 py-1.5 text-sm border border-borders rounded-md hover:bg-info-box-bg transition-colors"
                            >
                                Cancel
                            </button>
                        </div>
                    </div>
                )}
        </div>
    );
}

function Separator() {
    return <div className="w-[1px] h-4 bg-info-box-text/10 mx-0.5 self-center" />;
}

interface ToolbarButtonProps {
    onClick: () => void;
    isActive?: boolean;
    disabled?: boolean;
    title?: string;
    children: React.ReactNode;
    hasDropdown?: boolean;
}

function ToolbarButton({
    onClick,
    isActive = false,
    disabled = false,
    title,
    children,
    hasDropdown = false
}: ToolbarButtonProps) {
    return (
        <button
            onClick={onClick}
            disabled={disabled}
            title={title}
            tabIndex={-1}
            className={`
                flex items-center justify-center
                h-7 ${hasDropdown ? "min-w-[40px] px-1.5" : "w-7"} 
                text-xs rounded-md transition-all duration-200
                ${isActive
                    ? "bg-page-subtitle shadow-md shadow-page-subtitle/20 text-white"
                    : "hover:bg-info-box-link-bg text-info-box-text hover:shadow-sm"
                }
                ${disabled ? "opacity-30 cursor-not-allowed grayscale" : "active:scale-95"}
            `}
        >
            {children}
        </button>
    );
}

function DropdownMenu({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
    return (
        <>
            <div className="fixed inset-0 z-20" onClick={onClose} />
            <div className="absolute top-full left-0 mt-1.5 py-1 min-w-[160px] bg-page-background border border-borders rounded-lg shadow-2xl z-30 animate-in fade-in zoom-in-95 duration-100 origin-top-left overflow-hidden">
                {children}
            </div>
        </>
    );
}

function DropdownItem({ onClick, isActive, children, onClose }: { onClick: () => void; isActive: boolean; children: React.ReactNode; onClose?: () => void }) {
    return (
        <button
            onClick={() => {
                onClick();
                onClose?.();
            }}
            className={`
                flex items-center w-full px-3 py-2 text-sm text-left transition-colors
                ${isActive
                    ? "bg-page-subtitle/10 text-page-subtitle font-semibold"
                    : "text-page-text hover:bg-info-box-link-bg hover:text-page-subtitle"
                }
            `}
        >
            {children}
        </button>
    );
}

