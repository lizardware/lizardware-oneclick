'use client';

import { useState, useEffect, ReactNode } from 'react';
import { AuthProviderContext, AuthUser } from '@/context/AuthContext';
import { DEFAULT_LOCAL_USER } from '@/lib/auth-config';

export function LocalAuthProvider({ children }: { children: ReactNode }) {
    const [user, setUser] = useState<AuthUser | null>(null);
    const [isLoaded, setIsLoaded] = useState(false);

    useEffect(() => {
        // Check local storage for session
        const stored = typeof window !== 'undefined' ? localStorage.getItem('lizardware-local-auth') : null;
        if (stored) {
            setUser(DEFAULT_LOCAL_USER);
        }
        setIsLoaded(true);
    }, []);

    const signIn = () => {
        // Simple toggle for now, or we could require password
        // For this fallback, we'll assume "clicking login" is enough if the user knows to do it
        // effectively "god mode" for local dev/preview without clerk
        localStorage.setItem('lizardware-local-auth', 'true');
        setUser(DEFAULT_LOCAL_USER);
    };

    const signOut = () => {
        localStorage.removeItem('lizardware-local-auth');
        setUser(null);
    };

    return (
        <AuthProviderContext.Provider value={{
            user,
            isLoaded,
            isSignedIn: !!user,
            signIn,
            signOut
        }}>
            {children}
        </AuthProviderContext.Provider>
    );
}
