import { Block } from '@/types/blocks';

export function generateMdxFromBlocks(blocks: Block[]): string {
    if (!blocks || blocks.length === 0) return '';

    return blocks.map(block => {
        const props = Object.entries(block.props)
            .map(([key, value]) => {
                if (value === undefined || value === null) return '';
                if (typeof value === 'string') return `${key}="${value.replace(/"/g, '&quot;')}"`;
                if (typeof value === 'boolean') return value ? key : `${key}={false}`;
                return `${key}={${JSON.stringify(value)}}`;
            })
            .filter(Boolean)
            .join(' ');

        // Convert kebab-case type to PascalCase component name
        // e.g. 'feature-grid' -> 'FeatureGrid'
        const componentName = block.type
            .split('-')
            .map(part => part.charAt(0).toUpperCase() + part.slice(1))
            .join('');

        if (block.children && block.children.length > 0) {
            const childrenMdx = generateMdxFromBlocks(block.children);
            // Indent children for readability
            const indentedChildren = childrenMdx.split('\n').map(line => `  ${line}`).join('\n');
            return `<${componentName} ${props.trim() ? `${props}` : ''}>\n${indentedChildren}\n</${componentName}>`;
        }

        return `<${componentName} ${props.trim() ? `${props}` : ''} />`;
    }).join('\n\n');
}
