export interface RouteItem {
    label: string;
    path: string;
    type: 'system' | 'page' | 'post' | 'category';
    description?: string;
}

export const SYSTEM_ROUTES: RouteItem[] = [
    { label: 'Home', path: '/', type: 'system', description: 'The main landing page' },
    { label: 'Blog', path: '/blog', type: 'system', description: 'List of all blog posts' },
    { label: 'About', path: '/about', type: 'system', description: 'About us page' },
    { label: 'Contact', path: '/contact', type: 'system', description: 'Contact page' },
    { label: 'Privacy Policy', path: '/privacy', type: 'system', description: 'Legal privacy policy' },
    { label: 'Terms of Service', path: '/terms', type: 'system', description: 'Legal terms and conditions' },
    { label: 'Support', path: '/support', type: 'system', description: 'Customer support page' },
    { label: 'Platform', path: '/platform', type: 'system', description: 'Platform details' },
    { label: 'Documentation', path: '/docs', type: 'system', description: 'System documentation' },
];

export const ADMIN_ROUTES: RouteItem[] = [
    { label: 'Admin Dashboard', path: '/admin', type: 'system' },
    { label: 'Content Hub', path: '/admin/content', type: 'system' },
    { label: 'Blog Manager', path: '/admin/content/blog', type: 'system' },
    { label: 'Pages Manager', path: '/admin/content/pages', type: 'system' },
    { label: 'Media Library', path: '/admin/content/media', type: 'system' },
    { label: 'System Core', path: '/admin/system', type: 'system' },
    { label: 'SEO Toolkit', path: '/admin/growth/seo', type: 'system' },
    { label: 'Visual Identity', path: '/admin/design/identity', type: 'system' },
    { label: 'Theme Editor', path: '/admin/design/theme', type: 'system' },
    { label: 'Design Hub', path: '/admin/design', type: 'system' },
];

/**
 * Returns a list of all static system routes
 */
export function getSystemRoutes(includeAdmin = false): RouteItem[] {
    return includeAdmin ? [...SYSTEM_ROUTES, ...ADMIN_ROUTES] : SYSTEM_ROUTES;
}

/**
 * Server-only: Fetches dynamic routes from D1/Filesystem
 * This should be used in API routes or Server Actions
 */
export async function getContentRoutes(): Promise<RouteItem[]> {
    const routes: RouteItem[] = [];

    try {
        // We import these dynamically to avoid client-side bundling issues if this file is imported in client
        const { getAllPages } = await import('./pages');
        const { getAllPosts } = await import('./blog');

        // Fetch published pages
        const pages = await getAllPages('published');
        pages.forEach(page => {
            // Skip the ones already in SYSTEM_ROUTES if they are core pages
            const isCore = ['about', 'contact', 'privacy', 'terms', 'support', 'platform'].includes(page.slug);
            if (!isCore) {
                routes.push({
                    label: page.title,
                    path: `/${page.slug}`,
                    type: 'page',
                    description: page.description
                });
            }
        });

        // Fetch published posts
        const posts = await getAllPosts({ status: 'published' });
        posts.forEach(post => {
            routes.push({
                label: post.title,
                path: `/blog/${post.slug}`,
                type: 'post',
                description: post.excerpt
            });
        });

    } catch (error) {
        console.error('Error fetching content routes:', error);
    }

    return routes;
}
