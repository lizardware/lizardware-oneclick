import { Node, mergeAttributes, InputRule } from '@tiptap/core';
import { ReactNodeViewRenderer } from '@tiptap/react';
import VariablePillView from '@/components/admin/VariablePillView';

declare module '@tiptap/core' {
    interface Commands<ReturnType> {
        variablePill: {
            /**
             * Insert a variable pill at the current cursor position
             */
            insertVariable: (variableName: string) => ReturnType;
        };
    }
}

export const VariablePill = Node.create({
    name: 'variablePill',
    group: 'inline',
    inline: true,
    atom: true, // Makes it non-editable as a single unit

    addAttributes() {
        return {
            variableName: {
                default: null,
                parseHTML: element => element.getAttribute('data-variable'),
                renderHTML: attributes => {
                    if (!attributes.variableName) return {};
                    return {
                        'data-variable': attributes.variableName
                    };
                }
            }
        };
    },

    parseHTML() {
        return [
            {
                tag: 'span[data-variable]'
            }
        ];
    },

    renderHTML({ node, HTMLAttributes }) {
        return [
            'span',
            mergeAttributes(
                {
                    class: 'variable-pill',
                    'data-variable': node.attrs.variableName
                },
                HTMLAttributes
            ),
            `{{${node.attrs.variableName}}}`
        ];
    },

    addNodeView() {
        return ReactNodeViewRenderer(VariablePillView as any);
    },

    addCommands() {
        return {
            insertVariable:
                (variableName: string) =>
                    ({ commands }) => {
                        return commands.insertContent({
                            type: this.name,
                            attrs: { variableName }
                        });
                    }
        };
    },

    addInputRules() {
        return [
            new InputRule({
                find: /\{\{([a-zA-Z0-9_]+)\}\}/g,
                handler: ({ state, range, match }) => {
                    const variableName = match[1];
                    const { tr } = state;
                    const start = range.from;
                    const end = range.to;

                    tr.replaceWith(start, end, this.type.create({
                        variableName
                    }));
                }
            })
        ];
    }
});
