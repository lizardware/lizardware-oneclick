'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { AdminHeader } from '@/components/admin/AdminHeader';
import { ArrowLeft } from 'lucide-react';

export default function DiagnosticsPage() {
    const [kvStatus, setKvStatus] = useState<'loading' | 'connected' | 'error'>('loading');
    const [d1Status, setD1Status] = useState<'loading' | 'connected' | 'error'>('loading');
    const [kvError, setKvError] = useState<string | null>(null);
    const [d1Error, setD1Error] = useState<string | null>(null);
    const [wranglerConfig, setWranglerConfig] = useState<any>(null);

    useEffect(() => {
        checkConnections();
        loadWranglerConfig();
    }, []);

    async function checkConnections() {
        // Check KV
        try {
            const kvRes = await fetch('/api/admin/check-kv');
            const kvData = await kvRes.json() as { exists: boolean };
            setKvStatus(kvData.exists ? 'connected' : 'error');
            if (!kvData.exists) setKvError('KV binding not found');
        } catch (e: any) {
            setKvStatus('error');
            setKvError(e.message);
        }

        // Check D1
        try {
            const d1Res = await fetch('/api/admin/check-d1');
            const d1Data = await d1Res.json() as { exists: boolean };
            setD1Status(d1Data.exists ? 'connected' : 'error');
            if (!d1Data.exists) setD1Error('D1 binding not found');
        } catch (e: any) {
            setD1Status('error');
            setD1Error(e.message);
        }
    }

    async function loadWranglerConfig() {
        try {
            const res = await fetch('/api/admin/diagnostics/wrangler-config');
            if (res.ok) {
                const data = await res.json();
                setWranglerConfig(data);
            }
        } catch (e) {
            console.error('Could not load wrangler config:', e);
        }
    }

    const StatusIndicator = ({ status }: { status: 'loading' | 'connected' | 'error' }) => {
        if (status === 'loading') {
            return (
                <div className="flex items-center gap-2 text-zinc-500">
                    <div className="w-2 h-2 rounded-full bg-zinc-400 animate-pulse" />
                    <span>Checking...</span>
                </div>
            );
        }
        if (status === 'connected') {
            return (
                <div className="flex items-center gap-2 text-green-600 dark:text-green-400">
                    <div className="w-2 h-2 rounded-full bg-green-500 shadow-lg shadow-green-500/50" />
                    <span className="font-bold">Connected</span>
                </div>
            );
        }
        return (
            <div className="flex items-center gap-2 text-red-600 dark:text-red-400">
                <div className="w-2 h-2 rounded-full bg-red-500 shadow-lg shadow-red-500/50" />
                <span className="font-bold">Error</span>
            </div>
        );
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-zinc-50 via-white to-blue-50 dark:from-zinc-950 dark:via-black dark:to-blue-950 p-8">
            <div className="max-w-4xl mx-auto">
                {/* Header */}
                <AdminHeader
                    title={<>System <span className="text-zinc-500">Diagnostics</span></>}
                    description="Cloudflare bindings and resource status."
                    breadcrumbs={[
                        { label: 'Admin', href: '/admin' },
                        { label: 'Diagnostics' }
                    ]}
                    badge={
                        <div className="px-3 py-1.5 bg-zinc-100 dark:bg-zinc-800 rounded-lg text-[10px] font-bold uppercase tracking-widest text-zinc-500">System</div>
                    }
                    actions={
                        <Link
                            href="/admin"
                            className="px-3 py-1.5 bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 rounded-lg text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
                        >
                            <ArrowLeft size={12} /> Back
                        </Link>
                    }
                />

                {/* Connection Status */}
                <div className="bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 p-6 mb-6 shadow-xl">
                    <h2 className="text-xl font-bold mb-6 text-zinc-900 dark:text-white">Connection Status</h2>

                    <div className="space-y-4">
                        {/* KV */}
                        <div className="flex items-center justify-between p-4 rounded-xl bg-zinc-50 dark:bg-zinc-800/50">
                            <div>
                                <h3 className="font-bold text-zinc-900 dark:text-white">KV Namespace</h3>
                                <p className="text-sm text-zinc-500 dark:text-zinc-400">Key-Value storage for configuration</p>
                                {kvError && (
                                    <p className="text-xs text-red-600 dark:text-red-400 mt-1">{kvError}</p>
                                )}
                            </div>
                            <StatusIndicator status={kvStatus} />
                        </div>

                        {/* D1 */}
                        <div className="flex items-center justify-between p-4 rounded-xl bg-zinc-50 dark:bg-zinc-800/50">
                            <div>
                                <h3 className="font-bold text-zinc-900 dark:text-white">D1 Database</h3>
                                <p className="text-sm text-zinc-500 dark:text-zinc-400">SQL database for content</p>
                                {d1Error && (
                                    <p className="text-xs text-red-600 dark:text-red-400 mt-1">{d1Error}</p>
                                )}
                            </div>
                            <StatusIndicator status={d1Status} />
                        </div>
                    </div>
                </div>

                {/* Wrangler Config */}
                {wranglerConfig && (
                    <div className="bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 p-6 shadow-xl">
                        <h2 className="text-xl font-bold mb-4 text-zinc-900 dark:text-white">Current Configuration</h2>

                        <div className="space-y-3">
                            {wranglerConfig.kv && (
                                <div>
                                    <label className="text-xs font-bold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">KV Namespace ID</label>
                                    <code className="block mt-1 p-3 bg-zinc-100 dark:bg-zinc-800 rounded-lg text-sm font-mono text-zinc-900 dark:text-white">
                                        {wranglerConfig.kv.id}
                                    </code>
                                </div>
                            )}

                            {wranglerConfig.d1 && (
                                <div>
                                    <label className="text-xs font-bold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">D1 Database ID</label>
                                    <code className="block mt-1 p-3 bg-zinc-100 dark:bg-zinc-800 rounded-lg text-sm font-mono text-zinc-900 dark:text-white">
                                        {wranglerConfig.d1.database_id}
                                    </code>
                                </div>
                            )}

                            {wranglerConfig.r2 && (
                                <div>
                                    <label className="text-xs font-bold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">R2 Bucket</label>
                                    <code className="block mt-1 p-3 bg-zinc-100 dark:bg-zinc-800 rounded-lg text-sm font-mono text-zinc-900 dark:text-white">
                                        {wranglerConfig.r2.bucket_name}
                                    </code>
                                </div>
                            )}
                        </div>
                    </div>
                )}

                {/* Help */}
                {(kvStatus === 'error' || d1Status === 'error') && (
                    <div className="mt-6 p-6 bg-amber-500/10 dark:bg-amber-950/20 border border-amber-500/20 rounded-2xl">
                        <h3 className="font-bold text-amber-900 dark:text-amber-400 mb-2">Troubleshooting</h3>
                        <p className="text-sm text-amber-800 dark:text-amber-300 mb-3">
                            If resources are not connected, ensure they were provisioned correctly during build.
                        </p>
                        <div className="space-y-2 text-sm">
                            <p className="text-amber-900 dark:text-amber-200">
                                <strong>For local builds:</strong> Set environment variables in <code className="px-1 py-0.5 bg-amber-900/10 rounded">.env.local</code>
                            </p>
                            <p className="text-amber-900 dark:text-amber-200">
                                <strong>For Cloudflare Pages:</strong> Configure in Settings → Environment Variables
                            </p>
                        </div>
                        <Link
                            href="/docs/troubleshooting"
                            className="inline-flex items-center gap-2 mt-4 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-sm font-bold transition-colors"
                        >
                            View Troubleshooting Guide
                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                            </svg>
                        </Link>
                    </div>
                )}
            </div>
        </div>
    );
}
