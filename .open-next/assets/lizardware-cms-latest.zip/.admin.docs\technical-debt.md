# Technical Debt & Warnings Log

## 🔴 Critical Issues

### 1. D1 Binding Access Causing Worker Timeout
**Status:** 🔴 Critical - BLOCKING  
**Severity:** Production broken  
**Added:** December 17, 2025

**Issue:**
Worker hangs/times out when trying to access D1 via `getCloudflareContext()` in Server Components.

**Current Approach:**
```typescript
const { getCloudflareContext } = await import('@opennextjs/cloudflare');
const context = await getCloudflareContext();
```

**Problem:**
- May not work in Server Components (only in API routes?)
- Causing infinite spin on preview/production
- All bindings are properly configured (verified in build logs)

**Possible Solutions:**
1. Move D1 queries to API routes only
2. Use different binding access method
3. Check if context is available before calling
4. Use Edge runtime hints

**Priority:** 🔴 FIX IMMEDIATELY - Site is down

---

## 🟡 Medium Priority Issues

### 2. Deprecated Dependency: node-domexception
**Status:** 🟡 Low Priority  
**Severity:** Warning (non-blocking)  
**Added:** December 17, 2025

**Issue:**
```
npm warn deprecated node-domexception@1.0.0: Use your platform's native DOMException instead
```

**Impact:**
- No immediate functionality impact
- May cause issues in future Node.js versions
- Clutters build output

**Solution:**
- Audit dependency tree to find which package requires `node-domexception`
- Update parent package or replace with native DOMException
- Run `npm ls node-domexception` to find source

**Priority:** Address after critical bugs (after Phase 4 bug fixes)

---

## Resolved Issues
(None yet)

---

## Future Maintenance

### Regular Tasks
- [ ] Run `npm audit` monthly
- [ ] Review deprecation warnings quarterly
- [ ] Update dependencies (minor versions) monthly
- [ ] Update dependencies (major versions) with testing

### Known Technical Debt
- Theme storage migration to Git-backed (planned Phase 4)
- D1 database optimization (Phase 5)
- Multi-user auth system (Phase 5)

---

**Last Updated:** December 17, 2025
