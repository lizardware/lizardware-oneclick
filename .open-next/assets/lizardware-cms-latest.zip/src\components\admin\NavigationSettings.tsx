'use client';

import { useState, useEffect } from 'react';
import { Compass, ChevronRight, HelpCircle } from 'lucide-react';

interface NavigationSettingsProps {
    showInNav: boolean;
    navLabel: string;
    navParent: string;
    navOrder: number;
    title: string;
    onChange: (field: string, value: any) => void;
}

export default function NavigationSettings({
    showInNav,
    navLabel,
    navParent,
    navOrder,
    title,
    onChange
}: NavigationSettingsProps) {
    const [isExpanded, setIsExpanded] = useState(false);
    const [parents, setParents] = useState<{ id: string, label: string }[]>([]);
    const [loadingParents, setLoadingParents] = useState(true);

    useEffect(() => {
        // Fetch current nav to populate parent dropdown
        setLoadingParents(true);
        fetch('/api/admin/nav')
            .then(res => res.json() as Promise<{ navigation: any[] }>)
            .then(data => {
                if (data.navigation) {
                    const flatItems = flattenNav(data.navigation);
                    setParents(flatItems);
                }
            })
            .catch(err => console.error('Failed to fetch parents', err))
            .finally(() => setLoadingParents(false));
    }, []);

    const flattenNav = (items: any[], depth = 0): { id: string, label: string }[] => {
        let flat: any[] = [];
        items.forEach((item: any) => {
            // Only suggest items that can actually have children (usually those with id or specific types)
            // But for now, let's allow anything that has a label
            if (item.label) {
                flat.push({
                    id: item.id || item.href || item.label,
                    label: `${'—'.repeat(depth)} ${item.label}`
                });
            }
            if (item.children && Array.isArray(item.children)) {
                flat = [...flat, ...flattenNav(item.children, depth + 1)];
            }
        });
        return flat;
    };

    return (
        <div className="pt-4 border-t border-gray-200 dark:border-zinc-800 space-y-4">
            <div
                className="flex items-center justify-between cursor-pointer group"
                onClick={() => setIsExpanded(!isExpanded)}
            >
                <h3 className="text-sm font-semibold flex items-center gap-2 group-hover:text-primary transition-colors">
                    <Compass size={16} className="text-primary" />
                    Navigation Sync
                </h3>
                <ChevronRight size={16} className={`text-gray-400 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
            </div>

            {isExpanded && (
                <div className="space-y-4 animate-in slide-in-from-top-2 duration-300">
                    <label className="flex items-center gap-2 cursor-pointer group">
                        <input
                            type="checkbox"
                            checked={showInNav}
                            onChange={(e) => onChange('show_in_nav', e.target.checked)}
                            className="w-4 h-4 rounded border-gray-300 text-primary focus:ring-primary"
                        />
                        <span className="text-sm font-medium group-hover:text-primary transition-colors">Show in Navigation</span>
                    </label>

                    {showInNav && (
                        <div className="ml-2 space-y-4 border-l-2 border-primary/10 pl-4 animate-in fade-in">
                            <div>
                                <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1.5 flex items-center gap-1">
                                    Navigation Label
                                    <HelpCircle size={10} className="opacity-50" />
                                </label>
                                <input
                                    type="text"
                                    value={navLabel || ''}
                                    onChange={(e) => onChange('nav_label', e.target.value)}
                                    placeholder={title}
                                    className="w-full px-3 py-2 border rounded-lg dark:bg-zinc-800 dark:border-zinc-700 focus:ring-2 focus:ring-primary outline-none text-sm"
                                />
                                <p className="text-[9px] text-gray-500 mt-1">Leave empty to use the document title.</p>
                            </div>

                            <div>
                                <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1.5 flex items-center gap-1">
                                    Parent Menu Item
                                    {loadingParents && <span className="animate-spin text-[8px]">⌛</span>}
                                </label>
                                <select
                                    value={navParent || ''}
                                    onChange={(e) => onChange('nav_parent', e.target.value)}
                                    className="w-full px-3 py-2 border rounded-lg dark:bg-zinc-800 dark:border-zinc-700 focus:ring-2 focus:ring-primary outline-none text-sm"
                                >
                                    <option value="">Root (Main Menu)</option>
                                    {parents.map(p => (
                                        <option key={p.id} value={p.id}>{p.label}</option>
                                    ))}
                                </select>
                            </div>

                            <div>
                                <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1.5">Display Order</label>
                                <input
                                    type="number"
                                    value={navOrder || 0}
                                    onChange={(e) => onChange('nav_order', parseInt(e.target.value))}
                                    className="w-full px-3 py-2 border rounded-lg dark:bg-zinc-800 dark:border-zinc-700 focus:ring-2 focus:ring-primary outline-none text-sm"
                                />
                            </div>

                            <div className="pt-2">
                                <p className="text-[10px] text-gray-500 italic bg-gray-50 dark:bg-white/5 p-2 rounded-lg border border-gray-100 dark:border-white/5">
                                    <strong>How this works:</strong> Changes here won't instantly modify your navigation, but they will suggest this item to the <strong>Navigation Manager</strong> for intelligent synchronization.
                                </p>
                            </div>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}
