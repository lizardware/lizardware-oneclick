'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { FileText, Image, BookOpen, FolderOpen, Users, ArrowLeft, Plus } from 'lucide-react';
import { HubSectionCard } from '@/components/admin/HubSectionCard';
import { Breadcrumbs } from '@/components/admin/Breadcrumbs';
import { AdminHeader } from '@/components/admin/AdminHeader';
import { HUB_PAGE_STYLES, type GradientColor } from '@/lib/admin-hub-styles';
import { useAdminActions } from '@/hooks/useAdminActions';

interface ContentStats {
    totalPages: number;
    totalPosts: number;
    draftPosts: number;
    publishedPosts: number;
    totalCategories: number;
    totalAuthors: number;
    mediaFiles?: number;
}

export default function ContentHubPage() {
    useAdminActions([
        {
            id: 'new-post',
            label: 'New Post',
            href: '/admin/content/blog?action=new',
            variant: 'primary',
            showOnMobile: true,
            icon: <Plus className="w-4 h-4" />
        },
        {
            id: 'new-page',
            label: 'New Page',
            href: '/admin/content/pages?action=new',
            variant: 'secondary',
            icon: <FileText className="w-4 h-4" />
        },
        {
            id: 'upload',
            label: 'Upload Media',
            href: '/admin/content/media',
            variant: 'secondary',
            icon: <Image className="w-4 h-4" />
        }
    ]);

    const [stats, setStats] = useState<ContentStats>({
        totalPages: 0,
        totalPosts: 0,
        draftPosts: 0,
        publishedPosts: 0,
        totalCategories: 0,
        totalAuthors: 0,
        mediaFiles: 0
    });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchStats = async () => {
            try {
                const [pagesRes, postsRes, categoriesRes, authorsRes] = await Promise.all([
                    fetch('/api/admin/pages').then(r => r.json()),
                    fetch('/api/admin/blog').then(r => r.json()),
                    fetch('/api/admin/blog/categories').then(r => r.json()) as Promise<{ categories: any[] }>,
                    fetch('/api/admin/blog/authors').then(r => r.json()) as Promise<{ authors: any[] }>
                ]);

                setStats({
                    totalPages: Array.isArray(pagesRes) ? pagesRes.length : 0,
                    totalPosts: Array.isArray(postsRes) ? postsRes.length : 0,
                    draftPosts: Array.isArray(postsRes) ? postsRes.filter((p: any) => p.status === 'draft').length : 0,
                    publishedPosts: Array.isArray(postsRes) ? postsRes.filter((p: any) => p.status === 'published').length : 0,
                    totalCategories: categoriesRes.categories?.length || 0,
                    totalAuthors: authorsRes.authors?.length || 0,
                    mediaFiles: 0 // Placeholder
                });
            } catch (error) {
                console.error('Failed to fetch content stats:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchStats();
    }, []);

    const sections = [
        {
            title: 'Blog Dashboard',
            description: 'Manage blog posts, create new articles, and track engagement',
            href: '/admin/content/blog',
            icon: <BookOpen className="w-6 h-6" />,
            stats: `${stats.totalPosts} Posts (${stats.publishedPosts} Published, ${stats.draftPosts} Drafts)`,
            color: 'blue' as GradientColor
        },
        {
            title: 'Pages Playground',
            description: 'Create and edit custom pages with the visual editor',
            href: '/admin/content/pages',
            icon: <FileText className="w-6 h-6" />,
            stats: `${stats.totalPages} Custom Pages`,
            color: 'purple' as GradientColor
        },
        {
            title: 'Media Library',
            description: 'Upload, organize, and manage images and media assets',
            href: '/admin/content/media',
            icon: <Image className="w-6 h-6" />,
            stats: stats.mediaFiles ? `${stats.mediaFiles} Files` : 'Coming Soon',
            color: 'green' as GradientColor
        },
        {
            title: 'Categories',
            description: 'Organize blog posts with tags and categories',
            href: '/admin/content/blog/categories',
            icon: <FolderOpen className="w-6 h-6" />,
            stats: `${stats.totalCategories} Categories`,
            color: 'orange' as GradientColor
        },
        {
            title: 'Authors',
            description: 'Manage blog authors and contributors',
            href: '/admin/content/blog/authors',
            icon: <Users className="w-6 h-6" />,
            stats: `${stats.totalAuthors} Authors`,
            color: 'pink' as GradientColor
        }
    ];

    return (
        <div className={HUB_PAGE_STYLES.container}>
            <div className={`${HUB_PAGE_STYLES.maxWidth} ${HUB_PAGE_STYLES.topPadding} space-y-8`}>
                <AdminHeader
                    title={<>Content <span className="text-blue-500">Hub</span> 📦</>}
                    description="Central command for all your content library and media assets."
                    breadcrumbs={[
                        { label: 'Admin', href: '/admin' },
                        { label: 'Content' }
                    ]}
                    badge={
                        <div className="px-3 py-1.5 bg-blue-500/10 border border-blue-500/20 rounded-lg text-[10px] font-bold uppercase tracking-widest text-blue-600 dark:text-blue-400 flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse"></span>
                            Engine Active
                        </div>
                    }
                    actions={
                        <Link
                            href="/admin"
                            className="px-3 py-1.5 bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 rounded-lg text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
                        >
                            <ArrowLeft size={12} /> Back
                        </Link>
                    }
                />

                {/* Quick Stats */}
                {!loading && (
                    <div className={HUB_PAGE_STYLES.stats.grid}>
                        <div className="p-4 bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800">
                            <div className="text-2xl font-black text-zinc-900 dark:text-white">{stats.totalPosts}</div>
                            <div className="text-xs text-zinc-500 dark:text-zinc-400 uppercase font-bold tracking-wider">Blog Posts</div>
                        </div>
                        <div className="p-4 bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800">
                            <div className="text-2xl font-black text-zinc-900 dark:text-white">{stats.totalPages}</div>
                            <div className="text-xs text-zinc-500 dark:text-zinc-400 uppercase font-bold tracking-wider">Custom Pages</div>
                        </div>
                        <div className="p-4 bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800">
                            <div className="text-2xl font-black text-zinc-900 dark:text-white">{stats.totalCategories}</div>
                            <div className="text-xs text-zinc-500 dark:text-zinc-400 uppercase font-bold tracking-wider">Categories</div>
                        </div>
                        <div className="p-4 bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800">
                            <div className="text-2xl font-black text-zinc-900 dark:text-white">{stats.totalAuthors}</div>
                            <div className="text-xs text-zinc-500 dark:text-zinc-400 uppercase font-bold tracking-wider">Authors</div>
                        </div>
                    </div>
                )}

                {/* Section Cards */}
                <div className={HUB_PAGE_STYLES.sectionCards.grid}>
                    {sections.map((section) => (
                        <HubSectionCard
                            key={section.href}
                            title={section.title}
                            description={section.description}
                            icon={section.icon}
                            stats={section.stats}
                            gradient={section.color}
                            href={section.href}
                            status={section.title === 'Media Library' && !stats.mediaFiles ? 'coming-soon' : 'active'}
                        />
                    ))}
                </div>

                {/* Quick Actions */}
                <div className="p-8 bg-zinc-900 rounded-[2rem] border border-zinc-800">
                    <h3 className="text-sm font-black uppercase tracking-widest text-zinc-400 mb-6">Quick Actions</h3>
                    <div className="flex flex-wrap gap-3">
                        <Link href="/admin/content/blog?action=new" className="px-5 py-3 bg-blue-600 text-white rounded-xl text-xs font-bold uppercase tracking-wider hover:bg-blue-500 shadow-lg shadow-blue-900/20 hover:shadow-blue-900/40 hover:-translate-y-0.5 transition-all">
                            + New Post
                        </Link>
                        <Link href="/admin/content/pages?action=new" className="px-5 py-3 bg-purple-600 text-white rounded-xl text-xs font-bold uppercase tracking-wider hover:bg-purple-500 shadow-lg shadow-purple-900/20 hover:shadow-purple-900/40 hover:-translate-y-0.5 transition-all">
                            + New Page
                        </Link>
                        <Link href="/admin/content/media" className="px-5 py-3 bg-emerald-600 text-white rounded-xl text-xs font-bold uppercase tracking-wider hover:bg-emerald-500 shadow-lg shadow-emerald-900/20 hover:shadow-emerald-900/40 hover:-translate-y-0.5 transition-all">
                            Upload Media
                        </Link>
                    </div>
                </div>
            </div>
        </div>
    );
}
