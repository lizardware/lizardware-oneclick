import { Page } from "@/types/page";
import "./editor/editor-styles.css"; // Reuse editor styles for rendering

import { getDynamicSiteConfig } from "@/lib/site-server";
import { StandardPageLayout, MinimalPageLayout, SidebarRightLayout, FullWidthLayout } from "./layouts/LayoutLibrary";
import BlockRenderer from "./BlockRenderer";
import LivePreviewWrapper from "./LivePreviewWrapper";

interface PageRendererProps {
    page: Page;
    preview?: boolean;
}

export default async function PageRenderer({ page, preview = false }: PageRendererProps) {
    const siteConfig = await getDynamicSiteConfig();
    const siteName = siteConfig.name || "Lizardware CMS";

    // If in preview mode, hand off to client-side wrapper for hot-reloading
    if (preview) {
        return <LivePreviewWrapper initialPage={page} siteConfig={siteConfig} />;
    }

    // Helper to replace placeholders (for production SSR)
    const processText = (text: string = "") => {
        return text.replace(/{{siteName}}/g, siteName);
    };

    const displayTitle = processText(page.title);
    const displayDescription = processText(page.description || "");
    const displayContent = processText(page.content);
    const displayDate = page.updated_at ? new Date(page.updated_at).toLocaleDateString() : 'Recently';

    // Layout resolution
    const layoutId = page.layout_id || 'standard';

    if (layoutId === 'minimal') {
        return (
            <MinimalPageLayout
                title={displayTitle}
                description={displayDescription}
                content={displayContent}
                slug={page.slug}
            />
        );
    }

    if (layoutId === 'sidebar_right') {
        return (
            <SidebarRightLayout
                title={displayTitle}
                description={displayDescription}
                content={displayContent}
                updatedAt={displayDate}
                slug={page.slug}
            />
        );
    }

    if (layoutId === 'full_width') {
        return (
            <FullWidthLayout
                title={displayTitle}
                description={displayDescription}
                content={displayContent}
                updatedAt={displayDate}
                slug={page.slug}
            />
        );
    }

    if (layoutId === 'blocks') {
        return <BlockRenderer content={page.metadata_json || page.content} />;
    }

    // Default to Standard Layout
    return (
        <StandardPageLayout
            title={displayTitle}
            description={displayDescription}
            content={displayContent}
            updatedAt={displayDate}
            slug={page.slug}
        />
    );
}
