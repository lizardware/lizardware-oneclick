import { NextRequest, NextResponse } from 'next/server';
import { getCloudflareContext } from '@opennextjs/cloudflare';

export const dynamic = 'force-dynamic';

interface SetupStatus {
    locked: boolean;
}

// GET: Check if setup is locked
export async function GET() {
    try {
        const { env } = await getCloudflareContext({ async: true });

        // @ts-expect-error - Cloudflare env types
        if (!env?.DB) {
            // In development, we might not have D1
            if (process.env.NODE_ENV === 'development') {
                return NextResponse.json({ locked: false });
            }
            return NextResponse.json({ locked: false, error: 'No database' }, { status: 500 });
        }

        // @ts-expect-error - Cloudflare env types
        const result = await env.DB.prepare(
            'SELECT setup_completed FROM site_config LIMIT 1'
        ).first<{ setup_completed: number }>();

        return NextResponse.json({
            locked: result?.setup_completed === 1
        });
    } catch (error) {
        console.error('Failed to check setup status:', error);
        // Dev mode: fail gracefully
        if (process.env.NODE_ENV === 'development') {
            return NextResponse.json({ locked: false });
        }
        return NextResponse.json({ locked: false, error: 'Query failed' }, { status: 500 });
    }
}

// POST: Unlock setup (reset to allow wizard re-run)
export async function POST(request: NextRequest) {
    try {
        const { unlock } = await request.json() as { unlock: boolean };
        const { env } = await getCloudflareContext({ async: true });

        // @ts-expect-error - Cloudflare env types
        if (!env?.DB) {
            // In development, we might not have D1 - return success
            if (process.env.NODE_ENV === 'development') {
                return NextResponse.json({ success: true, locked: !unlock, message: 'Dev mode: no-op' });
            }
            return NextResponse.json({ error: 'No database connection' }, { status: 500 });
        }

        // Update setup_completed to 0 (unlocked) or 1 (locked)
        // @ts-expect-error - Cloudflare env types
        await env.DB.prepare(
            'UPDATE site_config SET setup_completed = ? WHERE id = 1'
        ).bind(unlock ? 0 : 1).run();

        return NextResponse.json({
            success: true,
            locked: !unlock,
            message: unlock ? 'Setup wizard unlocked' : 'Setup wizard locked'
        });
    } catch (error) {
        console.error('Failed to update setup lock:', error);
        // Dev mode: fail gracefully
        if (process.env.NODE_ENV === 'development') {
            return NextResponse.json({ success: true, locked: false, message: 'Dev mode: error ignored' });
        }
        return NextResponse.json({ error: 'Failed to update lock status' }, { status: 500 });
    }
}
