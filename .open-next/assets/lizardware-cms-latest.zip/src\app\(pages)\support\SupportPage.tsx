export default function SupportPage() {
    return (
        <div className="max-w-[1024px] mx-auto px-4 py-section space-y-8">
            <h1 className="text-title font-bold text-header-text mb-6">Support</h1>

            <div className="space-y-6 text-body text-page-text leading-relaxed">
                <p>Need help? Our team is here to assist you.</p>

                <p>You can contact support via email at <a href="mailto:contact@example.com" className="text-primary hover:text-primary/80 transition-colors underline">contact@example.com</a>.</p>

                <p>Support is available during standard business hours. We aim to respond to all inquiries within 24 hours.</p>
            </div>
        </div>
    );
}
