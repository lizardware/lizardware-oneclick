import type { OpenNextConfig } from '@opennextjs/cloudflare';

const config: OpenNextConfig = {
    buildCommand: "npm run next:build",
    default: {
        override: {
            wrapper: "cloudflare-node",
            converter: "edge",
            proxyExternalRequest: "fetch",
            incrementalCache: "dummy",
            tagCache: "dummy",
            queue: "dummy",
        },
    },
    edgeExternals: ["node:crypto"],
    middleware: {
        external: true,
        override: {
            wrapper: "cloudflare-edge",
            converter: "edge",
            proxyExternalRequest: "fetch",
            incrementalCache: "dummy",
            tagCache: "dummy",
            queue: "dummy",
        },
    },
    dangerous: {
        disableIncrementalCache: true,
        disableTagCache: true,
    },
};

export default config;
