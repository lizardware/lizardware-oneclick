import { NextResponse } from 'next/server';
import { getD1Database } from '@/lib/cloudflare';

export async function GET() {
    try {
        // In local development, we use filesystem fallbacks, so we don't strictly NEED bindings
        if (process.env.NODE_ENV === 'development') {
            return NextResponse.json({ exists: true });
        }

        const db = await getD1Database();
        const exists = !!db;

        return NextResponse.json({ exists });
    } catch (error) {
        console.error('D1 check error:', error);
        return NextResponse.json({ exists: false });
    }
}
