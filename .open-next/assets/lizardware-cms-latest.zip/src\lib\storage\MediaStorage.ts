export interface MediaAsset {
    id: string;
    filename: string;
    url: string;
    altText?: string;
    caption?: string;
    size: number;
    mimeType: string;
    createdAt: string;
}

export interface MediaStorage {
    // Upload a file and return its URL
    upload(file: File, metadata?: { altText?: string; caption?: string }): Promise<string>;

    // Delete a file by URL
    delete(url: string): Promise<void>;

    // List all media assets
    list(): Promise<MediaAsset[]>;

    // Get a single asset by ID
    get(id: string): Promise<MediaAsset | null>;

    // Provider name for display
    getName(): string;
}
