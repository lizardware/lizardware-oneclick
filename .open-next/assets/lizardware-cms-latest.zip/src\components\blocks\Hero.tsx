import Link from 'next/link';
import { ArrowRight } from 'lucide-react';

interface HeroProps {
    title: string;
    subtitle?: string;
    ctaText?: string;
    ctaLink?: string;
    alignment?: 'left' | 'center';
    paddingY?: string;
    maxWidth?: string;
}

export default function Hero({
    title,
    subtitle,
    ctaText = 'Get Started',
    ctaLink = '/contact',
    alignment = 'center',
    paddingY = '5rem',
    maxWidth = '64rem'
}: HeroProps) {
    return (
        <div className={`space-y-6 ${alignment === 'center' ? 'text-center' : 'text-left'}`}>
            <h1 className="text-4xl md:text-6xl font-black tracking-tight text-page-title">
                {title}
            </h1>
            {subtitle && (
                <div
                    className="text-xl text-page-text max-w-2xl mx-auto leading-relaxed"
                    dangerouslySetInnerHTML={{ __html: subtitle }}
                />
            )}
            {ctaText && (
                <div className={`flex ${alignment === 'center' ? 'justify-center' : 'justify-start'} pt-4`}>
                    <Link
                        href={ctaLink}
                        className="inline-flex items-center gap-2 px-8 py-4 bg-primary text-white rounded-full font-bold hover:opacity-90 transition-opacity shadow-lg shadow-primary/20"
                    >
                        {ctaText} <ArrowRight size={20} />
                    </Link>
                </div>
            )}
        </div>
    );
}
