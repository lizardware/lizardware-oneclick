import { notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { getAllPosts, Post } from "@/lib/blog";
import authorsData from "@/data/authors.json";
import BlogCard from "@/components/blog/BlogCard";
import { getD1Database } from "@/lib/cloudflare";
import { getAuthorById } from "@/lib/blog-authors";
import { getAllMedia } from "@/lib/blog-media";

interface AuthorPageProps {
    params: Promise<{
        authorId: string;
    }>;
    searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}

export async function generateMetadata({ params }: AuthorPageProps) {
    const { authorId } = await params;
    const author = authorsData.authors.find((a) => a.id === authorId);
    if (!author) return { title: "Author Not Found" };

    return {
        title: `${author.name} | Lizardware Blog`,
        description: author.bio,
    };
}

export default async function AuthorDetailPage({ params, searchParams }: AuthorPageProps) {
    const [{ authorId }] = await Promise.all([params, searchParams.then(() => void 0)]);

    let author: any = authorsData.authors.find((a) => a.id === authorId);

    const db = await getD1Database();
    const media: Record<string, string> = {};
    if (db) {
        const d1Author = await getAuthorById(db, authorId);
        if (d1Author) author = d1Author;

        const allMedia = await getAllMedia(db);
        allMedia.forEach(m => media[m.id] = m.url);
    }

    if (!author) notFound();

    const allPosts = await getAllPosts();
    const authorPosts = allPosts.filter((post: Post | Omit<Post, 'content'>) => post.author_id === authorId);

    return (
        <div className="max-w-[1024px] mx-auto px-4 py-12">
            {/* Author Header */}
            <div className="bg-info-box-bg border border-borders rounded-2xl p-8 mb-12 flex flex-col md:flex-row gap-8 items-center md:items-start">
                {author.avatar && (
                    <div className="relative w-32 h-32 rounded-full overflow-hidden border-2 border-primary/20 shadow-lg flex-shrink-0">
                        <Image
                            src={author.avatar}
                            alt={author.name}
                            width={128}
                            height={128}
                            className="w-full h-full object-cover"
                        />
                    </div>
                )}
                <div className="text-center md:text-left">
                    <h1 className="text-title font-bold text-page-title mb-3">{author.name}</h1>
                    <p className="text-page-text text-lg leading-relaxed mb-6 max-w-2xl">
                        {author.bio}
                    </p>
                    <div className="flex justify-center md:justify-start gap-4">
                        {author.social?.github && (
                            <a href={author.social.github} target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-primary transition-colors">
                                GitHub
                            </a>
                        )}
                        {author.social?.twitter && (
                            <a href={author.social.twitter} target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-primary transition-colors">
                                Twitter
                            </a>
                        )}
                    </div>
                </div>
            </div>

            {/* Posts by Author */}
            <div className="space-y-8">
                <h2 className="text-2xl font-bold text-page-title border-b border-borders pb-4">
                    Articles by {author.name}
                </h2>

                {authorPosts.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
                        {authorPosts.map((post) => (
                            <BlogCard
                                key={post.slug}
                                post={post}
                                imageUrl={post.featured_image_id ? media[post.featured_image_id] : undefined}
                            />
                        ))}
                    </div>
                ) : (
                    <p className="text-center py-12 text-slate-400 italic">
                        This author hasn&apos;t published any articles yet.
                    </p>
                )}
            </div>
        </div>
    );
}
