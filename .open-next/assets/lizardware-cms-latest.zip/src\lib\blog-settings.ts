import { getD1Database } from './cloudflare';

export interface BlogSettings {
    layout: 'grid' | 'list';
    excerpt_length: number;
    show_featured_post: boolean;
    posts_per_page: number;
}

export async function getBlogSettings(db: D1Database): Promise<BlogSettings> {
    const stmt = db.prepare('SELECT * FROM blog_settings');
    const result = await stmt.all<{ key: string; value: string }>();

    // Default settings
    const settings: BlogSettings = {
        layout: 'grid',
        excerpt_length: 200,
        show_featured_post: true,
        posts_per_page: 12
    };

    result.results.forEach(row => {
        if (row.key === 'layout') settings.layout = row.value as 'grid' | 'list';
        if (row.key === 'excerpt_length') settings.excerpt_length = parseInt(row.value);
        if (row.key === 'show_featured_post') settings.show_featured_post = row.value === '1';
        if (row.key === 'posts_per_page') settings.posts_per_page = parseInt(row.value);
    });

    return settings;
}

export async function updateBlogSetting(db: D1Database, key: string, value: string): Promise<void> {
    const stmt = db.prepare(`
        INSERT INTO blog_settings (key, value, updated_at)
        VALUES (?, ?, datetime('now'))
        ON CONFLICT(key) DO UPDATE SET
            value = excluded.value,
            updated_at = datetime('now')
    `).bind(key, value);
    await stmt.run();
}
