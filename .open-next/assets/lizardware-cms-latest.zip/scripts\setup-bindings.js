#!/usr/bin/env node

/**
 * Interactive CLI to set up local development bindings
 * 
 * This script prompts for KV/D1 IDs and saves them to .env.local
 * which is used by scripts/init-config.js to generate wrangler.jsonc.
 * 
 * Usage: npm run setup:bindings
 */

const fs = require('fs');
const path = require('path');
const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function question(query) {
    return new Promise(resolve => rl.question(query, resolve));
}

async function main() {
    console.log('\n🔧 Local Development Setup\n');
    console.log('This script configures your local environment bindings.');
    console.log('It creates/updates .env.local with your Cloudflare resource IDs.\n');
    console.log('You need to provide your KV and D1 resource IDs from Cloudflare Dashboard:\n');
    console.log('  📦 KV: Dashboard → Workers & Pages → KV → Click namespace → Copy ID');
    console.log('  💾 D1: Dashboard → Workers & Pages → D1 → Click database → Copy ID\n');

    const envPath = path.join(process.cwd(), '.env.local');
    let envContent = '';

    // Read existing .env.local if it exists
    if (fs.existsSync(envPath)) {
        envContent = fs.readFileSync(envPath, 'utf-8');
        console.log('📄 Found existing .env.local');
    }

    // Helper to extract existing value
    const getValue = (key) => {
        const match = envContent.match(new RegExp(`^${key}=(.*)$`, 'm'));
        return match ? match[1].trim() : null;
    };

    // Get KV ID
    const currentKv = getValue('WRANGLER_KV_ID');
    const kvPrompt = currentKv ? `Enter KV Namespace ID (${currentKv}): ` : 'Enter KV Namespace ID: ';
    let kvId = await question(kvPrompt);
    kvId = kvId.trim() || currentKv;

    if (!kvId) {
        console.error('❌ KV Namespace ID is required');
        rl.close();
        process.exit(1);
    }

    // Get D1 ID
    const currentD1 = getValue('WRANGLER_D1_ID');
    const d1Prompt = currentD1 ? `Enter D1 Database ID (${currentD1}): ` : 'Enter D1 Database ID: ';
    let d1Id = await question(d1Prompt);
    d1Id = d1Id.trim() || currentD1;

    if (!d1Id) {
        console.error('❌ D1 Database ID is required');
        rl.close();
        process.exit(1);
    }

    // Get Site URL
    /* 
    // Commented out as currently init-config.js doesn't inject variables into the template 'vars' block yet, 
    // but good to have ready relative to the previous version.
    // For now we trust users to set NEXT_PUBLIC_SITE_URL in .env (Next.js picks it up) or via Cloudflare Dashboard.
    */

    rl.close();

    // Prepare content
    const newLines = [
        `WRANGLER_KV_ID=${kvId}`,
        `WRANGLER_D1_ID=${d1Id}`
    ];

    // Merge with existing content (simple append/replace strategy for this script's specific keys)
    // We'll reconstruct the file to ensure our keys are set correctly
    let finalContent = envContent;

    // Replace or Append WRANGLER_KV_ID
    if (finalContent.match(/^WRANGLER_KV_ID=/m)) {
        finalContent = finalContent.replace(/^WRANGLER_KV_ID=.*$/m, `WRANGLER_KV_ID=${kvId}`);
    } else {
        finalContent += `\nWRANGLER_KV_ID=${kvId}`;
    }

    // Replace or Append WRANGLER_D1_ID
    if (finalContent.match(/^WRANGLER_D1_ID=/m)) {
        finalContent = finalContent.replace(/^WRANGLER_D1_ID=.*$/m, `WRANGLER_D1_ID=${d1Id}`);
    } else {
        finalContent += `\nWRANGLER_D1_ID=${d1Id}`;
    }

    // Clean up multiple newlines
    finalContent = finalContent.replace(/\n\s*\n/g, '\n').trim() + '\n';

    fs.writeFileSync(envPath, finalContent, 'utf-8');

    console.log('\n✅ .env.local updated successfully!');
    console.log('   WRANGLER_KV_ID set');
    console.log('   WRANGLER_D1_ID set');

    console.log('\n🚀 Next steps:');
    console.log('  1. Run: npm run build (to generate wrangler.jsonc)');
    console.log('  2. Run: npm run preview (to test locally)');
}

main().catch(err => {
    console.error('❌ Error:', err.message);
    process.exit(1);
});
