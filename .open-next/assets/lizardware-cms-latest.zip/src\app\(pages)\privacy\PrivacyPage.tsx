export default function PrivacyPage() {
    return (
        <div className="max-w-[1024px] mx-auto px-4 py-12 space-y-8">
            <h1 className="text-title font-bold text-primary mb-6">Privacy Policy</h1>
            <div className="prose dark:prose-invert max-w-none text-page-text">
                <p>This is a placeholder for your Privacy Policy. You can customize this page by editing <code>src/app/(pages)/privacy/PrivacyPage.tsx</code> or by creating a page with the slug <code>privacy</code> in the Admin Dashboard.</p>
            </div>
        </div>
    );
}
