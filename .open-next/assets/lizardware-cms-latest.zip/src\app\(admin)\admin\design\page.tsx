'use client';

import Link from "next/link";
import { Palette, ArrowLeft, Image as ImageIcon, Sparkles, Compass, Layers } from "lucide-react";
import { Breadcrumbs } from "@/components/admin/Breadcrumbs";
import { HubSectionCard } from "@/components/admin/HubSectionCard";
import { AdminHeader } from '@/components/admin/AdminHeader';
import { HUB_PAGE_STYLES } from "@/lib/admin-hub-styles";

export default function DesignHubPage() {
    return (
        <div className={HUB_PAGE_STYLES.container}>
            <div className={`${HUB_PAGE_STYLES.maxWidth} ${HUB_PAGE_STYLES.topPadding} space-y-8`}>

                <AdminHeader
                    title={<>Design <span className="text-purple-500">Hub</span> 🎨</>}
                    description="Establish your brand identity and fine-tune your modules and visual experience."
                    breadcrumbs={[
                        { label: 'Admin', href: '/admin' },
                        { label: 'Design' }
                    ]}
                    badge={
                        <div className="px-3 py-1.5 bg-purple-500/10 border border-purple-500/20 rounded-lg text-[10px] font-bold uppercase tracking-widest text-purple-600 dark:text-purple-400 flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-purple-500 animate-pulse"></span>
                            Creative Engine Active
                        </div>
                    }
                    actions={
                        <Link
                            href="/admin"
                            className="px-3 py-1.5 bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 rounded-lg text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
                        >
                            <ArrowLeft size={12} /> Back
                        </Link>
                    }
                />

                {/* Section Cards */}
                <div className={HUB_PAGE_STYLES.sectionCards.grid}>
                    <HubSectionCard
                        title="Module Manager"
                        description="Enable or disable system features, modules, and platform addons."
                        icon={<Layers className="w-6 h-6" />}
                        gradient="indigo"
                        href="/admin/design/features"
                        blockId="design-hub-modules"
                    />

                    <HubSectionCard
                        title="Visual Identity"
                        description="Configure logos, favicons, brand colors, and global layout presets."
                        icon={<ImageIcon className="w-6 h-6" />}
                        gradient="blue"
                        href="/admin/design/identity"
                        blockId="appearance-hub-visual-identity"
                    />

                    <HubSectionCard
                        title="Theme Transformer"
                        description="Granular control over typography, spacing, border radii, and effects."
                        icon={<Sparkles className="w-6 h-6" />}
                        gradient="purple"
                        href="/admin/design/theme"
                        blockId="appearance-hub-theme-transformer"
                    />

                    <HubSectionCard
                        title="Navigation Path"
                        description="Build menus, manage redirects, and structure site hierarchy path."
                        icon={<Compass className="w-6 h-6" />}
                        gradient="emerald"
                        href="/admin/design/nav"
                        blockId="appearance-hub-navigation"
                    />
                </div>

                {/* Pro Hint Box */}
                <div className="bg-zinc-900 text-zinc-400 p-6 rounded-3xl border border-zinc-800 flex items-start gap-4">
                    <div className="w-10 h-10 rounded-xl bg-zinc-800 flex items-center justify-center text-xl flex-shrink-0">
                        💡
                    </div>
                    <div>
                        <h3 className="font-bold text-zinc-100 mb-1 text-[10px] uppercase tracking-widest">Pro Tip</h3>
                        <p className="text-[11px] leading-relaxed max-w-2xl opacity-60">
                            Use <span className="text-zinc-200 font-bold">Visual Identity</span> for broad strokes and <span className="text-zinc-200 font-bold">Theme Transformer</span> for pixel-perfect adjustments. All changes are previewed in real-time.
                        </p>
                    </div>
                </div>

                {/* Quick Actions */}
                <div className="p-6 bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800">
                    <h3 className="text-sm font-black uppercase tracking-widest text-zinc-400 mb-4">Quick Shortcuts</h3>
                    <div className="flex flex-wrap gap-3">
                        <Link href="/admin/design/identity" className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-bold hover:bg-blue-700 transition-colors">
                            Update Logo
                        </Link>
                        <Link href="/admin/design/theme" className="px-4 py-2 bg-purple-600 text-white rounded-lg text-sm font-bold hover:bg-purple-700 transition-colors">
                            Edit Palettes
                        </Link>
                        <Link href="/admin/design/nav" className="px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm font-bold hover:bg-emerald-700 transition-colors">
                            Manage Menus
                        </Link>
                    </div>
                </div>
            </div>
        </div>
    );
}
