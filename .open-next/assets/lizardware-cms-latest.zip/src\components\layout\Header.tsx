"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { getNavigation } from "@/lib/navigation";
import { usePathname } from "next/navigation";
import { ThemeToggle } from "@/components/ui/ThemeToggle";
import { NavItem } from "@/types/nav";

export default function Header({ customItems, isPreview, siteName, logoUrl }: { customItems?: NavItem[], isPreview?: boolean, siteName?: string, logoUrl?: string }) {
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const [openDropdown, setOpenDropdown] = useState<string | null>(null);
    const globalNavItems = getNavigation();
    const navItems = customItems || globalNavItems;
    const pathname = usePathname();

    const toggleDropdown = (label: string) => {
        if (openDropdown === label) {
            setOpenDropdown(null);
        } else {
            setOpenDropdown(label);
        }
    };

    const handleLinkClick = (e: React.MouseEvent) => {
        if (isPreview) {
            e.preventDefault();
        }
    };

    return (
        <header className="bg-header-bg text-header-text border-b border-borders">
            <div className="max-w-[1024px] mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between items-center" style={{ height: 'var(--spacing-header, 4rem)' }}>
                    {/* Logo */}
                    <Link
                        href="/"
                        className="flex items-center group"
                        onClick={handleLinkClick}
                    >
                        <div className="mr-3 text-3xl transition-transform group-hover:scale-110">
                            {logoUrl ? (
                                logoUrl.startsWith('http') ? (
                                    <img src={logoUrl} alt="Logo" className="w-8 h-8 object-contain" />
                                ) : (
                                    logoUrl
                                )
                            ) : (
                                "🦎"
                            )}
                        </div>
                        <span className="font-bold text-xl tracking-tight text-slate-900 dark:text-white group-hover:text-primary transition-colors">
                            {siteName || "Lizardware"}
                        </span>
                    </Link>

                    {/* Desktop Nav */}
                    <nav className="hidden md:flex gap-header items-center">
                        {navItems.map((item) => (
                            <div key={item.label} className="relative group">
                                {item.children && item.children.length > 0 ? (
                                    <>
                                        <Link
                                            href={item.href}
                                            onClick={handleLinkClick}
                                            className="text-header-text hover:text-primary px-3 py-2 rounded-md text-sm font-medium inline-flex items-center transition-colors"
                                        >
                                            {item.label}
                                            <svg
                                                className="ml-1 h-4 w-4 group-hover:rotate-180 transition-transform duration-200"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                stroke="currentColor"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M19 9l-7 7-7-7"
                                                />
                                            </svg>
                                        </Link>

                                        {/* Dropdown Menu */}
                                        <div className="absolute left-1/2 transform -translate-x-1/2 mt-0 w-64 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 ease-out z-50 pt-2">
                                            <div className="rounded-lg shadow-xl ring-1 ring-black ring-opacity-5 overflow-hidden bg-header-bg">
                                                <div className="py-1 grid gap-y-1">
                                                    {item.children.map((child) => (
                                                        child.children ? (
                                                            // Nested submenu category
                                                            <div key={child.id} className="px-4 py-2">
                                                                <div className="flex items-center gap-2 text-xs font-bold text-page-subtitle uppercase tracking-wide mb-2">
                                                                    {child.icon && <span>{child.icon}</span>}
                                                                    {child.label}
                                                                </div>
                                                                <div className="pl-4 space-y-1">
                                                                    {child.children.map((subChild) => (
                                                                        <Link
                                                                            key={subChild.href}
                                                                            href={subChild.href}
                                                                            onClick={handleLinkClick}
                                                                            className="block text-sm text-header-text hover:text-primary hover:bg-header-bg/50 px-2 py-1 rounded transition-colors"
                                                                        >
                                                                            {subChild.label}
                                                                        </Link>
                                                                    ))}
                                                                </div>
                                                            </div>
                                                        ) : (
                                                            // Regular dropdown link
                                                            <DropdownLink
                                                                key={child.href}
                                                                href={child.href}
                                                                icon={child.icon || ""}
                                                                label={child.label}
                                                                onClick={handleLinkClick}
                                                            />
                                                        )
                                                    ))}
                                                </div>
                                            </div>
                                        </div>
                                    </>
                                ) : (
                                    <Link
                                        href={item.href}
                                        onClick={handleLinkClick}
                                        className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${pathname === item.href
                                            ? "text-primary bg-header-bg/50"
                                            : "text-header-text hover:text-primary"
                                            }`}
                                    >
                                        {item.label}
                                    </Link>
                                )}
                            </div>
                        ))}
                    </nav>

                    {/* Desktop Theme Toggle */}
                    <div className="hidden md:block ml-4">
                        <ThemeToggle />
                    </div>

                    {/* Mobile menu button */}
                    <div className="flex items-center gap-4 md:hidden">
                        <ThemeToggle />
                        <button
                            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                            className="inline-flex items-center justify-center p-2 rounded-md text-header-text hover:text-primary hover:bg-header-bg/50 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary"
                        >
                            <span className="sr-only">Open main menu</span>
                            {isMobileMenuOpen ? (
                                <svg
                                    className="block h-6 w-6"
                                    xmlns="http://www.w3.org/2000/svg"
                                    fill="none"
                                    viewBox="0 0 24 24"
                                    stroke="currentColor"
                                    aria-hidden="true"
                                >
                                    <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth={2}
                                        d="M6 18L18 6M6 6l12 12"
                                    />
                                </svg>
                            ) : (
                                <svg
                                    className="block h-6 w-6"
                                    xmlns="http://www.w3.org/2000/svg"
                                    fill="none"
                                    viewBox="0 0 24 24"
                                    stroke="currentColor"
                                    aria-hidden="true"
                                >
                                    <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth={2}
                                        d="M4 6h16M4 12h16M4 18h16"
                                    />
                                </svg>
                            )}
                        </button>
                    </div>
                </div>
            </div>

            {/* Mobile Menu Drawer */}
            {isMobileMenuOpen && (
                <>
                    {/* Backdrop */}
                    <div
                        className="fixed inset-0 bg-black/50 z-40 md:hidden backdrop-blur-sm"
                        onClick={() => setIsMobileMenuOpen(false)}
                    />

                    {/* Drawer */}
                    <div className="fixed top-0 right-0 h-full w-72 bg-header-bg border-l border-borders z-50 md:hidden shadow-2xl overflow-y-auto transform transition-transform duration-300 ease-in-out">
                        <div className="p-4 flex items-center justify-between border-b border-borders">
                            <span className="font-bold text-lg text-header-text">Menu</span>
                            <button
                                onClick={() => setIsMobileMenuOpen(false)}
                                className="p-2 rounded-md text-header-text hover:text-primary hover:bg-header-bg/50 focus:outline-none"
                            >
                                <svg
                                    className="h-6 w-6"
                                    xmlns="http://www.w3.org/2000/svg"
                                    fill="none"
                                    viewBox="0 0 24 24"
                                    stroke="currentColor"
                                >
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>
                        </div>

                        <div className="px-2 py-4 space-y-1">
                            {navItems.map((item) => (
                                <div key={item.label} className="mb-2">
                                    {item.children && item.children.length > 0 ? (
                                        <div className="space-y-1">
                                            <button
                                                onClick={() => toggleDropdown(item.label)}
                                                className="w-full flex items-center justify-between text-header-text hover:text-primary hover:bg-header-bg/50 px-3 py-2 rounded-md text-base font-medium"
                                            >
                                                <span>{item.label}</span>
                                                <svg
                                                    className={`ml-2 h-4 w-4 transform transition-transform ${openDropdown === item.label ? "rotate-180" : ""
                                                        }`}
                                                    fill="none"
                                                    viewBox="0 0 24 24"
                                                    stroke="currentColor"
                                                >
                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                                                </svg>
                                            </button>

                                            {openDropdown === item.label && (
                                                <div className="pl-4 space-y-1 bg-header-bg/30 rounded-lg mx-2 pb-2">
                                                    {item.children.map((child) => (
                                                        child.children ? (
                                                            // Nested submenu for mobile
                                                            <div key={child.id} className="py-2">
                                                                <div className="flex items-center gap-2 text-xs font-bold text-page-subtitle uppercase tracking-wide mb-1 px-3">
                                                                    {child.icon && <span>{child.icon}</span>}
                                                                    {child.label}
                                                                </div>
                                                                <div className="pl-4 space-y-1">
                                                                    {child.children.map((subChild) => (
                                                                        <MobileLink
                                                                            key={subChild.href}
                                                                            href={subChild.href}
                                                                            label={subChild.label}
                                                                            onClick={(e) => {
                                                                                handleLinkClick(e);
                                                                                setIsMobileMenuOpen(false);
                                                                            }}
                                                                        />
                                                                    ))}
                                                                </div>
                                                            </div>
                                                        ) : (
                                                            <MobileLink
                                                                key={child.href}
                                                                href={child.href}
                                                                label={child.label}
                                                                icon={child.icon}
                                                                onClick={(e) => {
                                                                    handleLinkClick(e);
                                                                    setIsMobileMenuOpen(false);
                                                                }}
                                                            />
                                                        )
                                                    ))}
                                                </div>
                                            )}
                                        </div>
                                    ) : (
                                        <MobileLink
                                            href={item.href}
                                            label={item.label}
                                            onClick={(e) => {
                                                handleLinkClick(e);
                                                setIsMobileMenuOpen(false);
                                            }}
                                        />
                                    )}
                                </div>
                            ))}
                        </div>
                    </div>
                </>
            )}
        </header>
    );
}

function DropdownLink({ href, icon, label, onClick }: { href: string; icon: string; label: string; onClick?: (e: React.MouseEvent) => void }) {
    return (
        <Link
            href={href}
            onClick={onClick}
            className="flex items-center px-4 py-3 text-sm text-header-text hover:bg-header-bg/50 hover:text-primary transition-colors"
        >
            <span className="mr-3 text-lg">{icon}</span>
            {label}
        </Link>
    );
}

function MobileLink({ href, label, icon, onClick }: { href: string; label: string; icon?: string; onClick?: (e: React.MouseEvent) => void }) {
    return (
        <Link
            href={href}
            onClick={onClick}
            className="block px-3 py-2 rounded-md text-base font-medium text-header-text hover:text-primary hover:bg-header-bg/50 transition-colors flex items-center"
        >
            {icon && <span className="mr-2">{icon}</span>}
            {label}
        </Link>
    );
}
