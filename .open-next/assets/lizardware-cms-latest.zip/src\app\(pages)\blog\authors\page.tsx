import Link from "next/link";
import Image from "next/image";
import { getAllPosts } from "@/lib/blog";
import authorsData from "@/data/authors.json";

export const metadata = {
    title: "Authors | Lizardware Blog",
    description: "Meet the experts behind Lizardware&apos;s insights and technology strategy.",
};

export default async function AuthorsPage() {
    const posts = await getAllPosts();
    const authors = authorsData.authors;

    // Count posts per author
    const authorPostCounts = posts.reduce((acc, post) => {
        if (post.author_id) {
            acc[post.author_id] = (acc[post.author_id] || 0) + 1;
        }
        return acc;
    }, {} as Record<string, number>);

    return (
        <div className="max-w-[1024px] mx-auto px-4 py-12">
            <h1 className="text-title font-bold text-page-title mb-4">Authors</h1>
            <p className="text-lg text-page-text mb-12">
                Meet our team of contributors sharing knowledge on IT strategy, automation, and cybersecurity.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {authors.map((author) => (
                    <Link
                        key={author.id}
                        href={`/blog/author/${author.id}`}
                        className="group flex flex-col md:flex-row gap-6 p-6 bg-info-box-bg border border-borders rounded-xl hover:border-primary transition-all shadow-sm"
                    >
                        {author.avatar && (
                            <div className="relative w-24 h-24 rounded-full overflow-hidden border border-borders flex-shrink-0">
                                <Image
                                    src={author.avatar}
                                    alt={author.name}
                                    width={96}
                                    height={96}
                                    className="w-full h-full object-cover"
                                />
                            </div>
                        )}
                        <div>
                            <h2 className="text-xl font-bold text-info-box-text group-hover:text-primary transition-colors">
                                {author.name}
                            </h2>
                            <p className="text-sm text-info-box-text/70 mt-2 line-clamp-2">
                                {author.bio}
                            </p>
                            <div className="mt-4 flex items-center justify-between">
                                <span className="text-xs font-semibold text-primary uppercase tracking-wider">
                                    {authorPostCounts[author.id] || 0} {(authorPostCounts[author.id] || 0) === 1 ? 'Post' : 'Posts'}
                                </span>
                                <span className="text-primary text-sm font-medium">View Profile →</span>
                            </div>
                        </div>
                    </Link>
                ))}
            </div>
        </div>
    );
}
