import { NextResponse } from 'next/server';
import { getD1Database, dbUnavailableResponse } from '@/lib/cloudflare';
import fs from 'fs';
import path from 'path';

const FEATURES_FILE_PATH = path.join(process.cwd(), 'src', 'data', 'features.json');

export async function GET() {
    try {
        // Development fallback: Read from local JSON file
        if (process.env.NODE_ENV === 'development') {
            if (fs.existsSync(FEATURES_FILE_PATH)) {
                const fileContent = fs.readFileSync(FEATURES_FILE_PATH, 'utf-8');
                return NextResponse.json(JSON.parse(fileContent));
            }
            // Default features (all enabled by default or empty)
            return NextResponse.json({});
        }

        const db = await getD1Database();
        if (!db) return dbUnavailableResponse();

        const result = await db.prepare('SELECT feature_name, enabled FROM feature_flags').all();

        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const flags: Record<string, boolean> = {};

        // Transform to simple key-value object
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (result.results || []).forEach((row: any) => {
            flags[row.feature_name] = row.enabled === 1;
        });

        return NextResponse.json(flags);
    } catch (error) {
        console.error('Feature flags fetch error:', error);
        return NextResponse.json({ error: 'Failed to fetch feature flags' }, { status: 500 });
    }
}

export async function POST(request: Request) {
    try {
        const features = await request.json() as Record<string, boolean>;

        // Development fallback: Write to local JSON file
        if (process.env.NODE_ENV === 'development') {
            fs.writeFileSync(FEATURES_FILE_PATH, JSON.stringify(features, null, 4));
            return NextResponse.json({ success: true, message: 'Feature flags saved locally (Dev Mode)' });
        }

        const db = await getD1Database();
        if (!db) return dbUnavailableResponse();

        // We use a transaction or just loop. D1 supports batch but loop is fine for < 20 items.
        // For upserting/updating:

        const stmt = db.prepare(
            'INSERT INTO feature_flags (feature_name, enabled, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP) ' +
            'ON CONFLICT(feature_name) DO UPDATE SET enabled = excluded.enabled, updated_at = excluded.updated_at'
        );

        const batch = [];
        for (const [name, enabled] of Object.entries(features)) {
            batch.push(stmt.bind(name, enabled ? 1 : 0));
        }

        if (batch.length > 0) {
            try {
                await db.batch(batch);
            } catch (dbError: any) {
                // Handle case where feature_flags table doesn't exist yet
                // This can happen during initial setup before database migration
                if (dbError?.message?.includes('no such table') || dbError?.message?.includes('feature_flags')) {
                    console.warn('Feature flags table not found - database may not be initialized yet');
                    return NextResponse.json({
                        success: true,
                        warning: 'Database not initialized. Feature flags will be set after database setup.'
                    });
                }
                throw dbError; // Re-throw if it's a different error
            }
        }

        return NextResponse.json({ success: true });
    } catch (error) {
        console.error('Feature flags update error:', error);
        return NextResponse.json({ error: 'Failed to update feature flags' }, { status: 500 });
    }
}
