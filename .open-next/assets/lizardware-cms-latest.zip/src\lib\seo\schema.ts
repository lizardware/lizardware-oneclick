// Schema.org structured data generators for SEO
// See: https://schema.org/docs/schemas.html
import siteConfigData from '@/data/site-config.json';

export interface OrganizationConfig {
    name: string;
    description: string;
    url: string;
    logo?: string;
    email?: string;
    telephone?: string;
    address?: {
        streetAddress: string;
        addressLocality: string;
        addressRegion: string;
        postalCode: string;
        addressCountry: string;
    };
    socialLinks?: string[];
}

export interface ArticleData {
    title: string;
    description: string;
    author: string;
    datePublished: string;
    dateModified: string;
    url: string;
    imageUrl?: string;
}

export function generateOrganizationSchema(config: OrganizationConfig) {
    return {
        '@context': 'https://schema.org',
        '@type': 'Organization',
        name: config.name,
        description: config.description,
        url: config.url,
        logo: config.logo || `${config.url}/icon.png`,
        email: config.email,
        telephone: config.telephone,
        address: config.address ? {
            '@type': 'PostalAddress',
            ...config.address,
        } : undefined,
        sameAs: config.socialLinks || [],
    };
}

export function generateWebSiteSchema(config: { name: string; url: string; description: string }) {
    return {
        '@context': 'https://schema.org',
        '@type': 'WebSite',
        name: config.name,
        description: config.description,
        url: config.url,
        potentialAction: {
            '@type': 'SearchAction',
            target: {
                '@type': 'EntryPoint',
                urlTemplate: `${config.url}/blog?search={search_term_string}`,
            },
            'query-input': 'required name=search_term_string',
        },
    };
}

export function generateArticleSchema(data: ArticleData) {
    return {
        '@context': 'https://schema.org',
        '@type': 'Article',
        headline: data.title,
        description: data.description,
        author: {
            '@type': 'Person',
            name: data.author,
        },
        datePublished: data.datePublished,
        dateModified: data.dateModified,
        url: data.url,
        image: data.imageUrl,
        publisher: {
            '@type': 'Organization',
            name: siteConfigData.name || 'Your Organization',
            logo: {
                '@type': 'ImageObject',
                url: `${process.env.NEXT_PUBLIC_SITE_URL}/icon.png`,
            },
        },
    };
}

export function generateBreadcrumbSchema(items: Array<{ name: string; url: string }>) {
    return {
        '@context': 'https://schema.org',
        '@type': 'BreadcrumbList',
        itemListElement: items.map((item, index) => ({
            '@type': 'ListItem',
            position: index + 1,
            name: item.name,
            item: item.url,
        })),
    };
}

export function generateWebPageSchema(data: { title: string; description: string; url: string }) {
    return {
        '@context': 'https://schema.org',
        '@type': 'WebPage',
        name: data.title,
        description: data.description,
        url: data.url,
    };
}
