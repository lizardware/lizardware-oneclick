'use client';

import { SafeSignIn } from "@/components/auth/SafeSignIn";

export default function SignInPage() {
    return (
        <div className="min-h-screen bg-zinc-900 flex items-center justify-center p-4 relative overflow-hidden">
            {/* Floating Glow Orbs */}
            <div className="absolute top-1/4 -left-20 w-80 h-80 bg-purple-600/20 rounded-full blur-[120px] animate-pulse" />
            <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-emerald-600/10 rounded-full blur-[130px] animate-pulse" style={{ animationDelay: '700ms' }} />

            <div className="relative group w-full max-w-md">
                <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 via-pink-600 to-emerald-600 rounded-[2rem] blur opacity-25 group-hover:opacity-40 transition duration-1000" />

                <div className="relative bg-zinc-950/95 backdrop-blur-3xl rounded-[1.75rem] border border-white/10 overflow-hidden shadow-2xl">
                    <div className="p-8 pb-6">
                        <div className="text-center mb-6">
                            <h1 className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-br from-white to-zinc-500 uppercase tracking-tighter mb-1">
                                Core Protocol
                            </h1>
                            <p className="text-[9px] font-bold text-zinc-500 uppercase tracking-[0.3em]">
                                Identity Verification Required
                            </p>
                        </div>

                        <SafeSignIn
                            appearance={{
                                baseTheme: undefined,
                                layout: {
                                    socialButtonsPlacement: "top",
                                    socialButtonsVariant: "iconButton",
                                },
                                variables: {
                                    colorBackground: 'transparent',
                                    colorInputBackground: 'rgba(255, 255, 255, 0.05)',
                                    colorInputText: '#fff',
                                    colorText: '#fff',
                                    colorTextSecondary: '#71717a',
                                    colorPrimary: '#a855f7',
                                    colorTextOnPrimaryBackground: '#fff',
                                    fontSize: '1rem',
                                    fontWeight: { normal: 500, medium: 600, bold: 700 },
                                },
                                elements: {
                                    rootBox: "w-full flex justify-center",
                                    card: "bg-transparent shadow-none border-none p-0 w-full",
                                    header: "hidden",
                                    headerTitle: "hidden",
                                    headerSubtitle: "hidden",
                                    logoBox: "hidden",
                                    main: "gap-6",
                                    footer: "hidden",
                                    footerAction: "hidden",
                                    footerPages: "hidden",

                                    // Horizontal Layout
                                    socialButtons: "flex flex-row gap-6 justify-center",

                                    // Big Round Buttons (Icon Only)
                                    // w-20 h-20 = 80px circles
                                    socialButtonsIconButton: "w-20 h-20 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-purple-500/50 hover:shadow-[0_0_30px_rgba(168,85,247,0.4)] transition-all duration-300 hover:scale-110 flex items-center justify-center",

                                    // Sizing handled by globals.css (48px)
                                    // Text-white ensures the SVG fill inherits correctly if possible, 
                                    // though Clerk SVGs sometimes ignore this without the global override I added.
                                    socialButtonsProviderIcon: "text-white",

                                    formButtonPrimary: "hidden",
                                    dividerRow: "hidden",
                                    formFieldInput: "hidden",
                                    formFieldLabel: "hidden",
                                }
                            }}
                            routing="path"
                            path="/sign-in"
                        />
                    </div>

                    <div className="px-6 py-2.5 bg-white/[0.03] border-t border-white/5 flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_6px_#10b981]" />
                            <span className="text-[7px] font-black text-emerald-500 uppercase tracking-widest">Protocol Active</span>
                        </div>
                        <span className="text-[7px] font-bold text-zinc-600 uppercase tracking-widest">v0.4.0</span>
                    </div>
                </div>
            </div>
        </div>
    );
}
