const fs = require('fs');
const path = require('path');
const configPath = path.join(process.cwd(), 'wrangler.jsonc');

// ================================================================
// DYNAMIC CONFIGURATION - GENERATED AT BUILD TIME
// ================================================================
// This script generates wrangler.jsonc from environment variables.
// Users never edit wrangler.jsonc directly.
//
// CI/CD: Reads WRANGLER_KV_ID / WRANGLER_D1_ID from Build Variables
// Local: Reads from .env or .env.local (if loaded)

// Load .env locally if not in CI (simple check)
if (process.env.SKIP_CF_PROVISION === 'true') {
    console.log('⏩ SKIP_CF_PROVISION is true. Skipping wrangler.jsonc generation (assumed already generated).');
    process.exit(0);
}

if (!process.env.CI && !process.env.CF_PAGES && fs.existsSync('.env.local')) {
    const envContent = fs.readFileSync('.env.local', 'utf-8');
    envContent.split('\n').forEach(line => {
        const [key, val] = line.split('=');
        if (key && val) process.env[key.trim()] = val.trim();
    });
}

const kvId = process.env.WRANGLER_KV_ID;
const d1Id = process.env.WRANGLER_D1_ID;

// Template Structure
const template = {
    name: "lizardware-dev-1",
    main: ".open-next/worker.js",
    compatibility_date: "2024-11-18",
    compatibility_flags: ["nodejs_compat"],
    assets: {
        directory: ".open-next/assets",
        binding: "ASSETS"
    },
    // Dynamically populated bindings
    kv_namespaces: [],
    d1_databases: [],
    // Commented-out routes template (informational)
    // routes: [{ pattern: "devprod.hoolutions.net/*", custom_domain: true }],
    vars: {
        USE_D1_BLOG: "true"
    },
    observability: {
        enabled: true,
        head_sampling_rate: 1,
        logs: { enabled: true, head_sampling_rate: 1, persist: true, invocation_logs: true },
        traces: { enabled: true, persist: true, head_sampling_rate: 1 }
    }
};

// Logic: Inject bindings ONLY if IDs are available
if (kvId && d1Id) {
    console.log(`🚀 Injecting Production IDs (KV: ${kvId.slice(0, 4)}..., D1: ${d1Id.slice(0, 4)}...)`);
    template.kv_namespaces.push({
        binding: "CONFIG_KV",
        id: kvId,
        preview_id: kvId
    });
    template.d1_databases.push({
        binding: "DB",
        database_name: "lizardware-db",
        database_id: d1Id,
        preview_database_id: d1Id
    });
} else {
    if (process.env.CI || process.env.CF_PAGES) {
        console.warn('⚠️  CI/CD Detected but missing IDs. Generating SETUP MODE config (no bindings).');
    } else {
        console.warn('⚠️  Local Build detected but missing IDs in .env.local.');
        console.warn('⚠️  Falling back to PREVIEW/PLACEHOLDER defaults (like previous behavior).');

        template.kv_namespaces.push({
            binding: "CONFIG_KV",
            id: "preview_kv_id",
            preview_id: "preview_kv_id"
        });
        template.d1_databases.push({
            binding: "DB",
            database_name: "lizardware-db",
            database_id: "preview_d1_id",
            preview_database_id: "preview_d1_id"
        });
    }
}

const output = `// GENERATED FILE - DO NOT EDIT DIRECTLY\n${JSON.stringify(template, null, 4)}`;

fs.writeFileSync(configPath, output);
console.log('✅ Generated wrangler.jsonc');
