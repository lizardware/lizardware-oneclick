import { getPostBySlug, getAllPosts } from "@/lib/blog";
import { notFound } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import { Metadata } from "next";
import { siteConfig } from "@/config/site";
import authorsData from "@/data/authors.json";
import PostViewCounter from "@/components/blog/PostViewCounter";
import { getD1Database } from "@/lib/cloudflare";
import { getAuthorById } from "@/lib/blog-authors";
import { getMediaById } from "@/lib/blog-media";
import { getCategoryBySlug } from "@/lib/blog-categories";

export async function generateStaticParams() {
  // Skip static generation during build if database isn't ready
  // This prevents "no such table" errors when D1 exists but schema isn't loaded
  // Pages will be generated on-demand at runtime instead
  if (process.env.NEXT_PHASE === 'phase-production-build') {
    console.log('Skipping blog static generation during build phase (will generate on-demand at runtime)');
    return [];
  }

  try {
    const posts = await getAllPosts();
    return posts.map((post) => ({
      slug: post.slug,
    }));
  } catch (error) {
    console.warn('Failed to generate static params for blog posts:', error);
    return [];
  }
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const post = await getPostBySlug(slug);

  if (!post) {
    return {
      title: "Post Not Found",
    };
  }

  const author = post.author_id
    ? authorsData.authors.find(a => a.id === post.author_id)
    : undefined;

  const authorName = author?.name || post.author || siteConfig.seo.author;

  const canonicalUrl = `${siteConfig.url}/blog/${slug}`;
  const ogImage = siteConfig.ogImage;

  return {
    title: `${post.title} | ${siteConfig.name} Blog`,
    description: post.description || siteConfig.seo.description,
    keywords: siteConfig.seo.keywords,
    authors: [{ name: authorName }],
    alternates: {
      canonical: canonicalUrl,
    },
    openGraph: {
      title: post.title,
      description: post.description || siteConfig.seo.description,
      url: canonicalUrl,
      siteName: siteConfig.openGraph.siteName,
      locale: siteConfig.openGraph.locale,
      type: "article",
      publishedTime: post.date,
      authors: [authorName],
      images: [
        {
          url: ogImage,
          width: 1200,
          height: 630,
          alt: post.title,
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title: post.title,
      description: post.description || siteConfig.seo.description,
      images: [ogImage],
      creator: siteConfig.seo.twitterHandle,
    },
  };
}

import MonetizationWrapper from "@/components/ui/MonetizationWrapper";

export default async function BlogPostPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
  const [{ slug }, { preview }] = await Promise.all([
    params,
    searchParams as Promise<{ [key: string]: string }>
  ]);

  let post = await getPostBySlug(slug);

  // If post not found, check if we're in preview mode
  if (!post) {
    if (preview === 'true') {
      // Create a mock post object for the live preview to target
      post = {
        slug: slug,
        title: "New Blog Post",
        content: "<p>Start writing your post content here...</p>",
        description: "Your post description will appear here.",
        date: new Date().toISOString(),
        status: 'draft',
        author: "Author",
        tags: [],
        view_count: 0
      } as any;
    } else {
      notFound();
    }
  }

  // At this point, post is guaranteed to be non-null (either from DB, preview mock, or notFound() was called)
  // TypeScript needs this assertion to understand the control flow
  const currentPost = post!;

  // Fetch contextual data from D1 if available
  let authorData: any = currentPost.author_id ? authorsData.authors.find(a => a.id === currentPost.author_id) : undefined;
  let categoryData: any = undefined;
  let featuredImageUrl: string | undefined = undefined;

  const db = await getD1Database();
  if (db) {
    try {
      if (currentPost.author_id) {
        const d1Author = await getAuthorById(db, currentPost.author_id);
        if (d1Author) authorData = d1Author;
      }
      if (currentPost.category_id) {
        const d1Category = await getCategoryBySlug(db, currentPost.category_id);
        if (d1Category) categoryData = d1Category;
      }
      if (currentPost.featured_image_id) {
        const d1Media = await getMediaById(db, currentPost.featured_image_id);
        if (d1Media) featuredImageUrl = d1Media.url;
      }
    } catch (error) {
      console.warn('Failed to fetch D1 data during render (likely build time), falling back to static data:', error);
    }
  }

  const authorName = authorData?.name || currentPost.author || "Lizardware Team";
  const authorAvatar = authorData?.avatar_url || authorData?.avatar;

  return (
    <div className="bg-page-background">
      <PostViewCounter slug={slug} />
      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Back to Blog Link */}
        <Link
          href="/blog"
          className="inline-flex items-center gap-2 text-sm text-page-subtitle hover:text-page-subtitle/80 mb-8 transition-colors"
        >
          <span>←</span>
          <span>Back to Blog</span>
        </Link>

        {/* Article Header */}
        <article className="space-y-8">
          <header className="space-y-4 pb-8 border-b border-borders">
            <h1 className="text-title font-bold tracking-tight text-page-title" data-content-title>
              {currentPost.title}
            </h1>

            {currentPost.description && (
              <p className="text-xl text-page-subtitle leading-relaxed" data-content-description>
                {currentPost.description}
              </p>
            )}

            {/* Post Meta */}
            <div className="flex flex-wrap items-center gap-6 text-sm text-page-text/60 pt-4">
              {authorData ? (
                <Link href={`/blog/author/${authorData.id}`} className="flex items-center gap-2 hover:text-primary transition-colors">
                  {authorAvatar && (
                    <Image
                      src={authorAvatar}
                      alt={authorName}
                      width={24}
                      height={24}
                      className="w-6 h-6 rounded-full object-cover border border-borders shadow-sm"
                    />
                  )}
                  <span className="font-semibold text-page-text">By {authorName}</span>
                </Link>
              ) : currentPost.author && (
                <span className="flex items-center gap-2">
                  <span className="font-semibold text-page-text">By {currentPost.author}</span>
                </span>
              )}

              {categoryData && (
                <Link href={`/blog/category/${categoryData.slug}`} className="flex items-center gap-2 text-purple-500 hover:text-purple-600 transition-colors font-bold uppercase text-[10px] tracking-widest px-2 py-0.5 bg-purple-500/5 rounded">
                  📁 {categoryData.name}
                </Link>
              )}

              {currentPost.date && (
                <span className="flex items-center gap-2">
                  📅 {new Date(currentPost.date).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })}
                </span>
              )}

              {currentPost.tags && currentPost.tags.length > 0 && (
                <div className="flex flex-wrap items-center gap-2">
                  🏷️ {currentPost.tags.map(tag => (
                    <Link
                      key={tag}
                      href={`/blog/tag/${tag.toLowerCase().replace(/\s+/g, '-')}`}
                      className="bg-info-box-bg border border-borders text-xs px-2 py-0.5 rounded-full hover:border-primary hover:text-primary transition-all"
                    >
                      {tag}
                    </Link>
                  ))}
                </div>
              )}

              <span className="flex items-center gap-2 opacity-60">
                📈 {currentPost.view_count || 0} views
              </span>
            </div>
          </header>

          <MonetizationWrapper placement="post_top" />

          {/* Featured Image */}
          {featuredImageUrl && (
            <div className="relative aspect-[21/9] rounded-3xl overflow-hidden shadow-2xl border border-borders group">
              <Image
                src={featuredImageUrl}
                alt={currentPost.title}
                fill
                className="object-cover group-hover:scale-105 transition-transform duration-700"
                priority
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
            </div>
          )}

          {/* Article Body */}
          <div
            className="prose prose-lg dark:prose-invert max-w-none
              prose-headings:text-page-title prose-headings:font-black prose-headings:tracking-tight
              prose-h1:text-4xl prose-h2:text-3xl prose-h3:text-2xl
              prose-p:text-page-text prose-p:leading-relaxed prose-p:mb-6
              prose-a:text-primary prose-a:no-underline hover:prose-a:underline prose-a:font-bold
              prose-strong:text-page-title prose-strong:font-black
              prose-code:text-primary prose-code:bg-primary/5 prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded-md prose-code:before:content-none prose-code:after:content-none
              prose-pre:bg-zinc-950 prose-pre:border prose-pre:border-borders prose-pre:rounded-2xl prose-pre:shadow-xl
              prose-blockquote:border-l-4 prose-blockquote:border-primary prose-blockquote:bg-primary/5 prose-blockquote:py-2 prose-blockquote:px-6 prose-blockquote:rounded-r-2xl prose-blockquote:italic prose-blockquote:text-page-title
              prose-ul:text-page-text prose-ol:text-page-text
              prose-li:text-page-text prose-li:my-2
              prose-img:rounded-3xl prose-img:shadow-2xl prose-img:border prose-img:border-borders
              prose-hr:border-borders prose-hr:my-12"
            data-content-body
            dangerouslySetInnerHTML={{ __html: currentPost.content }}
          />

          <MonetizationWrapper placement="post_bottom" />

          {/* Article Footer */}
          <footer className="pt-8 border-t border-borders">
            <Link
              href="/blog"
              className="inline-flex items-center gap-2 text-page-subtitle hover:text-page-subtitle/80 font-medium transition-colors"
            >
              <span>←</span>
              <span>Back to all posts</span>
            </Link>
          </footer>
        </article>
      </div>
    </div>
  );
}
