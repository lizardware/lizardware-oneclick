export const GENERIC_FAVICONS = [
    { id: 'lizard', value: '🦎', label: 'Lizard' },
    { id: 'rocket', value: '🚀', label: 'Rocket' },
    { id: 'fire', value: '🔥', label: 'Fire' },
    { id: 'globe', value: '🌐', label: 'Globe' },
    { id: 'star', value: '⭐', label: 'Star' },
    { id: 'bolt', value: '⚡', label: 'Bolt' },
    { id: 'heart', value: '❤️', label: 'Heart' },
    { id: 'laptop', value: '💻', label: 'Laptop' },
];

export const GENERIC_LOGOS = [
    { id: 'lizard', value: '🦎', label: 'Lizard' },
    { id: 'rocket', value: '🚀', label: 'Rocket' },
    { id: 'fire', value: '🔥', label: 'Fire' },
    { id: 'diamond', value: '💎', label: 'Diamond' },
    { id: 'cube', value: '🧊', label: 'Cube' },
    { id: 'sphere', value: '🔮', label: 'Sphere' },
    { id: 'shield', value: '🛡️', label: 'Shield' },
    { id: 'atom', value: '⚛️', label: 'Atom' },
];
