export type ThemeColors = {
    // Tier 1: Global (Foundational)
    bodyBackground: string;
    headerBackground: string;
    footerBackground: string;
    contentBackground: string;
    borders: string;

    // Tier 1.5: Component Defaults
    accordionBackground: string;
    buttonBackground: string;
    cardBackground: string;
    inputBackground: string;

    // Tier 2: Page Sections (Flexible)
    pageBackgroundPrimary: string;
    pageBackgroundSecondary: string;
    pageBackgroundAlternate: string;
    heroBackground: string;
    heroGradientStart: string;
    heroGradientEnd: string;
    heroGradientEnabled: boolean;

    // Text & UI (Unchanged but ensuring consistency)
    headerText: string;
    footerText: string;
    pageTitle: string;
    pageSubtitle: string;
    pageText: string;

    // Info Boxes / Cards (Legacy mapping or specific overrides)
    infoBoxBg: string;
    infoBoxText: string;
    infoBoxLinkBg: string;
    infoBoxLinkText: string;
    infoBoxLinkHover: string;

    // Section Headers
    sectionHeader: string;

    // Hero Text
    heroText: string;
};

export type ThemeConfig = {
    colors: {
        light: ThemeColors;
        dark: ThemeColors;
    };
    borderRadius: string;
    fontFamily: string;
    spacing?: {
        section: string;
        container: string;
        gap: string;
        header: string;
    };
    shadows?: {
        strength: string;
    };
    typography?: {
        fontSizeTitle: string;
        fontSizeSubtitle: string;
        fontSizeDescription: string;
        fontSizeBase: string;
    };
};

export interface ThemePreset {
    id: string;
    name: string;
    description: string;
    preview: string;
    accent: string;
    colors: {
        light: ThemeColors;
        dark: ThemeColors;
    };
    typography: {
        fontSizeTitle: string;
        fontSizeSubtitle: string;
        fontSizeBase: string;
    };
}
