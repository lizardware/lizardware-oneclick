/**
 * Build-Time Cloudflare Resource Provisioning
 * 
 * Automatically provisions KV, D1, and R2 resources before build.
 * Idempotent - safe to run multiple times.
 * 
 * Required Environment Variables:
 * - CLOUDFLARE_ACCOUNT_ID
 * - CLOUDFLARE_API_TOKEN
 * - CF_PROJECT_NAME
 */

const fs = require('fs');
const path = require('path');

// Parse CLI arguments
const args = process.argv.slice(2);
const JSON_MODE = args.includes('--json');
const DRY_RUN = args.includes('--dry-run');

// Environment variable validation
const ACCOUNT_ID = process.env.CLOUDFLARE_ACCOUNT_ID;
const API_TOKEN = process.env.CLOUDFLARE_API_TOKEN;
const SKIP_PROVISION = process.env.SKIP_CF_PROVISION === 'true';

const WRANGLER_PATH = path.join(__dirname, '..', 'wrangler.jsonc');

// ANSI color codes for terminal output
const colors = {
    reset: '\x1b[0m',
    red: '\x1b[31m',
    green: '\x1b[32m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    bold: '\x1b[1m'
};

function log(message, color = 'reset') {
    if (!JSON_MODE) {
        console.log(`${colors[color]}${message}${colors.reset}`);
    }
}

function error(message) {
    log(`❌ ${message}`, 'red');
}

function success(message) {
    log(`✅ ${message}`, 'green');
}

function info(message) {
    log(`ℹ️  ${message}`, 'blue');
}

function warn(message) {
    log(`⚠️  ${message}`, 'yellow');
}

// JSON output helper
function jsonOutput(data) {
    if (JSON_MODE) {
        console.log(JSON.stringify(data, null, 2));
    }
}

// Validation
if (SKIP_PROVISION) {
    warn('SKIP_CF_PROVISION is set to true. Skipping provisioning.');
    jsonOutput({ success: true, skipped: true, reason: 'SKIP_CF_PROVISION=true' });
    process.exit(0);
}

// Project name: Use env var if set, otherwise read from wrangler.jsonc
let PROJECT_NAME = process.env.CF_PROJECT_NAME;
if (!PROJECT_NAME) {
    try {
        const wranglerContent = fs.readFileSync(WRANGLER_PATH, 'utf8');
        // Remove comments and parse JSON
        const jsonContent = wranglerContent
            .split('\n')
            .filter(line => !line.trim().startsWith('//'))
            .join('\n')
            .replace(/\/\*[\s\S]*?\*\//g, '');
        const wranglerConfig = JSON.parse(jsonContent);
        PROJECT_NAME = wranglerConfig.name || 'lizardware-cms';
        info(`Using project name from wrangler.jsonc: ${PROJECT_NAME}`);
    } catch (e) {
        PROJECT_NAME = 'lizardware-cms';
        warn(`Could not read wrangler.jsonc, using default: ${PROJECT_NAME}`);
    }
}


if (!ACCOUNT_ID || !API_TOKEN) {
    const missingVars = {
        accountId: !ACCOUNT_ID,
        apiToken: !API_TOKEN
    };

    if (JSON_MODE) {
        jsonOutput({
            success: false,
            error: 'Missing Cloudflare credentials',
            missingVariables: missingVars,
            hint: 'Set CLOUDFLARE_ACCOUNT_ID and CLOUDFLARE_API_TOKEN environment variables'
        });
    } else {
        warn('Missing Cloudflare credentials. Skipping build-time provisioning.');
        console.log('');
        console.log('Required variables for auto-provisioning:');
        console.log(`  ${!ACCOUNT_ID ? '❌' : '✅'} CLOUDFLARE_ACCOUNT_ID`);
        console.log(`  ${!API_TOKEN ? '❌' : '✅'} CLOUDFLARE_API_TOKEN`);
        console.log('');
        console.log('This is normal for:');
        console.log('  1. Local development (using emulated resources)');
        console.log('  2. First-time deployments (use /setup wizard after deploy)');
        console.log('  3. Environments where resources are already created and bound manually');
        console.log('');
        info('Continuing build without provisioning...');
    }
    process.exit(0);
}

const safeProjectName = PROJECT_NAME.toLowerCase().replace(/[^a-z0-9]/g, '_');

// API Helper
async function cfApi(endpoint, method = 'GET', body = null) {
    const url = `https://api.cloudflare.com/client/v4${endpoint}`;
    const options = {
        method,
        headers: {
            'Authorization': `Bearer ${API_TOKEN}`,
            'Content-Type': 'application/json'
        }
    };

    if (body) {
        options.body = JSON.stringify(body);
    }

    const response = await fetch(url, options);
    const data = await response.json();

    if (!response.ok || !data.success) {
        const errorMsg = data.errors?.[0]?.message || 'Unknown error';
        throw new Error(`Cloudflare API Error: ${errorMsg}`);
    }

    return data.result;
}

// Check if KV namespace exists
async function checkKV(title) {
    try {
        const namespaces = await cfApi(`/accounts/${ACCOUNT_ID}/storage/kv/namespaces`);
        return namespaces.find(ns => ns.title === title);
    } catch (err) {
        throw new Error(`Failed to check KV: ${err.message}`);
    }
}

// Create KV namespace
async function createKV(title) {
    try {
        return await cfApi(`/accounts/${ACCOUNT_ID}/storage/kv/namespaces`, 'POST', { title });
    } catch (err) {
        throw new Error(`Failed to create KV: ${err.message}`);
    }
}

// Check if D1 database exists
async function checkD1(name) {
    try {
        const databases = await cfApi(`/accounts/${ACCOUNT_ID}/d1/database`);
        return databases.find(db => db.name === name);
    } catch (err) {
        throw new Error(`Failed to check D1: ${err.message}`);
    }
}

// Create D1 database
async function createD1(name) {
    try {
        return await cfApi(`/accounts/${ACCOUNT_ID}/d1/database`, 'POST', { name });
    } catch (err) {
        throw new Error(`Failed to create D1: ${err.message}`);
    }
}

// Check if R2 bucket exists
async function checkR2(name) {
    try {
        const buckets = await cfApi(`/accounts/${ACCOUNT_ID}/r2/buckets`);
        return buckets.buckets?.find(b => b.name === name);
    } catch (err) {
        // R2 is optional, don't fail on error
        warn(`Could not check R2 (optional resource): ${err.message}`);
        return null;
    }
}

// Create R2 bucket
async function createR2(name) {
    try {
        return await cfApi(`/accounts/${ACCOUNT_ID}/r2/buckets`, 'POST', { name });
    } catch (err) {
        warn(`Could not create R2 bucket (optional): ${err.message}`);
        return null;
    }
}

// Update wrangler.jsonc
function updateWranglerConfig(kvId, d1Id, r2Name) {
    try {
        let wranglerContent = fs.readFileSync(WRANGLER_PATH, 'utf8');

        // Update KV binding
        wranglerContent = wranglerContent.replace(
            /("id":\s*")[^"]*(".*?# KV_ID)/,
            `$1${kvId}$2`
        );

        // Update D1 binding
        wranglerContent = wranglerContent.replace(
            /("database_id":\s*")[^"]*(".*?# D1_ID)/,
            `$1${d1Id}$2`
        );

        // Update R2 binding (if provided)
        if (r2Name) {
            wranglerContent = wranglerContent.replace(
                /("bucket_name":\s*")[^"]*(".*?# R2_BUCKET)/,
                `$1${r2Name}$2`
            );
        }

        fs.writeFileSync(WRANGLER_PATH, wranglerContent, 'utf8');
        success('Updated wrangler.jsonc with resource IDs');
        return true;
    } catch (err) {
        warn(`Could not update wrangler.jsonc (non-critical): ${err.message}`);
        return false;
    }
}

// Main provisioning logic
async function provision() {
    info(`Starting Cloudflare provisioning for: ${safeProjectName}`);
    if (!JSON_MODE) console.log('');

    try {
        // 1. KV Namespace
        const kvTitle = `${safeProjectName}_config_kv`;
        info(`Checking KV namespace: ${kvTitle}`);
        let kv = await checkKV(kvTitle);

        if (kv) {
            success(`KV namespace exists: ${kv.id}`);
        } else {
            if (DRY_RUN) {
                info('DRY RUN: Would create KV namespace');
                kv = { id: 'dry-run-kv-id' };
            } else {
                info('Creating KV namespace...');
                kv = await createKV(kvTitle);
                success(`Created KV namespace: ${kv.id}`);
            }
        }

        // 2. D1 Database
        const d1Name = `${safeProjectName}_db`;
        info(`Checking D1 database: ${d1Name}`);
        let d1 = await checkD1(d1Name);

        if (d1) {
            success(`D1 database exists: ${d1.uuid}`);
        } else {
            if (DRY_RUN) {
                info('DRY RUN: Would create D1 database');
                d1 = { uuid: 'dry-run-d1-id' };
            } else {
                info('Creating D1 database...');
                d1 = await createD1(d1Name);
                success(`Created D1 database: ${d1.uuid}`);
            }
        }

        // 3. R2 Bucket (optional)
        const r2Name = `${safeProjectName}-media-bucket`;
        info(`Checking R2 bucket: ${r2Name}`);
        let r2 = await checkR2(r2Name);

        if (r2) {
            success(`R2 bucket exists: ${r2.name}`);
        } else {
            if (DRY_RUN) {
                info('DRY RUN: Would create R2 bucket');
                r2 = { name: r2Name };
            } else {
                info('Creating R2 bucket...');
                r2 = await createR2(r2Name);
                if (r2) {
                    success(`Created R2 bucket: ${r2.name}`);
                }
            }
        }

        // 4. Update wrangler.jsonc (skip in JSON mode - handled by workflow)
        if (!JSON_MODE) {
            console.log('');
            info('Updating wrangler.jsonc...');
            updateWranglerConfig(kv.id, d1.uuid, r2?.name);
        }

        // Success output
        const resources = {
            kvId: kv.id,
            d1Id: d1.uuid,
            r2Name: r2?.name || null
        };

        if (JSON_MODE) {
            jsonOutput({
                success: true,
                resources,
                projectName: safeProjectName
            });
        } else {
            console.log('');
            success('🎉 Cloudflare provisioning completed successfully!');
            console.log('');
            console.log('Resources:');
            console.log(`  KV:  ${kv.id}`);
            console.log(`  D1:  ${d1.uuid}`);
            if (r2) console.log(`  R2:  ${r2.name}`);
        }

        process.exit(0);
    } catch (err) {
        if (JSON_MODE) {
            jsonOutput({
                success: false,
                error: err.message,
                troubleshooting: err.message.includes('authentication') || err.message.includes('token')
                    ? 'Verify CLOUDFLARE_API_TOKEN has required permissions (D1: Edit, Workers KV Storage: Edit, Workers R2 Storage: Edit, Workers Scripts: Edit)'
                    : null
            });
        } else {
            console.log('');
            error('Provisioning failed!');
            console.log('');
            console.log(`Error: ${err.message}`);
            console.log('');

            if (err.message.includes('authentication') || err.message.includes('token')) {
                console.log('Troubleshooting:');
                console.log('  1. Verify CLOUDFLARE_API_TOKEN is correct');
                console.log('  2. Ensure token has the following permissions (Create Custom Token):');
                console.log('     [Account] Account Settings: Read');
                console.log('     [Account] D1: Edit');
                console.log('     [Account] Workers KV Storage: Edit');
                console.log('     [Account] Workers R2 Storage: Edit');
                console.log('     [Account] Workers Scripts: Edit');
                console.log('');
                console.log('  3. Check CLOUDFLARE_ACCOUNT_ID matches the token');
                console.log('');
                console.log('Create token: https://dash.cloudflare.com/profile/api-tokens');
            }
        }

        process.exit(1);
    }
}

// Run if called directly
if (require.main === module) {
    provision();
}

// Export for GitHub Actions
module.exports = { provision };
