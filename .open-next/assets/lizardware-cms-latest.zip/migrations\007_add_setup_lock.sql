-- Column 'setup_completed' already exists from migration 005
-- This UPDATE is for existing installs upgrading from pre-005 versions
UPDATE site_config 
SET setup_completed = 1 
WHERE template_id IS NOT NULL AND template_id != '';

