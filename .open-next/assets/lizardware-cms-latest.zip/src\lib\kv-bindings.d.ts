// Cloudflare D1 and KV global type declarations
declare global {
    interface Env {
        DB: D1Database;
        CONFIG_KV: KVNamespace;
    }
}

export { };

// D1 Database interface (extends @cloudflare/workers-types)
interface D1Database {
    prepare(query: string): D1PreparedStatement;
    dump(): Promise<ArrayBuffer>;
    batch<T = unknown>(statements: D1PreparedStatement[]): Promise<D1Result<T>[]>;
    exec(query: string): Promise<D1ExecResult>;
}

interface D1PreparedStatement {
    bind(...values: unknown[]): D1PreparedStatement;
    first<T = unknown>(colName?: string): Promise<T | null>;
    run(): Promise<D1Result>;
    all<T = unknown>(): Promise<D1Result<T>>;
    raw<T = unknown>(): Promise<T[]>;
}

interface D1Result<T = unknown> {
    results: T[];
    success: boolean;
    meta: {
        duration: number;
        rows_read: number;
        rows_written: number;
    };
}

interface D1ExecResult {
    count: number;
    duration: number;
}
