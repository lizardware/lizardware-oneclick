import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
    const env = getEnv(request);

    if (!env.DB) {
        return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }

    const data = await request.json() as any;

    try {
        // Prepare organization schema
        const organizationSchema = JSON.stringify({
            '@context': 'https://schema.org',
            '@type': data.businessType,
            name: data.businessName,
            logo: data.logoUrl,
            sameAs: Object.values(data.socialProfiles).filter(Boolean),
        });

        // Update or insert global settings
        await env.DB.prepare(`
      UPDATE seo_global_settings SET
        title_template = ?,
        meta_description_template = ?,
        og_image_default = ?,
        organization_schema = ?,
        setup_wizard_completed = 1,
        google_search_console_code = ?,
        bing_webmaster_code = ?,
        twitter_card_type = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = 1
    `).bind(
            data.titleTemplate,
            data.metaDescriptionTemplate,
            data.defaultOgImage,
            organizationSchema,
            data.googleSearchConsoleCode,
            data.bingWebmasterCode,
            data.twitterCardType
        ).run();

        return NextResponse.json({ success: true });
    } catch (error) {
        console.error('Failed to save wizard data:', error);
        return NextResponse.json({ error: 'Failed to save settings' }, { status: 500 });
    }
}

export async function GET(request: NextRequest) {
    const env = getEnv(request);

    if (!env.DB) {
        return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }

    const settings = await env.DB.prepare('SELECT * FROM seo_global_settings WHERE id = 1').first();

    return NextResponse.json({ settings });
}

function getEnv(request: NextRequest): any {
    return (request as any).env || process.env;
}
