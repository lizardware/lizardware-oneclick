-- Seed: Service Business / Agency
-- Created: 2026-01-03
-- Strategy: Professional services structure

-- 1. Blog Posts (Industry Insights)
INSERT OR IGNORE INTO posts (slug, title, content, description, author, author_id, tags, date, status, created_at, updated_at)
VALUES (
  'future-of-consulting',
  'The Future of Strategic Consulting',
  '<h1>Adapting to Change</h1><p>The consulting landscape is shifting. Clients no longer want just advice; they want implementation partners who can share the risk and the reward.</p><p>At {{siteName}}, we believe in outcomes over outputs.</p>',
  'Trends shaping the professional services industry.',
  'CEO',
  'ceo',
  '["Industry Insights", "Strategy"]',
  datetime('now', '-5 days'),
  'published',
  datetime('now'),
  datetime('now')
);

INSERT OR IGNORE INTO posts (slug, title, content, description, author, author_id, tags, date, status, created_at, updated_at)
VALUES (
  'case-study-logistics',
  'Case Study: Optimizing Global Logistics',
  '<h1>The Challenge</h1><p>A global shipping firm was struggling with legacy systems that caused 48-hour delays in tracking updates.</p><h2>The Solution</h2><p>We implemented a real-time IoT tracking solution integrated with their existing ERP.</p><h2>The Results</h2><ul><li><strong>95%</strong> reduction in tracking latency</li><li><strong>15%</strong> operational cost savings</li></ul>',
  'How we helped a global logistics firm modernize their tracking.',
  'Project Lead',
  'lead',
  '["Case Study", "Success Story"]',
  datetime('now', '-20 days'),
  'published',
  datetime('now'),
  datetime('now')
);

-- 2. Pages
-- Home
INSERT OR IGNORE INTO pages (slug, title, content, description, status, sort_order, created_at, updated_at)
VALUES (
  'welcome',
  'Strategic Solutions Partner',
  '<h1>We Solve Complex Problems</h1><p>Welcome to <strong>{{siteName}}</strong>. We are a premier consultancy helping businesses navigate the digital age.</p><h2>Our Expertise</h2><p>From digital transformation to organizational change management, we have the experience to guide you.</p><p><a href="/services" class="btn-primary">View Our Services</a></p>',
  'Home of {{siteName}} - Strategic Consulting.',
  'published',
  0,
  datetime('now'),
  datetime('now')
);

-- Services Page
INSERT OR IGNORE INTO pages (slug, title, content, description, status, sort_order, created_at, updated_at)
VALUES (
  'services',
  'Our Services',
  '<h1>What We Do</h1><p>Comprehensive solutions for modern enterprises.</p><h2>Digital Transformation</h2><p>Modernize your tech stack and workflows to compete in the digital economy.</p><h2>Data Analytics</h2><p>Turn raw data into actionable insights with our advanced BI solutions.</p><h2>Cybersecurity</h2><p>Protect your assets with enterprise-grade security audits and implementation.</p>',
  'Comprehensive list of professional services.',
  'published',
  10,
  datetime('now'),
  datetime('now')
);

-- Contact Page
INSERT OR IGNORE INTO pages (slug, title, content, description, status, sort_order, created_at, updated_at)
VALUES (
  'contact',
  'Contact Us',
  '<h1>Let''s Work Together</h1><p>Ready to transform your business? Get in touch with our team today.</p><ul><li><strong>Email:</strong> contact@example.com</li><li><strong>Phone:</strong> (555) 123-4567</li><li><strong>Office:</strong> 123 Business Park Dr, Innovation City</li></ul><p><em>(Contact form placeholder)</em></p>',
  'Get in touch with {{siteName}}.',
  'published',
  20,
  datetime('now'),
  datetime('now')
);
