import { NextRequest, NextResponse } from 'next/server';
import { updateSiteConfig, type SiteConfig } from '@/lib/config-storage';
import { getSafeCloudflareContext } from '@/lib/cloudflare';
import { siteConfig as defaultSiteConfig } from '@/config/site';

/**
 * PUT /api/config/site
 * 
 * Update site configuration in KV storage (instant, no rebuild!)
 * Protected by Cloudflare Access
 */
export async function PUT(request: NextRequest) {
    try {
        const context = await getSafeCloudflareContext();
        const kv = context?.env?.CONFIG_KV as KVNamespace;
        const siteConfig = await request.json() as SiteConfig & { setup_completed?: boolean };

        // Basic validation - Name is required, URL is optional (will be merged)
        if (!siteConfig.name) {
            return NextResponse.json(
                { error: 'Invalid site config: name is required' },
                { status: 400 }
            );
        }

        if (!kv) {
            // Development fallback: Write to local JSON file
            if (process.env.NODE_ENV === 'development') {
                const fs = await import('fs');
                const path = await import('path');
                const configPath = path.join(process.cwd(), 'src', 'data', 'site-config.json');

                // Read existing config to merge
                let existingConfig = { ...defaultSiteConfig };
                try {
                    if (fs.existsSync(configPath)) {
                        const fileContent = fs.readFileSync(configPath, 'utf-8');
                        existingConfig = JSON.parse(fileContent);
                    }
                } catch (e) {
                    console.warn('Failed to read existing config for merge:', e);
                }

                // Merge: Existing + New (New overwrites)
                // If new config doesn't have URL, existing URL is kept.
                const newConfig = { ...existingConfig, ...siteConfig };

                // Ensure URL exists (fallback to default if both missing)
                if (!newConfig.url) newConfig.url = defaultSiteConfig.url;

                fs.writeFileSync(configPath, JSON.stringify(newConfig, null, 4));

                return NextResponse.json({
                    success: true,
                    message: 'Site configuration saved to local file system (Development Mode)',
                });
            }

            return NextResponse.json(
                { error: 'KV storage not available' },
                { status: 503 }
            );
        }

        // 1. Save to KV (instant!)
        await updateSiteConfig(kv, siteConfig);

        // 2. Sync to D1 (for setup security)
        try {
            const { getD1Database } = await import('@/lib/cloudflare');
            const db = await getD1Database();
            if (db) {
                await db.prepare(`
                    UPDATE site_config 
                    SET name = ?, description = ?, template_id = ?, setup_completed = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE id = 1
                `).bind(
                    siteConfig.name,
                    siteConfig.description || '',
                    (siteConfig as any).template_id || 'custom',
                    siteConfig.setup_completed ? 1 : 0
                ).run();
                console.log('[Site Config] Synced to D1');
            }
        } catch (d1Error) {
            console.error('[Site Config] Failed to sync to D1:', d1Error);
            // We don't fail the whole request because KV worked
        }

        return NextResponse.json({
            success: true,
            message: 'Site configuration updated successfully',
        });
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error('Site config update error:', message);

        return NextResponse.json(
            { error: message },
            { status: 500 }
        );
    }
}

/**
 * GET /api/config/site
 * 
 * Get current site configuration from KV
 */
export async function GET() {
    try {
        const context = await getSafeCloudflareContext();
        const kv = context?.env?.CONFIG_KV as KVNamespace;

        let siteConfig = null;

        if (!kv) {
            // Development fallback: Read from local JSON file
            if (process.env.NODE_ENV === 'development') {
                try {
                    const fs = await import('fs');
                    const path = await import('path');
                    const configPath = path.join(process.cwd(), 'src', 'data', 'site-config.json');
                    if (fs.existsSync(configPath)) {
                        const fileContent = fs.readFileSync(configPath, 'utf-8');
                        siteConfig = JSON.parse(fileContent);
                    }
                } catch (err) {
                    console.warn('Could not read local site-config file, falling back to default:', err);
                }
            }
        } else {
            siteConfig = await kv.get('site', 'json');
        }

        // Always merge with defaults to ensure complete structure
        const completeConfig = {
            ...defaultSiteConfig,
            ...(siteConfig || {}),
            // Deep merge nested objects
            seo: {
                ...(defaultSiteConfig.seo || {}),
                ...(siteConfig?.seo || {})
            },
            links: {
                ...(defaultSiteConfig.links || {}),
                ...(siteConfig?.links || {})
            },
            openGraph: {
                ...(defaultSiteConfig.openGraph || {}),
                ...(siteConfig?.openGraph || {})
            }
        };

        return NextResponse.json(completeConfig);
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error('Site config fetch error:', message);

        return NextResponse.json(
            { error: message },
            { status: 500 }
        );
    }
}
