'use client';

import { BLOCK_REGISTRY } from '@/lib/blocks/registry';
import BlockCard from './BlockCard';

export default function BlockLibrary() {
    return (
        <div className="flex flex-col h-full bg-zinc-50 dark:bg-zinc-900/50">
            <div className="p-4 border-b border-gray-200 dark:border-zinc-800">
                <h3 className="text-xs font-black uppercase tracking-widest text-gray-500">Block Library</h3>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-3">
                <p className="text-[10px] text-gray-400 font-medium mb-2">Drag blocks to the canvas</p>

                {Object.values(BLOCK_REGISTRY).map((block) => (
                    <BlockCard key={block.type} block={block} />
                ))}
            </div>
        </div>
    );
}
