import { getAllServicesWithSlugs } from "./services";
import navConfig from "@/data/nav.json";
import { NavItem } from "@/types/nav";
import { getFeatureMode, isMSPMode, shouldShowDeveloperDocs } from "./feature-mode";

export type { NavItem };

export function enrichNavigation(items: NavItem[]): NavItem[] {
    const services = getAllServicesWithSlugs();
    const nav = JSON.parse(JSON.stringify(items));

    // Find Features/Services item
    const featuresItem = nav.find((item: NavItem) =>
        item.id === "features" || item.id === "services"
    );

    // Only auto-inject if children are empty or missing
    if (featuresItem && (!featuresItem.children || featuresItem.children.length === 0)) {
        featuresItem.children = services.map((service: any) => ({
            id: `service-${service.slug}`,
            label: service.shortTitle || service.title,
            href: `/features/${service.slug}`,
            icon: service.icon
        }));
    }

    return nav;
}

export function getNavigation(): NavItem[] {
    const baseNav = enrichNavigation(navConfig.navigation as NavItem[]);

    // Filter and transform navigation based on mode
    return baseNav.map(item => {
        // Filter out developer docs in production unless developer mode
        if (item.id === 'docs' && item.children) {
            item.children = item.children.filter(child => {
                if (child.id === 'docs-developers') {
                    return shouldShowDeveloperDocs();
                }
                return true;
            });
        }

        // Rename Features/Services based on mode
        if (item.id === 'features' || item.id === 'services') {
            item.label = isMSPMode() ? 'Services' : 'Features';
        }

        return item;
    });
}
