'use client';

import { BookOpen, FileText, Image, FolderOpen, Users, Search, BarChart, ArrowLeft } from 'lucide-react';
import { HubSectionCard } from '@/components/admin/HubSectionCard';
import { AdminHeader } from '@/components/admin/AdminHeader';
import { Breadcrumbs } from '@/components/admin/Breadcrumbs';
import { HUB_PAGE_STYLES } from '@/lib/admin-hub-styles';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useAdminActions } from '@/hooks/useAdminActions';

interface GrowthStats {
    trafficScore: number;
    revenue: string;
    conversionRate: string;
    subscribers: number;
}

export default function GrowthHubPage() {
    useAdminActions([
        {
            id: 'seo-wizard',
            label: 'Start SEO Wizard',
            href: '/admin/growth/seo',
            variant: 'primary',
            showOnMobile: true,
            icon: <Search className="w-4 h-4" />
        },
        {
            id: 'analytics',
            label: 'Analytics',
            href: '/admin/analytics',
            variant: 'ghost',
            disabled: true,
            icon: <BarChart className="w-4 h-4" />
        }
    ]);

    const [stats, setStats] = useState<GrowthStats>({
        trafficScore: 0,
        revenue: '$0',
        conversionRate: '0%',
        subscribers: 0
    });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Placeholder for stats fetching
        // In a real implementation, this would fetch from analytics APIs
        setStats({
            trafficScore: 45,
            revenue: '$1,234',
            conversionRate: '3.2%',
            subscribers: 156
        });
        setLoading(false);
    }, []);

    return (
        <div className={HUB_PAGE_STYLES.container}>
            <div className={`${HUB_PAGE_STYLES.maxWidth} ${HUB_PAGE_STYLES.topPadding} space-y-8`}>
                <AdminHeader
                    title={<>Growth <span className="text-emerald-500">Hub</span> 🚀</>}
                    description="Optimize your reach, revenue, and engagement."
                    breadcrumbs={[
                        { label: 'Admin', href: '/admin' },
                        { label: 'Growth' }
                    ]}
                    badge={
                        <div className="px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-[10px] font-bold uppercase tracking-widest text-emerald-600 dark:text-emerald-400 flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                            Engine Active
                        </div>
                    }
                    actions={
                        <Link
                            href="/admin"
                            className="px-3 py-1.5 bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 rounded-lg text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
                        >
                            <ArrowLeft size={12} /> Back
                        </Link>
                    }
                />

                {/* Quick Stats */}
                {!loading && (
                    <div className={HUB_PAGE_STYLES.stats.grid}>
                        <div className="p-4 bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800">
                            <div className="text-2xl font-black text-zinc-900 dark:text-white">{stats.trafficScore}</div>
                            <div className="text-xs text-zinc-500 dark:text-zinc-400 uppercase font-bold tracking-wider">Traffic Score</div>
                        </div>
                        <div className="p-4 bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800">
                            <div className="text-2xl font-black text-zinc-900 dark:text-white">{stats.revenue}</div>
                            <div className="text-xs text-zinc-500 dark:text-zinc-400 uppercase font-bold tracking-wider">Revenue</div>
                        </div>
                        <div className="p-4 bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800">
                            <div className="text-2xl font-black text-zinc-900 dark:text-white">{stats.conversionRate}</div>
                            <div className="text-xs text-zinc-500 dark:text-zinc-400 uppercase font-bold tracking-wider">Conversion Rate</div>
                        </div>
                        <div className="p-4 bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800">
                            <div className="text-2xl font-black text-zinc-900 dark:text-white">{stats.subscribers}</div>
                            <div className="text-xs text-zinc-500 dark:text-zinc-400 uppercase font-bold tracking-wider">Subscribers</div>
                        </div>
                    </div>
                )}

                {/* Section Cards */}
                <div className={HUB_PAGE_STYLES.sectionCards.grid}>
                    <HubSectionCard
                        title="SEO Toolkit"
                        description="Optimize for search engines and organic traffic"
                        icon={<span className="text-2xl">🔍</span>}
                        gradient="green"
                        href="/admin/growth/seo"
                        blockId="growth-hub-seo-card"
                    />

                    <HubSectionCard
                        title="Analytics Dashboard"
                        description="Track visitor behavior, traffic sources, and engagement metrics"
                        icon={<span className="text-2xl">📊</span>}
                        gradient="blue"
                        href="/admin/growth/analytics"
                        status="coming-soon"
                        blockId="growth-hub-analytics-card"
                    />

                    <HubSectionCard
                        title="Revenue Streams"
                        description="Manage subscriptions, AdSense, and sponsor partnerships"
                        icon={<span className="text-2xl">💸</span>}
                        gradient="purple"
                        href="/admin/growth/monetization"
                        blockId="growth-hub-revenue-card"
                    />

                    <HubSectionCard
                        title="Newsletter Hub"
                        description="Build and nurture your email subscriber community"
                        icon={<span className="text-2xl">📧</span>}
                        gradient="orange"
                        href="/admin/growth/newsletter"
                        status="coming-soon"
                        blockId="growth-hub-newsletter-card"
                    />
                </div>

                {/* Quick Actions */}
                <div className="p-6 bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800">
                    <h3 className="text-sm font-black uppercase tracking-widest text-zinc-400 mb-4">Quick Actions</h3>
                    <div className="flex flex-wrap gap-3">
                        <Link
                            href="/admin/growth/seo"
                            className="px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm font-bold hover:bg-emerald-700 transition-colors"
                        >
                            Start SEO Wizard
                        </Link>
                        <button
                            disabled
                            className="px-4 py-2 bg-zinc-200 dark:bg-zinc-800 text-zinc-400 rounded-lg text-sm font-bold cursor-not-allowed"
                        >
                            View Analytics Report
                        </button>
                        <Link
                            href="/admin/growth/monetization"
                            className="px-4 py-2 bg-purple-600 text-white rounded-lg text-sm font-bold hover:bg-purple-700 transition-colors"
                        >
                            Configure Monetization
                        </Link>
                    </div>
                </div>
            </div>
        </div>
    );
}
