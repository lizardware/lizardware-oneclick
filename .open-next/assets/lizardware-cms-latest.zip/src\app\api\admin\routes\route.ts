import { NextResponse } from 'next/server';
import { getSystemRoutes, getContentRoutes } from '@/lib/routes';



export async function GET() {
    try {
        const systemRoutes = getSystemRoutes(true);
        const contentRoutes = await getContentRoutes();

        return NextResponse.json({
            system: systemRoutes,
            content: contentRoutes,
            all: [...systemRoutes, ...contentRoutes]
        });
    } catch (error) {
        console.error('Failed to fetch routes:', error);
        return NextResponse.json({ error: 'Failed to fetch routes' }, { status: 500 });
    }
}
