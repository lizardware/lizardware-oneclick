import { getAllDocs } from '@/data/docs-content';
import Link from 'next/link';
import { Metadata } from 'next';
import { ArrowLeft } from 'lucide-react';
import { AdminHeader } from "@/components/admin/AdminHeader";

export const metadata: Metadata = {
    title: 'Documentation | Lizardware Admin',
};

export default function AdminDocsDirectory() {
    const docs = getAllDocs();

    // Group docs by category (first part of slug)
    const categories: Record<string, typeof docs> = {};
    docs.forEach(doc => {
        const parts = doc.slug.split('/');
        const category = parts.length > 1 ? parts[0] : 'general';
        if (!categories[category]) categories[category] = [];
        categories[category].push(doc);
    });

    return (
        <div className="max-w-7xl mx-auto px-6 pt-0 pb-12 space-y-8">

            <AdminHeader
                title={<>System <span className="text-emerald-500">Documentation</span></>}
                description="Comprehensive knowledge base for the entire platform."
                breadcrumbs={[
                    { label: 'Admin', href: '/admin' },
                    { label: 'System', href: '/admin/system' },
                    { label: 'Docs' }
                ]}
                badge={
                    <div className="px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-[10px] font-bold uppercase tracking-widest text-emerald-600 dark:text-emerald-400">
                        Reference Library
                    </div>
                }
                actions={
                    <Link
                        href="/admin/system"
                        className="px-3 py-1.5 bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 rounded-lg text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
                    >
                        <ArrowLeft size={12} /> Back
                    </Link>
                }
            />

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {Object.entries(categories).map(([category, items]) => (
                    <div key={category} className="bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-3xl p-6 shadow-sm hover:shadow-md transition-all">
                        <h2 className="text-[10px] font-black uppercase tracking-[0.2em] text-primary mb-4 pb-2 border-b border-gray-50 dark:border-zinc-800">
                            {category}
                        </h2>
                        <ul className="space-y-2">
                            {items.sort((a, b) => a.slug.localeCompare(b.slug)).map(doc => (
                                <li key={doc.slug}>
                                    <Link
                                        href={doc.slug === 'changelog' ? '/admin/system/changelog' : (doc.slug === 'developers/roadmap' ? '/admin/system/roadmap' : `/admin/system/docs/${doc.slug}`)}
                                        className="text-sm font-bold text-zinc-600 dark:text-zinc-400 hover:text-primary transition-colors block py-1"
                                    >
                                        {doc.title}
                                    </Link>
                                </li>
                            ))}
                        </ul>
                    </div>
                ))}
            </div>
        </div>
    );
}
