-- Seed: Restaurant / Hospitality
-- Created: 2026-01-03
-- Strategy: Placeholders for Menu, Reservations, and About

-- 1. Blog Posts (News/Events)
INSERT OR IGNORE INTO posts (slug, title, content, description, author, author_id, tags, date, status, created_at, updated_at)
VALUES (
  'seasonal-menu-update',
  'New Seasonal Menu Arrives',
  '<h1>Taste the Season</h1><p>We are excited to announce our new seasonal menu featuring fresh, locally-sourced ingredients. From heirloom tomatoes to wild-caught seafood, our chef has curated a dining experience that celebrates the flavors of the season.</p><h2>Highlights</h2><ul><li><strong>Appetizer:</strong> Grilled Artichoke with Lemon Aioli</li><li><strong>Main:</strong> Pan-Seared Scallops with Truffle Risotto</li><li><strong>Dessert:</strong> House-made Tiramisu</li></ul><p>Join us this weekend to taste the magic!</p>',
  'Announcing our new seasonal menu highlights.',
  'Head Chef',
  'chef',
  '["Menu", "News"]',
  datetime('now'),
  'published',
  datetime('now'),
  datetime('now')
);

INSERT OR IGNORE INTO posts (slug, title, content, description, author, author_id, tags, date, status, created_at, updated_at)
VALUES (
  'meet-the-team',
  'Meet Our Culinary Team',
  '<h1>Passion in Every Dish</h1><p>Our kitchen is driven by a diverse team of culinary experts dedicated to crafting unforgettable meals.</p><p>We believe that great food starts with great people. Stop by the open kitchen to say hello!</p>',
  'A look behind the scenes at our talented kitchen staff.',
  'Restaurant Manager',
  'manager',
  '["Team", "Behind the Scenes"]',
  datetime('now', '-7 days'),
  'published',
  datetime('now'),
  datetime('now')
);

-- 2. Pages
-- Home
INSERT OR IGNORE INTO pages (slug, title, content, description, status, sort_order, created_at, updated_at)
VALUES (
  'welcome',
  'Welcome to {{siteName}}',
  '<h1>Experience Excellence</h1><p>Welcome to {{siteName}}, where culinary tradition meets modern innovation. Located in the heart of the city, we offer a dining experience like no other.</p><h2>Our Philosophy</h2><p>We believe in sustainable sourcing, meticulous preparation, and warm hospitality.</p><h3>Reserve Your Table</h3><p>Space is limited. <a href="/reservations">Book now</a> to secure your spot.</p>',
  'Welcome to {{siteName}} - Fine dining experience.',
  'published',
  0,
  datetime('now'),
  datetime('now')
);

-- Menu Page
INSERT OR IGNORE INTO pages (slug, title, content, description, status, sort_order, created_at, updated_at)
VALUES (
  'menu',
  'Our Menu',
  '<h1>Our Offerings</h1><p>Explore our carefully curated selection of dishes.</p><h2>Starters</h2><ul><li>Soup of the Day - $12</li><li>Burrata Salad - $16</li></ul><h2>Mains</h2><ul><li>Wagyu Burger - $24</li><li>Grilled Salmon - $28</li><li>Mushroom Risotto (V) - $22</li></ul><h2>Desserts</h2><ul><li>Chocolate Lava Cake - $10</li><li>Artisan Cheese Board - $18</li></ul>',
  'View our full menu including starters, mains, and desserts.',
  'published',
  10,
  datetime('now'),
  datetime('now')
);

-- Reservations Page
INSERT OR IGNORE INTO pages (slug, title, content, description, status, sort_order, created_at, updated_at)
VALUES (
  'reservations',
  'Reservations',
  '<h1>Book a Table</h1><p>We accept reservations up to 30 days in advance. For parties larger than 8, please contact us directly.</p><p><em>(Reservation widget placeholder)</em></p><h3>Hours of Operation</h3><p>Mon-Sun: 5:00 PM - 10:00 PM</p>',
  'Book a table at {{siteName}}.',
  'published',
  20,
  datetime('now'),
  datetime('now')
);

-- About Page
INSERT OR IGNORE INTO pages (slug, title, content, description, status, sort_order, created_at, updated_at)
VALUES (
  'about',
  'Our Story',
  '<h1>From Farm to Table</h1><p>Since opening our doors, {{siteName}} has been committed to serving the community with honest, delicious food.</p><p>Our journey began with a simple idea: that good food brings people together.</p>',
  'The story behind {{siteName}}.',
  'published',
  30,
  datetime('now'),
  datetime('now')
);
