'use client';

import React, { useState, useEffect, useRef } from 'react';
import { RouteItem } from '@/lib/routes';

interface RoutePickerProps {
    value: string;
    onChange: (value: string) => void;
    placeholder?: string;
    className?: string;
}

export function RoutePicker({ value, onChange, placeholder = 'Select or type a path...', className = '' }: RoutePickerProps) {
    const [isOpen, setIsOpen] = useState(false);
    const [routes, setRoutes] = useState<RouteItem[]>([]);
    const [filteredRoutes, setFilteredRoutes] = useState<RouteItem[]>([]);
    const [loading, setLoading] = useState(false);
    const [selectedIndex, setSelectedIndex] = useState(0);
    const containerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        async function fetchRoutes() {
            setLoading(true);
            try {
                const res = await fetch('/api/admin/routes');
                const data = await res.json() as { all: RouteItem[] };
                if (data && data.all) {
                    setRoutes(data.all);
                    setFilteredRoutes(data.all);
                }
            } catch (error) {
                console.error('Failed to fetch routes:', error);
            } finally {
                setLoading(false);
            }
        }
        fetchRoutes();
    }, []);

    useEffect(() => {
        const filtered = routes.filter(r =>
            r.path.toLowerCase().includes(value.toLowerCase()) ||
            r.label.toLowerCase().includes(value.toLowerCase())
        );
        setFilteredRoutes(filtered);
        setSelectedIndex(0);
    }, [value, routes]);

    useEffect(() => {
        function handleClickOutside(event: MouseEvent) {
            if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        }
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handleKeyDown = (e: React.KeyboardEvent) => {
        if (!isOpen && (e.key === 'ArrowDown' || e.key === 'Enter')) {
            setIsOpen(true);
            return;
        }

        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setSelectedIndex(prev => (prev + 1) % Math.max(1, filteredRoutes.length));
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setSelectedIndex(prev => (prev - 1 + filteredRoutes.length) % Math.max(1, filteredRoutes.length));
        } else if (e.key === 'Enter' && filteredRoutes.length > 0) {
            e.preventDefault();
            const selected = filteredRoutes[selectedIndex];
            onChange(selected.path);
            setIsOpen(false);
        } else if (e.key === 'Escape') {
            setIsOpen(false);
        }
    };

    return (
        <div ref={containerRef} className={`relative ${className}`}>
            <div className="relative">
                <input
                    type="text"
                    value={value}
                    onChange={(e) => {
                        onChange(e.target.value);
                        setIsOpen(true);
                    }}
                    onFocus={() => setIsOpen(true)}
                    onKeyDown={handleKeyDown}
                    placeholder={placeholder}
                    className="w-full px-4 py-3 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-white/10 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all font-medium text-sm"
                />
                <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-2">
                    {loading && (
                        <svg className="animate-spin h-4 w-4 text-zinc-400" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                        </svg>
                    )}
                    {value && !loading && (
                        <div className="flex items-center">
                            {routes.some(r => r.path === value) || value.startsWith('http') ? (
                                <div className="text-emerald-500 bg-emerald-500/10 p-1 rounded-full" title="Valid internal path or external URL">
                                    <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                                    </svg>
                                </div>
                            ) : (
                                <div className="text-amber-500 bg-amber-500/10 p-1 rounded-full" title="Possible 404: Path not found in registry">
                                    <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                                    </svg>
                                </div>
                            )}
                        </div>
                    )}
                    <button
                        type="button"
                        onClick={() => setIsOpen(!isOpen)}
                        className="text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 transition-colors"
                    >
                        <svg className={`w-4 h-4 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                        </svg>
                    </button>
                </div>
            </div>

            {isOpen && (
                <div className="absolute z-[100] w-full mt-2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-white/10 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
                    <div className="max-h-[300px] overflow-y-auto p-2 space-y-1">
                        {filteredRoutes.length === 0 ? (
                            <div className="px-4 py-8 text-center">
                                <p className="text-sm text-zinc-500 italic">No matching routes found</p>
                                <p className="text-[10px] text-zinc-400 mt-1 uppercase tracking-widest font-bold">Using custom path: {value}</p>
                            </div>
                        ) : (
                            filteredRoutes.map((route, index) => (
                                <button
                                    key={route.path}
                                    onClick={() => {
                                        onChange(route.path);
                                        setIsOpen(false);
                                    }}
                                    onMouseEnter={() => setSelectedIndex(index)}
                                    className={`w-full text-left px-4 py-3 rounded-xl transition-all flex items-start justify-between group ${selectedIndex === index
                                        ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20'
                                        : 'hover:bg-zinc-100 dark:hover:bg-white/5'
                                        }`}
                                >
                                    <div className="flex flex-col">
                                        <span className="font-bold text-sm flex items-center gap-2">
                                            {route.label}
                                            <span className={`text-[9px] uppercase tracking-widest px-1.5 py-0.5 rounded-md font-black ${selectedIndex === index
                                                ? 'bg-white/20 text-white'
                                                : 'bg-zinc-100 dark:bg-white/10 text-zinc-500'
                                                }`}>
                                                {route.type}
                                            </span>
                                        </span>
                                        <span className={`text-xs ${selectedIndex === index ? 'text-blue-100' : 'text-zinc-500'}`}>
                                            {route.path}
                                        </span>
                                    </div>
                                    {selectedIndex === index && (
                                        <svg className="w-4 h-4 animate-in slide-in-from-left-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                                        </svg>
                                    )}
                                </button>
                            ))
                        )}
                    </div>
                    <div className="p-3 bg-zinc-50 dark:bg-black/20 border-t border-zinc-200 dark:border-white/5 flex items-center justify-between">
                        <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">
                            Navigation Intelligence v1.0
                        </span>
                        <div className="flex gap-2">
                            <span className="px-1.5 py-0.5 rounded border border-zinc-200 dark:border-white/20 text-[9px] font-bold text-zinc-400">ESC to close</span>
                            <span className="px-1.5 py-0.5 rounded border border-zinc-200 dark:border-white/20 text-[9px] font-bold text-zinc-400">↵ to select</span>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
