"use client";

import React, { createContext, useContext, useState, useCallback, ReactNode } from "react";
import { Info, AlertCircle, CheckCircle2, X } from "lucide-react";
import { createPortal } from "react-dom";

type PopupType = "alert" | "confirm" | "success" | "error";

interface PopupOptions {
    title?: string;
    confirmLabel?: string;
    cancelLabel?: string;
    isDanger?: boolean;
}

interface PopupState {
    isOpen: boolean;
    type: PopupType;
    message: string;
    title?: string;
    confirmLabel?: string;
    cancelLabel?: string;
    isDanger?: boolean;
    resolve?: (value: boolean) => void;
}

interface PopupContextType {
    alert: (message: string, options?: PopupOptions) => Promise<boolean>;
    confirm: (message: string, options?: PopupOptions) => Promise<boolean>;
    success: (message: string) => void;
    error: (message: string) => void;
}

const PopupContext = createContext<PopupContextType | undefined>(undefined);

export const usePopup = () => {
    const context = useContext(PopupContext);
    if (!context) {
        throw new Error("usePopup must be used within a PopupProvider");
    }
    return context;
};

export const PopupProvider = ({ children }: { children: ReactNode }) => {
    const [state, setState] = useState<PopupState>({
        isOpen: false,
        type: "alert",
        message: "",
    });

    const show = useCallback((type: PopupType, message: string, options: PopupOptions = {}) => {
        return new Promise<boolean>((resolve) => {
            setState({
                isOpen: true,
                type,
                message,
                ...options,
                resolve,
            });
        });
    }, []);

    const alert = (message: string, options?: PopupOptions) => show("alert", message, { title: "Nexus Protocol", ...options });
    const confirm = (message: string, options?: PopupOptions) => show("confirm", message, { title: "Confirmation Required", ...options });

    // Toast-like alerts for success/error
    const success = (message: string) => {
        // For now, let's use a non-blocking alert or just a regular alert
        // The user wants to avoid native popups
        show("success", message, { title: "Success" });
    };

    const error = (message: string) => {
        show("error", message, { title: "System Error", isDanger: true });
    };

    const close = (value: boolean) => {
        if (state.resolve) {
            state.resolve(value);
        }
        setState((prev) => ({ ...prev, isOpen: false }));
    };

    return (
        <PopupContext.Provider value={{ alert, confirm, success, error }}>
            {children}
            {state.isOpen && typeof document !== "undefined" && createPortal(
                <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
                    {/* Backdrop with high-end blur */}
                    <div
                        className="absolute inset-0 bg-black/60 backdrop-blur-md animate-in fade-in duration-300"
                        onClick={() => state.type === "alert" || state.type === "success" || state.type === "error" ? close(true) : null}
                    />

                    {/* The Popup Card */}
                    <div className="relative w-full max-w-sm bg-white dark:bg-zinc-900 rounded-[2.5rem] shadow-[0_32px_64px_-16px_rgba(0,0,0,0.5)] border border-white/10 overflow-hidden transform animate-in zoom-in-95 slide-in-from-bottom-8 duration-500 ease-out">
                        {/* Visual Header Accent */}
                        <div className={`h-2 w-full ${state.isDanger ? 'bg-red-500' : 'bg-blue-600'}`} />

                        <div className="p-8 space-y-6">
                            <div className="flex items-start gap-4">
                                <div className={`p-4 rounded-2xl ${state.isDanger ? 'bg-red-500/10 text-red-500' : 'bg-blue-600/10 text-blue-600'} flex-shrink-0`}>
                                    {state.isDanger ? <AlertCircle size={24} /> : (state.type === 'success' ? <CheckCircle2 size={24} /> : <Info size={24} />)}
                                </div>
                                <div className="space-y-1">
                                    <h3 className="text-xs font-black uppercase tracking-[0.2em] text-zinc-400 dark:text-zinc-500">
                                        {state.title || "Transmission"}
                                    </h3>
                                    <p className="text-xl font-black text-zinc-900 dark:text-white leading-tight">
                                        {state.message}
                                    </p>
                                </div>
                            </div>

                            <div className="flex gap-3 pt-2">
                                {state.type === "confirm" && (
                                    <button
                                        onClick={() => close(false)}
                                        className="flex-1 px-6 py-4 rounded-2xl bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 font-bold text-xs uppercase tracking-widest hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-all active:scale-95"
                                    >
                                        {state.cancelLabel || "Abort"}
                                    </button>
                                )}
                                <button
                                    onClick={() => close(true)}
                                    className={`flex-1 px-6 py-4 rounded-2xl font-black text-xs uppercase tracking-widest transition-all active:scale-95 shadow-lg shadow-blue-600/20 text-white ${state.isDanger ? 'bg-red-600 hover:bg-red-700' : 'bg-blue-600 hover:bg-blue-700'
                                        }`}
                                >
                                    {state.confirmLabel || "Acknowledge"}
                                </button>
                            </div>
                        </div>

                        {/* Micro-interactive close button for non-critical alerts */}
                        {(state.type === 'success' || state.type === 'alert') && (
                            <button
                                onClick={() => close(true)}
                                className="absolute top-4 right-4 p-2 text-zinc-300 hover:text-zinc-600 dark:hover:text-white transition-colors"
                            >
                                <X size={16} />
                            </button>
                        )}
                    </div>
                </div>,
                document.body
            )}
        </PopupContext.Provider>
    );
};
