import Link from "next/link";
import { getAllPosts } from "@/lib/blog";

export const metadata = {
    title: "Tags | Lizardware Blog",
    description: "Browse blog posts by topic and category.",
};

export default async function TagsPage() {
    const posts = await getAllPosts();

    // Aggregate tags and count posts
    const tagCounts = posts.reduce((acc, post) => {
        if (post.tags && Array.isArray(post.tags)) {
            post.tags.forEach(tag => {
                const normalizedTag = tag.trim();
                if (normalizedTag) {
                    acc[normalizedTag] = (acc[normalizedTag] || 0) + 1;
                }
            });
        }
        return acc;
    }, {} as Record<string, number>);

    const sortedTags = Object.entries(tagCounts)
        .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));

    return (
        <div className="max-w-[1024px] mx-auto px-4 py-12">
            <h1 className="text-title font-bold text-page-title mb-4">Tags</h1>
            <p className="text-lg text-page-text mb-12">
                Explore articles by topic. From IT strategy to cybersecurity, find exactly what you&apos;re looking for.
            </p>

            <div className="flex flex-wrap gap-4">
                {sortedTags.map(([tag, count]) => (
                    <Link
                        key={tag}
                        href={`/blog/tag/${tag.toLowerCase().replace(/\s+/g, '-')}`}
                        className="group flex items-center gap-3 px-6 py-3 bg-white dark:bg-zinc-900 border border-borders rounded-full hover:border-primary hover:shadow-md transition-all"
                    >
                        <span className="font-semibold text-slate-700 dark:text-zinc-300 group-hover:text-primary">
                            #{tag}
                        </span>
                        <span className="bg-slate-100 dark:bg-zinc-800 text-slate-500 dark:text-zinc-400 text-xs px-2 py-1 rounded-full group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                            {count}
                        </span>
                    </Link>
                ))}

                {sortedTags.length === 0 && (
                    <div className="text-center py-12 text-slate-400 italic w-full">
                        No tags found in any published posts.
                    </div>
                )}
            </div>
        </div>
    );
}
