import { NextResponse } from 'next/server';
import { getD1Database } from '@/lib/cloudflare';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
    try {
        const { action, slugs, status } = await request.json() as {
            action: 'delete' | 'status',
            slugs: string[],
            status?: 'published' | 'draft'
        };

        if (!slugs || slugs.length === 0) {
            return NextResponse.json({ error: 'No items selected' }, { status: 400 });
        }

        const db = await getD1Database();
        if (!db) {
            return NextResponse.json({ error: 'Database not available' }, { status: 503 });
        }

        if (action === 'delete') {
            // Bulk delete
            const placeholders = slugs.map(() => '?').join(',');
            await db.prepare(`DELETE FROM posts WHERE slug IN (${placeholders})`).bind(...slugs).run();
        } else if (action === 'status' && status) {
            // Bulk status update
            const placeholders = slugs.map(() => '?').join(',');
            await db.prepare(`UPDATE posts SET status = ?, updated_at = ? WHERE slug IN (${placeholders})`)
                .bind(status, new Date().toISOString(), ...slugs)
                .run();
        }

        return NextResponse.json({ success: true, count: slugs.length });
    } catch (error) {
        console.error('Blog bulk operation failed:', error);
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
    }
}
