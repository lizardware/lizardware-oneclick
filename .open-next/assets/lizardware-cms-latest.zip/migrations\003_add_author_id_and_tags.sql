-- Migration: Add author_id and tags to posts table
-- Created: 2025-12-17

-- ALTER TABLE posts ADD COLUMN author_id TEXT;
-- ALTER TABLE posts ADD COLUMN tags TEXT; -- Stored as JSON string

-- Add index for author filtering
CREATE INDEX IF NOT EXISTS idx_posts_author_id ON posts(author_id);
-- Index for tags is harder in SQLite/D1 without FTS or specific extensions, 
-- but we can still index the column for exact matches or prefix searches if needed.
CREATE INDEX IF NOT EXISTS idx_posts_tags ON posts(tags);
