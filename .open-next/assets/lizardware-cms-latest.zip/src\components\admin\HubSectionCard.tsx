'use client';

import Link from 'next/link';
import { CARD_GRADIENTS, type GradientColor } from '@/lib/admin-hub-styles';

interface HubSectionCardProps {
    // Content
    title: string;
    description: string;
    icon: React.ReactNode;
    stats?: string; // Optional stats line

    // Styling
    gradient: GradientColor;

    // Navigation
    href: string;
    status?: 'active' | 'coming-soon' | 'disabled';
    target?: '_blank' | '_self';

    // Block metadata (for future block system integration)
    blockId?: string;
    blockConfig?: Record<string, any>;
}

export function HubSectionCard({
    title,
    description,
    icon,
    stats,
    gradient,
    href,
    status = 'active',
    target = '_self',
    blockId,
    blockConfig,
}: HubSectionCardProps) {
    const isActive = status === 'active';

    if (!isActive) {
        return (
            <div
                className={`p-6 bg-gradient-to-br ${CARD_GRADIENTS[gradient]} border-2 rounded-2xl opacity-50 grayscale select-none`}
                data-block-id={blockId}
                data-block-config={blockConfig ? JSON.stringify(blockConfig) : undefined}
            >
                <div className="flex items-start justify-between mb-4">
                    <div className="p-3 bg-white/80 dark:bg-zinc-900/80 rounded-xl">
                        {icon}
                    </div>
                    <span className="text-[8px] px-1.5 py-0.5 bg-zinc-200 dark:bg-zinc-800 text-zinc-500 rounded-md font-black uppercase">
                        {status === 'coming-soon' ? 'Coming Soon' : 'Disabled'}
                    </span>
                </div>

                <h3 className="text-xl font-black text-zinc-900 dark:text-white mb-2">
                    {title}
                </h3>

                <p className="text-sm text-zinc-600 dark:text-zinc-400 leading-relaxed">
                    {description}
                </p>
            </div>
        );
    }

    return (
        <Link
            href={href}
            target={target}
            className={`group relative p-6 bg-gradient-to-br ${CARD_GRADIENTS[gradient]} border-2 rounded-2xl transition-all duration-300 hover:-translate-y-1 hover:shadow-xl block`}
            data-block-id={blockId}
            data-block-config={blockConfig ? JSON.stringify(blockConfig) : undefined}
        >
            {/* Icon */}
            <div className="p-3 bg-white/80 dark:bg-zinc-900/80 rounded-xl mb-4 inline-flex">
                {icon}
            </div>

            {/* Arrow indicator */}
            <svg
                className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity absolute top-6 right-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
            >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 7l5 5m0 0l-5 5m5-5H6" />
            </svg>

            {/* Title */}
            <h3 className="text-xl font-black text-zinc-900 dark:text-white mb-2">
                {title}
            </h3>

            {/* Description */}
            <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-4 leading-relaxed">
                {description}
            </p>

            {/* Stats (optional) */}
            {stats && (
                <div className="text-xs font-bold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">
                    {stats}
                </div>
            )}
        </Link>
    );
}
