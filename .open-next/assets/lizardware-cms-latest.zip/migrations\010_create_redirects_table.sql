-- Migration: Create redirects table for 301/302 URL redirects
-- Version: 0.3.0
-- Purpose: Enable SEO-friendly URL redirects for moved or renamed content

CREATE TABLE IF NOT EXISTS redirects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_path TEXT NOT NULL UNIQUE,
  destination_path TEXT NOT NULL,
  type INTEGER NOT NULL DEFAULT 301,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_redirects_source ON redirects(source_path);
