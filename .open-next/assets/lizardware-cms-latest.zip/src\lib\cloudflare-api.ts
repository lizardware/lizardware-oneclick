/**
 * Cloudflare API Integration Utilities
 * Used for auto-provisioning KV, D1, and R2 resources.
 * Note: Uses dynamic imports for 'fs' to ensure Edge compatibility.
 */

interface CloudflareClient {
    apiToken: string;
    accountId: string;
}

/**
 * Creates a KV Namespace (Idempotent)
 */
export async function createKVNamespace(client: CloudflareClient, title: string) {
    // 1. Attempt to create
    const response = await fetch(
        `https://api.cloudflare.com/client/v4/accounts/${client.accountId}/storage/kv/namespaces`,
        {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${client.apiToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ title })
        }
    );

    const data = await response.json() as any;

    if (response.ok) {
        return data.result;
    }

    // 2. If failed, check if it's because it already exists
    // Error 10014: "A namespace with this account ID and title already exists"
    const errorMsg = data.errors?.[0]?.message || '';
    if (errorMsg.includes('already exists')) {
        console.log(`[KV] Namespace '${title}' exists. Fetching ID with pagination...`);

        // Paginate through namespaces to find the existing one
        // KV list endpoint does not support filtering by title, so we must list all.
        let page = 1;
        const perPage = 100; // Max per page roughly
        let found = null;
        let hasMore = true;

        while (hasMore && !found) {
            const listResponse = await fetch(
                `https://api.cloudflare.com/client/v4/accounts/${client.accountId}/storage/kv/namespaces?page=${page}&per_page=${perPage}`,
                {
                    method: 'GET',
                    headers: {
                        'Authorization': `Bearer ${client.apiToken}`,
                        'Content-Type': 'application/json'
                    }
                }
            );

            const listData = await listResponse.json() as any;

            if (listData.success && listData.result.length > 0) {
                found = listData.result.find((ns: any) => ns.title === title);
                if (!found) {
                    // Check logic for pagination end
                    const resultInfo = listData.result_info;
                    // If current page * per_page >= total_count, we are done
                    if (resultInfo && (page * resultInfo.per_page >= resultInfo.total_count)) {
                        hasMore = false;
                    } else {
                        page++;
                    }
                }
            } else {
                hasMore = false;
            }
        }

        if (found) {
            console.log(`[KV] Found existing namespace ID: ${found.id}`);
            return found;
        }
    }

    throw new Error(errorMsg || 'Failed to create KV namespace');
}

/**
 * Creates a D1 Database (Idempotent)
 */
export async function createD1Database(client: CloudflareClient, name: string) {
    const response = await fetch(
        `https://api.cloudflare.com/client/v4/accounts/${client.accountId}/d1/database`,
        {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${client.apiToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name })
        }
    );

    const data = await response.json() as any;

    if (response.ok) {
        return data.result;
    }

    // 2. Check for existence if failed
    const errorMsg = data.errors?.[0]?.message || '';
    if (errorMsg.includes('already exists') || errorMsg.includes('Duplicate')) {
        console.log(`[D1] Database '${name}' exists. Fetching ID using search...`);
        // Use 'name' query parameter to filter directly
        const listResponse = await fetch(
            `https://api.cloudflare.com/client/v4/accounts/${client.accountId}/d1/database?name=${encodeURIComponent(name)}`,
            {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${client.apiToken}`,
                    'Content-Type': 'application/json'
                }
            }
        );
        const listData = await listResponse.json() as any;
        if (listData.success) {
            // result is an array of matches
            const found = listData.result.find((db: any) => db.name === name);
            if (found) {
                console.log(`[D1] Found existing database UUID: ${found.uuid}`);
                return found;
            }
        }
    }

    throw new Error(errorMsg || 'Failed to create D1 database');
}

/**
 * Executes SQL queries on a D1 database
 */
export async function executeD1Migration(client: CloudflareClient, databaseId: string, sql: string) {
    // Split SQL into individual statements
    // This is a naive split, but generally works for standard migrations
    const statements = sql
        .split(';')
        .map(s => {
            // Remove comments (both full-line and inline)
            return s
                .split('\n')
                .map(line => {
                    // Strip inline comments (anything after --)
                    const commentIndex = line.indexOf('--');
                    if (commentIndex !== -1) {
                        line = line.substring(0, commentIndex);
                    }
                    return line.trim();
                })
                .filter(line => line.length > 0)
                .join(' ');
        })
        .filter(s => s.length > 0);

    const results = [];
    for (const statement of statements) {
        const response = await fetch(
            `https://api.cloudflare.com/client/v4/accounts/${client.accountId}/d1/database/${databaseId}/query`,
            {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${client.apiToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ sql: statement })
            }
        );

        const data = await response.json() as any;
        if (!response.ok || data.success === false) {
            const errorMsg = data.errors?.map((e: any) => e.message).join(', ') || 'Unknown Cloudflare error';
            const sqlContext = statement.length > 200 ? statement.substring(0, 200) + '...' : statement;
            throw new Error(`D1 Error: ${errorMsg} \nSQL: "${sqlContext}"`);
        }
        results.push(data.result);
    }

    return results;
}

/**
 * Creates an R2 Bucket
 */
export async function createR2Bucket(client: CloudflareClient, name: string) {
    const response = await fetch(
        `https://api.cloudflare.com/client/v4/accounts/${client.accountId}/r2/buckets/${name}`,
        {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${client.apiToken}`,
                'Content-Type': 'application/json'
            }
        }
    );

    const data = await response.json() as any;
    if (!response.ok) {
        throw new Error(data.errors?.[0]?.message || 'Failed to create R2 bucket');
    }

    return { name };
}

/**
 * Updates wrangler.jsonc with new binding IDs
 */
export async function updateWranglerConfig(kvId: string, d1Id: string, r2Name?: string) {
    try {
        const fs = (await import('fs')).default;
        const path = (await import('path')).default;

        const configPath = path.join(process.cwd(), 'wrangler.jsonc');

        // Safety check: In production/lambda/worker, we might not have write access or the file might not exist.
        if (!fs.existsSync(configPath)) {
            console.warn('[Cloudflare API] wrangler.jsonc not found (likely production environment). Skipping file update.');
            return false;
        }

        let configContent = fs.readFileSync(configPath, 'utf8');

        // 1. Update KV ID
        if (configContent.includes('"binding": "CONFIG_KV"')) {
            configContent = configContent.replace(
                /("binding":\s*"CONFIG_KV",\s*"id":\s*")[^"]*(")/,
                `$1${kvId}$2`
            );
        } else {
            console.warn('[Cloudflare API] CONFIG_KV binding not found in wrangler.jsonc');
        }

        // 2. Update D1 ID
        if (configContent.includes('"binding": "DB"')) {
            configContent = configContent.replace(
                /("binding":\s*"DB",[\s\S]*?"database_id":\s*")[^"]*(")/,
                `$1${d1Id}$2`
            );
        } else {
            console.warn('[Cloudflare API] DB binding not found in wrangler.jsonc');
        }

        // 3. Update or Add R2 Bucket Name (Only if successfully provisioned)
        if (r2Name) {
            if (configContent.includes('"binding": "MEDIA_BUCKET"')) {
                configContent = configContent.replace(
                    /("binding":\s*"MEDIA_BUCKET",\s*"bucket_name":\s*")[^"]*(")/,
                    `$1${r2Name}$2`
                );
            } else {
                // Add R2 buckets section if missing
                console.log('[Cloudflare API] Adding R2_BUCKETS section to wrangler.jsonc');
                const r2Section = `\n    "r2_buckets": [\n        {\n            "binding": "MEDIA_BUCKET",\n            "bucket_name": "${r2Name}"\n        }\n    ],`;

                // Try to insert before 'vars' or 'd1_databases' or at the end
                if (configContent.includes('"vars":')) {
                    configContent = configContent.replace(/"vars":/, `${r2Section}\n    "vars":`);
                } else if (configContent.includes('"d1_databases":')) {
                    // Find end of d1_databases array
                    const lastBraceIndex = configContent.lastIndexOf('}');
                    configContent = configContent.substring(0, lastBraceIndex) + r2Section + '\n' + configContent.substring(lastBraceIndex);
                }
            }
        }

        fs.writeFileSync(configPath, configContent, 'utf8');
        return true;
    } catch (error) {
        console.warn('[Cloudflare API] Failed to update wrangler.jsonc:', error);
        return false;
    }
}

/**
 * Sets an environment variable or secret for a WorkerScript
 */
export async function setWorkerEnvironmentVariable(
    client: CloudflareClient,
    scriptName: string,
    key: string,
    value: string,
    isSecret: boolean = false
) {
    if (isSecret) {
        const response = await fetch(
            `https://api.cloudflare.com/client/v4/accounts/${client.accountId}/workers/scripts/${scriptName}/secrets`,
            {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${client.apiToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    name: key,
                    text: value,
                    type: 'secret_text'
                })
            }
        );

        const data = await response.json() as any;
        if (!response.ok) {
            throw new Error(data.errors?.[0]?.message || `Failed to set secret ${key}`);
        }
        return data.result;
    } else {
        throw new Error("Setting plain text variables via API is not yet implemented safely. Use Secrets instead.");
    }
}
