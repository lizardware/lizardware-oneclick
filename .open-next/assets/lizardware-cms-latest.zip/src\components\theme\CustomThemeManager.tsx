'use client';

import { useEffect, useState } from 'react';
import { useTheme } from 'next-themes';
import { ThemeConfig } from '@/types/theme';

export function CustomThemeManager({ initialTheme }: { initialTheme: ThemeConfig | null }) {
  const [theme, setTheme] = useState<ThemeConfig | null>(initialTheme);
  const { theme: currentTheme, setTheme: setCurrentTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    // Only fetch if we don't have initial theme
    if (!initialTheme) {
      fetch('/api/config/theme')
        .then((res) => res.json())
        .then((data) => setTheme(data as ThemeConfig))
        .catch((err) => console.error('Failed to load theme:', err));
    }

    // Listen for preview updates and theme changes
    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'UPDATE_THEME') {
        console.log('CustomThemeManager: Received UPDATE_THEME', event.data.payload);
        setTheme(event.data.payload);
      }
      if (event.data?.type === 'SET_THEME' && mounted) {
        console.log('CustomThemeManager: Received SET_THEME', event.data.theme);
        setCurrentTheme(event.data.theme);
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [initialTheme, setCurrentTheme, mounted]);

  // Notify parent when theme changes (only if in iframe)
  useEffect(() => {
    if (window.parent !== window && currentTheme) {
      window.parent.postMessage({
        type: 'THEME_CHANGED',
        theme: currentTheme
      }, '*');
    }
  }, [currentTheme]);

  if (!theme) return null;

  const styleContent = `
    :root {
      /* Tier 1: Global */
      --body-background: ${theme.colors.light.bodyBackground};
      --header-background: ${theme.colors.light.headerBackground};
      --footer-background: ${theme.colors.light.footerBackground};
      --content-background: ${theme.colors.light.contentBackground};
      --borders: ${theme.colors.light.borders};

      /* Tier 1.5: Components */
      --accordion-background: ${theme.colors.light.accordionBackground};
      --button-background: ${theme.colors.light.buttonBackground};
      --card-background: ${theme.colors.light.cardBackground};
      --input-background: ${theme.colors.light.inputBackground};

      /* Tier 2: Page Sections */
      --page-bg-primary: ${theme.colors.light.pageBackgroundPrimary};
      --page-bg-secondary: ${theme.colors.light.pageBackgroundSecondary};
      --page-bg-alternate: ${theme.colors.light.pageBackgroundAlternate};
      --hero-background: ${theme.colors.light.heroBackground};

      /* Text & UI */
      --header-text: ${theme.colors.light.headerText};
      --footer-text: ${theme.colors.light.footerText};
      --page-title: ${theme.colors.light.pageTitle};
      --page-subtitle: ${theme.colors.light.pageSubtitle};
      --page-text: ${theme.colors.light.pageText};
      
      /* Legacy & Computed */
      --header-bg: var(--header-background);
      --site-background: var(--body-background);
      --page-background: var(--page-bg-primary);
      --info-box-bg: var(--content-background);
      --info-box-text: ${theme.colors.light.infoBoxText};
      --info-box-link-bg: ${theme.colors.light.infoBoxLinkBg};
      --info-box-link-text: ${theme.colors.light.infoBoxLinkText};
      --info-box-link-hover: ${theme.colors.light.infoBoxLinkHover};
      --section-header-bg: ${theme.colors.light.sectionHeader};
      --hero-bg: ${theme.colors.light.heroGradientEnabled ? `linear-gradient(to bottom right, ${theme.colors.light.heroGradientStart}, ${theme.colors.light.heroGradientEnd})` : theme.colors.light.heroBackground};
      --hero-text: ${theme.colors.light.heroText};
      
      /* Design Architecture */
      --space-radius-base: ${theme.borderRadius || '0.5rem'};
      --space-section: ${theme.spacing?.section || '4rem'};
      --space-container: ${theme.spacing?.container || '1.5rem'};
      --space-gap: ${theme.spacing?.gap || '1.25rem'};
      --space-header: ${theme.spacing?.header || '3rem'};
      --shadow-strength: ${theme.shadows?.strength || '0.1'};

      /* Typography Sizes (Storage) */
      --typo-title: ${theme.typography?.fontSizeTitle || '60px'};
      --typo-subtitle: ${theme.typography?.fontSizeSubtitle || '30px'};
      --typo-description: ${theme.typography?.fontSizeDescription || '24px'};
      --typo-base: ${theme.typography?.fontSizeBase || '16px'};
    }
    .dark {
      /* Tier 1: Global */
      --body-background: ${theme.colors.dark.bodyBackground};
      --header-background: ${theme.colors.dark.headerBackground};
      --footer-background: ${theme.colors.dark.footerBackground};
      --content-background: ${theme.colors.dark.contentBackground};
      --borders: ${theme.colors.dark.borders};

      /* Tier 1.5: Components */
      --accordion-background: ${theme.colors.dark.accordionBackground};
      --button-background: ${theme.colors.dark.buttonBackground};
      --card-background: ${theme.colors.dark.cardBackground};
      --input-background: ${theme.colors.dark.inputBackground};

      /* Tier 2: Page Sections */
      --page-bg-primary: ${theme.colors.dark.pageBackgroundPrimary};
      --page-bg-secondary: ${theme.colors.dark.pageBackgroundSecondary};
      --page-bg-alternate: ${theme.colors.dark.pageBackgroundAlternate};
      --hero-background: ${theme.colors.dark.heroBackground};

      /* Text & UI */
      --header-text: ${theme.colors.dark.headerText};
      --footer-text: ${theme.colors.dark.footerText};
      --page-title: ${theme.colors.dark.pageTitle};
      --page-subtitle: ${theme.colors.dark.pageSubtitle};
      --page-text: ${theme.colors.dark.pageText};

      /* Legacy & Computed */
      --header-bg: var(--header-background);
      --site-background: var(--body-background);
      --page-background: var(--page-bg-primary);
      --info-box-bg: var(--content-background);
      --info-box-text: ${theme.colors.dark.infoBoxText};
      --info-box-link-bg: ${theme.colors.dark.infoBoxLinkBg};
      --info-box-link-text: ${theme.colors.dark.infoBoxLinkText};
      --info-box-link-hover: ${theme.colors.dark.infoBoxLinkHover};
      --section-header-bg: ${theme.colors.dark.sectionHeader};
      --hero-bg: ${theme.colors.dark.heroGradientEnabled ? `linear-gradient(to bottom right, ${theme.colors.dark.heroGradientStart}, ${theme.colors.dark.heroGradientEnd})` : theme.colors.dark.heroBackground};
      --hero-text: ${theme.colors.dark.heroText};
      --shadow-strength: ${theme.shadows?.strength ? parseFloat(theme.shadows.strength) * 2.5 : '0.25'};

      /* Typography Sizes (Storage) */
      --typo-title: ${theme.typography?.fontSizeTitle || '60px'};
      --typo-subtitle: ${theme.typography?.fontSizeSubtitle || '30px'};
      --typo-description: ${theme.typography?.fontSizeDescription || '24px'};
      --typo-base: ${theme.typography?.fontSizeBase || '16px'};
    }
  `;

  return (
    <style dangerouslySetInnerHTML={{ __html: styleContent }} />
  );
}
