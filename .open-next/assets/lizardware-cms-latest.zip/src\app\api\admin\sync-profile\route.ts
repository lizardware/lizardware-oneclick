import { auth, currentUser } from '@clerk/nextjs/server';
import { getD1Database } from '@/lib/cloudflare';
import { NextResponse } from 'next/server';

export async function POST(req: Request) {
    const { userId } = await auth();

    if (!userId) {
        return new Response('Unauthorized', { status: 401 });
    }

    const user = await currentUser();
    if (!user) {
        return new Response('User not found', { status: 404 });
    }

    const { id, name, email, imageUrl }: { id: string, name: string, email: string, imageUrl: string } = await req.json();

    // Verify ID matches session
    if (id !== userId) {
        return new Response('Forbidden', { status: 403 });
    }

    try {
        const db = await getD1Database();
        if (db) {
            // Only update if needed or insert if missing
            await db.prepare(`
                INSERT INTO authors (id, name, email, image_url, role, updated_at)
                VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(id) DO UPDATE SET
                    name = excluded.name,
                    email = excluded.email,
                    image_url = excluded.image_url,
                    updated_at = CURRENT_TIMESTAMP
            `).bind(
                id,
                name || 'Anonymous',
                email || 'no-email@clerk.com',
                imageUrl || null,
                'owner' // Default for shadow sync if missing? Actually role should be from metadata
            ).run();

            return NextResponse.json({ success: true });
        }
    } catch (error) {
        console.error('Shadow sync error:', error);
        return new Response('Database error', { status: 500 });
    }

    return new Response('No database', { status: 500 });
}
