"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { PageMeta } from "@/types/page";
import { AdminLoadingState } from "./AdminLoadingState";
import { createPortal } from "react-dom";
import { CommandBarButton } from "./AdminCommandBar";
import { Trash2, Eye, EyeOff, CheckSquare, Square, X, Search, ChevronUp, ChevronDown } from "lucide-react";
import { VariableText } from "./VariableText";
import { usePopup } from "./AdminPopupProvider";

export default function PagesList() {
    const popup = usePopup();
    const [pages, setPages] = useState<PageMeta[]>([]);
    const [activeTab, setActiveTab] = useState<'all' | 'templates' | 'custom'>('all');
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [searchQuery, setSearchQuery] = useState("");
    const [statusFilter, setStatusFilter] = useState<'all' | 'published' | 'draft'>('all');
    const [selectedSlugs, setSelectedSlugs] = useState<Set<string>>(new Set());
    const [isBulkOperating, setIsBulkOperating] = useState(false);
    const [mounted, setMounted] = useState(false);
    const [sortBy, setSortBy] = useState<'updated' | 'title' | 'order'>('order');

    useEffect(() => {
        setMounted(true);
        async function fetchPages() {
            try {
                const response = await fetch("/api/admin/pages");
                if (!response.ok) {
                    throw new Error(`Failed to fetch pages: ${response.status}`);
                }
                const data = (await response.json()) as { pages: PageMeta[] };
                // Sort by sort_order if available, otherwise by updated_at
                const sorted = data.pages.sort((a, b) => {
                    const orderA = a.sort_order ?? 999;
                    const orderB = b.sort_order ?? 999;
                    if (orderA !== orderB) return orderA - orderB;
                    return new Date(b.updated_at || 0).getTime() - new Date(a.updated_at || 0).getTime();
                });
                setPages(sorted);
            } catch (err) {
                setError(err instanceof Error ? err.message : "Unknown error");
                console.error("Error fetching pages:", err);
            } finally {
                setLoading(false);
            }
        }
        fetchPages();
    }, []);

    // Selection Logic
    const toggleSelect = (slug: string, e?: React.MouseEvent) => {
        if (e) {
            e.preventDefault();
            e.stopPropagation();
        }
        const newSelected = new Set(selectedSlugs);
        if (newSelected.has(slug)) {
            newSelected.delete(slug);
        } else {
            newSelected.add(slug);
        }
        setSelectedSlugs(newSelected);
    };

    const toggleSelectAll = () => {
        if (selectedSlugs.size === filteredPages.length) {
            setSelectedSlugs(new Set());
        } else {
            setSelectedSlugs(new Set(filteredPages.map(p => p.slug)));
        }
    };

    const handleBulkAction = async (action: 'delete' | 'status', status?: 'published' | 'draft') => {
        if (selectedSlugs.size === 0) return;

        const confirmMsg = action === 'delete'
            ? `Are you sure you want to delete ${selectedSlugs.size} pages?`
            : `Update ${selectedSlugs.size} pages to ${status}?`;

        const confirmed = await popup.confirm(confirmMsg, { isDanger: action === 'delete' });
        if (!confirmed) return;

        setIsBulkOperating(true);
        try {
            const response = await fetch("/api/admin/pages/bulk", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    action,
                    slugs: Array.from(selectedSlugs),
                    status
                })
            });

            if (!response.ok) throw new Error("Bulk operation failed");

            // Refresh list
            const freshResponse = await fetch("/api/admin/pages");
            const data = await freshResponse.json() as { pages: PageMeta[] };
            setPages(data.pages);
            setSelectedSlugs(new Set());
            popup.success('Bulk operation completed successfully.');
        } catch (err) {
            console.error(err);
            popup.error("Failed to complete bulk operation. Check connection.");
        } finally {
            setIsBulkOperating(false);
        }
    };

    const handleReorder = async (slug: string, direction: 'up' | 'down') => {
        setIsBulkOperating(true);
        try {
            const response = await fetch("/api/admin/pages/reorder", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ slug, direction })
            });

            if (!response.ok) throw new Error("Reorder failed");

            // Refresh list
            const freshResponse = await fetch("/api/admin/pages");
            const data = await freshResponse.json() as { pages: PageMeta[] };
            const sorted = data.pages.sort((a, b) => {
                const orderA = a.sort_order ?? 999;
                const orderB = b.sort_order ?? 999;
                if (orderA !== orderB) return orderA - orderB;
                return new Date(b.updated_at || 0).getTime() - new Date(a.updated_at || 0).getTime();
            });
            setPages(sorted);
        } catch (err) {
            console.error(err);
            popup.error("Failed to reorder page sequence.");
        } finally {
            setIsBulkOperating(false);
        }
    };

    // Filter pages based on active tab, search query, and status filter
    const filteredPages = pages.filter(page => {
        // Tab Filter
        if (activeTab === 'templates' && !page.is_template) return false;
        if (activeTab === 'custom' && page.is_template) return false;

        // Status Filter
        if (statusFilter !== 'all' && page.status !== statusFilter) return false;

        // Search Filter
        if (searchQuery) {
            const query = searchQuery.toLowerCase();
            const matchesTitle = page.title.toLowerCase().includes(query);
            const matchesSlug = page.slug.toLowerCase().includes(query);
            const matchesDesc = page.description?.toLowerCase().includes(query);
            if (!matchesTitle && !matchesSlug && !matchesDesc) return false;
        }

        return true;
    });

    // Sort Logic
    const sortedPages = [...filteredPages].sort((a, b) => {
        if (sortBy === 'title') return a.title.localeCompare(b.title);
        if (sortBy === 'order') {
            const orderA = a.sort_order ?? 999;
            const orderB = b.sort_order ?? 999;
            if (orderA !== orderB) return orderA - orderB;
            // Fallback to updated_at for same order
            return new Date(b.updated_at || 0).getTime() - new Date(a.updated_at || 0).getTime();
        }
        if (sortBy === 'updated') {
            return new Date(b.updated_at || 0).getTime() - new Date(a.updated_at || 0).getTime();
        }
        return 0;
    });

    if (loading) {
        return <AdminLoadingState message="Fetching content matrix..." />;
    }

    if (error) {
        return (
            <div className="bg-info-box-bg border border-borders rounded-lg p-container text-center">
                <div className="max-w-md mx-auto">
                    <span className="text-4xl mb-4 block">⚠️</span>
                    <h3 className="text-xl font-semibold text-info-box-text mb-2">
                        Error Loading Pages
                    </h3>
                    <p className="text-sm text-info-box-text/70 mb-6">{error}</p>
                    <button
                        onClick={() => window.location.reload()}
                        className="px-6 py-2 bg-page-subtitle hover:bg-page-subtitle/90 text-white font-medium rounded-lg transition-colors"
                    >
                        Retry
                    </button>
                </div>
            </div>
        );
    }

    if (pages.length === 0) {
        return (
            <div className="space-y-6">
                <div className="bg-info-box-bg border border-borders rounded-[2rem] p-12 text-center shadow-xl">
                    <div className="max-w-md mx-auto">
                        <span className="text-6xl mb-6 block drop-shadow-lg">✨</span>
                        <h3 className="text-2xl font-black text-page-title mb-4 tracking-tight">
                            The Canvas is Blank
                        </h3>
                        <p className="text-page-text/70 mb-8 font-medium">
                            Initialize your first transmission or load a blueprint to begin architecting your digital presence.
                        </p>

                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="space-y-8 animate-in fade-in duration-700">

            {/* Content Filters - Standardized & Polished */}
            <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 p-4 rounded-3xl shadow-xl shadow-black/5">
                <div className="flex flex-wrap items-center gap-2">
                    {/* Tab Navigation */}
                    <div className="flex items-center gap-1 bg-gray-50 dark:bg-zinc-950 p-1 rounded-2xl border border-gray-100 dark:border-zinc-800">
                        <button
                            onClick={() => setActiveTab('all')}
                            className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'all'
                                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20'
                                : 'text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200'
                                }`}
                        >
                            All ({pages.length})
                        </button>
                        <button
                            onClick={() => setActiveTab('templates')}
                            className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'templates'
                                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20'
                                : 'text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200'
                                }`}
                        >
                            Templates ({pages.filter(p => p.is_template).length})
                        </button>
                        <button
                            onClick={() => setActiveTab('custom')}
                            className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'custom'
                                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20'
                                : 'text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200'
                                }`}
                        >
                            Custom ({pages.filter(p => !p.is_template).length})
                        </button>
                    </div>

                    {/* Status Dropdown */}
                    <div className="flex items-center gap-2">
                        <select
                            value={statusFilter}
                            onChange={(e) => setStatusFilter(e.target.value as any)}
                            className="bg-gray-50 dark:bg-zinc-950 border border-gray-100 dark:border-zinc-800 rounded-2xl px-4 py-2 text-[10px] font-black uppercase tracking-widest text-zinc-500 outline-none focus:border-indigo-500 transition-colors cursor-pointer appearance-none"
                        >
                            <option value="all">Status: All</option>
                            <option value="published">Status: Live</option>
                            <option value="draft">Status: Draft</option>
                        </select>
                    </div>

                    {/* Sort Dropdown */}
                    <div className="flex items-center gap-2">
                        <select
                            value={sortBy}
                            onChange={(e) => setSortBy(e.target.value as any)}
                            className="bg-gray-50 dark:bg-zinc-950 border border-gray-100 dark:border-zinc-800 rounded-2xl px-4 py-2 text-[10px] font-black uppercase tracking-widest text-zinc-500 outline-none focus:border-indigo-500 transition-colors cursor-pointer appearance-none"
                        >
                            <option value="order">Order: Sequence</option>
                            <option value="updated">Order: Recent</option>
                            <option value="title">Order: A-Z</option>
                        </select>
                    </div>
                </div>

                {/* Search Bar */}
                <div className="relative w-full md:w-80">
                    <input
                        type="text"
                        placeholder="Scan content matrix..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full bg-gray-50 dark:bg-zinc-950 border border-gray-100 dark:border-zinc-800 rounded-2xl pl-12 pr-4 py-2.5 text-xs font-bold text-zinc-900 dark:text-zinc-100 placeholder:text-zinc-400 outline-none focus:border-indigo-500 transition-all shadow-inner"
                    />
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
                    {searchQuery && (
                        <button
                            onClick={() => setSearchQuery("")}
                            className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-indigo-500 transition-colors"
                        >
                            <X size={16} />
                        </button>
                    )}
                </div>
            </div>

            {/* Selection Info Bar */}
            {selectedSlugs.size > 0 && (
                <div className="flex items-center justify-between bg-page-subtitle/10 border border-page-subtitle/20 p-3 rounded-xl animate-in fade-in slide-in-from-top-2">
                    <div className="flex items-center gap-3">
                        <button
                            onClick={toggleSelectAll}
                            className="p-1.5 hover:bg-page-subtitle/10 rounded-lg transition-colors"
                        >
                            {selectedSlugs.size === filteredPages.length ? <CheckSquare size={18} className="text-page-subtitle" /> : <Square size={18} className="text-gray-400" />}
                        </button>
                        <span className="text-xs font-bold text-page-subtitle uppercase tracking-widest">
                            {selectedSlugs.size} Items Selected
                        </span>
                    </div>
                    <button
                        onClick={() => setSelectedSlugs(new Set())}
                        className="text-gray-400 hover:text-gray-600 p-1"
                    >
                        <X size={16} />
                    </button>
                </div>
            )}

            {/* Pages Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {sortedPages.length === 0 ? (
                    <div className="md:col-span-2 bg-info-box-bg border border-borders border-dashed rounded-[2rem] p-12 text-center">
                        <div className="max-w-md mx-auto">
                            <span className="text-4xl mb-4 block opacity-50">🔍</span>
                            <h3 className="text-lg font-bold text-page-title mb-2">No Matching Transmissions</h3>
                            <p className="text-sm text-page-text/60 mb-6">Adjust your orbital filters or search criteria.</p>
                            <button
                                onClick={() => { setSearchQuery(""); setStatusFilter("all"); setActiveTab("all"); }}
                                className="text-xs font-bold uppercase tracking-widest text-page-subtitle hover:underline"
                            >
                                Clear All Parameters
                            </button>
                        </div>
                    </div>
                ) : sortedPages.map((page) => (
                    <div key={page.slug} className="relative group">
                        {/* Selector Checkbox - Floating Above Card */}
                        <button
                            onClick={(e) => toggleSelect(page.slug, e)}
                            className={`absolute -top-2 -left-2 z-20 p-2 rounded-xl border shadow-lg transition-all transform scale-0 group-hover:scale-100 active:scale-90 ${selectedSlugs.has(page.slug)
                                ? 'bg-page-subtitle border-page-subtitle text-white scale-100'
                                : 'bg-white dark:bg-zinc-800 border-borders text-gray-400 hover:text-gray-600'
                                }`}
                        >
                            {selectedSlugs.has(page.slug) ? <CheckSquare size={16} /> : <Square size={16} />}
                        </button>

                        <Link
                            href={`/admin/editor/page/${page.slug}`}
                            className={`block bg-white dark:bg-zinc-900 border rounded-3xl p-8 transition-all duration-500 h-full flex flex-col group/card ${selectedSlugs.has(page.slug)
                                ? 'border-indigo-600 ring-4 ring-indigo-500/10 shadow-2xl shadow-indigo-500/20'
                                : 'border-gray-100 dark:border-zinc-800 hover:border-indigo-500/50 hover:-translate-y-2 hover:shadow-[0_20px_50px_rgba(79,70,229,0.15)] dark:hover:shadow-[0_20px_50px_rgba(79,70,229,0.1)]'
                                }`}
                        >
                            {/* Page Meta Header: Status & Category */}
                            <div className="flex flex-wrap items-center gap-2 mb-6">
                                <span
                                    className={`px-3 py-1 text-[9px] uppercase tracking-widest font-black rounded-full ${page.status === 'published'
                                        ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                                        : 'bg-amber-500/10 text-amber-600 dark:text-amber-400'
                                        }`}
                                >
                                    {page.status === 'published' ? '● Published' : '○ Draft'}
                                </span>

                                {page.is_template && (
                                    <span className="px-3 py-1 text-[9px] uppercase tracking-widest font-black rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                                        📋 Template
                                    </span>
                                )}

                                {page.template_category && (
                                    <span className="px-3 py-1 text-[9px] uppercase tracking-widest font-black rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 border border-zinc-200 dark:border-zinc-700">
                                        {page.template_category}
                                    </span>
                                )}

                                <div className="ml-auto flex items-center gap-2">
                                    {page.status === 'published' ? (
                                        <button
                                            onClick={(e) => {
                                                e.preventDefault();
                                                e.stopPropagation();
                                                window.open(`/${page.slug}`, '_blank', 'noopener,noreferrer');
                                            }}
                                            className="text-[9px] font-black uppercase tracking-widest text-emerald-600 hover:bg-emerald-600/10 px-3 py-1.5 rounded-xl border border-emerald-500/20 transition-all hidden sm:flex items-center gap-2 group-hover/card:scale-105"
                                        >
                                            <Eye size={12} /> Live View →
                                        </button>
                                    ) : (
                                        <button
                                            onClick={(e) => {
                                                e.preventDefault();
                                                e.stopPropagation();
                                                window.open(`/${page.slug}?preview=true`, '_blank', 'noopener,noreferrer');
                                            }}
                                            className="text-[9px] font-black uppercase tracking-widest text-amber-600 hover:bg-amber-500/10 px-3 py-1.5 rounded-xl border border-amber-500/20 transition-all hidden sm:flex items-center gap-2 group-hover/card:scale-105"
                                        >
                                            <PenLine size={12} /> Preview →
                                        </button>
                                    )}
                                </div>
                            </div>

                            {/* Reorder Buttons */}
                            {!searchQuery && sortBy === 'order' && (
                                <div className="absolute top-1/2 -right-4 -translate-y-1/2 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-all duration-300 z-10 translate-x-4 group-hover:translate-x-0">
                                    <button
                                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); handleReorder(page.slug, 'up'); }}
                                        disabled={isBulkOperating}
                                        className="p-2 bg-white dark:bg-zinc-800 border border-gray-100 dark:border-zinc-700 rounded-xl shadow-2xl hover:text-indigo-600 hover:scale-110 transition-all disabled:opacity-50"
                                        title="Move Up"
                                    >
                                        <ChevronUp size={16} />
                                    </button>
                                    <button
                                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); handleReorder(page.slug, 'down'); }}
                                        disabled={isBulkOperating}
                                        className="p-2 bg-white dark:bg-zinc-800 border border-gray-100 dark:border-zinc-700 rounded-xl shadow-2xl hover:text-indigo-600 hover:scale-110 transition-all disabled:opacity-50"
                                        title="Move Down"
                                    >
                                        <ChevronDown size={16} />
                                    </button>
                                </div>
                            )}

                            {/* Page Title */}
                            <h3 className="text-2xl font-black text-zinc-900 dark:text-zinc-100 group-hover:text-indigo-600 transition-colors mb-3 line-clamp-2 leading-tight">
                                {page.title}
                            </h3>

                            {/* Page Description */}
                            {page.description && (
                                <div className="text-sm text-zinc-500 dark:text-zinc-400 line-clamp-2 mb-6 font-medium leading-relaxed">
                                    <VariableText text={page.description} />
                                </div>
                            )}

                            {/* Page Slug & Actions */}
                            <div className="flex items-center justify-between mt-auto pt-6 border-t border-gray-50 dark:border-zinc-800/50">
                                <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest bg-gray-50 dark:bg-zinc-950 px-3 py-1.5 rounded-xl border border-gray-100 dark:border-zinc-800">
                                    /{page.slug}
                                </p>
                                <span className="text-[10px] font-black uppercase tracking-widest text-zinc-400 group-hover:text-indigo-600 flex items-center gap-2 transition-all">
                                    Edit Workspace <span className="transform group-hover:translate-x-2 transition-transform">→</span>
                                </span>
                            </div>
                        </Link>
                    </div>
                ))}
            </div>

            {/* Bulk Actions Portal */}
            {mounted && selectedSlugs.size > 0 && (() => {
                const portalTarget = document.getElementById('admin-actions-portal');
                if (!portalTarget) return null;

                return createPortal(
                    <div className="flex items-center gap-2 pointer-events-auto bg-white dark:bg-zinc-800 p-2 rounded-2xl border border-borders shadow-2xl animate-in fade-in slide-in-from-bottom-4 ring-4 ring-black/5">
                        <CommandBarButton
                            onClick={() => handleBulkAction('status', 'published')}
                            label="Publish"
                            variant="secondary"
                            disabled={isBulkOperating}
                            icon={<Eye size={18} />}
                        />
                        <CommandBarButton
                            onClick={() => handleBulkAction('status', 'draft')}
                            label="Draft"
                            variant="secondary"
                            disabled={isBulkOperating}
                            icon={<EyeOff size={18} />}
                        />
                        <div className="w-[1px] h-6 bg-borders mx-1"></div>
                        <CommandBarButton
                            onClick={() => handleBulkAction('delete')}
                            label="Delete"
                            variant="danger"
                            disabled={isBulkOperating}
                            icon={<Trash2 size={18} />}
                        />
                        <div className="w-[1px] h-6 bg-borders mx-1"></div>
                        <button
                            onClick={() => setSelectedSlugs(new Set())}
                            className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
                        >
                            <X size={18} />
                        </button>
                    </div>,
                    portalTarget
                );
            })()}
        </div>
    );
}

import { FileText, Globe, PenLine, Layout } from "lucide-react";
