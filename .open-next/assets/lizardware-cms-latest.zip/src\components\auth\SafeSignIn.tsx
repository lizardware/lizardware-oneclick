'use client';

import { SignIn } from "@clerk/nextjs";
import { isClerkConfigured } from "@/lib/auth-config";
import { useAuth } from "@/context/AuthContext";
import { useState } from "react";
import { useRouter } from "next/navigation";

export function SafeSignIn(props: any) {
    const isClerk = isClerkConfigured();
    const { signIn } = useAuth();
    const router = useRouter();
    const [loading, setLoading] = useState(false);

    if (isClerk) {
        return <SignIn {...props} />;
    }

    const handleLocalLogin = (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);

        // Simulate network delay
        setTimeout(() => {
            signIn();
            // Redirect to admin
            router.push('/admin');
        }, 800);
    };

    return (
        <div className="w-full max-w-sm mx-auto">
            <form onSubmit={handleLocalLogin} className="space-y-4">
                <div className="space-y-2 text-center">
                    <h3 className="text-white font-bold text-lg">Local Administrator Access</h3>
                    <p className="text-zinc-400 text-xs">Clerk is disabled. Use local fallback.</p>
                </div>

                <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-3 bg-white text-black font-bold rounded-xl hover:bg-zinc-200 transition-colors disabled:opacity-50"
                >
                    {loading ? 'Authenticating...' : 'Enter Admin Mode'}
                </button>
            </form>
        </div>
    );
}
