"use client";

import { useEffect } from "react";

export default function PostViewCounter({ slug }: { slug: string }) {
    useEffect(() => {
        // Increment view count on mount
        // We use a small delay or check to avoid double-counting during dev/refresh
        const timer = setTimeout(() => {
            fetch(`/api/blog/views?slug=${slug}`, { method: "POST" })
                .catch(err => console.error("Failed to increment view count:", err));
        }, 2000); // 2 second engagement delay

        return () => clearTimeout(timer);
    }, [slug]);

    return null;
}
