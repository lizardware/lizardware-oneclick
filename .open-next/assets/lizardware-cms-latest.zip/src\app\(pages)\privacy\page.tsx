import { Metadata } from "next";
import { getPageBySlug } from "@/lib/pages";
import PageRenderer from "@/components/PageRenderer";
import PrivacyPage from "./PrivacyPage";

export const metadata: Metadata = {
    title: "Privacy Policy",
};

export default async function Privacy({ searchParams }: { searchParams: Promise<{ preview?: string }> }) {
    const { preview } = await searchParams;
    let page = await getPageBySlug("privacy");

    // In preview mode, ensure we use the PageRenderer even if the page doesn't exist yet
    // This allows the ContentPreviewListener to populate the UI as the user types
    if (preview === 'true') {
        if (!page) {
            page = {
                slug: 'privacy',
                title: 'Privacy Policy',
                content: '<p>Start typing your privacy policy content...</p>',
                description: '',
                status: 'draft'
            } as any;
        }
        // Type assertion: page is guaranteed non-null at this point
        return <PageRenderer page={page!} />;
    }

    if (page && page.status === "published") {
        return <PageRenderer page={page} />;
    }

    return <PrivacyPage />;
}
