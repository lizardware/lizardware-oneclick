'use client';

import { useState, useEffect } from 'react';
import { getAllVariables, getCategories, type Variable } from '@/lib/variables';

/**
 * Hook for accessing the variable registry
 */
export function useVariables() {
    const [variables, setVariables] = useState<Variable[]>([]);
    const [categories, setCategories] = useState<string[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // In future, could fetch from API for custom user variables
        // For now, just use static registry
        setVariables(getAllVariables());
        setCategories(getCategories());
        setLoading(false);
    }, []);

    return {
        variables,
        categories,
        loading
    };
}
