"use client";

import React from "react";

interface DefaultPageLayoutProps {
    title: string;
    description?: string;
    content: string;
    updatedAt?: string;
    slug: string;
}

/**
 * Standard Layout
 * The first preconfigured layout for Lizardware CMS.
 * Features a centered header, clean typography, and a standard footer.
 */
export function StandardPageLayout({ title, description, content, updatedAt, slug }: DefaultPageLayoutProps) {
    return (
        <article className="bg-page-background min-h-[60vh] animate-in fade-in duration-1000">
            <div className="max-w-[1024px] mx-auto px-4 py-12">
                {/* Header */}
                <header className="mb-12 text-center space-y-4">
                    <div className="inline-block px-3 py-1 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 rounded-full text-[10px] font-black uppercase tracking-widest mb-2">
                        System Protocol 01
                    </div>
                    <h1 className="text-4xl md:text-6xl font-black mb-4 text-zinc-900 dark:text-white tracking-tight leading-none" data-content-title>
                        {title}
                    </h1>
                    {description && (
                        <p className="text-xl text-zinc-500 dark:text-zinc-400 max-w-2xl mx-auto leading-relaxed font-medium" data-content-description>
                            {description}
                        </p>
                    )}
                    <div className="w-24 h-1 bg-indigo-500 mx-auto rounded-full opacity-20"></div>
                </header>

                {/* Content */}
                <div
                    className="tiptap-editor prose dark:prose-invert max-w-none text-page-text leading-extra-relaxed"
                    data-content-body
                    dangerouslySetInnerHTML={{ __html: content }}
                />

                {/* Footer Metadata */}
                <footer className="mt-20 pt-10 border-t border-zinc-100 dark:border-zinc-800/50 text-[11px] font-bold text-gray-400 uppercase tracking-widest flex flex-col md:flex-row justify-between items-center gap-4">
                    <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                        Last updated: {updatedAt || new Date().toLocaleDateString()}
                    </div>
                    <div className="px-3 py-1 bg-gray-50 dark:bg-zinc-900 rounded-lg border border-gray-100 dark:border-zinc-800 font-mono lowercase">
                        /{slug}
                    </div>
                </footer>
            </div>
        </article>
    );
}

/**
 * Minimal Layout
 * A focused, distraction-free layout.
 */
export function MinimalPageLayout({ title, description, content, slug }: DefaultPageLayoutProps) {
    return (
        <article className="bg-white dark:bg-zinc-950 min-h-screen">
            <div className="max-w-2xl mx-auto px-6 py-24">
                <h1 className="text-3xl font-bold mb-4 text-black dark:text-white" data-content-title>{title}</h1>
                {description && (
                    <p className="text-lg text-gray-600 dark:text-gray-400 mb-8 font-medium leading-relaxed" data-content-description>
                        {description}
                    </p>
                )}
                <div
                    className="prose dark:prose-invert max-w-none"
                    data-content-body
                    dangerouslySetInnerHTML={{ __html: content }}
                />
            </div>
        </article>
    );
}

/**
 * Sidebar Right Layout
 * Classic documentation/blog style with a sidebar on the right.
 */
export function SidebarRightLayout({ title, description, content, updatedAt }: DefaultPageLayoutProps) {
    return (
        <article className="bg-page-background min-h-screen">
            <div className="max-w-7xl mx-auto px-6 py-12">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
                    {/* Main Content */}
                    <div className="lg:col-span-8">
                        <header className="mb-10 pb-10 border-b border-gray-100 dark:border-zinc-800">
                            <h1 className="text-4xl md:text-5xl font-black text-gray-900 dark:text-white mb-4 tracking-tight" data-content-title>
                                {title}
                            </h1>
                            {description && (
                                <p className="text-xl text-gray-500 dark:text-gray-400 leading-relaxed" data-content-description>
                                    {description}
                                </p>
                            )}
                        </header>
                        <div
                            className="prose prose-lg dark:prose-invert max-w-none"
                            data-content-body
                            dangerouslySetInnerHTML={{ __html: content }}
                        />
                    </div>

                    {/* Sidebar */}
                    <aside className="lg:col-span-4 space-y-8">
                        <div className="bg-gray-50 dark:bg-zinc-900 p-6 rounded-2xl border border-gray-100 dark:border-zinc-800 sticky top-24">
                            <h3 className="font-bold text-sm uppercase tracking-widest text-gray-400 mb-4">
                                Page Details
                            </h3>
                            <div className="space-y-4 text-sm">
                                <div>
                                    <div className="text-gray-500 mb-1">Last Updated</div>
                                    <div className="font-medium">{updatedAt || 'Recently'}</div>
                                </div>
                                <div className="pt-4 border-t border-gray-200 dark:border-zinc-800">
                                    <button className="w-full py-2 bg-primary/10 text-primary rounded-lg font-bold hover:bg-primary/20 transition-colors">
                                        Share Page
                                    </button>
                                </div>
                            </div>
                        </div>
                    </aside>
                </div>
            </div>
        </article>
    );
}

/**
 * Full Width Layout
 * Immersive layout with a dark header and wide content area.
 */
export function FullWidthLayout({ title, description, content }: DefaultPageLayoutProps) {
    return (
        <article className="min-h-screen">
            <div className="bg-zinc-900 text-white py-32 px-6">
                <div className="max-w-5xl mx-auto text-center space-y-6">
                    <h1 className="text-5xl md:text-7xl font-black tracking-tighter" data-content-title>
                        {title}
                    </h1>
                    {description && (
                        <p className="text-2xl text-zinc-400 max-w-3xl mx-auto font-light" data-content-description>
                            {description}
                        </p>
                    )}
                </div>
            </div>
            <div className="max-w-7xl mx-auto px-6 py-20">
                <div
                    className="prose prose-xl dark:prose-invert max-w-none text-center"
                    data-content-body
                    dangerouslySetInnerHTML={{ __html: content }}
                />
            </div>
        </article>
    );
}
