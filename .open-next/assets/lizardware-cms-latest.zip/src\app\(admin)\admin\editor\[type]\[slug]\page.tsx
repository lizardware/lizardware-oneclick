import { notFound } from 'next/navigation';
import { getPageBySlug } from '@/lib/pages';
import { getPostBySlug } from '@/lib/blog';
import { Page } from '@/types/page';
import { Post } from '@/types/blog';
import UnifiedEditor from '@/components/admin/UnifiedEditor';

export const dynamic = 'force-dynamic';

type EditorType = 'page' | 'blog';

interface EditorPageProps {
    params: Promise<{
        type: EditorType;
        slug: string;
    }>;
}

export default async function EditorPage({ params }: EditorPageProps) {
    const { type, slug } = await params;

    // Validate type
    if (type !== 'page' && type !== 'blog') {
        notFound();
    }

    // Handle new content
    if (slug === 'new') {
        const defaultContent = type === 'page'
            ? {
                title: '',
                slug: '',
                content: '',
                status: 'draft',
                description: '',
                is_template: false,
                sort_order: 0
            } as Page
            : {
                title: '',
                slug: '',
                content: '',
                status: 'draft',
                description: '',
                date: new Date().toISOString()
            } as Post;

        return <UnifiedEditor type={type} initialContent={defaultContent} slug="new" />;
    }

    // Fetch content
    const content = type === 'page'
        ? await getPageBySlug(slug)
        : await getPostBySlug(slug);

    if (!content) {
        notFound();
    }

    return <UnifiedEditor type={type} initialContent={content} slug={slug} />;
}
