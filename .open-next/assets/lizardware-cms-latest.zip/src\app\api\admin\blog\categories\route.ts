import { NextRequest, NextResponse } from "next/server";
import { getD1Database } from "@/lib/cloudflare";
import { getAllCategories, upsertCategory, deleteCategory } from "@/lib/blog-categories";

export async function GET() {
    try {
        const db = await getD1Database();
        if (!db) {
            return NextResponse.json({ error: "D1 Database not available" }, { status: 503 });
        }
        const categories = await getAllCategories(db);
        return NextResponse.json({ categories }, { status: 200 });
    } catch (error) {
        return NextResponse.json({ error: (error as Error).message }, { status: 500 });
    }
}

export async function POST(request: NextRequest) {
    try {
        const db = await getD1Database();
        if (!db) {
            return NextResponse.json({ error: "D1 Database not available" }, { status: 503 });
        }
        const body = await request.json() as { id: string, name: string, slug: string, description?: string };
        if (!body.id || !body.name || !body.slug) {
            return NextResponse.json({ error: "Missing required fields: id, name, slug" }, { status: 400 });
        }
        await upsertCategory(db, body);
        return NextResponse.json({ success: true, message: "Category saved successfully" }, { status: 200 });
    } catch (error) {
        return NextResponse.json({ error: (error as Error).message }, { status: 500 });
    }
}

export async function DELETE(request: NextRequest) {
    try {
        const db = await getD1Database();
        if (!db) {
            return NextResponse.json({ error: "D1 Database not available" }, { status: 503 });
        }
        const { searchParams } = new URL(request.url);
        const id = searchParams.get('id');
        if (!id) {
            return NextResponse.json({ error: "Missing required field: id" }, { status: 400 });
        }
        await deleteCategory(db, id);
        return NextResponse.json({ success: true, message: "Category deleted successfully" }, { status: 200 });
    } catch (error) {
        return NextResponse.json({ error: (error as Error).message }, { status: 500 });
    }
}
