import Link from "next/link";
import { notFound } from "next/navigation";
import { servicesData } from "@/data/services";
import { getDynamicSiteConfig } from "@/lib/site-server";

export default async function ServicePage({ slug }: { slug: string }) {
    const service = servicesData[slug];

    if (!service) {
        notFound();
    }

    const siteConfig = await getDynamicSiteConfig();
    const siteName = siteConfig.name || "Lizardware CMS";

    const replacePlaceholders = (text: string) => text.replace(/{{siteName}}/g, siteName);

    return (
        <div className="bg-page-background">
            {/* Hero Section */}
            <section className="relative py-section bg-hero-gradient text-hero-text overflow-hidden border-b border-borders/20">
                <div className="relative max-w-7xl mx-auto px-4 text-center space-y-6">
                    <h1 className="text-title font-bold tracking-tight">
                        {service.title}
                    </h1>
                    <h2 className="text-subtitle font-semibold opacity-90">
                        {service.tagline || replacePlaceholders("Modern Content Management on the Edge")}
                    </h2>
                    <p className="text-body opacity-80 max-w-3xl mx-auto leading-relaxed">
                        {replacePlaceholders(service.intro)}
                    </p>
                </div>
            </section>

            <div className="max-w-7xl mx-auto px-4 py-section space-y-24">
                {service.sections.map((section, index) => (
                    <section key={index} className="space-y-8">
                        <div className="flex items-center justify-center gap-6">
                            <div className="h-8 w-1.5 bg-page-subtitle rounded-full shadow-[0_0_15px_var(--page-subtitle)]"></div>
                            <h2 className="text-subtitle font-bold text-page-title text-center">
                                {replacePlaceholders(section.title)}
                            </h2>
                            <div className="h-8 w-1.5 bg-page-subtitle rounded-full shadow-[0_0_15px_var(--page-subtitle)]"></div>
                        </div>

                        {section.content && (
                            <p className="text-body text-page-text leading-relaxed max-w-4xl mx-auto text-center">
                                {replacePlaceholders(section.content)}
                            </p>
                        )}

                        {section.list && (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
                                {section.list.map((item, i) => (
                                    <div key={i} className="p-container bg-info-box-link-bg border border-borders rounded-xl shadow-sm">
                                        <h3 className="text-lg font-bold text-info-box-link-text mb-2">
                                            {replacePlaceholders(item.title)}
                                        </h3>
                                        <p className="text-page-text">
                                            {replacePlaceholders(item.description)}
                                        </p>
                                    </div>
                                ))}
                            </div>
                        )}
                    </section>
                ))}

                {/* CTA Section */}
                <section className="bg-info-box-bg border-y border-borders -mx-4 px-4 py-section text-center rounded-3xl">
                    <div className="max-w-3xl mx-auto space-y-8">
                        <h2 className="text-subtitle font-bold text-page-title">
                            {replacePlaceholders(service.cta.title)}
                        </h2>
                        <p className="text-body text-page-text">
                            {replacePlaceholders(service.cta.text)}
                        </p>
                        <Link
                            href={`/contact?reason=${service.cta.reasonSlug}`}
                            className="inline-block bg-page-subtitle hover:bg-page-subtitle/90 text-white font-bold py-4 px-10 rounded-full shadow-lg hover:shadow-page-subtitle/25 transition-all transform hover:-translate-y-1"
                        >
                            {service.cta.buttonText}
                        </Link>
                    </div>
                </section>
            </div>
        </div>
    );
}
