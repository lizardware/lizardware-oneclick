"use client";

import React, { useState, useEffect } from "react";
import { X, ZoomIn } from "lucide-react";

interface ImageZoomProps {
    src: string;
    alt: string;
    className?: string;
    priority?: boolean;
}

import { createPortal } from "react-dom";

export function ImageZoom({ src, alt, className = "", priority = false }: ImageZoomProps) {
    const [isOpen, setIsOpen] = useState(false);
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        setMounted(true);
    }, []);

    // Handle Escape key to close
    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === "Escape") {
                setIsOpen(false);
            }
        };

        if (isOpen) {
            window.addEventListener("keydown", handleKeyDown);
            // Lock body scroll
            document.body.style.overflow = "hidden";
        }

        return () => {
            window.removeEventListener("keydown", handleKeyDown);
            document.body.style.overflow = "unset";
        };
    }, [isOpen]);

    const modalContent = (
        <div
            className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200 no-print"
            onClick={() => setIsOpen(false)}
        >
            {/* Close Button */}
            <button
                className="absolute top-4 right-4 p-2 bg-black/50 text-white rounded-full hover:bg-black/70 transition-colors z-50 focus:outline-none focus:ring-2 focus:ring-white"
                onClick={(e) => {
                    e.stopPropagation();
                    setIsOpen(false);
                }}
            >
                <X size={24} />
            </button>

            {/* Zoomed Image */}
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
                src={src}
                alt={alt}
                className="max-w-full max-h-[90vh] object-contain rounded-md shadow-2xl animate-in zoom-in-95 duration-300"
                onClick={(e) => e.stopPropagation()} // Prevent close when clicking "the image itself"
            />

            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-white/80 text-sm font-medium bg-black/50 px-3 py-1 rounded-full backdrop-blur-sm">
                Press ESC to close
            </div>
        </div>
    );

    return (
        <>
            {/* Thumbnail */}
            <div
                className={`relative group cursor-zoom-in inline-block ${className}`}
                onClick={() => setIsOpen(true)}
            >
                <img
                    src={src}
                    alt={alt}
                    className={`block w-full h-auto rounded-lg border border-borders shadow-md transition-transform duration-200 group-hover:scale-[1.01] ${className}`}
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors rounded-lg flex items-center justify-center opacity-0 group-hover:opacity-100">
                    <div className="bg-black/50 text-white p-2 rounded-full backdrop-blur-sm shadow-sm">
                        <ZoomIn size={20} />
                    </div>
                </div>
            </div>

            {/* Modal Overlay Portalled to Body */}
            {isOpen && mounted && createPortal(modalContent, document.body)}
        </>
    );
}
