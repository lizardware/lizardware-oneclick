import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

export async function GET() {
    const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://lizardware.dev';

    try {
        // Fetch posts for dynamic routes
        const postsResponse = await fetch(`${baseUrl}/api/posts`);
        const posts = postsResponse.ok ? await postsResponse.json() : [];

        const staticRoutes = [
            { url: '', priority: '1.0', changefreq: 'daily' },
            { url: '/about', priority: '0.8', changefreq: 'monthly' },
            { url: '/contact', priority: '0.7', changefreq: 'monthly' },
            { url: '/features', priority: '0.9', changefreq: 'weekly' },
            { url: '/blog', priority: '0.9', changefreq: 'daily' },
            { url: '/platform', priority: '0.8', changefreq: 'monthly' },
            { url: '/docs', priority: '0.8', changefreq: 'weekly' },
        ];

        const blogRoutes = (posts as any[]).map(post => ({
            url: `/blog/${post.slug}`,
            priority: '0.7',
            changefreq: 'weekly',
            lastmod: new Date(post.updatedAt || post.createdAt).toISOString().split('T')[0]
        }));

        const allRoutes = [...staticRoutes, ...blogRoutes];
        const now = new Date().toISOString().split('T')[0];

        const xml = `<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="/sitemap.xsl"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${allRoutes.map(route => `    <url>
        <loc>${baseUrl}${route.url}</loc>
        <lastmod>${(route as any).lastmod || now}</lastmod>
        <changefreq>${route.changefreq}</changefreq>
        <priority>${route.priority}</priority>
    </url>`).join('\n')}
</urlset>`;

        return new NextResponse(xml, {
            headers: {
                'Content-Type': 'application/xml',
                'Cache-Control': 'public, s-maxage=86400, stale-while-revalidate=43200'
            },
        });
    } catch (error) {
        console.error('Sitemap generation error:', error);
        return new NextResponse(`<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="/sitemap.xsl"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url><loc>${baseUrl}</loc><priority>1.0</priority></url>
</urlset>`, {
            headers: { 'Content-Type': 'application/xml' }
        });
    }
}
