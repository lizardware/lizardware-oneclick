import Link from 'next/link';
import AdminLoginForm from '@/components/auth/AdminLoginForm';

export const metadata = {
    title: 'Lizardware Command | Access Control',
    description: 'Restricted system access.'
};

export default function AdminLoginPage() {
    return (
        <div className="min-h-screen flex items-center justify-center bg-body-background p-4">
            <div className="w-full max-w-md">
                <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 md:p-10 shadow-2xl relative overflow-hidden">
                    {/* Decorative Elements */}
                    <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full -mr-32 -mt-32 blur-3xl"></div>
                    <div className="absolute bottom-0 left-0 w-48 h-48 bg-purple-500/5 rounded-full -ml-24 -mb-24 blur-3xl"></div>

                    <div className="relative z-10 space-y-8">
                        <div className="text-center space-y-2">
                            <div className="w-12 h-12 bg-zinc-900 dark:bg-white rounded-xl flex items-center justify-center text-xl mx-auto shadow-lg mb-6">🦎</div>
                            <h1 className="text-2xl font-black tracking-tight text-page-title">
                                System <span className="text-primary">Access</span>
                            </h1>
                            <p className="text-zinc-400 text-xs font-medium uppercase tracking-widest">
                                Authorized Personnel Only
                            </p>
                        </div>

                        <AdminLoginForm />

                        <div className="text-center pt-4 border-t border-zinc-100 dark:border-zinc-800">
                            <p className="text-[10px] text-zinc-400">
                                Protected by Edge Native Security Protocols.
                            </p>
                            <Link href="/" className="text-[10px] font-bold text-primary hover:underline mt-2 block">
                                Return to Surface
                            </Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
