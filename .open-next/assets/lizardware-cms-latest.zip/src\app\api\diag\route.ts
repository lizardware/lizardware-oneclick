import { NextResponse } from 'next/server';
import { getSafeCloudflareContext } from '@/lib/cloudflare';

export async function GET() {
    console.log('[API] Diag triggered - using safe utility');

    interface DiagInfo {
        timestamp: string;
        runtime: string;
        env_keys: string[];
        context?: string;
        manual_search?: string;
        global_keys?: string[];
        db?: string;
        db_test?: string;
        tables?: string[];
        posts_count?: unknown;
        db_error?: string;
        error?: string;
        stack?: string;
    }

    const diag: DiagInfo = {
        timestamp: new Date().toISOString(),
        runtime: 'edge',
        env_keys: []
    };

    try {
        const context = await getSafeCloudflareContext();

        if (!context) {
            diag.context = 'missing';
            diag.manual_search = 'failed';

            // Extensive global search for debugging
            diag.global_keys = Object.keys(globalThis).filter(k =>
                k.includes('NEXT') || k.includes('CLOUDFLARE') || k.includes('process')
            );
        } else {
            diag.context = 'available';
            diag.env_keys = Object.keys(context.env || {});

            if (context.env?.DB) {
                diag.db = 'bound';
                try {
                    const testQuery = await (context.env.DB as D1Database).prepare('SELECT 1 as result').first() as { result: number } | null;
                    diag.db_test = testQuery?.result === 1 ? 'success' : 'failed';

                    const tablesResult = await (context.env.DB as D1Database).prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
                    diag.tables = tablesResult.results.map((r: unknown) => (r as { name: string }).name);

                    if (diag.tables.includes('posts')) {
                        const countResult = await (context.env.DB as D1Database).prepare("SELECT COUNT(*) as count FROM posts").first() as { count: number } | null;
                        diag.posts_count = countResult?.count;
                    }
                } catch (dbError) {
                    diag.db_error = dbError instanceof Error ? dbError.message : String(dbError);
                }
            } else {
                diag.db = 'not_bound';
            }
        }
    } catch (_error) {
        const error = _error instanceof Error ? _error : new Error(String(_error));
        diag.error = error.message;
        diag.stack = error.stack;
    }

    return NextResponse.json(diag);
}
