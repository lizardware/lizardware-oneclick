-- Create site_config table if it doesn't exist (fixing missing table error)
CREATE TABLE IF NOT EXISTS site_config (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  template_id TEXT DEFAULT 'custom',
  setup_completed INTEGER DEFAULT 0
);

-- Initialize default row
INSERT OR IGNORE INTO site_config (id, template_id, setup_completed) VALUES (1, 'custom', 0);

-- Feature flags table
CREATE TABLE IF NOT EXISTS feature_flags (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  feature_name TEXT NOT NULL UNIQUE,
  enabled INTEGER DEFAULT 1,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Default feature flags
INSERT OR IGNORE INTO feature_flags (feature_name, enabled) VALUES
  ('blog', 1),
  ('gallery', 0),
  ('newsletter', 0),
  ('monetization', 0),
  ('comments', 0),
  ('servicePages', 0),
  ('menu', 0),
  ('booking', 0),
  ('customerPortal', 0),
  ('analytics', 0);
