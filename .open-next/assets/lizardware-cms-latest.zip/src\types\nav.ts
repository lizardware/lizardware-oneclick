export interface NavItem {
    id: string;
    label: string;
    href: string;
    icon?: string;
    children?: NavItem[];
}

export interface NavConfig {
    navigation: NavItem[];
}
