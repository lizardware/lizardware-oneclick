import { marked } from 'marked';

// Configure marked for better rendering
marked.setOptions({
    gfm: true,
    breaks: true,
});

interface MarkdownViewerProps {
    content: string;
    title?: string;
    description?: string;
    simple?: boolean;
}

export default function MarkdownViewer({ content, title, description, simple = false }: MarkdownViewerProps) {
    const htmlContent = marked(content) as string;

    if (simple) {
        return (
            <div
                className="markdown-content
                    [&>h1]:text-4xl [&>h1]:font-black [&>h1]:mb-8 [&>h1]:mt-0 [&>h1]:pb-4 [&>h1]:border-b [&>h1]:border-zinc-100 dark:[&>h1]:border-zinc-800 [&>h1]:text-zinc-900 dark:[&>h1]:text-white
                    [&>h2]:text-2xl [&>h2]:font-bold [&>h2]:mt-12 [&>h2]:mb-6 [&>h2]:pb-3 [&>h2]:border-b [&>h2]:border-zinc-100/50 dark:[&>h2]:border-zinc-800/50 [&>h2]:text-zinc-900 dark:[&>h2]:text-white
                    [&>h3]:text-xl [&>h3]:font-semibold [&>h3]:mt-8 [&>h3]:mb-4 [&>h3]:text-zinc-900 dark:[&>h3]:text-white
                    [&>h4]:text-lg [&>h4]:font-semibold [&>h4]:mt-6 [&>h4]:mb-3 [&>h4]:text-zinc-900 dark:[&>h4]:text-white
                    [&>p]:text-zinc-600 dark:[&>p]:text-zinc-400 [&>p]:leading-7 [&>p]:mb-5
                    [&_a]:text-page-subtitle [&_a]:font-bold [&_a]:underline [&_a]:decoration-page-subtitle/50 underline-offset-4 hover:[&_a]:decoration-page-subtitle [&_a]:transition-all
                    [&>code]:text-primary [&>code]:bg-zinc-50 dark:[&>code]:bg-zinc-800/50 [&>code]:px-2 [&>code]:py-1 [&>code]:rounded-md [&>code]:text-sm [&>code]:font-mono [&>code]:border [&>code]:border-primary/10
                    [&>pre]:bg-zinc-900 dark:[&>pre]:bg-zinc-950 [&>pre]:text-zinc-100 [&>pre]:border [&>pre]:border-zinc-800 [&>pre]:rounded-2xl [&>pre]:p-6 [&>pre]:overflow-x-auto [&>pre]:my-6 [&>pre]:shadow-inner [&>pre]:font-mono [&>pre]:text-sm [&>pre]:leading-relaxed
                    [&>blockquote]:border-l-4 [&>blockquote]:border-primary [&>blockquote]:bg-primary/5 dark:[&>blockquote]:bg-primary/5 [&>blockquote]:rounded-r-xl [&>blockquote]:py-4 [&>blockquote]:px-6 [&>blockquote]:my-6 [&>blockquote]:font-medium
                    [&>ul]:my-5 [&>ul]:list-none [&>ul]:pl-0
                    [&>ul>li]:relative [&>ul>li]:pl-7 [&>ul>li]:my-2 [&>ul>li]:before:content-['▸'] [&>ul>li]:before:absolute [&>ul>li]:before:left-0 [&>ul>li]:before:text-primary [&>ul>li]:before:font-bold
                    [&>ol]:my-5 [&>ol]:pl-6 [&>ol]:list-decimal
                    [&>ol>li]:my-2 [&>ol>li]:pl-2
                    [&>strong]:text-zinc-900 dark:[&>strong]:text-white [&>strong]:font-bold
                    [&>table]:border-collapse [&>table]:w-full [&>table]:my-8 [&>table]:rounded-xl [&>table]:overflow-hidden [&>table]:border [&>table]:border-zinc-100 dark:[&>table]:border-zinc-800
                    [&>table>thead]:bg-zinc-50 dark:[&>table>thead]:bg-zinc-800/50
                    [&>table>thead>tr>th]:px-4 [&>table>thead>tr>th]:py-3 [&>table>thead>tr>th]:text-left [&>table>thead>tr>th]:font-bold [&>table>thead>tr>th]:text-xs [&>table>thead>tr>th]:uppercase [&>table>thead>tr>th]:tracking-wider [&>table>thead>tr>th]:text-zinc-500
                    [&>table>tbody>tr>td]:px-4 [&>table>tbody>tr>td]:py-3 [&>table>tbody>tr>td]:text-sm [&>table>tbody>tr>td]:border-t [&>table>tbody>tr>td]:border-zinc-100 dark:[&>table>tbody>tr>td]:border-zinc-800
                    [&>table>tbody>tr]:transition-colors hover:[&>table>tbody>tr]:bg-zinc-50/50 dark:hover:[&>table>tbody>tr]:bg-zinc-800/30
                "
                dangerouslySetInnerHTML={{ __html: htmlContent }}
            />
        );
    }

    return (
        <div className="max-w-4xl mx-auto">
            <article className="bg-white dark:bg-zinc-900 rounded-3xl border border-gray-100 dark:border-zinc-800 p-8 md:p-12 shadow-xl">
                {(title || description) && (
                    <div className="mb-12 pb-8 border-b border-gray-100 dark:border-zinc-800/50">
                        {title && (
                            <h1 className="text-3xl md:text-4xl font-black tracking-tight text-zinc-900 dark:text-white mb-4">
                                {title}
                            </h1>
                        )}
                        {description && (
                            <p className="text-zinc-500 dark:text-zinc-400 text-lg leading-relaxed">
                                {description}
                            </p>
                        )}
                    </div>
                )}

                <div
                    className="markdown-content
                        [&>h1]:text-4xl [&>h1]:font-black [&>h1]:mb-8 [&>h1]:mt-0 [&>h1]:pb-4 [&>h1]:border-b [&>h1]:border-zinc-100 dark:[&>h1]:border-zinc-800 [&>h1]:text-zinc-900 dark:[&>h1]:text-white
                        [&>h2]:text-2xl [&>h2]:font-bold [&>h2]:mt-12 [&>h2]:mb-6 [&>h2]:pb-3 [&>h2]:border-b [&>h2]:border-zinc-100/50 dark:[&>h2]:border-zinc-800/50 [&>h2]:text-zinc-900 dark:[&>h2]:text-white
                        [&>h3]:text-xl [&>h3]:font-semibold [&>h3]:mt-8 [&>h3]:mb-4 [&>h3]:text-zinc-900 dark:[&>h3]:text-white
                        [&>h4]:text-lg [&>h4]:font-semibold [&>h4]:mt-6 [&>h4]:mb-3 [&>h4]:text-zinc-900 dark:[&>h4]:text-white
                        [&>p]:text-zinc-600 dark:[&>p]:text-zinc-400 [&>p]:leading-7 [&>p]:mb-5
                        [&_a]:text-page-subtitle [&_a]:font-bold [&_a]:underline [&_a]:decoration-page-subtitle/50 underline-offset-4 hover:[&_a]:decoration-page-subtitle [&_a]:transition-all
                        [&>code]:text-primary [&>code]:bg-zinc-50 dark:[&>code]:bg-zinc-800/50 [&>code]:px-2 [&>code]:py-1 [&>code]:rounded-md [&>code]:text-sm [&>code]:font-mono [&>code]:border [&>code]:border-primary/10
                        [&>pre]:bg-zinc-900 dark:[&>pre]:bg-zinc-950 [&>pre]:text-zinc-100 [&>pre]:border [&>pre]:border-zinc-800 [&>pre]:rounded-2xl [&>pre]:p-6 [&>pre]:overflow-x-auto [&>pre]:my-6 [&>pre]:shadow-inner [&>pre]:font-mono [&>pre]:text-sm [&>pre]:leading-relaxed
                        [&>blockquote]:border-l-4 [&>blockquote]:border-primary [&>blockquote]:bg-primary/5 dark:[&>blockquote]:bg-primary/5 [&>blockquote]:rounded-r-xl [&>blockquote]:py-4 [&>blockquote]:px-6 [&>blockquote]:my-6 [&>blockquote]:font-medium
                        [&>ul]:my-5 [&>ul]:list-none [&>ul]:pl-0
                        [&>ul>li]:relative [&>ul>li]:pl-7 [&>ul>li]:my-2 [&>ul>li]:before:content-['▸'] [&>ul>li]:before:absolute [&>ul>li]:before:left-0 [&>ul>li]:before:text-primary [&>ul>li]:before:font-bold
                        [&>ol]:my-5 [&>ol]:pl-6 [&>ol]:list-decimal
                        [&>ol>li]:my-2 [&>ol>li]:pl-2
                        [&>strong]:text-zinc-900 dark:[&>strong]:text-white [&>strong]:font-bold
                        [&>em]:text-zinc-600 dark:[&>em]:text-zinc-400 [&>em]:italic
                        [&>table]:border-collapse [&>table]:w-full [&>table]:my-8 [&>table]:rounded-xl [&>table]:overflow-hidden [&>table]:border [&>table]:border-zinc-100 dark:[&>table]:border-zinc-800
                        [&>table>thead]:bg-zinc-50 dark:[&>table>thead]:bg-zinc-800/50
                        [&>table>thead>tr>th]:px-4 [&>table>thead>tr>th]:py-3 [&>table>thead>tr>th]:text-left [&>table>thead>tr>th]:font-bold [&>table>thead>tr>th]:text-xs [&>table>thead>tr>th]:uppercase [&>table>thead>tr>th]:tracking-wider [&>table>thead>tr>th]:text-zinc-500
                        [&>table>tbody>tr>td]:px-4 [&>table>tbody>tr>td]:py-3 [&>table>tbody>tr>td]:text-sm [&>table>tbody>tr>td]:border-t [&>table>tbody>tr>td]:border-zinc-100 dark:[&>table>tbody>tr>td]:border-zinc-800
                        [&>table>tbody>tr]:transition-colors hover:[&>table>tbody>tr]:bg-zinc-50/50 dark:hover:[&>table>tbody>tr]:bg-zinc-800/30
                        [&>img]:rounded-2xl [&>img]:border [&>img]:border-zinc-100 dark:[&>img]:border-zinc-800 [&>img]:shadow-xl [&>img]:my-8
                        [&>hr]:border-t-2 [&>hr]:border-zinc-100 dark:[&>hr]:border-zinc-800 [&>hr]:my-12 [&>hr]:rounded-full
                    "
                    dangerouslySetInnerHTML={{ __html: htmlContent }}
                />
            </article>
        </div>
    );
}
