import { getD1Database } from './cloudflare';

export interface MediaAsset {
    id: string;
    filename: string;
    url: string;
    alt_text?: string;
    caption?: string;
    file_size?: number;
    mime_type?: string;
    uploaded_by?: string;
    created_at?: string;
}

export async function getAllMedia(db: D1Database): Promise<MediaAsset[]> {
    const stmt = db.prepare('SELECT * FROM media ORDER BY created_at DESC');
    const result = await stmt.all<MediaAsset>();
    return result.results;
}

export async function getMediaById(db: D1Database, id: string): Promise<MediaAsset | null> {
    const stmt = db.prepare('SELECT * FROM media WHERE id = ? LIMIT 1').bind(id);
    return await stmt.first<MediaAsset>();
}

export async function registerMediaAsset(db: D1Database, asset: MediaAsset): Promise<void> {
    const stmt = db.prepare(`
        INSERT INTO media (id, filename, url, alt_text, caption, file_size, mime_type, uploaded_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
        asset.id,
        asset.filename,
        asset.url,
        asset.alt_text || null,
        asset.caption || null,
        asset.file_size || null,
        asset.mime_type || null,
        asset.uploaded_by || null
    );
    await stmt.run();
}

export async function deleteMediaAsset(db: D1Database, id: string): Promise<void> {
    const stmt = db.prepare('DELETE FROM media WHERE id = ?').bind(id);
    await stmt.run();
}
