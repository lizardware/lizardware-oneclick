'use client';

import { forwardRef, useEffect } from 'react';

interface EditorPreviewProps {
    url: string;
    type: 'page' | 'blog';
    isResizing?: boolean;
}

const EditorPreview = forwardRef<HTMLIFrameElement, EditorPreviewProps>(
    ({ url, type, isResizing }, ref) => {
        useEffect(() => {
            if (!ref || typeof ref === 'function') return;
            
            const iframe = ref.current;
            if (!iframe) return;

            const handleLoad = () => {
                try {
                    const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
                    if (!iframeDoc) return;

                    // Intercept all clicks in the iframe
                    const clickHandler = (e: MouseEvent) => {
                        const target = e.target as HTMLElement;
                        
                        // Allow theme toggle button clicks (check for common theme toggle attributes)
                        const isThemeToggle = target.closest('[data-theme-toggle]') || 
                                             target.closest('button[aria-label*="theme"]') ||
                                             target.closest('button[aria-label*="dark"]') ||
                                             target.closest('button[title*="theme"]') ||
                                             target.closest('button[title*="dark"]');
                        
                        if (isThemeToggle) {
                            // Allow theme toggle to work
                            return;
                        }

                        // Prevent all link navigation
                        const link = target.closest('a');
                        if (link) {
                            e.preventDefault();
                            e.stopPropagation();
                            return false;
                        }
                    };

                    // Add click handler to iframe document
                    iframeDoc.addEventListener('click', clickHandler, true);

                    // Cleanup on unmount
                    return () => {
                        iframeDoc.removeEventListener('click', clickHandler, true);
                    };
                } catch (err) {
                    // Cross-origin iframe, can't access content
                    console.warn('Cannot access iframe content:', err);
                }
            };

            iframe.addEventListener('load', handleLoad);
            
            // If iframe is already loaded
            if (iframe.contentDocument?.readyState === 'complete') {
                handleLoad();
            }

            return () => {
                iframe.removeEventListener('load', handleLoad);
            };
        }, [ref, url]);

        return (
            <div className="flex-grow bg-gray-100 dark:bg-zinc-950 flex flex-col p-3 relative overflow-hidden">
                {/* Preview Toolbar - Moved to bottom and added breathing effect */}
                <div className="absolute bottom-6 left-0 right-0 z-10 flex justify-center items-center pointer-events-none">
                    <div className="bg-zinc-900 dark:bg-black border border-white/10 rounded-full px-4 py-2 text-[10px] font-black uppercase tracking-widest shadow-[0_20px_50px_rgba(0,0,0,0.3)] pointer-events-auto flex items-center gap-2.5">
                        <span className="relative flex h-2 w-2">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                        </span>
                        <span className="text-white animate-[pulse_3s_ease-in-out_infinite] tracking-[0.2em]">Live Preview</span>
                        <span className="h-3 w-px bg-white/20 mx-0.5" />
                        <span className="text-primary font-black">
                            {type === 'page' ? 'PAGE' : 'POST'}
                        </span>
                    </div>
                </div>

                {/* Preview Iframe */}
                <div className="w-full h-full relative group shadow-[0_32px_64px_-12px_rgba(0,0,0,0.15)] dark:shadow-[0_32px_64px_-12px_rgba(0,0,0,0.5)]">
                    <iframe
                        ref={ref}
                        src={url}
                        className={`w-full h-full bg-white dark:bg-zinc-900 rounded-2xl border border-gray-200 dark:border-zinc-800 overflow-hidden ${isResizing ? 'pointer-events-none' : ''}`}
                        title="Content Preview"
                    />
                </div>
            </div>
        );
    }
);

EditorPreview.displayName = 'EditorPreview';

export default EditorPreview;
