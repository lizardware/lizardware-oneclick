"use client";

import React from "react";
import { Database } from "lucide-react";

export interface StatItem {
    label: string;
    value: number;
    icon: React.ReactNode;
    color: string;
    bg?: string;
}

interface QuickStatsNavProps {
    title?: string;
    titleIcon?: React.ReactNode;
    titleColor?: string;
    stats: StatItem[];
    variant?: 'horizontal' | 'vertical' | 'responsive';
}

export function QuickStatsNav({
    title = "Data Matrix",
    titleIcon = <Database size={14} className="animate-pulse" />,
    titleColor = "text-emerald-500",
    stats,
    variant = 'horizontal'
}: QuickStatsNavProps) {
    // Layout Logic
    const containerClasses = {
        horizontal: "flex-row items-center gap-6",
        vertical: "flex-col items-start gap-4 min-w-[150px]",
        responsive: "flex-row md:flex-col items-center md:items-start md:min-w-[150px] gap-6 md:gap-4"
    };

    const dividerClasses = {
        horizontal: "hidden md:block h-8 w-px bg-gray-100 dark:bg-zinc-800",
        vertical: "w-full h-px bg-gray-100 dark:bg-zinc-800",
        responsive: "md:hidden h-8 w-px bg-gray-100 dark:bg-zinc-800 md:border-b-0" // Vertical line on mobile, hidden on desktop
    };

    const titleContainerClasses = {
        horizontal: "items-center",
        vertical: "items-center w-full",
        responsive: "items-center md:items-start md:w-full"
    };

    const valueSizeClasses = {
        horizontal: "text-lg md:text-base", // Readable on headers
        vertical: "text-lg md:text-sm", // Compact vertical stack
        responsive: "text-lg md:text-sm" // Compact vertical stack on desktop
    };

    return (
        <div className={`flex px-6 py-4 bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-[2rem] shadow-xl relative overflow-hidden group ${containerClasses[variant]}`}>

            {/* Title Section */}
            <div className={`flex gap-1.5 text-[10px] font-black uppercase tracking-[0.2em] ${titleColor} shrink-0 transition-transform group-hover:translate-x-0.5 ${titleContainerClasses[variant]} ${variant === 'responsive' ? 'hidden md:flex' : ''}`}>
                {titleIcon}
                {title}
            </div>

            {/* Mobile Title for Responsive Mode */}
            {variant === 'responsive' && (
                <div className={`md:hidden flex items-center gap-1.5 text-[10px] font-black uppercase tracking-[0.2em] ${titleColor} shrink-0`}>
                    {titleIcon}
                    <span className="hidden sm:inline">{title}</span>
                </div>
            )}

            {/* Divider */}
            <div className={`${dividerClasses[variant]}`} />

            {/* Stats Row/Col */}
            <div className={`flex ${variant === 'vertical' ? 'flex-col gap-2 w-full pl-0' : variant === 'responsive' ? 'flex-row md:flex-col gap-6 md:gap-2 md:w-full md:border-l border-gray-100 dark:border-zinc-800 md:pl-3' : 'flex-row items-center gap-6'}`}>
                {stats.map((stat, i) => (
                    <div key={i} className={`flex items-center gap-3 group/item ${variant === 'responsive' ? 'md:gap-2' : ''}`}>
                        {/* Icon */}
                        <div className={`w-8 h-8 md:w-6 md:h-6 rounded-xl ${stat.bg || 'bg-gray-100 dark:bg-zinc-800'} ${stat.color} flex items-center justify-center transition-transform group-hover/item:scale-110 shadow-sm`}>
                            {React.cloneElement(stat.icon as React.ReactElement, { size: 14 })}
                        </div>

                        {/* Value & Label - Side by Side */}
                        <div className="flex items-center gap-2">
                            <span className={`${valueSizeClasses[variant]} font-black text-zinc-900 dark:text-zinc-100 leading-none tracking-tight`}>
                                {stat.value}
                            </span>
                            <span className="text-[9px] md:text-[8px] font-bold text-gray-400 uppercase tracking-widest pt-0.5">
                                {stat.label}
                            </span>
                        </div>
                    </div>
                ))}
            </div>

            {/* Subtle Background Glow */}
            <div className={`absolute -bottom-4 -right-4 w-24 h-24 rounded-full blur-2xl opacity-5 group-hover:opacity-10 transition-all ${titleColor.replace('text-', 'bg-')}`}></div>
        </div>
    );
}
