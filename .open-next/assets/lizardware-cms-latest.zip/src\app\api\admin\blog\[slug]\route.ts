import { NextRequest, NextResponse } from "next/server";
import { getPostBySlug } from "@/lib/blog";
import { upsertPostToD1, deletePostFromD1 } from "@/lib/blog-storage";
import { getD1Database, dbUnavailableResponse } from '@/lib/cloudflare';
import { Post } from "@/types/blog";

// GET /api/admin/blog/[slug] - Get single post
export async function GET(
    request: NextRequest,
    { params }: { params: Promise<{ slug: string }> }
) {
    try {
        const db = await getD1Database();
        if (!db) return dbUnavailableResponse();

        const { slug } = await params;
        const post = await getPostBySlug(slug);

        if (!post) {
            return NextResponse.json({ error: "Post not found" }, { status: 404 });
        }

        return NextResponse.json({ post });
    } catch (error) {
        return NextResponse.json(
            { error: error instanceof Error ? error.message : String(error) },
            { status: 500 }
        );
    }
}

// PUT /api/admin/blog/[slug] - Update post
export async function PUT(
    request: NextRequest,
    { params }: { params: Promise<{ slug: string }> }
) {
    try {
        const db = await getD1Database();
        if (!db) return dbUnavailableResponse();

        const { slug: urlSlug } = await params;
        const post = await request.json() as Post;

        // Ensure slug matches URL
        post.slug = urlSlug;

        await upsertPostToD1(db, post);

        return NextResponse.json({
            success: true,
            message: "Post updated successfully",
        });
    } catch (error) {
        return NextResponse.json(
            { error: error instanceof Error ? error.message : String(error) },
            { status: 500 }
        );
    }
}

// DELETE /api/admin/blog/[slug] - Delete post
export async function DELETE(
    request: NextRequest,
    { params }: { params: Promise<{ slug: string }> }
) {
    try {
        const db = await getD1Database();
        if (!db) return dbUnavailableResponse();

        const { slug } = await params;
        await deletePostFromD1(db, slug);

        return NextResponse.json({
            success: true,
            message: "Post deleted successfully",
        });
    } catch (error) {
        return NextResponse.json(
            { error: error instanceof Error ? error.message : String(error) },
            { status: 500 }
        );
    }
}
