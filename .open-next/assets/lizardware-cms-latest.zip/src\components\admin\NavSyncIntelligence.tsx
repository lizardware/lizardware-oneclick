'use client';

import { useState, useEffect } from 'react';
import { Sparkles, Plus, Loader2 } from 'lucide-react';

export interface Suggestion {
    slug: string;
    title: string;
    show_in_nav: boolean;
    nav_label?: string;
    nav_parent?: string;
    nav_order?: number;
    type: 'page' | 'post' | 'system';
    href: string;
}

interface NavSyncIntelligenceProps {
    existingHrefs: Set<string>;
    onAdd: (suggestion: Suggestion) => void;
}

export default function NavSyncIntelligence({ existingHrefs, onAdd }: NavSyncIntelligenceProps) {
    const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetch('/api/admin/nav/suggestions')
            .then(res => res.json() as Promise<{ pages: any[], posts: any[], internal_routes: any[] }>)
            .then(data => {
                const all: Suggestion[] = [
                    ...data.pages.map((p: any) => ({ ...p, type: 'page', href: p.slug.startsWith('/') ? p.slug : `/${p.slug}` })),
                    ...data.posts.map((p: any) => ({ ...p, type: 'post', href: `/blog/${p.slug}` })),
                    ...data.internal_routes.map((r: any) => ({ ...r, type: 'system', href: r.path }))
                ];

                // Only keep items marked for nav AND not already in nav
                const filtered = all.filter(s => s.show_in_nav && !existingHrefs.has(s.href));
                setSuggestions(filtered);
            })
            .catch(err => console.error(err))
            .finally(() => setLoading(false));
    }, [existingHrefs]);

    if (loading) {
        return (
            <div className="bg-indigo-600/5 border border-indigo-500/20 p-6 rounded-3xl animate-pulse flex items-center justify-center gap-3 text-indigo-500 text-xs font-bold">
                <Loader2 size={16} className="animate-spin" />
                Scanning Content...
            </div>
        );
    }

    if (suggestions.length === 0) return null;

    return (
        <div className="bg-gradient-to-br from-indigo-600 via-indigo-700 to-purple-800 p-6 rounded-3xl text-white shadow-xl shadow-indigo-600/20 relative overflow-hidden animate-in zoom-in-95 duration-500">
            <div className="relative z-10 space-y-4">
                <div className="flex items-center justify-between">
                    <h3 className="font-black text-lg flex items-center gap-2">
                        <Sparkles size={20} className="text-yellow-400 animate-pulse" />
                        Sync Intelligence
                    </h3>
                    <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-full font-black tracking-widest uppercase">
                        {suggestions.length} Found
                    </span>
                </div>

                <p className="text-[11px] text-white/80 leading-relaxed font-medium">
                    New content items are requesting to be added to your navigation structure.
                </p>

                <div className="space-y-2 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                    {suggestions.map((s, i) => (
                        <div key={i} className="p-3 bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 flex items-center justify-between group hover:bg-white/20 transition-all">
                            <div className="min-w-0 flex-1">
                                <div className="flex items-center gap-2 mb-0.5">
                                    <span className={`text-[8px] font-black uppercase tracking-widest px-1.5 py-0.5 rounded ${s.type === 'page' ? 'bg-blue-500/30' :
                                        s.type === 'post' ? 'bg-orange-500/30' : 'bg-emerald-500/30'
                                        }`}>
                                        {s.type}
                                    </span>
                                    {s.nav_parent && (
                                        <span className="text-[8px] text-white/50 truncate">
                                            Parent: {s.nav_parent}
                                        </span>
                                    )}
                                </div>
                                <div className="text-sm font-black truncate">{s.nav_label || s.title}</div>
                                <div className="text-[9px] text-white/40 font-mono truncate">{s.href}</div>
                            </div>
                            <button
                                onClick={() => onAdd(s)}
                                className="ml-3 p-2.5 bg-white text-indigo-600 hover:bg-yellow-400 hover:text-black rounded-xl transition-all shadow-lg active:scale-95 flex-shrink-0"
                                title="Add to Navigation"
                            >
                                <Plus size={16} strokeWidth={3} />
                            </button>
                        </div>
                    ))}
                </div>

                <p className="text-[9px] text-white/40 italic">
                    Tip: Content creators can manage these suggestions from the Editor.
                </p>
            </div>
            {/* Decorative Pulse */}
            <div className="absolute -bottom-12 -left-12 w-32 h-32 bg-yellow-400/10 rounded-full blur-3xl animate-pulse"></div>
            <div className="absolute -top-12 -right-12 w-48 h-48 bg-white/5 rounded-full blur-2xl"></div>
        </div>
    );
}
