"use client";

import { useEffect } from "react";
import { marked } from 'marked';

export function ContentPreviewListener() {
    useEffect(() => {
        // Only run in iframe
        if (window.self === window.top) return;

        const handleMessage = async (event: MessageEvent) => {
            if (event.data?.type === 'UPDATE_CONTENT') {
                const { title, content, description } = event.data.payload;

                // Update page title (browser tag)
                if (title) {
                    const siteName = document.title.split('|')[1]?.trim() || 'Lizardware';
                    document.title = `${title} | ${siteName}`;
                }

                // Update Title in DOM
                const titleElement = document.querySelector('[data-content-title]');
                if (titleElement && title) {
                    titleElement.textContent = title;
                }

                // Update Description in DOM
                const descElement = document.querySelector('[data-content-description]');
                if (descElement && description) {
                    descElement.textContent = description;
                }

                // Update Body/Content in DOM
                const contentElement = document.querySelector('[data-content-body]');
                if (contentElement && content) {
                    // Try to render markdown if it looks like markdown
                    // Otherwise just set it. We use Tiptap usually which gives HTML.
                    // But some editors give Markdown.
                    try {
                        const htmlContent = await marked.parse(content);
                        contentElement.innerHTML = htmlContent;
                    } catch (e) {
                        contentElement.innerHTML = content;
                    }
                }

                // Update description meta tag
                if (description) {
                    const metaDesc = document.querySelector('meta[name="description"]');
                    if (metaDesc) metaDesc.setAttribute('content', description);
                }
            }
        };

        window.addEventListener('message', handleMessage);
        return () => window.removeEventListener('message', handleMessage);
    }, []);

    return null;
}
