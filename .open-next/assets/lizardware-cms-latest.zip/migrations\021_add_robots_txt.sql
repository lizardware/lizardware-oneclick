-- Migration: Add robots_txt to seo_global_settings
-- Version: 0.3.2

ALTER TABLE seo_global_settings ADD COLUMN robots_txt TEXT DEFAULT 'User-agent: *\nAllow: /\nDisallow: /admin/\nDisallow: /api/\nDisallow: /setup/\n\nSitemap: https://example.com/sitemap.xml';
