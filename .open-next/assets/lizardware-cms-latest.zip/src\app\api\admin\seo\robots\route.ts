import { NextRequest, NextResponse } from 'next/server';
import { getD1Database, dbUnavailableResponse } from '@/lib/cloudflare';

export const dynamic = 'force-dynamic';

export async function GET() {
    try {
        const db = await getD1Database();
        if (!db) {
            return dbUnavailableResponse();
        }

        const settings = await db.prepare('SELECT robots_txt FROM seo_global_settings WHERE id = 1').first() as { robots_txt: string } | null;

        // Convert escaped newlines to actual newlines
        let robotsTxt = settings?.robots_txt || '';
        if (robotsTxt) {
            robotsTxt = robotsTxt.replace(/\\n/g, '\n');
        }

        return NextResponse.json({ robots_txt: robotsTxt });
    } catch (error) {
        console.error('Failed to fetch robots.txt:', error);
        return NextResponse.json({ error: 'Failed to fetch settings' }, { status: 500 });
    }
}

export async function POST(request: NextRequest) {
    try {
        const db = await getD1Database();
        if (!db) {
            return dbUnavailableResponse();
        }

        const { robots_txt } = await request.json() as { robots_txt: string };

        await db.prepare(`
            UPDATE seo_global_settings 
            SET robots_txt = ?, updated_at = CURRENT_TIMESTAMP 
            WHERE id = 1
        `).bind(robots_txt).run();

        return NextResponse.json({ success: true });
    } catch (error) {
        console.error('Failed to save robots.txt:', error);
        return NextResponse.json({ error: 'Failed to save settings' }, { status: 500 });
    }
}
