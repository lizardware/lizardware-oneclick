/**
 * Generate wrangler.jsonc from CLI arguments
 * Used by GitHub Actions to inject provisioned resource IDs
 * 
 * Usage:
 *   node generate-wrangler-config.js --kv-id ID --d1-id ID --r2-name NAME
 */

const fs = require('fs');
const path = require('path');

// Parse CLI arguments
const args = process.argv.slice(2);
const getArg = (flag) => {
    const index = args.indexOf(flag);
    return index !== -1 && args[index + 1] ? args[index + 1] : null;
};

const KV_ID = getArg('--kv-id') || process.env.WRANGLER_KV_ID;
const D1_ID = getArg('--d1-id') || process.env.WRANGLER_D1_ID;
const R2_NAME = getArg('--r2-name') || process.env.WRANGLER_R2_NAME;
const PROJECT_NAME = getArg('--project-name') || process.env.CF_PROJECT_NAME;

if (!KV_ID || !D1_ID) {
    console.error('❌ Error: Missing required arguments');
    console.error('Usage: node generate-wrangler-config.js --kv-id ID --d1-id ID [--r2-name NAME]');
    process.exit(1);
}

console.log('📝 Generating wrangler.jsonc with provisioned resource IDs...');
console.log(`  KV ID:  ${KV_ID}`);
console.log(`  D1 ID:  ${D1_ID}`);
console.log(`  R2 NAME: ${R2_NAME || 'null'}`);

// Read template
const templatePath = path.join(__dirname, 'wrangler.template.jsonc');
const outputPath = path.join(__dirname, '..', 'wrangler.jsonc');

let template;
if (fs.existsSync(templatePath)) {
    template = fs.readFileSync(templatePath, 'utf8');
} else {
    // If template doesn't exist, fail early with clear message
    console.error('❌ Error: wrangler.template.jsonc not found!');
    console.error(`Expected path: ${templatePath}`);
    console.error('This file is required for GitHub Actions deployment.');
    process.exit(1);
}

// Replace placeholders for KV (both id and preview_id)
let config = template
    .replace(/"id":\s*"[^"]*",\s*\/\/ KV_ID/g, `"id": "${KV_ID}", // KV_ID`)
    .replace(/"preview_id":\s*"[^"]*"/g, `"preview_id": "${KV_ID}"`);

// Replace placeholders for D1 (both database_id and preview_database_id)
config = config
    .replace(/"database_id":\s*"[^"]*",\s*\/\/ D1_ID/g, `"database_id": "${D1_ID}", // D1_ID`)
    .replace(/"preview_database_id":\s*"[^"]*"/g, `"preview_database_id": "${D1_ID}"`);

// Replace R2 bucket name if provided
if (R2_NAME && R2_NAME !== 'null') {
    config = config.replace(/"bucket_name":\s*"[^"]*"\s*\/\/ R2_BUCKET/g, `"bucket_name": "${R2_NAME}" // R2_BUCKET`);
} else {
    // Remove the r2_buckets block if no R2 name is provided
    // Match optional comma, whitespace, "r2_buckets", array brackets, and content
    config = config.replace(/,?\s*"r2_buckets":\s*\[\s*\{[\s\S]*?\}\s*\]/g, '');
}

// Replace project name if provided
if (PROJECT_NAME && PROJECT_NAME !== 'null') {
    config = config.replace(/"name":\s*"[^"]*"/, `"name": "${PROJECT_NAME}"`);
}

// Write output
fs.writeFileSync(outputPath, config, 'utf8');
console.log('✅ wrangler.jsonc generated successfully!');
console.log(`📄 Output: ${outputPath}`);
