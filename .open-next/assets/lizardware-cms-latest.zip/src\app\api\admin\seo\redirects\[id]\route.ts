import { NextRequest, NextResponse } from 'next/server';

// PUT: Update redirect
export async function PUT(
    request: NextRequest,
    context: { params: Promise<{ id: string }> }
) {
    const { id } = await context.params;
    const env = getEnv(request);

    if (!env.DB) {
        return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }

    const { source_path, destination_path, type } = await request.json() as any;

    await env.DB.prepare(
        'UPDATE redirects SET source_path = ?, destination_path = ?, type = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?'
    ).bind(source_path, destination_path, type || 301, id).run();

    return NextResponse.json({ success: true });
}

// DELETE: Remove redirect
export async function DELETE(
    request: NextRequest,
    context: { params: Promise<{ id: string }> }
) {
    const { id } = await context.params;
    const env = getEnv(request);

    if (!env.DB) {
        return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }

    await env.DB.prepare('DELETE FROM redirects WHERE id = ?').bind(id).run();

    return NextResponse.json({ success: true });
}

function getEnv(request: NextRequest): any {
    return (request as any).env || process.env;
}
