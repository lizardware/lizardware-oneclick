const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Exclude list (patterns to skip)
const EXCLUDE_LIST = [
    '.git',
    '.ai.docs',
    '.agent',
    '.github',
    'node_modules',
    '.next',
    '.wrangler',
    '.open-next',
    'release.zip',
    'package-lock.json',
    'release-stats.json',
    'scripts/package-release.js'
];

/**
 * Lizardware CMS - Release Packager (PowerShell Version)
 * Generates a clean ZIP for direct deployment using native Windows features.
 */
function packageReleasePowerShell() {
    const rootDir = path.resolve(__dirname, '..');
    const version = require(path.join(rootDir, 'package.json')).version;

    // Safety Check: Ensure we are on the 'template' branch
    try {
        const branch = execSync('git rev-parse --abbrev-ref HEAD').toString().trim();
        console.log(`🌿 Current branch: ${branch}`);

        if (branch !== 'template') {
            const force = process.argv.includes('--force');
            if (!force) {
                console.error(`\n❌ ERROR: You are attempting to package from '${branch}'.`);
                console.error(`   Releases should normally be packaged from the 'template' branch`);
                console.error(`   to ensure internal documentation is excluded.`);
                console.error(`\n   To override, run: node scripts/package-release.js --force\n`);
                process.exit(1);
            } else {
                console.warn(`⚠️ WARNING: Forcing package creation from non-template branch '${branch}'.`);
            }
        }
    } catch (e) {
        console.warn('⚠️ Unable to detect git branch. Proceeding with caution.');
    }

    const outputName = `lizardware-cms-v${version}.zip`;
    const outputPath = path.resolve(__dirname, '..', outputName);

    console.log(`📦 Packaging Lizardware CMS v${version} (via PowerShell)...`);

    // Build exclusion string for PowerShell
    // We'll use a temporary folder strategy for cleanliness
    const tempDir = path.join(rootDir, '.release-temp');

    // Rename old temp dir if it exists (faster than deleting on Windows)
    if (fs.existsSync(tempDir)) {
        const oldTemp = `${tempDir}-old-${Date.now()}`;
        try {
            fs.renameSync(tempDir, oldTemp);
            console.log(`📦 Moved old temp to: ${path.basename(oldTemp)}`);
        } catch (e) {
            console.warn('⚠️ Old temp dir exists, proceeding anyway...');
        }
    }

    // Create fresh temp directory
    fs.mkdirSync(tempDir, { recursive: true });

    // Filtered copy
    function copyFiltered(src, dest) {
        const relativeSrc = path.relative(rootDir, src);

        // Prevent copying the temp directory or any subdirectory within it
        if (src === tempDir || relativeSrc.includes('.release-temp')) return;

        const files = fs.readdirSync(src);
        for (const file of files) {
            const srcPath = path.join(src, file);
            const destPath = path.join(dest, file);
            const relativePath = path.relative(rootDir, srcPath);

            // Skip excluded patterns
            if (EXCLUDE_LIST.some(pattern => relativePath.startsWith(pattern) || file === pattern)) continue;
            // Skip temp dir and output file
            if (srcPath === tempDir || srcPath === outputPath || relativePath.includes('.release-temp')) continue;

            const stat = fs.statSync(srcPath);
            if (stat.isDirectory()) {
                if (!fs.existsSync(destPath)) fs.mkdirSync(destPath, { recursive: true });
                copyFiltered(srcPath, destPath);
            } else {
                fs.copyFileSync(srcPath, destPath);
            }
        }
    }

    try {
        console.log('📂 Copying files...');
        copyFiltered(rootDir, tempDir);

        console.log('🗜️ Zipping...');
        if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);

        // Use PowerShell to compress the temp directory
        execSync(`powershell -Command "Compress-Archive -Path '${tempDir}\\*' -DestinationPath '${outputPath}' -Force"`);

        const stats = fs.statSync(outputPath);
        const sizeInMB = (stats.size / (1024 * 1024)).toFixed(2);

        fs.writeFileSync(path.join(rootDir, 'release-stats.json'), JSON.stringify({
            version,
            filename: outputName,
            branch: tryGetBranch(),
            size: stats.size,
            sizeFormatted: `${sizeInMB} MB`,
            timestamp: new Date().toISOString(),
            method: 'PowerShell'
        }, null, 2));

        console.log(`✅ Release packaged: ${outputName} (${sizeInMB} MB)`);
    } catch (err) {
        console.error('❌ Packaging failed:', err.message);
        process.exit(1);
    } finally {
        // Cleanup if successful
        try {
            if (fs.existsSync(tempDir)) fs.rmSync(tempDir, { recursive: true, force: true });
        } catch (e) { }
    }
}

function tryGetBranch() {
    try {
        return execSync('git rev-parse --abbrev-ref HEAD').toString().trim();
    } catch {
        return 'unknown';
    }
}

packageReleasePowerShell();
