-- Seed: Blog / Publishing
-- Created: 2026-01-03
-- Strategy: Content-focused structure

-- 1. Categories
INSERT OR IGNORE INTO categories (name, slug, description) VALUES
('Writing', 'writing', 'Articles about the craft of writing and storytelling.'),
('Lifestyle', 'lifestyle', 'Thoughts on modern living and minimalism.'),
('Travel', 'travel', 'Journeys and photography from around the world.');

-- 2. Blog Posts
INSERT OR IGNORE INTO posts (slug, title, content, description, author, author_id, tags, date, status, category_id, created_at, updated_at)
VALUES (
  'the-art-of-storytelling',
  'The Art of Storytelling',
  '<h1>Why Stories Matter</h1><p>Human beings are wired for stories. From ancient campfires to modern streaming services, narrative is how we make sense of the world.</p><h2>The Elements of a Good Story</h2><ul><li><strong>Character:</strong> Who is it about?</li><li><strong>Conflict:</strong> What stands in their way?</li><li><strong>Resolution:</strong> How does it end?</li></ul><p>Whether you''re writing a novel or a blog post, these elements are essential.</p>',
  'Exploring the fundamental elements of narrative structure.',
  'Editor',
  'editor',
  '["Writing", "Creativity"]',
  datetime('now'),
  'published',
  'writing',
  datetime('now'),
  datetime('now')
);

INSERT OR IGNORE INTO posts (slug, title, content, description, author, author_id, tags, date, status, category_id, created_at, updated_at)
VALUES (
  'digital-minimalism',
  'Embracing Digital Minimalism',
  '<h1>Less is More</h1><p>In a world of constant notifications and infinite scrolling, reclaiming your attention is a radical act.</p><p>Digital minimalism isn''t about rejecting technology; it''s about using it intentionally.</p><blockquote>"The cost of a thing is the amount of what I call life which is required to be exchanged for it, immediately or in the long run." - Henry David Thoreau</blockquote>',
  'Thoughts on intentional technology use.',
  'Contributor',
  'contributor',
  '["Lifestyle", "Minimalism"]',
  datetime('now', '-3 days'),
  'published',
  'lifestyle',
  datetime('now'),
  datetime('now')
);

INSERT OR IGNORE INTO posts (slug, title, content, description, author, author_id, tags, date, status, category_id, created_at, updated_at)
VALUES (
  'travel-diary-kyoto',
  'Travel Diary: Autumn in Kyoto',
  '<h1>Red Maples and Gold Temples</h1><p>Kyoto in autumn is a sight to behold. The city transforms into a canvas of vibrant reds, oranges, and golds.</p><p>We spent our days wandering through Arashiyama and our evenings exploring the narrow alleys of Pontocho.</p><p><em>(Gallery placeholder)</em></p>',
  'A visual journey through Kyoto during the fall foliage season.',
  'Traveler',
  'traveler',
  '["Travel", "Photography", "Japan"]',
  datetime('now', '-10 days'),
  'published',
  'travel',
  datetime('now'),
  datetime('now')
);

-- 3. Pages
-- Home (Blog Layout usually handles home, but we provide a text home page too)
INSERT OR IGNORE INTO pages (slug, title, content, description, status, sort_order, is_template, created_at, updated_at)
VALUES (
  'welcome',
  'Welcome to {{siteName}}',
  '<h1>Read. Think. Grow.</h1><p>Welcome to <strong>{{siteName}}</strong>, a space dedicated to thoughtful ideas and compelling stories.</p><p>Check out our <a href="/blog">latest posts</a> or learn more <a href="/about">about us</a>.</p>',
  'Home of {{siteName}}',
  'published',
  0,
  0,
  datetime('now'),
  datetime('now')
);

-- About Page
INSERT OR IGNORE INTO pages (slug, title, content, description, status, sort_order, is_template, created_at, updated_at)
VALUES (
  'about',
  'About the Author',
  '<h1>Hi, I''m the Editor.</h1><p>I started {{siteName}} as a way to share my thoughts on technology, culture, and design.</p><p>When I''m not writing, you can find me hiking, reading, or brewing the perfect cup of coffee.</p><h2>Contact</h2><p>Have a question or a story idea? Reach out at <a href="mailto:hello@example.com">hello@example.com</a>.</p>',
  'About the voice behind {{siteName}}.',
  'published',
  10,
  0,
  datetime('now'),
  datetime('now')
);
