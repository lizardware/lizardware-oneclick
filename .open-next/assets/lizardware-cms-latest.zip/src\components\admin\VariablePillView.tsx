'use client';

import { NodeViewWrapper } from '@tiptap/react';
import { getVariable } from '@/lib/variables';

interface VariablePillViewProps {
    node: {
        attrs: {
            variableName: string;
        };
    };
}

export default function VariablePillView({ node }: VariablePillViewProps) {
    const variableName = node.attrs.variableName;
    const variable = getVariable(variableName);

    if (!variable) {
        return (
            <NodeViewWrapper
                as="span"
                className="variable-pill variable-pill--unknown"
                data-tooltip={`Unknown variable: ${variableName}`}
            >
                <span className="variable-pill__label">{`{{${variableName}}}`}</span>
            </NodeViewWrapper>
        );
    }

    return (
        <NodeViewWrapper
            as="span"
            className="variable-pill"
            data-tooltip={`${variable.description} (example: "${variable.example}")`}
        >
            <span className="variable-pill__icon">{variable.icon}</span>
            <span className="variable-pill__label">{variable.label}</span>
        </NodeViewWrapper>
    );
}
