-- Migration 019: Create forum moderation tables
-- Version: 0.6.0
-- Purpose: Content moderation, reports, and user management

CREATE TABLE IF NOT EXISTS forum_reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id INTEGER,
  thread_id INTEGER,
  reporter_user_id INTEGER NOT NULL,
  reason TEXT NOT NULL, -- 'spam', 'offensive', 'off-topic', 'harassment', 'other'
  details TEXT,
  status TEXT DEFAULT 'pending', -- 'pending', 'resolved', 'dismissed'
  resolved_by_user_id INTEGER,
  resolved_at DATETIME,
  moderator_notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (post_id) REFERENCES forum_posts(id) ON DELETE CASCADE,
  FOREIGN KEY (thread_id) REFERENCES forum_threads(id) ON DELETE CASCADE,
  FOREIGN KEY (reporter_user_id) REFERENCES forum_users(id) ON DELETE CASCADE,
  FOREIGN KEY (resolved_by_user_id) REFERENCES forum_users(id) ON DELETE SET NULL,
  CHECK ((post_id IS NOT NULL AND thread_id IS NULL) OR (post_id IS NULL AND thread_id IS NOT NULL))
);

CREATE INDEX idx_forum_reports_status ON forum_reports(status);
CREATE INDEX idx_forum_reports_post ON forum_reports(post_id);
CREATE INDEX idx_forum_reports_thread ON forum_reports(thread_id);
CREATE INDEX idx_forum_reports_reporter ON forum_reports(reporter_user_id);
CREATE INDEX idx_forum_reports_created ON forum_reports(created_at DESC);

-- User bans and restrictions
CREATE TABLE IF NOT EXISTS forum_user_bans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  banned_by_user_id INTEGER NOT NULL,
  reason TEXT NOT NULL,
  expires_at DATETIME, -- NULL for permanent ban
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES forum_users(id) ON DELETE CASCADE,
  FOREIGN KEY (banned_by_user_id) REFERENCES forum_users(id) ON DELETE SET NULL
);

CREATE INDEX idx_forum_user_bans_user ON forum_user_bans(user_id);
CREATE INDEX idx_forum_user_bans_expires ON forum_user_bans(expires_at);
