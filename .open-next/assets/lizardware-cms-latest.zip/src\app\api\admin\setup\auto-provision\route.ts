import { NextResponse } from 'next/server';
import {
    createKVNamespace,
    createD1Database,
    createR2Bucket,
    executeD1Migration,
    updateWranglerConfig,
} from '@/lib/cloudflare-api';
import { INSTALL_STRUCTURE_SQL } from '@/data/install-sql';

export async function POST(req: Request) {
    try {
        const body = await req.json() as any;
        let { apiToken, accountId, projectName, clerkPublishableKey, clerkSecretKey } = body;

        // Fallback to system environment variables if not provided in body
        if (!apiToken) apiToken = process.env.CLOUDFLARE_API_TOKEN;
        if (!accountId) accountId = process.env.CLOUDFLARE_ACCOUNT_ID;
        if (!projectName) {
            projectName = process.env.CF_PROJECT_NAME ||
                process.env.CF_PAGES_PROJECT_NAME ||
                process.env.CLOUDFLARE_PROJECT_NAME;
        }

        // 1. Validation
        if (!apiToken || !accountId || !projectName) {
            return NextResponse.json(
                {
                    error: 'Missing required configuration: API Token, Account ID, and Project Name are required.',
                    missing: {
                        apiToken: !apiToken,
                        accountId: !accountId,
                        projectName: !projectName
                    }
                },
                { status: 400 }
            );
        }

        const client = { apiToken, accountId };
        const safeProjectName = projectName.toLowerCase().replace(/[^a-z0-9]/g, '-');

        // 2. Resource Provisioning
        console.log(`[Auto-Provision] Starting for project: ${safeProjectName}`);

        // A. Create KV
        console.log('[Auto-Provision] Creating KV Namespace...');
        let kv;
        try {
            kv = await createKVNamespace(client, `${safeProjectName}-config-kv`);
        } catch (e: any) {
            throw new Error(`KV Creation Failed: ${e.message}`);
        }

        // B. Create D1
        console.log('[Auto-Provision] Creating D1 Database...');
        let d1;
        try {
            d1 = await createD1Database(client, `${safeProjectName}-db`);
        } catch (e: any) {
            throw new Error(`D1 Creation Failed: ${e.message}`);
        }

        // C. Create R2 (Optional - Fail Safe)
        console.log('[Auto-Provision] Creating R2 Bucket...');
        let r2 = null;
        try {
            r2 = await createR2Bucket(client, `${safeProjectName}-media-bucket`);
        } catch (error: any) {
            console.warn('[Auto-Provision] R2 Bucket creation failed (Optional Step):', error.message);
            // Proceed without R2 - it's not critical for initial setup
        }

        // 3. Database Initialization (Migrations)
        console.log('[Auto-Provision] Initializing D1 database schema...');
        try {
            await executeD1Migration(client, d1.uuid, INSTALL_STRUCTURE_SQL);
        } catch (e: any) {
            throw new Error(`Database Migration Failed: ${e.message}`);
        }

        // 4. Update Local Configuration (Development Only)
        // In production, we cannot edit wrangler.jsonc. We must return the IDs to the user.
        let fileUpdated = false;
        try {
            console.log('[Auto-Provision] Attempting to update wrangler.jsonc...');
            // updateWranglerConfig now handles dynamic imports internally
            fileUpdated = await updateWranglerConfig(kv.id, d1.uuid, r2?.name);
        } catch (err) {
            console.warn('[Auto-Provision] Could not update wrangler.jsonc (likely in production/ephemeral):', err);
            fileUpdated = false;
        }

        // 5. (Optional) Set Clerk Secrets
        let secretsUpdated = false;
        if (clerkPublishableKey && clerkSecretKey) {
            try {
                // Only attempt to write .env.local if we are NOT in production
                // and seemingly in a Node.js-compatible environment (dev)
                if (process.env.NODE_ENV !== 'production') {
                    console.log('[Auto-Provision] Saving Clerk keys to .env.local...');

                    const fs = (await import('fs')).default;
                    const path = (await import('path')).default;

                    const envLocalPath = path.join(process.cwd(), '.env.local');

                    let envContent = '';
                    if (fs.existsSync(envLocalPath)) {
                        envContent = fs.readFileSync(envLocalPath, 'utf8');
                    }

                    const keys = {
                        NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY: clerkPublishableKey,
                        CLERK_SECRET_KEY: clerkSecretKey
                    };

                    let newEnvContent = envContent;
                    for (const [key, value] of Object.entries(keys)) {
                        if (newEnvContent.includes(`${key}=`)) {
                            newEnvContent = newEnvContent.replace(new RegExp(`${key}=.*`), `${key}=${value}`);
                        } else {
                            newEnvContent += `\n${key}=${value}`;
                        }
                    }

                    fs.writeFileSync(envLocalPath, newEnvContent, 'utf8');
                    console.log('[Auto-Provision] Clerk keys saved locally.');
                    secretsUpdated = true;
                } else {
                    console.log('[Auto-Provision] Skipping .env.local update (Production Environment)');
                }
            } catch (err) {
                console.warn('[Auto-Provision] Could not update .env.local:', err);
                secretsUpdated = false;
            }
        }

        console.log('[Auto-Provision] Success!');

        return NextResponse.json({
            success: true,
            message: fileUpdated
                ? 'All resources provisioned and configured successfully!'
                : 'Resources created! Manual configuration required for final step.',
            fileUpdated,
            secretsUpdated,
            resources: {
                kv: { id: kv.id, title: kv.title },
                d1: { id: d1.uuid, name: d1.name },
                r2: r2 ? { name: r2.name } : null
            }
        });

    } catch (error: any) {
        console.error('[Auto-Provision] Error:', error);
        return NextResponse.json(
            {
                error: error.message || 'An unexpected error occurred during auto-provisioning.',
                details: error.stack || null
            },
            { status: 500 }
        );
    }
}
