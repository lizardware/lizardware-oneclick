import siteConfigData from "@/data/site-config.json";
import { SiteConfig } from "@/types/site-config";

export const siteConfig: SiteConfig = siteConfigData as SiteConfig;

