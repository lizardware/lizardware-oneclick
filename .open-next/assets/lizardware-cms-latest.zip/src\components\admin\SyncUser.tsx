'use client';

import { useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';

export function SyncUser() {
    const { user, isLoaded } = useAuth();

    useEffect(() => {
        if (isLoaded && user) {
            // Trigger a shallow sync to ensure D1 has the author record
            // This is a safety fallback for when webhooks are delayed
            fetch('/api/admin/sync-profile', {
                method: 'POST',
                body: JSON.stringify({
                    id: user.id,
                    name: user.name,
                    email: user.email,
                    imageUrl: user.imageUrl,
                }),
            }).catch(err => console.error('Shallow sync failed', err));
        }
    }, [isLoaded, user]);

    return null;
}
