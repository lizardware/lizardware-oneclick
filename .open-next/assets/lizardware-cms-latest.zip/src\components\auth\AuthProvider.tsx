'use client';

import { ReactNode } from 'react';
import { ClerkProvider } from '@clerk/nextjs';
import { isClerkConfigured } from '@/lib/auth-config';
import { ClerkAuthAdapter } from './ClerkAuthAdapter';
import { LocalAuthProvider } from './LocalAuthProvider';

import { ClerkErrorBoundary } from './ClerkErrorBoundary';

export function AuthProvider({ children }: { children: ReactNode }) {
    const useClerk = isClerkConfigured();

    const localAuth = (
        <LocalAuthProvider>
            {children}
        </LocalAuthProvider>
    );

    if (useClerk) {
        return (
            <ClerkErrorBoundary fallback={localAuth}>
                <ClerkProvider>
                    <ClerkAuthAdapter>
                        {children}
                    </ClerkAuthAdapter>
                </ClerkProvider>
            </ClerkErrorBoundary>
        );
    }

    return localAuth;
}
