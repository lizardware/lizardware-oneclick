'use client';

import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { usePopup } from '@/components/admin/AdminPopupProvider';
import { Accordion } from '@/components/ui/Accordion';
import { THEME_PRESETS } from '@/lib/themes';
import { CommandBarButton } from '@/components/admin/AdminCommandBar';
import { ArrowLeft, RotateCcw, Save, Check } from 'lucide-react';

const COLOR_SWATCHES = [
    '#f97316', '#3b82f6', '#22c55e', '#ef4444', '#a855f7',
    '#6366f1', '#10b981', '#000000', '#ffffff', '#71717a',
];

const adjustBrightness = (hex: string, percent: number) => {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);

    const targetR = Math.round(Math.min(255, Math.max(0, r + (percent < 0 ? r : (255 - r)) * (percent / 100))));
    const targetG = Math.round(Math.min(255, Math.max(0, g + (percent < 0 ? g : (255 - g)) * (percent / 100))));
    const targetB = Math.round(Math.min(255, Math.max(0, b + (percent < 0 ? b : (255 - b)) * (percent / 100))));

    return "#" + ((1 << 24) + (targetR << 16) + (targetG << 8) + targetB).toString(16).slice(1);
};

import { ThemeConfig, ThemeColors } from '@/types/theme';

const defaultTheme: ThemeConfig = {
    colors: {
        light: {
            // Tier 1: Global
            bodyBackground: '#f9fafb',
            headerBackground: '#ffffff',
            footerBackground: '#f9fafb',
            contentBackground: '#ffffff',
            borders: '#e5e7eb',

            // Tier 1.5: Components
            accordionBackground: '#f3f4f6',
            buttonBackground: '#ffffff',
            cardBackground: '#ffffff',
            inputBackground: '#f9fafb',

            // Tier 2: Page Sections
            pageBackgroundPrimary: '#ffffff',
            pageBackgroundSecondary: '#f9fafb',
            pageBackgroundAlternate: '#f97316',
            heroBackground: '#0f172a',
            heroGradientStart: '#ffffff',
            heroGradientEnd: '#f3f4f6',
            heroGradientEnabled: false,

            // Text & UI
            headerText: '#171717',
            footerText: '#171717',
            pageTitle: '#171717',
            pageSubtitle: '#f97316',
            pageText: '#4b5563',

            // Specific Overrides / Legacy
            infoBoxBg: '#f9fafb',
            infoBoxText: '#171717',
            infoBoxLinkBg: '#ffffff',
            infoBoxLinkText: '#171717',
            infoBoxLinkHover: '#f97316',
            sectionHeader: '#f3f4f6',
            heroText: '#ffffff'
        },
        dark: {
            // Tier 1: Global
            bodyBackground: '#09090b',
            headerBackground: '#18181b',
            footerBackground: '#09090b',
            contentBackground: '#27272a',
            borders: '#27272a',

            // Tier 1.5: Components
            accordionBackground: '#1e293b',
            buttonBackground: '#1e293b',
            cardBackground: '#1e293b',
            inputBackground: '#0f172a',

            // Tier 2: Page Sections
            pageBackgroundPrimary: '#18181b',
            pageBackgroundSecondary: '#09090b',
            pageBackgroundAlternate: '#f97316',
            heroBackground: '#0f172a',
            heroGradientStart: '#000000',
            heroGradientEnd: '#f97316',
            heroGradientEnabled: true,

            // Text & UI
            headerText: '#fafafa',
            footerText: '#a1a1aa',
            pageTitle: '#fafafa',
            pageSubtitle: '#fb923c',
            pageText: '#d4d4d8',

            // Specific Overrides / Legacy
            infoBoxBg: '#27272a',
            infoBoxText: '#fafafa',
            infoBoxLinkBg: '#3f3f46',
            infoBoxLinkText: '#fafafa',
            infoBoxLinkHover: '#fb923c',
            sectionHeader: '#3f3f46',
            heroText: '#ffffff'
        }
    },
    borderRadius: '0.5rem',
    fontFamily: 'Inter',
    spacing: {
        section: '4rem',
        container: '1.5rem',
        gap: '1.25rem',
        header: '3rem'
    },
    shadows: {
        strength: '0.1'
    },
    typography: {
        fontSizeTitle: '60px',
        fontSizeSubtitle: '30px',
        fontSizeDescription: '24px',
        fontSizeBase: '16px'
    }
};


export default function ThemeEditorPage() {
    const [theme, setTheme] = useState<ThemeConfig>(defaultTheme);
    const [savedTheme, setSavedTheme] = useState<ThemeConfig>(defaultTheme);
    const popup = usePopup();
    const [loading, setLoading] = useState(true);

    // Initialize to user's current theme preference, defaulting to dark
    const getUserTheme = (): 'light' | 'dark' => {
        if (typeof window === 'undefined') return 'dark';
        const htmlClassList = document.documentElement.classList;
        if (htmlClassList.contains('dark')) return 'dark';
        if (htmlClassList.contains('light')) return 'light';
        // Default to dark if no preference set
        return 'dark';
    };

    const [activeTab, setActiveTab] = useState<'light' | 'dark'>(getUserTheme());
    const [isRevertModalOpen, setIsRevertModalOpen] = useState(false);
    const [isSaveModalOpen, setIsSaveModalOpen] = useState(false);
    const [isSyncing, setIsSyncing] = useState(false);
    const syncTimeoutRef = useRef<NodeJS.Timeout | null>(null);
    const [openPicker, setOpenPicker] = useState<string | null>(null);
    const pickerRef = useRef<HTMLDivElement>(null);
    const iframeRef = useRef<HTMLIFrameElement>(null);
    const router = useRouter();

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (pickerRef.current && !pickerRef.current.contains(event.target as Node)) {
                setOpenPicker(null);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    useEffect(() => {
        fetch('/api/config/theme')
            .then((res) => res.json())
            .then((data) => {
                setTheme(data as ThemeConfig);
                setSavedTheme(data as ThemeConfig);
                setLoading(false);
            })
            .catch((err) => console.error(err));

        // Listen for theme changes from internal toggle in iframe
        const handleThemeChange = (event: MessageEvent) => {
            if (event.data?.type === 'THEME_CHANGED') {
                // Ensure we only switch if it's a valid mode
                if (event.data.theme === 'light' || event.data.theme === 'dark') {
                    setActiveTab(event.data.theme as 'light' | 'dark');
                }
            }
        };
        window.addEventListener('message', handleThemeChange);
        return () => window.removeEventListener('message', handleThemeChange);
    }, []);

    const updateTheme = (newTheme: ThemeConfig) => {
        setTheme(newTheme);

        // Show sync indicator
        setIsSyncing(true);
        if (syncTimeoutRef.current) clearTimeout(syncTimeoutRef.current);
        // Extended stay time for the "Syncing" state
        syncTimeoutRef.current = setTimeout(() => setIsSyncing(false), 2000);

        // Send to iframe
        if (iframeRef.current?.contentWindow) {
            iframeRef.current.contentWindow.postMessage({
                type: 'UPDATE_THEME',
                payload: newTheme
            }, '*');
        }
    };

    const handleColorChange = (mode: 'light' | 'dark', key: keyof ThemeColors, value: string | boolean) => {
        const newTheme = {
            ...theme,
            colors: {
                ...theme.colors,
                [mode]: {
                    ...theme.colors[mode],
                    [key]: value
                }
            }
        };
        updateTheme(newTheme);
    };

    const handleRadiusChange = (value: string) => {
        const newTheme = { ...theme, borderRadius: value };
        updateTheme(newTheme);
    };

    const handleSpacingChange = (key: 'section' | 'container' | 'gap' | 'header', value: string) => {
        const newTheme = {
            ...theme,
            spacing: {
                ...theme.spacing || defaultTheme.spacing!,
                [key]: value
            }
        };
        updateTheme(newTheme);
    };

    const handleTypographyChange = (key: keyof NonNullable<ThemeConfig['typography']>, value: string) => {
        const newTheme = {
            ...theme,
            typography: {
                ...theme.typography || defaultTheme.typography!,
                [key]: value
            }
        };
        updateTheme(newTheme);
    };

    const handleShadowChange = (value: string) => {
        const newTheme = {
            ...theme,
            shadows: {
                ...theme.shadows || defaultTheme.shadows!,
                strength: value
            }
        };
        updateTheme(newTheme);
    };

    const handleTabChange = (mode: 'light' | 'dark') => {
        console.log('Theme editor: switching to', mode);
        setActiveTab(mode);
        // Sync to iframe - send message to change theme
        if (iframeRef.current?.contentWindow) {
            console.log('Theme editor: sending SET_THEME message to iframe');
            iframeRef.current.contentWindow.postMessage({
                type: 'SET_THEME',
                theme: mode
            }, '*');
        } else {
            console.log('Theme editor: iframe not ready');
        }
    };

    // Function to apply a preset
    const applyPreset = (presetId: string) => {
        const preset = THEME_PRESETS.find(p => p.id === presetId);
        if (preset) {
            const newTheme = {
                ...theme,
                colors: {
                    light: { ...theme.colors.light, ...preset.colors.light },
                    dark: { ...theme.colors.dark, ...preset.colors.dark }
                }
            };
            updateTheme(newTheme as any);
        }
    };

    const handleSaveClick = async (exit = false) => {
        const confirmed = await popup.confirm('Commit these design changes to the production runtime?');
        if (confirmed) await handleSaveConfirm(exit);
    };

    const handleSaveConfirm = async (exit = false) => {
        try {
            const res = await fetch('/api/config/theme', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(theme)
            });
            if (res.ok) {
                setSavedTheme(theme);
                popup.success('Visual core updated. Design has been synchronized.');
                router.refresh();
                if (exit) {
                    router.push('/admin/design');
                }
            } else {
                popup.error('Failed to commit theme configuration.');
            }
        } catch (err) {
            console.error(err);
            popup.error('Connectivity loss during theme synchronization.');
        }
    };

    const handleRevertClick = async () => {
        const confirmed = await popup.confirm('Revert all unsaved design changes?', { isDanger: true });
        if (confirmed) {
            updateTheme(savedTheme);
        }
    };

    if (loading) return <div className="p-8 text-center">Loading editor...</div>;

    const renderRangeInput = (
        label: string,
        value: string,
        onChange: (val: string) => void,
        min: number,
        max: number,
        step: number,
        unit: string = 'px'
    ) => {
        // Parse float value for slider
        const numericValue = parseFloat(value.replace(/[^0-9.]/g, '')) || 0;

        return (
            <div className="space-y-1">
                <div className="flex justify-between text-xs">
                    <label>{label}</label>
                    <span className="font-mono text-gray-500">{value}</span>
                </div>
                <input
                    type="range"
                    min={min}
                    max={max}
                    step={step}
                    value={numericValue}
                    onChange={(e) => onChange(`${e.target.value}${unit}`)}
                    className="w-full h-1 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-zinc-700"
                />
            </div>
        );
    };

    const renderShadowInput = (label: string, value: string, onChange: (val: string) => void) => {
        const numericValue = parseFloat(value) || 0;
        return (
            <div className="space-y-1">
                <div className="flex justify-between text-xs">
                    <label>{label}</label>
                    <span className="font-mono text-gray-500">{Math.round(numericValue * 100)}%</span>
                </div>
                <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.05}
                    value={numericValue}
                    onChange={(e) => onChange(e.target.value)}
                    className="w-full h-1 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-zinc-700"
                />
                <div className="flex justify-between text-[10px] text-gray-400">
                    <span>Flat</span>
                    <span>Deep</span>
                </div>
            </div>
        );
    };

    const renderColorInput = (key: keyof ThemeColors, label: string) => {
        const currentColor = theme.colors[activeTab][key] as string;
        const themeAccent = theme.colors[activeTab].pageSubtitle;
        const shades = [
            adjustBrightness(themeAccent, 80),
            adjustBrightness(themeAccent, 60),
            adjustBrightness(themeAccent, 40),
            adjustBrightness(themeAccent, 20),
            themeAccent,
            adjustBrightness(themeAccent, -20),
            adjustBrightness(themeAccent, -40),
        ];

        return (
            <div className="space-y-1.5 py-1">
                <div className="flex items-center justify-between">
                    <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">{label}</label>
                    <button
                        onClick={(e) => {
                            const rect = e.currentTarget.getBoundingClientRect();
                            setOpenPicker(openPicker === key ? null : key);
                            // Store the top position for the fixed popover
                            document.documentElement.style.setProperty('--picker-top', `${rect.top}px`);
                        }}
                        className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-white dark:bg-zinc-800 border border-borders hover:border-primary transition-all group shadow-sm relative z-10"
                    >
                        <div
                            className="w-3.5 h-3.5 rounded-full border border-black/10 shadow-sm transition-transform group-hover:scale-110"
                            style={{ backgroundColor: currentColor }}
                        ></div>
                        <span className="font-mono text-[10px] text-gray-400 group-hover:text-primary tracking-tight">{currentColor}</span>

                        {/* Connecting lines - snaps to sidebar edge */}
                        {openPicker === key && (
                            <div className="absolute left-[calc(100%+8px)] top-1/2 -translate-y-1/2 pointer-events-none hidden lg:block" style={{ width: '24px', height: '80px' }}>
                                <svg width="24" height="80" viewBox="0 0 24 80" fill="none" className="overflow-visible">
                                    <path
                                        d="M0 35 L24 0 M0 45 L24 80"
                                        stroke="currentColor"
                                        strokeWidth="1.5"
                                        className="text-primary/40"
                                        strokeDasharray="3 3"
                                    />
                                </svg>
                            </div>
                        )}
                    </button>
                </div>

                {openPicker === key && (
                    <div
                        ref={pickerRef}
                        className="fixed left-[320px] z-[300] w-72 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-md border border-borders rounded-r-2xl border-l-0 shadow-[20px_0_60px_rgba(0,0,0,0.1)] p-5 space-y-5 animate-in fade-in slide-in-from-left-2 duration-200"
                        style={{ top: 'calc(var(--picker-top) - 60px)' }}
                    >
                        <div className="space-y-2">
                            <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
                                <span className="w-1.5 h-1.5 rounded-full bg-primary"></span>
                                Theme Shades
                            </h4>
                            <div className="grid grid-cols-4 gap-2">
                                {shades.map((color) => (
                                    <button
                                        key={color}
                                        onClick={() => {
                                            handleColorChange(activeTab, key, color);
                                            setOpenPicker(null);
                                        }}
                                        className={`h-8 rounded-lg border border-black/5 transition-all hover:scale-105 ${currentColor === color ? 'ring-2 ring-primary ring-offset-2 dark:ring-offset-zinc-900 shadow-lg z-10' : 'hover:shadow-md'}`}
                                        style={{ backgroundColor: color }}
                                    />
                                ))}
                            </div>
                        </div>

                        <div className="space-y-2">
                            <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
                                <span className="w-1.5 h-1.5 rounded-full bg-gray-400"></span>
                                Classic Colors
                            </h4>
                            <div className="grid grid-cols-5 gap-2">
                                {COLOR_SWATCHES.map((color) => (
                                    <button
                                        key={color}
                                        onClick={() => {
                                            handleColorChange(activeTab, key, color);
                                            setOpenPicker(null);
                                        }}
                                        className={`h-6 rounded-md border border-black/5 transition-all hover:scale-110 ${currentColor === color ? 'ring-2 ring-primary ring-offset-2 dark:ring-offset-zinc-900' : ''}`}
                                        style={{ backgroundColor: color }}
                                    />
                                ))}
                            </div>
                        </div>

                        <div className="pt-2 border-t border-borders flex items-center justify-between">
                            <div className="flex items-center gap-2">
                                <div className="relative">
                                    <input
                                        type="color"
                                        value={currentColor}
                                        onChange={(e) => handleColorChange(activeTab, key, e.target.value)}
                                        className="h-8 w-8 cursor-pointer rounded-lg overflow-hidden border-2 border-slate-100 dark:border-zinc-800 p-0 appearance-none bg-transparent"
                                    />
                                    <div className="absolute inset-0 pointer-events-none flex items-center justify-center opacity-0 hover:opacity-100">
                                        🎨
                                    </div>
                                </div>
                                <span className="text-xs font-medium text-gray-500">Pick Custom</span>
                            </div>
                            <button
                                onClick={() => setOpenPicker(null)}
                                className="text-[10px] bg-slate-100 dark:bg-zinc-800 px-3 py-1 rounded-full font-bold hover:bg-primary hover:text-white transition-colors"
                            >
                                DONE
                            </button>
                        </div>
                    </div>
                )}
            </div>
        );
    };

    const sidebarStyle = {
        // Foundations
        '--body-background': theme.colors[activeTab].bodyBackground,
        '--header-background': theme.colors[activeTab].headerBackground,
        '--footer-background': theme.colors[activeTab].footerBackground,
        '--content-background': theme.colors[activeTab].contentBackground,
        '--borders': theme.colors[activeTab].borders,

        // Components
        '--accordion-background': theme.colors[activeTab].accordionBackground,
        '--button-background': theme.colors[activeTab].buttonBackground,
        '--card-background': theme.colors[activeTab].cardBackground,
        '--input-background': theme.colors[activeTab].inputBackground,

        // Page Sections
        '--page-bg-primary': theme.colors[activeTab].pageBackgroundPrimary,
        '--page-bg-secondary': theme.colors[activeTab].pageBackgroundSecondary,
        '--page-bg-alternate': theme.colors[activeTab].pageBackgroundAlternate,
        '--hero-background': theme.colors[activeTab].heroBackground,

        // Text & UI
        '--header-text': theme.colors[activeTab].headerText,
        '--footer-text': theme.colors[activeTab].footerText,
        '--page-title': theme.colors[activeTab].pageTitle,
        '--page-subtitle': theme.colors[activeTab].pageSubtitle,
        '--page-text': theme.colors[activeTab].pageText,

        // Legacy & Computed Aliases for Sidebar UI
        '--site-background': theme.colors[activeTab].bodyBackground,
        '--page-background': theme.colors[activeTab].pageBackgroundPrimary,
        '--header-bg': theme.colors[activeTab].headerBackground,
        '--info-box-bg': theme.colors[activeTab].contentBackground,
        '--info-box-text': theme.colors[activeTab].infoBoxText,
        '--info-box-link-bg': theme.colors[activeTab].infoBoxLinkBg,
        '--info-box-link-text': theme.colors[activeTab].infoBoxLinkText,
        '--info-box-link-hover': theme.colors[activeTab].infoBoxLinkHover,
        '--section-header-bg': theme.colors[activeTab].sectionHeader,
        '--hero-bg': theme.colors[activeTab].heroBackground,
        '--hero-text': theme.colors[activeTab].heroText,
        '--hero-gradient-start': theme.colors[activeTab].heroGradientStart,
        '--hero-gradient-end': theme.colors[activeTab].heroGradientEnd,
        '--hero-gradient-enabled': (theme.colors[activeTab].heroGradientEnabled ? '1' : '0') as string,

        // Design Architecture
        '--space-radius-base': theme.borderRadius,
        '--space-section': theme.spacing?.section || '4rem',
        '--space-container': theme.spacing?.container || '1.5rem',
        '--space-gap': theme.spacing?.gap || '1.25rem',
        '--space-header': theme.spacing?.header || '3rem',
        '--shadow-strength': theme.shadows?.strength || '0.1',
        '--typo-title': theme.typography?.fontSizeTitle || '3.75rem',
        '--typo-subtitle': theme.typography?.fontSizeSubtitle || '1.875rem',
        '--typo-base': theme.typography?.fontSizeBase || '1rem',
    } as React.CSSProperties;

    return (
        <div className="fixed inset-0 z-[100] flex h-screen overflow-hidden bg-gray-50 dark:bg-zinc-900 text-sm pb-14">
            {/* Sidebar Controls */}
            <div className="w-80 flex-shrink-0 flex flex-col border-r border-gray-200 dark:border-zinc-800 bg-white dark:bg-zinc-900" style={sidebarStyle}>
                {/* Header - Fixed */}
                <div className="p-4 border-b border-gray-200 dark:border-zinc-800 flex-shrink-0">
                    <div className="mb-3">
                        <h1 className="font-bold text-lg flex items-center gap-2">
                            <span>✨</span>
                            Theme Transformer
                        </h1>
                        <button
                            onClick={() => router.push('/admin/design')}
                            className="text-xs text-gray-500 hover:text-gray-900 dark:hover:text-gray-300 flex items-center gap-1 mt-1"
                        >
                            ← Back to Design
                        </button>
                    </div>
                    <div className="flex bg-gray-100 dark:bg-zinc-800/50 rounded-lg p-1 w-full border border-gray-200 dark:border-zinc-800/50">
                        <button
                            onClick={() => handleTabChange('light')}
                            className={`flex-1 flex items-center justify-center gap-2 py-1.5 rounded-md text-[10px] font-bold transition-all ${activeTab === 'light' ? 'bg-white dark:bg-zinc-800 shadow-sm text-primary' : 'text-gray-400 hover:text-gray-900 dark:hover:text-gray-200'}`}
                        >
                            <span>☀️</span> Daylight
                        </button>
                        <button
                            onClick={() => handleTabChange('dark')}
                            className={`flex-1 flex items-center justify-center gap-2 py-1.5 rounded-md text-[10px] font-bold transition-all ${activeTab === 'dark' ? 'bg-white dark:bg-zinc-800 shadow-sm text-primary' : 'text-gray-400 hover:text-gray-900 dark:hover:text-gray-200'}`}
                        >
                            <span>🌙</span> Moonlight
                        </button>
                    </div>
                </div>

                {/* Scrollable Content */}
                <div className="flex-1 overflow-y-auto">
                    <div className="p-4 space-y-5">
                        {/* 2. Quick Presets */}
                        <Accordion title="Theme Presets" variant="section">
                            <div className="grid grid-cols-2 gap-2 mt-2">
                                {THEME_PRESETS.map((preset) => {
                                    const isDark = activeTab === 'dark';
                                    const presetColors = preset.colors[activeTab];
                                    const textColor = presetColors.pageSubtitle;

                                    return (
                                        <button
                                            key={preset.id}
                                            onClick={() => applyPreset(preset.id)}
                                            className="p-1 rounded-xl border border-gray-200 dark:border-zinc-800 hover:border-primary transition-all relative group overflow-hidden bg-white dark:bg-zinc-900 shadow-sm"
                                        >
                                            <div
                                                className={`h-14 w-full rounded-lg border border-black/5 flex items-center justify-center p-2 text-center relative overflow-hidden`}
                                                style={{
                                                    background: presetColors.heroGradientEnabled
                                                        ? `linear-gradient(to bottom right, ${presetColors.heroGradientStart}, ${presetColors.heroGradientEnd})`
                                                        : presetColors.pageBackgroundPrimary
                                                }}
                                            >
                                                <div className="absolute inset-0 bg-gradient-to-b from-black/10 to-transparent"></div>
                                                <span
                                                    className={`relative z-10 font-bold text-[10px] leading-tight tracking-tight uppercase`}
                                                    style={{ color: textColor }}
                                                >
                                                    {preset.name}
                                                </span>
                                            </div>
                                        </button>
                                    );
                                })}
                            </div>
                            <p className="text-[9px] text-gray-400 mt-3 leading-tight italic">Applying an Artstyle updates both Day and Moon modes instantly.</p>
                        </Accordion>

                        {/* 3. Global Foundations */}
                        <Accordion title="Global Foundations" variant="section" defaultOpen={true}>
                            <div className="space-y-3 pt-1">
                                {renderColorInput('bodyBackground', 'Page Wrapper')}
                                {renderColorInput('headerBackground', 'Site Header')}
                                {renderColorInput('footerBackground', 'Site Footer')}
                                {renderColorInput('borders', 'Borders & Lines')}
                            </div>
                        </Accordion>

                        {/* 4. UI Components */}
                        <Accordion title="UI Components" variant="section">
                            <div className="space-y-3 pt-1">
                                {renderColorInput('accordionBackground', 'Accordions')}
                                {renderColorInput('buttonBackground', 'Buttons & Links')}
                                {renderColorInput('cardBackground', 'Content Cards')}
                                {renderColorInput('inputBackground', 'Form Inputs')}
                            </div>
                        </Accordion>

                        {/* 5. Page Sections */}
                        <Accordion title="Page Sections" variant="section">
                            <div className="space-y-3 pt-1">
                                {renderColorInput('pageBackgroundPrimary', 'Primary Section')}
                                {renderColorInput('pageBackgroundSecondary', 'Secondary Section')}
                                {renderColorInput('pageBackgroundAlternate', 'Alternate Section')}
                                {renderColorInput('sectionHeader', 'Section Dividers')}
                            </div>
                        </Accordion>

                        {/* 5. Typography */}
                        <Accordion title="Typography" variant="section">
                            <div className="space-y-5 pt-1">
                                <div className="space-y-3">
                                    <span className="text-[10px] font-bold uppercase text-primary/70 block">Font Sizes</span>
                                    {renderRangeInput('Page Title', theme.typography?.fontSizeTitle || '60px', (v) => handleTypographyChange('fontSizeTitle', v), 12, 120, 1, 'px')}
                                    {renderRangeInput('Page Description', theme.typography?.fontSizeDescription || '24px', (v) => handleTypographyChange('fontSizeDescription', v), 10, 60, 1, 'px')}
                                    {renderRangeInput('Section Headers', theme.typography?.fontSizeSubtitle || '30px', (v) => handleTypographyChange('fontSizeSubtitle', v), 10, 80, 1, 'px')}
                                    {renderRangeInput('Body Text', theme.typography?.fontSizeBase || '16px', (v) => handleTypographyChange('fontSizeBase', v), 8, 48, 1, 'px')}
                                </div>
                                <div className="space-y-3 pt-2 border-t border-gray-100 dark:border-zinc-800">
                                    <span className="text-[10px] font-bold uppercase text-primary/70 block">Text Colors</span>
                                    {renderColorInput('pageTitle', 'Heading Color')}
                                    {renderColorInput('pageSubtitle', 'Primary Accent')}
                                    {renderColorInput('pageText', 'Body Color')}
                                    {renderColorInput('headerText', 'Header Text')}
                                    {renderColorInput('footerText', 'Footer Text')}
                                </div>
                            </div>
                        </Accordion>

                        {/* 6. Hero Experience */}
                        <Accordion title="Hero Experience" variant="section">
                            <div className="space-y-4 pt-1">
                                <div className="flex items-center justify-between px-1">
                                    <span className="text-[10px] font-bold uppercase text-primary/70">Gradient Mode</span>
                                    <button
                                        onClick={() => handleColorChange(activeTab, 'heroGradientEnabled', !theme.colors[activeTab].heroGradientEnabled)}
                                        className={`w-10 h-5 rounded-full p-1 transition-colors ${theme.colors[activeTab].heroGradientEnabled ? 'bg-primary' : 'bg-gray-200 dark:bg-zinc-700'}`}
                                    >
                                        <div className={`w-3 h-3 bg-white rounded-full transition-transform ${theme.colors[activeTab].heroGradientEnabled ? 'translate-x-5' : 'translate-x-0'}`} />
                                    </button>
                                </div>

                                {theme.colors[activeTab].heroGradientEnabled ? (
                                    <div className="space-y-3 p-3 bg-gray-50 dark:bg-zinc-800/50 rounded-xl border border-gray-100 dark:border-zinc-800">
                                        {renderColorInput('heroGradientStart', 'Start Color')}
                                        {renderColorInput('heroGradientEnd', 'End Color')}
                                    </div>
                                ) : (
                                    renderColorInput('heroBackground', 'Hero Solid Color')
                                )}
                                {renderColorInput('heroText', 'Hero Text Color')}
                            </div>
                        </Accordion>

                        {/* 7. Action Components */}
                        <Accordion title="Interaction" variant="section">
                            <div className="space-y-4 pt-1">
                                <div className="space-y-2">
                                    <h4 className="text-[10px] font-bold text-primary/70 uppercase">Call to Actions</h4>
                                    {renderColorInput('infoBoxLinkBg', 'Button Background')}
                                    {renderColorInput('infoBoxLinkText', 'Button Text')}
                                    {renderColorInput('infoBoxLinkHover', 'Button Hover Effect')}
                                </div>
                            </div>
                        </Accordion>


                        {/* 8. Design Architecture */}
                        <Accordion title="Layout & Style" variant="section">
                            <div className="space-y-5 pt-2">
                                {/* Spacing */}
                                <div className="space-y-3">
                                    <div className="flex items-center gap-1.5">
                                        <span className="text-[10px] font-bold uppercase text-primary/70">Spacing & Layout</span>
                                    </div>
                                    {renderRangeInput('Navbar Height', theme.spacing?.header || '3rem', (v) => handleSpacingChange('header', v), 2, 6, 0.25, 'rem')}
                                    {renderRangeInput('Section Spacing', theme.spacing?.section || '4rem', (v) => handleSpacingChange('section', v), 0.25, 8, 0.25, 'rem')}
                                    {renderRangeInput('Container Padding', theme.spacing?.container || '1.5rem', (v) => handleSpacingChange('container', v), 0.5, 4, 0.25, 'rem')}
                                    {renderRangeInput('Element Gaps', theme.spacing?.gap || '1.25rem', (v) => handleSpacingChange('gap', v), 0.25, 3, 0.25, 'rem')}
                                </div>

                                {/* Shadows */}
                                <div className="space-y-3 pt-2 border-t border-gray-100 dark:border-zinc-800">
                                    <span className="text-[10px] font-bold uppercase text-primary/70 block">Depth & Elevation</span>
                                    {renderShadowInput('Shadow Density', theme.shadows?.strength || '0.1', handleShadowChange)}
                                </div>

                                {/* Radius */}
                                <div className="pt-2 border-t border-gray-100 dark:border-zinc-800">
                                    <label className="block text-[11px] font-bold text-gray-500 uppercase mb-2">Corner Roundness</label>
                                    <div className="grid grid-cols-3 gap-2">
                                        {['0', '0.25rem', '0.5rem', '0.75rem', '1rem', '1.25rem'].map((r) => (
                                            <button
                                                key={r}
                                                onClick={() => handleRadiusChange(r)}
                                                className={`py-1.5 rounded-lg text-[10px] font-bold border transition-all ${theme.borderRadius === r
                                                    ? 'bg-primary text-white border-primary shadow-sm ring-2 ring-primary/20'
                                                    : 'bg-white dark:bg-zinc-800 border-gray-200 dark:border-zinc-700 text-gray-500 hover:border-primary/50'
                                                    }`}
                                            >
                                                {r === '0' ? 'Sharp' : r.replace('rem', '') + ' (R)'}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </Accordion>
                    </div>
                </div>
            </div>

            {/* Preview Pane */}
            <div className="flex-grow bg-gray-100 dark:bg-zinc-950 flex flex-col p-4 relative overflow-hidden">
                <div className="w-full h-full relative group shadow-[0_32px_64px_-12px_rgba(0,0,0,0.15)] dark:shadow-[0_32px_64px_-12px_rgba(0,0,0,0.5)]">
                    <iframe
                        ref={iframeRef}
                        src="/"
                        className="w-full h-full bg-white dark:bg-zinc-900 rounded-2xl border border-gray-200 dark:border-zinc-800 overflow-hidden"
                        title="Site Preview"
                        onLoad={() => {
                            setTimeout(() => {
                                if (iframeRef.current?.contentWindow) {
                                    iframeRef.current.contentWindow.postMessage({
                                        type: 'UPDATE_THEME',
                                        payload: theme
                                    }, '*');
                                    setTimeout(() => {
                                        if (iframeRef.current?.contentWindow) {
                                            iframeRef.current.contentWindow.postMessage({
                                                type: 'SET_THEME',
                                                theme: activeTab
                                            }, '*');
                                        }
                                    }, 100);
                                }
                            }, 500);
                        }}
                    />
                </div>

            </div>

            {/* Bottom Command Bar */}
            <div className="fixed bottom-0 inset-x-0 h-14 bg-white/90 dark:bg-zinc-900/90 backdrop-blur-xl border-t border-gray-200 dark:border-zinc-800 z-[120] flex items-center px-4 pointer-events-auto">
                <div className="flex items-center gap-2">
                    <CommandBarButton
                        label="Exit"
                        onClick={() => router.push('/admin/design')}
                        icon={<ArrowLeft size={16} />}
                        variant="default"
                    />
                    <div className="w-px h-6 bg-gray-200 dark:bg-zinc-800/50 mx-1 hidden sm:block" />
                    <div className="hidden sm:block">
                        <CommandBarButton
                            label="Revert"
                            onClick={handleRevertClick}
                            icon={<RotateCcw size={16} />}
                            variant="danger"
                        />
                    </div>
                </div>

                {/* Center: Status & Save */}
                <div className="absolute left-1/2 -translate-x-1/2 hidden md:flex items-center gap-3">
                    <div className={`flex items-center gap-2.5 px-3 py-1.5 rounded-lg border transition-all duration-300 ${isSyncing
                        ? 'bg-blue-500/10 border-blue-500/20 text-blue-500'
                        : 'bg-emerald-500/10 border-emerald-500/20 text-emerald-600 dark:text-emerald-400'
                        }`}>
                        <div className="relative flex items-center justify-center w-1.5 h-1.5">
                            {(isSyncing || true) && <span className={`absolute inline-flex h-full w-full rounded-full opacity-75 animate-ping bg-current ${!isSyncing ? 'opacity-20' : ''}`}></span>}
                            <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-current"></span>
                        </div>
                        <span className="text-[10px] font-black uppercase tracking-widest leading-none">
                            {isSyncing ? 'Syncing...' : 'Live Preview'}
                        </span>
                    </div>

                    <CommandBarButton
                        label="Save"
                        onClick={() => handleSaveClick(false)}
                        icon={<Save size={16} />}
                        variant="secondary"
                    />
                </div>

                {/* Right: Save & Exit */}
                <div className="ml-auto flex items-center gap-2">
                    <CommandBarButton
                        label="Save & Exit"
                        onClick={() => handleSaveClick(true)}
                        icon={<Check size={16} />}
                        variant="primary"
                    />
                </div>
            </div>
        </div >
    );
}

