'use client';

import { createContext, useContext, useState, ReactNode } from 'react';

export interface AdminAction {
    id: string;
    label: string | ReactNode;
    onClick?: () => void;
    href?: string;
    icon?: ReactNode;
    variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'success';
    showOnMobile?: boolean; // Mobile "Primary" action
    disabled?: boolean;
}

interface AdminActionsContextType {
    actions: AdminAction[];
    setActions: (actions: AdminAction[]) => void;
}

export const AdminActionsContext = createContext<AdminActionsContextType | undefined>(undefined);

export function AdminActionsProvider({ children }: { children: ReactNode }) {
    const [actions, setActions] = useState<AdminAction[]>([]);

    return (
        <AdminActionsContext.Provider value={{ actions, setActions }}>
            {children}
        </AdminActionsContext.Provider>
    );
}

export function useAdminActionsContext() {
    const context = useContext(AdminActionsContext);
    if (!context) {
        throw new Error('useAdminActionsContext must be used within an AdminActionsProvider');
    }
    return context;
}
