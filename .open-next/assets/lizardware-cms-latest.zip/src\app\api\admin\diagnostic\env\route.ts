import { NextResponse } from 'next/server';

// Diagnostic route to show current environment variables
// SECURITY: This should be removed or protected in production!
export async function GET() {
    const envVars = {
        // Clerk
        clerkPublishableKey: process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY || 'MISSING',
        clerkSecretKey: process.env.CLERK_SECRET_KEY ? '***SET***' : 'MISSING',
        clerkWebhookSecret: process.env.CLERK_WEBHOOK_SECRET ? '***SET***' : 'MISSING',
        clerkSignInUrl: process.env.NEXT_PUBLIC_CLERK_SIGN_IN_URL || 'MISSING',
        clerkSignUpUrl: process.env.NEXT_PUBLIC_CLERK_SIGN_UP_URL || 'MISSING',
        clerkAfterSignIn: process.env.NEXT_PUBLIC_CLERK_AFTER_SIGN_IN_URL || 'MISSING',
        clerkAfterSignUp: process.env.NEXT_PUBLIC_CLERK_AFTER_SIGN_UP_URL || 'MISSING',

        // Cloudflare
        wranglerKvId: process.env.WRANGLER_KV_ID || 'MISSING',
        wranglerD1Id: process.env.WRANGLER_D1_ID || 'MISSING',
        cfApiToken: process.env.CLOUDFLARE_API_TOKEN ? '***SET***' : 'MISSING',
        cfAccountId: process.env.CLOUDFLARE_ACCOUNT_ID || 'MISSING',

        // Other
        siteUrl: process.env.NEXT_PUBLIC_SITE_URL || 'MISSING',
        useD1Blog: process.env.USE_D1_BLOG || 'MISSING',
        githubToken: process.env.GITHUB_TOKEN ? '***SET***' : 'MISSING',
        githubRepo: process.env.GITHUB_REPO || 'MISSING',
        mediaStorageProvider: process.env.MEDIA_STORAGE_PROVIDER || 'MISSING'
    };

    return NextResponse.json(envVars, {
        headers: {
            'Cache-Control': 'no-store, no-cache, must-revalidate'
        }
    });
}
