import { getPageBySlug, getAllPages } from "@/lib/pages";
import { notFound } from "next/navigation";
import { Metadata } from "next";
import { siteConfig } from "@/config/site";
import PageRenderer from "@/components/PageRenderer";

export async function generateStaticParams() {
    // Skip static generation during build if database isn't ready
    // This prevents "no such table" errors when D1 exists but schema isn't loaded
    // Pages will be generated on-demand at runtime instead
    if (process.env.NEXT_PHASE === 'phase-production-build') {
        console.log('Skipping pages static generation during build phase (will generate on-demand at runtime)');
        return [];
    }

    try {
        const pages = await getAllPages('published');
        return pages.map((page) => ({
            slug: page.slug,
        }));
    } catch (error) {
        console.warn('Failed to generate static params for pages:', error);
        return [];
    }
}

export async function generateMetadata({
    params,
}: {
    params: Promise<{ slug: string }>;
}): Promise<Metadata> {
    const { slug } = await params;
    const page = await getPageBySlug(slug);

    if (!page) {
        return {
            title: "Page Not Found",
        };
    }

    return {
        title: `${page.title} | ${siteConfig.name}`,
        description: page.description || siteConfig.seo.description,
        keywords: siteConfig.seo.keywords,
    };
}

export default async function DynamicPage({
    params,
    searchParams,
}: {
    params: Promise<{ slug: string }>;
    searchParams: Promise<{ preview?: string }>;
}) {
    const [{ slug }, { preview }] = await Promise.all([
        params,
        searchParams as Promise<{ [key: string]: string }>
    ]);

    let page = await getPageBySlug(slug);

    // If page not found, check if we're in preview mode
    if (!page) {
        if (preview === 'true') {
            // Create a mock page object for the live preview to target
            page = {
                slug: slug,
                title: "New Page",
                content: "<p>Start writing your page content here...</p>",
                description: "Your page description will appear here.",
                status: 'draft',
                is_template: false,
                sort_order: 0
            } as any;
        } else {
            notFound();
        }
    }

    // At this point, page is guaranteed to be non-null (either from DB, preview mock, or notFound() was called)
    const currentPage = page!;

    // Only show published pages in normal mode (preview mode shows everything)
    if (preview !== 'true' && currentPage.status !== 'published') {
        notFound();
    }

    return <PageRenderer page={currentPage} preview={preview === 'true'} />;
}
