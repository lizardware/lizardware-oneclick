// Page storage utilities for Cloudflare D1
import { Page, PageMeta } from '../types/page';

export interface D1Page {
    id: number;
    slug: string;
    title: string;
    content: string;
    description: string | null;
    status: 'draft' | 'published';
    created_at: string;
    updated_at: string;
    metadata_json: string | null; // JSON
    is_template: number;          // SQLite boolean
    template_category: string | null;
    sort_order: number;
    show_in_nav: number;          // SQLite boolean
    nav_label: string | null;
    nav_parent: string | null;
    nav_order: number;
}

// Get all pages from D1
export async function getAllPagesFromD1(
    db: D1Database,
    includeContent = false,
    includeStatus?: 'draft' | 'published'
): Promise<Page[]> {
    const columns = includeContent
        ? '*'
        : 'id, slug, title, description, status, created_at, updated_at, metadata_json, is_template, template_category, sort_order, show_in_nav, nav_label, nav_parent, nav_order';

    let query = `SELECT ${columns} FROM pages`;
    const bindings: string[] = [];

    if (includeStatus) {
        query += ` WHERE status = ?`;
        bindings.push(includeStatus);
    }

    query += ` ORDER BY sort_order ASC, updated_at DESC`;

    let stmt = db.prepare(query);
    if (bindings.length > 0) {
        stmt = stmt.bind(...bindings);
    }

    const result = await stmt.all<D1Page>();

    return result.results.map(dbPage => ({
        slug: dbPage.slug,
        title: dbPage.title,
        description: dbPage.description || undefined,
        status: dbPage.status,
        content: includeContent ? dbPage.content : '',
        created_at: dbPage.created_at,
        updated_at: dbPage.updated_at,
        metadata_json: dbPage.metadata_json || undefined,
        is_template: Boolean(dbPage.is_template),
        template_category: dbPage.template_category || undefined,
        sort_order: dbPage.sort_order,
        show_in_nav: Boolean(dbPage.show_in_nav),
        nav_label: dbPage.nav_label || undefined,
        nav_parent: dbPage.nav_parent || undefined,
        nav_order: dbPage.nav_order,
    }));
}

// Get single page by slug
export async function getPageBySlugFromD1(
    db: D1Database,
    slug: string
): Promise<Page | null> {
    const stmt = db.prepare(
        'SELECT * FROM pages WHERE slug = ? LIMIT 1'
    ).bind(slug);

    const page = await stmt.first<D1Page>();

    if (!page) return null;

    return {
        slug: page.slug,
        title: page.title,
        content: page.content,
        description: page.description || undefined,
        status: page.status,
        created_at: page.created_at,
        updated_at: page.updated_at,
        metadata_json: page.metadata_json || undefined,
        is_template: Boolean(page.is_template),
        template_category: page.template_category || undefined,
        sort_order: page.sort_order,
        show_in_nav: Boolean(page.show_in_nav),
        nav_label: page.nav_label || undefined,
        nav_parent: page.nav_parent || undefined,
        nav_order: page.nav_order,
    };
}

// Create or update page
export async function upsertPageToD1(
    db: D1Database,
    page: Page
): Promise<void> {
    const stmt = db.prepare(`
    INSERT INTO pages (slug, title, content, description, status, updated_at, metadata_json, is_template, template_category, sort_order, show_in_nav, nav_label, nav_parent, nav_order)
    VALUES (?, ?, ?, ?, ?, datetime('now'), ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(slug) DO UPDATE SET
      title = excluded.title,
      content = excluded.content,
      description = excluded.description,
      status = excluded.status,
      updated_at = datetime('now'),
      metadata_json = excluded.metadata_json,
      is_template = excluded.is_template,
      template_category = excluded.template_category,
      sort_order = excluded.sort_order,
      show_in_nav = excluded.show_in_nav,
      nav_label = excluded.nav_label,
      nav_parent = excluded.nav_parent,
      nav_order = excluded.nav_order
  `).bind(
        page.slug,
        page.title,
        page.content,
        page.description || null,
        page.status || 'draft',
        page.metadata_json || null,
        page.is_template ? 1 : 0,
        page.template_category || null,
        page.sort_order || 0,
        page.show_in_nav ? 1 : 0,
        page.nav_label || null,
        page.nav_parent || null,
        page.nav_order || 0
    );

    await stmt.run();
}

// Delete page
export async function deletePageFromD1(
    db: D1Database,
    slug: string
): Promise<void> {
    const stmt = db.prepare('DELETE FROM pages WHERE slug = ?').bind(slug);
    await stmt.run();
}

/**
 * Get all template pages by category
 */
export async function getTemplatePages(
    db: D1Database,
    category?: string
): Promise<Page[]> {
    let query = 'SELECT * FROM pages WHERE is_template = 1';
    let stmt: D1PreparedStatement;

    if (category) {
        query += ' AND template_category = ?';
        query += ' ORDER BY sort_order ASC, updated_at DESC';
        stmt = db.prepare(query).bind(category);
    } else {
        query += ' ORDER BY sort_order ASC, updated_at DESC';
        stmt = db.prepare(query);
    }

    const result = await stmt.all<D1Page>();
    return result.results.map(dbPage => ({
        slug: dbPage.slug,
        title: dbPage.title,
        description: dbPage.description || undefined,
        status: dbPage.status,
        content: dbPage.content,
        created_at: dbPage.created_at,
        updated_at: dbPage.updated_at,
        metadata_json: dbPage.metadata_json || undefined,
        is_template: true,
        template_category: dbPage.template_category || undefined,
        sort_order: dbPage.sort_order,
    }));
}

/**
 * Get all custom (non-template) pages
 */
export async function getCustomPages(db: D1Database): Promise<Page[]> {
    const result = await db
        .prepare('SELECT * FROM pages WHERE is_template = 0 OR is_template IS NULL ORDER BY sort_order ASC, updated_at DESC')
        .all<D1Page>();

    return result.results.map(dbPage => ({
        slug: dbPage.slug,
        title: dbPage.title,
        description: dbPage.description || undefined,
        status: dbPage.status,
        content: dbPage.content,
        created_at: dbPage.created_at,
        updated_at: dbPage.updated_at,
        metadata_json: dbPage.metadata_json || undefined,
        is_template: false,
        template_category: dbPage.template_category || undefined,
        sort_order: dbPage.sort_order,
    }));
}
