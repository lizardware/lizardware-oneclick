-- Migration: Create categories table
-- Created: 2026-01-04
-- Purpose: Fix missing table error for Blog & Publishing business type

CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    description TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_categories_slug ON categories(slug);

-- Seed default category if empty
INSERT OR IGNORE INTO categories (name, slug, description) 
VALUES ('General', 'general', 'Uncategorized posts');
