-- Migration 017: Create forum posts table
-- Version: 0.6.0
-- Purpose: Replies and nested comments on forum threads

CREATE TABLE IF NOT EXISTS forum_posts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  thread_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  parent_post_id INTEGER, -- For nested replies
  content TEXT NOT NULL, -- HTML from Tiptap
  is_edited BOOLEAN DEFAULT 0,
  edited_at DATETIME,
  is_hidden BOOLEAN DEFAULT 0, -- For moderation
  hidden_reason TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (thread_id) REFERENCES forum_threads(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES forum_users(id) ON DELETE CASCADE,
  FOREIGN KEY (parent_post_id) REFERENCES forum_posts(id) ON DELETE CASCADE
);

CREATE INDEX idx_forum_posts_thread ON forum_posts(thread_id);
CREATE INDEX idx_forum_posts_user ON forum_posts(user_id);
CREATE INDEX idx_forum_posts_parent ON forum_posts(parent_post_id);
CREATE INDEX idx_forum_posts_created ON forum_posts(created_at DESC);
