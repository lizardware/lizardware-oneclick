# 🧪 TESTING REQUIRED - v0.3.3 Generic Templates

**Branch:** `feature/generic-templates-v0.3.3`  
**Status:** ✅ Code Complete | ⚠️ NOT TESTED  
**Last Updated:** December 26, 2025

> [!WARNING]
> **ACTION REQUIRED:** This branch has NOT been tested in the browser. Complete the tests below before merging to main.

---

## Quick Context

This release includes:
1. **Generic Templates (v0.3.3)** - Replaced hardcoded "Lizardware" branding with dynamic site name
2. **Blog Status System (v0.3.2)** - Draft/Published toggle for blog posts
3. **Mobile Navigation** - Hamburger menu for responsive design

---

## 🔍 Testing Checklist

### 1. Generic Template Testing (Priority: HIGH)

**Public Site - Dynamic Branding:**
- [ ] Visit `http://localhost:3000/features`
  - Verify page title shows your configured site name (not "Lizardware CMS")
  - Check hero section uses dynamic site name in the paragraph text
  - Verify all feature cards show your site name in descriptions
  
- [ ] Visit individual feature pages (e.g., `/features/content-management`)
  - Verify intro text shows your configured site name (not "Lizardware")
  - Check all section content has replaced `{{siteName}}` placeholders
  - Verify metadata/SEO title includes your site name

**Footer Attribution:**
- [ ] Visit any public page (`/`, `/features`, `/blog`)
  - Verify footer shows "Powered by Lizardware CMS" link
  - Confirm link points to `https://lizardware.io`
  - Check styling is tasteful and not intrusive

**Admin Dashboard - Preserved Branding:**
- [ ] Visit `/admin`
  - Verify header still shows "Lizardware CMS" branding
  - Confirm setup wizard (if accessible) keeps "Lizardware CMS" title
  - Check all admin navigation remains branded

### 2. Blog Status System Testing (Priority: HIGH)

**Blog Editor:**
- [ ] Create a new blog post at `/admin/blog/new`
  - Verify status toggle button appears (Draft/Published)
  - Default status should be "Draft"
  - Toggle to "Published" and save
  
- [ ] Edit an existing post at `/admin/blog/[slug]`
  - Verify current status displays correctly
  - Change status and save
  - Reload page to confirm status persisted

**Blog List (Admin):**
- [ ] Visit `/admin/blog`
  - Verify status filter buttons appear (All, Published, Draft)
  - Filter by "Draft" - should show only draft posts
  - Filter by "Published" - should show only published posts
  - Create both draft and published posts to test filtering

**Public Blog (Critical):**
- [ ] Create a draft post in admin
- [ ] Visit `/blog` (public view)
  - **CRITICAL:** Verify draft posts do NOT appear
  - Only published posts should be visible
- [ ] Visit the draft post's URL directly (e.g., `/blog/draft-post-slug`)
  - Should return 404 or not be accessible

### 3. Mobile Navigation Testing (Priority: MEDIUM)

**Public Site Mobile Menu:**
- [ ] Resize browser to mobile width (< 768px)
  - Verify hamburger menu icon appears in header
  - Click hamburger - drawer should slide out from left
  - Click a link - drawer should close
  - Click backdrop/overlay - drawer should close

**Admin Mobile Menu:**
- [ ] Visit `/admin` on mobile width
  - Verify mobile navigation works similarly
  - Check top and bottom navigation bars are responsive

### 4. Type Safety & Build Testing

- [ ] Run `npm run type-check` - should pass with 0 errors ✅ (Already verified)
- [ ] Run `npm run build` - should complete without errors
- [ ] Test deployment preview (optional but recommended)

---

## 🐛 Known Issues to Watch For

1. **Placeholder Not Replaced** - If you see `{{siteName}}` literally on any page, that's a bug
2. **Draft Posts Visible** - If draft posts appear on public `/blog`, that's a CRITICAL security issue
3. **Admin Branding Changed** - Admin should still say "Lizardware CMS" everywhere
4. **Footer Not Showing** - "Powered by" link should appear on all public pages

---

## ✅ After Testing Passes

1. **Update Version:**
   ```bash
   # Update package.json to v0.3.3
   npm version 0.3.3 --no-git-tag-version
   ```

2. **Update CHANGELOG.md:**
   - Add v0.3.3 entry with all features
   - Note the genericization work

3. **Merge to Main:**
   ```bash
   git checkout main
   git merge feature/generic-templates-v0.3.3
   git tag v0.3.3
   git push origin main --tags
   ```

4. **Deploy:**
   - Cloudflare Pages should auto-deploy from main
   - Monitor deployment logs

---

## 🚨 If Tests Fail

1. **Document the Issue:**
   - Take screenshots
   - Note browser/device
   - Record exact steps to reproduce

2. **Create Fix Branch:**
   ```bash
   git checkout -b fix/v0.3.3-issue-description
   ```

3. **Fix & Re-test:**
   - Make minimal changes
   - Re-run full test suite
   - Document fix in commit message

---

## 📍 Technical Context

**Files Modified:**
- `src/data/services.ts` - Genericized with `{{siteName}}` placeholders
- `src/app/(categories)/features/page.tsx` - Dynamic metadata + content
- `src/app/(categories)/features/[slug]/ServicePage.tsx` - Placeholder replacement
- `src/components/layout/Footer.tsx` - Added "Powered by" attribution
- `src/types/site-config.ts` - Added `whiteLabel?: boolean` field
- `migrations/022_add_post_status.sql` - Blog status system
- `src/lib/blog.ts` - Status filtering logic
- `src/components/admin/BlogEditor.tsx` - Status toggle UI

**Configuration to Check:**
- Site name is configured in `/admin/visual-identity` or site config
- Test with different site names to verify dynamic replacement works

---

**Next Agent: When you start, prompt the user with:**
"Ready to test v0.3.3 changes? I have a testing checklist at `TESTING-v0.3.3.md`. Should I guide you through it?"
