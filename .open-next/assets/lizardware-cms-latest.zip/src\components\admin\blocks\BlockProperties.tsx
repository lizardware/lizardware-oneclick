'use client';

import { Block, BlockField } from '@/types/blocks';
import { BLOCK_REGISTRY } from '@/lib/blocks/registry';
import { ChevronLeft } from 'lucide-react';
import RichTextEditor from '@/components/editor/RichTextEditor';

import { useState } from 'react';

interface BlockPropertiesProps {
    block: Block;
    onChange: (updates: { props?: Record<string, any>; styleOptions?: Block['styleOptions'] }) => void;
    onBack: () => void;
}

export default function BlockProperties({ block, onChange, onBack }: BlockPropertiesProps) {
    const [activeTab, setActiveTab] = useState<'content' | 'style'>('content');
    const def = BLOCK_REGISTRY[block.type];
    if (!def) return null;

    const handlePropChange = (name: string, value: any) => {
        onChange({ props: { ...block.props, [name]: value } });
    };

    const handleStyleChange = (name: string, value: any) => {
        onChange({ styleOptions: { ...block.styleOptions, [name]: value } });
    };

    return (
        <div className="flex flex-col h-full bg-white dark:bg-zinc-900">
            <div className="p-3 border-b border-gray-200 dark:border-zinc-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <button
                        onClick={onBack}
                        className="p-1 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-md transition-colors"
                    >
                        <ChevronLeft size={16} />
                    </button>
                    <h3 className="text-[10px] font-black uppercase tracking-widest text-gray-500">
                        {def.label}
                    </h3>
                </div>

                <div className="flex bg-gray-100 dark:bg-zinc-800 rounded-lg p-0.5">
                    <button
                        onClick={() => setActiveTab('content')}
                        className={`px-3 py-1 text-[9px] font-bold uppercase rounded-md transition-all ${activeTab === 'content' ? 'bg-white dark:bg-zinc-700 shadow-sm text-primary' : 'text-gray-400'}`}
                    >Data</button>
                    <button
                        onClick={() => setActiveTab('style')}
                        className={`px-3 py-1 text-[9px] font-bold uppercase rounded-md transition-all ${activeTab === 'style' ? 'bg-white dark:bg-zinc-700 shadow-sm text-purple-600' : 'text-gray-400'}`}
                    >Style</button>
                </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {activeTab === 'content' ? (
                    <>
                        {def.fields?.map((field) => (
                            <div key={field.name} className="space-y-1.5">
                                <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400">
                                    {field.label}
                                </label>

                                {field.type === 'text' && (
                                    <input
                                        type="text"
                                        value={block.props[field.name] || ''}
                                        onChange={(e) => handlePropChange(field.name, e.target.value)}
                                        className="w-full px-3 py-2 border rounded-lg dark:bg-zinc-800 dark:border-zinc-700 focus:ring-2 focus:ring-primary outline-none text-sm"
                                    />
                                )}

                                {field.type === 'textarea' && (
                                    <div className="border rounded-lg overflow-hidden">
                                        <RichTextEditor
                                            content={block.props[field.name] || '<p></p>'}
                                            onChange={(newContent) => handlePropChange(field.name, newContent)}
                                            placeholder="Enter content..."
                                            minHeight="200px"
                                            editable={true}
                                        />
                                    </div>
                                )}

                                {field.type === 'number' && (
                                    <input
                                        type="number"
                                        value={block.props[field.name] || 0}
                                        onChange={(e) => handlePropChange(field.name, parseInt(e.target.value))}
                                        className="w-full px-3 py-2 border rounded-lg dark:bg-zinc-800 dark:border-zinc-700 focus:ring-2 focus:ring-primary outline-none text-sm"
                                    />
                                )}

                                {field.type === 'select' && (
                                    <select
                                        value={block.props[field.name]}
                                        onChange={(e) => handlePropChange(field.name, e.target.value)}
                                        className="w-full px-3 py-2 border rounded-lg dark:bg-zinc-800 dark:border-zinc-700 focus:ring-2 focus:ring-primary outline-none text-sm"
                                    >
                                        {field.options?.map((opt) => (
                                            <option key={opt.value} value={opt.value}>
                                                {opt.label}
                                            </option>
                                        ))}
                                    </select>
                                )}
                            </div>
                        ))}

                        {(!def.fields || def.fields.length === 0) && (
                            <p className="text-xs text-gray-500 italic text-center py-10">
                                This block has no editable properties.
                            </p>
                        )}
                    </>
                ) : (
                    <div className="space-y-6">
                        {/* Background */}
                        <div className="space-y-2">
                            <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400">Section Atmosphere</label>
                            <div className="grid grid-cols-2 gap-2">
                                {[
                                    { id: 'primary', label: 'Primary', color: 'bg-page-bg-primary' },
                                    { id: 'secondary', label: 'Secondary', color: 'bg-page-bg-secondary' },
                                    { id: 'alternate', label: 'Alternate', color: 'bg-page-bg-alternate' },
                                    { id: 'transparent', label: 'Ghost', color: 'border-2 border-dashed border-gray-200' }
                                ].map((bg) => (
                                    <button
                                        key={bg.id}
                                        onClick={() => handleStyleChange('background', bg.id)}
                                        className={`flex flex-col items-center gap-2 p-3 rounded-xl border transition-all ${block.styleOptions?.background === bg.id
                                            ? 'border-primary ring-2 ring-primary/20 bg-primary/5'
                                            : 'border-gray-100 dark:border-zinc-800'
                                            }`}
                                    >
                                        <div className={`w-full h-8 rounded-lg shadow-inner ${bg.color}`}></div>
                                        <span className="text-[9px] font-black uppercase tracking-tighter">{bg.label}</span>
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* Padding */}
                        <div className="space-y-2">
                            <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400">Vertical Breathing</label>
                            <div className="grid grid-cols-4 gap-2">
                                {[
                                    { id: 'none', label: 'Off' },
                                    { id: 'small', label: 'Tight' },
                                    { id: 'medium', label: 'Std' },
                                    { id: 'large', label: 'Exp' }
                                ].map((p) => (
                                    <button
                                        key={p.id}
                                        onClick={() => handleStyleChange('padding', p.id)}
                                        className={`py-2 rounded-lg border text-[9px] font-black uppercase tracking-tighter transition-all ${block.styleOptions?.padding === p.id
                                            ? 'bg-primary text-white border-primary shadow-lg shadow-primary/20'
                                            : 'bg-gray-50 dark:bg-zinc-800 border-gray-100 dark:border-zinc-700 text-gray-400'
                                            }`}
                                    >
                                        {p.label}
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* Max Width */}
                        <div className="space-y-2">
                            <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400">Content Horizon</label>
                            <div className="grid grid-cols-3 gap-2">
                                {[
                                    { id: 'narrow', label: 'Narrow' },
                                    { id: 'standard', label: 'Standard' },
                                    { id: 'full', label: 'Full' }
                                ].map((w) => (
                                    <button
                                        key={w.id}
                                        onClick={() => handleStyleChange('maxWidth', w.id)}
                                        className={`py-2 rounded-lg border text-[9px] font-black uppercase tracking-tighter transition-all ${block.styleOptions?.maxWidth === w.id
                                            ? 'bg-purple-600 text-white border-purple-600 shadow-lg shadow-purple-600/20'
                                            : 'bg-gray-50 dark:bg-zinc-800 border-gray-100 dark:border-zinc-700 text-gray-400'
                                            }`}
                                    >
                                        {w.label}
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* Custom Color */}
                        <div className="space-y-2">
                            <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400">Custom Hue</label>
                            <div className="flex gap-2">
                                <input
                                    type="color"
                                    value={block.styleOptions?.customBackground || '#ffffff'}
                                    onChange={(e) => handleStyleChange('customBackground', e.target.value)}
                                    className="w-10 h-10 rounded-lg p-1 bg-white dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 cursor-pointer"
                                />
                                <input
                                    type="text"
                                    value={block.styleOptions?.customBackground || ''}
                                    onChange={(e) => handleStyleChange('customBackground', e.target.value)}
                                    placeholder="Hex code (optional)"
                                    className="flex-1 px-3 py-2 border rounded-lg dark:bg-zinc-800 dark:border-zinc-700 focus:ring-2 focus:ring-primary outline-none text-xs font-mono"
                                />
                                {block.styleOptions?.customBackground && (
                                    <button
                                        onClick={() => handleStyleChange('customBackground', undefined)}
                                        className="px-2 text-[9px] font-bold text-red-500 hover:bg-red-50 rounded"
                                    >Clear</button>
                                )}
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
