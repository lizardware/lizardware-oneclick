// This file exports version info for use in client components
export const VERSION = '0.4.3';
