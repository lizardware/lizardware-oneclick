'use client';

interface SpacerProps {
    height?: string;
}

export default function Spacer({ height = '2rem' }: SpacerProps) {
    return <div style={{ height }} />;
}
