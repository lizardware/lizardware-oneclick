-- Migration 016: Create forum threads table
-- Version: 0.6.0
-- Purpose: Discussion threads within categories

CREATE TABLE IF NOT EXISTS forum_threads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  content TEXT NOT NULL, -- First post content (HTML from Tiptap)
  is_pinned BOOLEAN DEFAULT 0,
  is_locked BOOLEAN DEFAULT 0,
  view_count INTEGER DEFAULT 0,
  reply_count INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  last_post_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  last_post_user_id INTEGER,
  FOREIGN KEY (category_id) REFERENCES forum_categories(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES forum_users(id) ON DELETE CASCADE,
  FOREIGN KEY (last_post_user_id) REFERENCES forum_users(id) ON DELETE SET NULL
);

CREATE INDEX idx_forum_threads_category ON forum_threads(category_id);
CREATE INDEX idx_forum_threads_user ON forum_threads(user_id);
CREATE INDEX idx_forum_threads_pinned ON forum_threads(is_pinned);
CREATE INDEX idx_forum_threads_last_post ON forum_threads(last_post_at DESC);
CREATE INDEX idx_forum_threads_slug ON forum_threads(slug);
