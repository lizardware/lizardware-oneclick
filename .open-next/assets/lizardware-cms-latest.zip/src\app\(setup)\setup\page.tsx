'use client';

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { getAllBusinessTypes, getBusinessType, type BusinessType } from '@/data/business-types';
import { THEME_PRESETS } from '@/lib/themes';
import { LizardLogo } from '@/components/layout/LizardLogo';
import { INSTALL_SQL } from '@/data/install-sql';
import { usePopup } from '@/components/admin/AdminPopupProvider';
import { ImageZoom } from '@/components/ui/ImageZoom';
import { CreateAdminStep } from '@/components/setup/steps/CreateAdminStep';

// Icons
const CheckIcon = () => (
    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-green-500/10 border border-green-500/20 text-green-500 shadow-[0_0_15px_rgba(34,197,94,0.2)]">
        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
        </svg>
    </div>
);

const CopyButton = ({ text }: { text: string }) => {
    const [copied, setCopied] = useState(false);

    const handleCopy = () => {
        navigator.clipboard.writeText(text);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <button
            onClick={handleCopy}
            className="group relative ml-1 p-1.5 shrink-0 rounded-lg transition-all bg-zinc-100/50 dark:bg-white/5 hover:bg-zinc-200 dark:hover:bg-white/10 text-zinc-500 dark:text-zinc-400 border border-zinc-200 dark:border-white/10 hover:border-zinc-300 dark:hover:border-white/20 active:scale-90"
            title="Copy to clipboard"
        >
            {copied ? (
                <svg className="w-3.5 h-3.5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                </svg>
            ) : (
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
                </svg>
            )}

            {copied && (
                <span className="absolute -top-8 left-1/2 -translate-x-1/2 px-2 py-1 bg-zinc-800 text-white text-[10px] font-bold rounded shadow-xl animate-bounce whitespace-nowrap z-50">
                    Copied!
                </span>
            )}
        </button>
    );
};

// --- Step Components (Defined outside to prevent remounting) ---

function ResourcePrerequisitesStep({
    onNext
}: {
    onNext: () => void;
}) {
    const popup = usePopup();
    const [kvExists, setKvExists] = useState(false);
    const [d1Exists, setD1Exists] = useState(false);
    const [checking, setChecking] = useState(true);

    // Auto-provisioning states
    const [apiToken, setApiToken] = useState('');
    const [accountId, setAccountId] = useState('');
    const [isVerifyingToken, setIsVerifyingToken] = useState(false);
    const [projectName, setProjectName] = useState('');
    const [isProvisioning, setIsProvisioning] = useState(false);
    const [provisioningStatus, setProvisioningStatus] = useState('');
    const [provisioningError, setProvisioningError] = useState<{ message: string; type: string | null; details?: string | null } | null>(null);
    const [provisionedData, setProvisionedData] = useState<any>(null);
    const [showTokenHelp, setShowTokenHelp] = useState(false);
    const [showAccountHelp, setShowAccountHelp] = useState(false);
    const [hasSystemToken, setHasSystemToken] = useState(false);

    useEffect(() => {
        // Check for system token on load
        fetch('/api/admin/setup/check-system-token')
            .then(res => res.json())
            .then((data: any) => {
                if (data.hasToken) {
                    // console.log('System token detected:', data); // Debug
                    setHasSystemToken(true);
                    // Pre-fill fields if system provided them
                    if (data.accountId) setAccountId(data.accountId);
                    if (data.projectName) setProjectName(data.projectName);
                }
            })
            .catch(err => console.error('Failed to check system token:', err));
    }, []);


    const checkResources = async () => {
        setChecking(true);
        try {
            const [kv, d1] = await Promise.all([
                fetch('/api/admin/check-kv').then(r => r.json()) as Promise<{ exists: boolean }>,
                fetch('/api/admin/check-d1').then(r => r.json()) as Promise<{ exists: boolean }>
            ]);
            setKvExists(kv.exists);
            setD1Exists(d1.exists);
        } catch (err) {
            console.error('Failed to check resources:', err);
        } finally {
            setChecking(false);
        }
    };

    const handleAutoProvision = async () => {
        // Validation: If no system token, require all fields. If system token, require Account/Project.
        if (!hasSystemToken && !apiToken) {
            popup.error('Please provide an API Token.');
            return;
        }
        if (!accountId || !projectName) {
            popup.error('Please provide Account ID and Project Name.');
            return;
        }

        setIsProvisioning(true);
        setProvisioningStatus('Initiating Cloudflare resource creation...');
        setProvisioningError(null);

        try {
            const response = await fetch('/api/admin/setup/auto-provision', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ apiToken, accountId, projectName, autoConfigure: !window.location.hostname.includes('.dev') })
            });

            const data = await response.json() as any;

            if (!response.ok) {
                const errorMsg = data.error || 'Provisioning failed';
                let errorType = null;

                if (errorMsg.toLowerCase().includes('token')) errorType = 'token';
                if (errorMsg.toLowerCase().includes('authentication')) errorType = 'token';
                if (errorMsg.toLowerCase().includes('account')) errorType = 'account';
                if (errorMsg.toLowerCase().includes('permission')) errorType = 'permission';

                setProvisioningError({ message: errorMsg, type: errorType, details: data.details });
                throw new Error(errorMsg);
            }


            if (data.fileUpdated) {
                setProvisioningStatus('✅ All resources created and configured successfully!');
                popup.success('Cloudflare resources provisioned and configured!');
                await checkResources(); // Re-check to update UI
            } else {
                setProvisioningStatus('✅ Resources created! Manual configuration required (Prod Environment).');
                popup.success('Resources created! Please configure in Cloudflare Dashboard.');

                // Here we should probably trigger a different UI state to show the IDs
                // For now, let's just log them and maybe set a state that shows the "Manual Config" card with PRE-FILLED values
                // But the current UI doesn't support "pre-filled" display easily without changing verification logic.
                // Better approach: Show a persistent "Configuration Data" box below the button.

                // Quick hack for Alpha test: Update the inputs or show a special "Result" card.
                // Let's create a local state for this result data.
                // (Assuming we add `provisionedResult` state to the component)
            }

            // Pass the result up or handle it locally. 
            // For now, we will handle the "Manual Config" display by adding a new state variable.
            if (data.resources && !data.fileUpdated) {
                setProvisionedData(data.resources);
            }

            // Re-check resources to update UI
            await checkResources();

            // Small delay for user to read success message before moving to next step if they want
            // or we can just let them click continue.
        } catch (error: any) {
            setProvisioningStatus(`❌ Error: ${error.message}`);
            popup.error(`Provisioning failed: ${error.message}`);
        } finally {
            setIsProvisioning(false);
        }
    };

    useEffect(() => {
        checkResources();

        // Auto-infer project name from hostname
        if (typeof window !== 'undefined') {
            const hostname = window.location.hostname;
            // logic: if ends in .pages.dev or .workers.dev, take the first part
            // if localhost, default to 'my-lizardware-site'
            if (hostname.includes('pages.dev')) {
                setProjectName(hostname.split('.')[0]);
            } else if (hostname.includes('workers.dev')) {
                setProjectName(hostname.split('.')[0]);
            } else if (hostname === 'localhost' || hostname === '127.0.0.1') {
                setProjectName('my-lizardware-site');
            } else {
                // custom domain - use the domain name without TLD as a guess
                const parts = hostname.split('.');
                if (parts.length >= 2) {
                    setProjectName(parts[parts.length - 2]);
                } else {
                    setProjectName('my-lizardware-site');
                }
            }
        }
    }, []);

    const handleTokenBlur = async () => {
        if (!apiToken || accountId) return; // Don't verify if empty or Account ID already set

        setIsVerifyingToken(true);
        try {
            const res = await fetch('/api/admin/setup/lookup-account', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ apiToken })
            });
            const data = await res.json() as any;

            if (data.success && data.accountId) {
                setAccountId(data.accountId);
                popup.success(`Found Account: ${data.accountName || 'Unknown'} (${data.accountId})`);
            }
        } catch (err) {
            console.warn('Silent lookup failed:', err);
        } finally {
            setIsVerifyingToken(false);
        }
    };

    // Dev/Testing: Use ?force=true to always show provisioning UI
    const searchParams = useSearchParams();
    const forceShow = searchParams.get('force') === 'true';

    const allReady = !forceShow && (kvExists && d1Exists);

    return (
        <div className="space-y-10 max-w-3xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-700">
            <div className="text-center space-y-4">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-600 dark:text-blue-400 text-[10px] font-bold uppercase tracking-widest">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-ping" />
                    Infrastructure Check
                </div>
                <h2 className="text-4xl font-black text-zinc-900 dark:text-white tracking-tight">
                    Resource Prerequisites
                </h2>
                <p className="text-zinc-500 dark:text-zinc-400 text-lg">
                    Let's ensure your Cloudflare foundation is ready for liftoff.
                </p>
            </div>

            {/* GitHub Actions Pre-Provisioned Success Banner */}
            {allReady && !forceShow && (
                <div className="p-8 bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-[2.5rem] shadow-xl relative overflow-hidden group animate-in fade-in slide-in-from-top-4 duration-700">
                    <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:opacity-10 transition-opacity">
                        <svg className="w-24 h-24" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12 2L4.5 20.29l.71.71L12 18l6.79 3 .71-.71L12 2z" />
                        </svg>
                    </div>

                    <div className="relative z-10 space-y-4">
                        <div className="flex items-center gap-4">
                            <div className="w-12 h-12 shrink-0 rounded-full bg-green-500 text-white flex items-center justify-center shadow-lg shadow-green-500/30">
                                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                            </div>
                            <div className="flex-1 min-w-0">
                                <h3 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-green-500 to-emerald-500 uppercase tracking-tighter">
                                    ✅ Resources Ready
                                </h3>
                                <p className="text-sm text-zinc-500 dark:text-zinc-400 font-medium">
                                    Your Cloudflare infrastructure has been provisioned and configured.
                                </p>
                            </div>
                        </div>

                        <div className="p-4 bg-green-500/5 border border-green-500/10 rounded-xl">
                            <div className="flex items-start gap-3">
                                <svg className="w-5 h-5 text-green-500 mt-0.5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                                <div className="flex-1 min-w-0">
                                    <p className="text-xs font-bold text-green-600 dark:text-green-400 uppercase tracking-wider mb-1">Automated via GitHub Actions</p>
                                    <p className="text-[11px] text-zinc-500 dark:text-zinc-400 leading-relaxed">
                                        KV and D1 bindings were detected in your Worker environment. If you deployed via GitHub Actions, resources were created automatically during the build process. You can proceed directly to the next step.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Quick Setup Section (Auto-Provisioning) */}
            {!allReady && (
                <div className="p-8 bg-gradient-to-br from-purple-500/10 to-blue-500/10 border border-purple-500/20 rounded-[2.5rem] shadow-xl overflow-hidden relative group">
                    <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:opacity-10 transition-opacity">
                        <svg className="w-24 h-24" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12 2L4.5 20.29l.71.71L12 18l6.79 3 .71-.71L12 2z" />
                        </svg>
                    </div>

                    <div className="relative z-10 space-y-6">
                        <div className="space-y-2">
                            <h3 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-blue-500 uppercase tracking-tighter">
                                🚀 Instant Provisioning
                            </h3>
                            <p className="text-sm text-zinc-500 dark:text-zinc-400 font-medium">
                                Provide your Cloudflare API details and we'll create all necessary resources automatically.
                            </p>
                        </div>

                        <div className="grid gap-4">
                            <div className="space-y-1.5">
                                {hasSystemToken ? (
                                    <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-xl flex items-center gap-4 animate-in fade-in slide-in-from-top-1">
                                        <div className="w-10 h-10 shrink-0 rounded-full bg-green-500 text-white flex items-center justify-center shadow-lg shadow-green-500/20">
                                            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                            </svg>
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <p className="text-sm font-black text-green-700 dark:text-green-400 uppercase tracking-wide">System Token Active</p>
                                            <p className="text-[11px] text-zinc-500 dark:text-zinc-400 font-medium truncate">
                                                Using environment credentials
                                            </p>
                                        </div>
                                        <button
                                            onClick={() => setHasSystemToken(false)}
                                            className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-widest text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 bg-white/50 dark:bg-black/20 hover:bg-white dark:hover:bg-black/40 rounded-lg transition-all"
                                        >
                                            Override
                                        </button>
                                    </div>
                                ) : (
                                    <>
                                        <div className="flex justify-between items-end mb-1">
                                            <label className="text-[10px] font-black text-zinc-400 uppercase tracking-widest ml-1">API Token</label>
                                            <button
                                                onClick={() => setShowTokenHelp(!showTokenHelp)}
                                                className="text-[9px] font-bold text-blue-500 hover:text-blue-600 uppercase tracking-wider flex items-center gap-1 transition-colors"
                                            >
                                                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                                </svg>
                                                {showTokenHelp ? 'Hide Instructions' : 'How to create?'}
                                            </button>
                                        </div>
                                        <input
                                            type="password"
                                            placeholder="Enter Cloudflare API Token..."
                                            className="w-full px-5 py-3.5 bg-zinc-900/50 border border-zinc-700 rounded-xl focus:border-purple-500 focus:ring-4 focus:ring-purple-500/10 outline-none transition-all font-mono text-sm"
                                            value={apiToken}
                                            onChange={(e) => setApiToken(e.target.value)}
                                        />
                                        <div className="mt-2 p-4 bg-blue-500/5 border border-blue-500/10 rounded-xl animate-in fade-in slide-in-from-top-2 duration-300">
                                            <p className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-widest mb-2">Create & Connect Token</p>
                                            <ol className="text-[11px] text-zinc-500 dark:text-zinc-400 space-y-2 list-decimal pl-4">
                                                <li>Go to <a href="https://dash.cloudflare.com/profile/api-tokens" target="_blank" className="text-blue-500 hover:underline font-bold">Cloudflare API Tokens Profile</a>.</li>
                                                <li>Find your project token (e.g. <strong>Lizardware-{projectName}</strong>).</li>
                                                <li>Click the <strong>three dots (⋮)</strong> and select <strong>Roll</strong> to generate a new value.</li>
                                                <li>Copy and paste the new token here.</li>
                                            </ol>
                                            <div className="mt-3 mb-2">
                                                <ImageZoom
                                                    src="/images/docs/cloudflare-roll-token.png"
                                                    alt="Cloudflare Dashboard: Action menu showing 'Roll' option for API token"
                                                    className="w-full rounded-lg border border-zinc-200 dark:border-zinc-700 shadow-sm"
                                                />
                                            </div>
                                            <div className="mt-3 p-2 bg-yellow-500/10 border border-yellow-500/20 rounded">
                                                <p className="text-[10px] text-yellow-600 dark:text-yellow-400 leading-tight">
                                                    <strong>⚠️ Don't see a project token?</strong><br />
                                                    Click <strong>Create Token</strong> &rarr; use <strong>Custom Token</strong> (Account: Read / D1, KV, R2, Scripts: Edit).
                                                </p>
                                            </div>
                                        </div>
                                    </>
                                )}
                            </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-1.5">
                                <div className="flex justify-between items-end mb-1">
                                    <label className="text-[10px] font-black text-zinc-400 uppercase tracking-widest ml-1">Account ID</label>
                                    <button
                                        onClick={() => setShowAccountHelp(!showAccountHelp)}
                                        className="text-[9px] font-bold text-blue-500 hover:text-blue-600 uppercase tracking-wider flex items-center gap-1 transition-colors"
                                    >
                                        <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                        </svg>
                                        {showAccountHelp ? 'Hide' : 'Where?'}
                                    </button>
                                </div>
                                <input
                                    type="text"
                                    placeholder="Cloudflare Account ID..."
                                    className="w-full px-5 py-3.5 bg-zinc-900/50 border border-zinc-700 rounded-xl focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all font-mono text-sm"
                                    value={accountId}
                                    onChange={(e) => setAccountId(e.target.value)}
                                />
                                {showAccountHelp && (
                                    <div className="mt-2 p-4 bg-blue-500/5 border border-blue-500/10 rounded-xl animate-in fade-in slide-in-from-top-2 duration-300">
                                        <p className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-widest mb-2">Finding Account ID</p>
                                        <ol className="text-[11px] text-zinc-500 dark:text-zinc-400 space-y-2 list-decimal pl-4">
                                            <li>Go to <a href="https://dash.cloudflare.com" target="_blank" className="text-blue-500 hover:underline font-bold">dash.cloudflare.com</a>.</li>
                                            <li>Locate your account name and click the <span className="font-bold text-zinc-900 dark:text-white">three dots (⋮)</span> on the far right.</li>
                                            <li>Select <span className="font-bold text-zinc-900 dark:text-white uppercase">Copy Account ID</span>.</li>
                                        </ol>
                                    </div>
                                )}
                            </div>
                            <div className="space-y-1.5">
                                <label className="text-[10px] font-black text-zinc-400 uppercase tracking-widest ml-1">Project Slug / Name</label>
                                <input
                                    type="text"
                                    placeholder="my-lizardware-site"
                                    className="w-full px-5 py-3.5 bg-zinc-900/50 border border-zinc-700 rounded-xl focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all font-mono text-sm"
                                    value={projectName}
                                    onChange={(e) => setProjectName(e.target.value)}
                                />
                                <p className="text-[10px] text-zinc-500 px-1">
                                    Usually your subdomain (e.g. <strong>{projectName || 'site'}</strong>.pages.dev)
                                </p>
                            </div>
                        </div>
                    </div>

                    <button
                        onClick={handleAutoProvision}
                        disabled={isProvisioning || !apiToken || !accountId}
                        className={`w-full py-5 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-black rounded-2xl transition-all shadow-lg active:scale-[0.98] disabled:opacity-50 flex items-center justify-center gap-3 uppercase tracking-[0.2em] text-sm ${isProvisioning ? 'animate-pulse' : ''}`}
                    >
                        {isProvisioning ? (
                            <>
                                <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                                </svg>
                                Provisioning Resources...
                            </>
                        ) : (
                            '✨ Auto-Create Everything'
                        )}
                    </button>

                    {provisioningStatus && !provisioningError && (
                        <div className={`p-4 rounded-xl text-center text-xs font-bold ${provisioningStatus.includes('❌') ? 'bg-red-500/10 text-red-400 border border-red-500/20' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'}`}>
                            {provisioningStatus}
                        </div>
                    )}

                    {provisioningError && (
                        <div className="p-6 bg-red-500/5 dark:bg-red-950/20 border border-red-500/20 rounded-2xl animate-in zoom-in-95 duration-300">
                            <div className="flex items-start gap-4 mb-4">
                                <div className="w-12 h-12 shrink-0 rounded-full bg-red-500 flex items-center justify-center text-white shadow-xl shadow-red-500/20">
                                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                                    </svg>
                                </div>
                                <div className="flex-1 min-w-0">
                                    <h3 className="text-sm font-black text-red-600 dark:text-red-400 uppercase tracking-widest mb-1">Provisioning Failed</h3>
                                    <p className="text-xs text-zinc-600 dark:text-zinc-400 font-medium leading-relaxed">
                                        {provisioningError.message}
                                    </p>
                                </div>
                            </div>

                            <div className="space-y-3 bg-white dark:bg-black/20 p-4 rounded-xl border border-red-500/10">
                                <p className="text-[10px] font-black uppercase tracking-[0.15em] text-red-500/80 mb-2">Recommended Fix</p>

                                {provisioningError.type === 'token' ? (
                                    <div className="space-y-2">
                                        <p className="text-[11px] text-zinc-500 dark:text-zinc-400 leading-relaxed">
                                            <strong>Authentication Failed.</strong> Double-check that your API Token matches your Account ID.
                                        </p>
                                        <div className="text-[10px] text-zinc-500 dark:text-zinc-400 p-2 bg-red-500/5 rounded border border-red-500/10">
                                            <span className="font-bold block mb-1">Required Custom Token Permissions:</span>
                                            <ul className="list-disc pl-4 space-y-0.5">
                                                <li>Account Settings: Read</li>
                                                <li>D1, KV, R2: Edit</li>
                                                <li>Workers Scripts: Edit</li>
                                            </ul>
                                        </div>
                                    </div>
                                ) : provisioningError.type === 'account' ? (
                                    <p className="text-[11px] text-zinc-500 dark:text-zinc-400 leading-relaxed">
                                        Verify your Account ID is correct. You can find it on your Cloudflare Dashboard under "Workers & Pages".
                                    </p>
                                ) : (
                                    <p className="text-[11px] text-zinc-500 dark:text-zinc-400 leading-relaxed">
                                        This error usually occurs when the API token doesn't have enough power to create databases or namespaces.
                                    </p>
                                )}

                                {provisioningError.details && (
                                    <details className="mt-2 mb-3 p-2 bg-red-950/10 rounded border border-red-500/10 text-left group">
                                        <summary className="text-[10px] font-bold text-red-500 cursor-pointer uppercase tracking-wider select-none list-none flex items-center gap-2 outline-none">
                                            <svg className="w-3 h-3 transition-transform group-open:rotate-90" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
                                            Show Error Details
                                        </summary>
                                        <div className="mt-2 p-2 bg-black/5 dark:bg-black/20 rounded border border-red-500/5">
                                            <pre className="text-[10px] font-mono text-red-700 dark:text-red-300/90 whitespace-pre-wrap break-all leading-relaxed">
                                                {provisioningError.details}
                                            </pre>
                                        </div>
                                    </details>
                                )}

                                <div className="flex flex-col sm:flex-row gap-2 pt-2">
                                    <Link
                                        href="/docs/troubleshooting"
                                        target="_blank"
                                        className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-lg shadow-red-600/20"
                                    >
                                        <span>Open Troubleshooting Guide</span>
                                        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                                        </svg>
                                    </Link>
                                    <button
                                        onClick={handleAutoProvision}
                                        className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-600 dark:text-zinc-300 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all"
                                    >
                                        Retry Auto-Create
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}


                    {/* Manual Configuration Display (For Production Environments) */}
                    {provisionedData && (
                        <div className="p-6 bg-blue-500/10 border border-blue-500/20 rounded-2xl animate-in fade-in slide-in-from-top-4 duration-500">
                            <div className="flex items-center gap-4 mb-4">
                                <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white shadow-lg shadow-blue-500/30">
                                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                                    </svg>
                                </div>
                                <div>
                                    <h3 className="text-lg font-black text-zinc-900 dark:text-white tracking-tight">Configuration Required</h3>
                                    <p className="text-xs text-zinc-500 dark:text-zinc-400 font-bold">Resources created! Add these to your Settings.</p>
                                </div>
                            </div>

                            <div className="space-y-4">
                                <div className="p-3 bg-white/50 dark:bg-black/20 rounded-lg border border-blue-500/10">
                                    <p className="text-xs font-medium mb-1.5 uppercase tracking-wide text-zinc-500">
                                        1. Settings &rarr; <span className="text-blue-600 dark:text-blue-400 font-bold">Build</span> &rarr; Variables and secrets
                                    </p>
                                    <div className="space-y-1.5">
                                        <div className="flex justify-between items-center text-[10px] font-mono bg-zinc-100 dark:bg-black/40 p-2 rounded">
                                            <span className="text-zinc-500">WRANGLER_KV_ID</span>
                                            <div className="flex items-center gap-2">
                                                <span className="font-bold text-blue-600 dark:text-blue-400 select-all">{provisionedData.kv.id}</span>
                                                <CopyButton text={provisionedData.kv.id} />
                                            </div>
                                        </div>
                                        <div className="flex justify-between items-center text-[10px] font-mono bg-zinc-100 dark:bg-black/40 p-2 rounded">
                                            <span className="text-zinc-500">WRANGLER_D1_ID</span>
                                            <div className="flex items-center gap-2">
                                                <span className="font-bold text-blue-600 dark:text-blue-400 select-all">{provisionedData.d1.id}</span>
                                                <CopyButton text={provisionedData.d1.id} />
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="p-3 bg-white/50 dark:bg-black/20 rounded-lg border border-blue-500/10">
                                    <p className="text-xs font-medium mb-1.5 uppercase tracking-wide text-zinc-500">2. R2 Object Storage</p>
                                    <div className="flex justify-between items-center text-[10px] font-mono bg-zinc-100 dark:bg-black/40 p-2 rounded">
                                        <span className="text-zinc-500">MEDIA_BUCKET (Name)</span>
                                        <div className="flex items-center gap-2">
                                            <span className="font-bold text-blue-600 dark:text-blue-400 select-all">{provisionedData.r2.name}</span>
                                            <CopyButton text={provisionedData.r2.name} />
                                        </div>
                                    </div>
                                    <p className="text-[10px] text-zinc-400 mt-1 italic">
                                        * Ensure your Worker has a binding to this bucket name.
                                    </p>
                                </div>

                                <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg">
                                    <div className="flex items-start gap-2">
                                        <svg className="w-4 h-4 text-amber-500 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                                        </svg>
                                        <div>
                                            <p className="text-xs font-bold text-amber-600 mb-0.5">Redeploy Required!</p>
                                            <p className="text-[10px] text-zinc-600 dark:text-zinc-400 leading-relaxed">
                                                Because `wrangler.jsonc` generates at build time, simply adding variables isn't enough.
                                                You must <span className="font-bold">trigger a new deployment</span> (e.g. push to valid branch) for these bindings to take effect.
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                <div className="text-center pt-2">
                                    <button
                                        onClick={() => window.location.reload()}
                                        className="px-6 py-2.5 bg-zinc-900 dark:bg-white text-white dark:text-black rounded-xl text-xs font-black uppercase tracking-widest hover:scale-105 transition-transform shadow-lg"
                                    >
                                        I Have Redeployed &rarr; Reload Page
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}

                    <div className="pt-2 text-[10px] text-center text-zinc-500 font-medium">
                        * Tokens are used only once and never stored. Requires <span className="text-zinc-400 underline italic">KV, D1, R2, and Workers</span> permissions.
                    </div>
                </div>
            )}

            <div className="flex items-center gap-4 py-4">
                <div className="h-px flex-1 bg-zinc-200 dark:bg-white/10" />
                <span className="text-[10px] font-black text-zinc-400 uppercase tracking-[0.3em]">Vertical Validation</span>
                <div className="h-px flex-1 bg-zinc-200 dark:bg-white/10" />
            </div>

            <div className="grid gap-6">
                {/* KV Check Card */}
                <div className={`group relative p-8 rounded-[2rem] border-2 transition-all duration-300 ${kvExists ? 'border-green-500/30 bg-green-500/5 shadow-[0_20px_40px_-20px_rgba(34,197,94,0.15)]' : 'border-orange-500/30 bg-orange-500/5 shadow-[0_20px_40px_-20px_rgba(249,115,22,0.15)]'}`}>
                    <div className="flex items-start justify-between">
                        <div className="space-y-1">
                            <h3 className="text-xl font-bold flex items-center gap-3">
                                {kvExists ? <CheckIcon /> : (
                                    <div className="w-8 h-8 rounded-full bg-orange-500/10 border border-orange-500/20 text-orange-500 flex items-center justify-center">
                                        <svg className="w-5 h-5 animate-pulse" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                                        </svg>
                                    </div>
                                )}
                                KV Namespace
                            </h3>
                            <p className="text-sm text-zinc-500 font-medium">Used for global configuration storage</p>
                        </div>
                        <div className="flex flex-col items-end gap-1">
                            {checking ? (
                                <span className="flex items-center gap-2 text-xs font-bold text-zinc-400 uppercase tracking-widest">
                                    <svg className="animate-spin h-3 w-3" viewBox="0 0 24 24">
                                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                                    </svg>
                                    Checking...
                                </span>
                            ) : kvExists ? (
                                <span className="text-xs font-black text-green-600 dark:text-green-400 uppercase tracking-[0.2em] bg-green-500/10 px-3 py-1 rounded-full">✓ Found</span>
                            ) : (
                                <span className="text-xs font-black text-orange-600 dark:text-orange-400 uppercase tracking-[0.2em] bg-orange-500/10 px-3 py-1 rounded-full animate-pulse">⚠ Pending</span>
                            )}
                        </div>
                    </div>

                    {!kvExists && !checking && (
                        <div className="mt-8 pt-8 border-t border-orange-500/10 space-y-6 animate-in fade-in slide-in-from-top-2 duration-500">
                            <div className="space-y-4">
                                <p className="text-sm font-bold text-zinc-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
                                    <span className="w-5 h-5 flex items-center justify-center bg-orange-500 text-white rounded-md text-[10px]">1</span>
                                    Create KV Namespace
                                </p>
                                <ol className="space-y-3 pl-7">
                                    <li className="text-sm text-zinc-600 dark:text-zinc-400 leading-relaxed">
                                        Cloudflare Dashboard → <span className="text-zinc-900 dark:text-white font-medium">Workers & Pages</span> → <span className="text-zinc-900 dark:text-white font-medium">KV</span> → <span className="text-blue-500 font-bold">Create namespace</span>
                                    </li>
                                    <li className="flex flex-wrap items-center gap-x-2 gap-y-1 text-sm text-zinc-600 dark:text-zinc-400">
                                        <span className="shrink-0 font-medium">Name:</span>
                                        <div className="flex items-center gap-2 min-w-0">
                                            <code className="bg-zinc-100 dark:bg-white/10 text-blue-600 dark:text-blue-400 px-2 py-1 rounded-lg font-mono font-bold text-xs sm:text-sm truncate max-w-[200px] sm:max-w-none">lizardware-config</code>
                                            <CopyButton text="lizardware-config" />
                                        </div>
                                    </li>
                                </ol>
                            </div>

                            <div className="p-5 bg-blue-500/5 border border-blue-500/20 rounded-2xl relative overflow-hidden group/alert">
                                <div className="absolute top-0 right-0 p-3 opacity-10 group-hover/alert:opacity-20 transition-opacity">
                                    <svg className="w-12 h-12" fill="currentColor" viewBox="0 0 24 24">
                                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z" />
                                    </svg>
                                </div>
                                <h4 className="text-sm font-black text-blue-700 dark:text-blue-300 uppercase tracking-widest mb-3 flex items-center gap-2">
                                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                    </svg>
                                    Technical Alert
                                </h4>
                                <p className="text-xs text-blue-600/80 dark:text-blue-300/60 leading-relaxed italic mb-3">Cloudflare has multiple variable locations. Success requires the correct one:</p>
                                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                                    <div className="p-2 rounded-xl bg-red-500/5 border border-red-500/10 opacity-60">
                                        <span className="text-[10px] font-black block mb-1">RUNTIME ❌</span>
                                        <span className="text-[9px] leading-tight block">Settings → Variables</span>
                                    </div>
                                    <div className="p-2 rounded-xl bg-blue-500/10 border border-blue-500/30 ring-2 ring-blue-500/20">
                                        <span className="text-[10px] font-black block mb-1">BUILD ✅</span>
                                        <span className="text-[9px] leading-tight block font-bold">Settings → Build</span>
                                    </div>
                                    <div className="p-2 rounded-xl bg-red-500/5 border border-red-500/10 opacity-60">
                                        <span className="text-[10px] font-black block mb-1">BINDINGS ❌</span>
                                        <span className="text-[9px] leading-tight block">Auto-managed</span>
                                    </div>
                                </div>
                            </div>

                            <div className="space-y-4">
                                <p className="text-sm font-bold text-zinc-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
                                    <span className="w-5 h-5 flex items-center justify-center bg-orange-500 text-white rounded-md text-[10px]">2</span>
                                    Add Build Variable
                                </p>
                                <ol className="space-y-3 pl-7">
                                    <li className="text-sm text-zinc-600 dark:text-zinc-400">
                                        Workers Project → <span className="font-bold">Settings</span> → <span className="font-bold">Build section</span> → <span className="font-bold text-blue-500 underline decoration-blue-500/30">Variables and secrets</span>
                                    </li>
                                    <li className="flex flex-wrap items-center gap-x-2 gap-y-1 text-sm text-zinc-600 dark:text-zinc-400">
                                        <span className="shrink-0 font-medium">Key:</span>
                                        <div className="flex items-center gap-2 min-w-0">
                                            <code className="bg-zinc-100 dark:bg-white/10 text-blue-600 dark:text-blue-400 px-2 py-1 rounded-lg font-mono font-bold text-xs sm:text-sm truncate max-w-[200px] sm:max-w-none">WRANGLER_KV_ID</code>
                                            <CopyButton text="WRANGLER_KV_ID" />
                                        </div>
                                    </li>
                                    <li className="text-sm text-orange-600 dark:text-orange-400 font-bold italic text-xs">
                                        * Save and trigger redeploy after adding.
                                    </li>
                                </ol>
                            </div>
                        </div>
                    )}
                </div>

                {/* D1 Check Card */}
                <div className={`p-8 rounded-[2rem] border-2 transition-all duration-300 ${d1Exists ? 'border-green-500/30 bg-green-500/5 shadow-[0_20px_40px_-20px_rgba(34,197,94,0.15)]' : 'border-orange-500/30 bg-orange-500/5 shadow-[0_20px_40px_-20px_rgba(249,115,22,0.15)]'}`}>
                    <div className="flex items-start justify-between">
                        <div className="space-y-1">
                            <h3 className="text-xl font-bold flex items-center gap-3">
                                {d1Exists ? <CheckIcon /> : (
                                    <div className="w-8 h-8 rounded-full bg-orange-500/10 border border-orange-500/20 text-orange-500 flex items-center justify-center">
                                        <svg className="w-5 h-5 animate-pulse" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                                        </svg>
                                    </div>
                                )}
                                D1 Database
                            </h3>
                            <p className="text-sm text-zinc-500 font-medium">Persistent relational data engine</p>
                        </div>
                        <div className="flex flex-col items-end gap-1">
                            {checking ? (
                                <span className="flex items-center gap-2 text-xs font-bold text-zinc-400 uppercase tracking-widest">
                                    <svg className="animate-spin h-3 w-3" viewBox="0 0 24 24">
                                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                                    </svg>
                                    Checking...
                                </span>
                            ) : d1Exists ? (
                                <span className="text-xs font-black text-green-600 dark:text-green-400 uppercase tracking-[0.2em] bg-green-500/10 px-3 py-1 rounded-full">✓ Found</span>
                            ) : (
                                <span className="text-xs font-black text-orange-600 dark:text-orange-400 uppercase tracking-[0.2em] bg-orange-500/10 px-3 py-1 rounded-full animate-pulse">⚠ Pending</span>
                            )}
                        </div>
                    </div>

                    {!d1Exists && !checking && (
                        <div className="mt-8 pt-8 border-t border-orange-500/10 space-y-8 animate-in fade-in slide-in-from-top-2 duration-500">
                            <div className="space-y-4">
                                <p className="text-sm font-bold text-zinc-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
                                    <span className="w-5 h-5 flex items-center justify-center bg-orange-500 text-white rounded-md text-[10px]">1</span>
                                    Create D1 Database
                                </p>
                                <ol className="space-y-3 pl-7">
                                    <li className="text-sm text-zinc-600 dark:text-zinc-400">
                                        Cloudflare Dashboard → <span className="font-medium">D1</span> → <span className="text-blue-500 font-bold">Create database</span>
                                    </li>
                                    <li className="flex flex-wrap items-center gap-x-2 gap-y-1 text-sm text-zinc-600 dark:text-zinc-400">
                                        <span className="shrink-0 font-medium">Name:</span>
                                        <div className="flex items-center gap-2 min-w-0">
                                            <code className="bg-zinc-100 dark:bg-white/10 text-blue-600 dark:text-blue-400 px-2 py-1 rounded-lg font-mono font-bold text-xs sm:text-sm truncate max-w-[200px] sm:max-w-none">lizardware-db</code>
                                            <CopyButton text="lizardware-db" />
                                        </div>
                                    </li>
                                </ol>
                            </div>

                            <div className="space-y-4">
                                <p className="text-sm font-bold text-zinc-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
                                    <span className="w-5 h-5 flex items-center justify-center bg-orange-500 text-white rounded-md text-[10px]">2</span>
                                    Add Build Variable
                                </p>
                                <ol className="space-y-3 pl-7">
                                    <li className="text-sm text-zinc-600 dark:text-zinc-400">
                                        Same location as KV: <span className="font-bold underline decoration-zinc-300 dark:decoration-white/20">Settings → Build → Variables</span>
                                    </li>
                                    <li className="flex flex-wrap items-center gap-x-2 gap-y-1 text-sm text-zinc-600 dark:text-zinc-400">
                                        <span className="shrink-0 font-medium">Key:</span>
                                        <div className="flex items-center gap-2 min-w-0">
                                            <code className="bg-zinc-100 dark:bg-white/10 text-blue-600 dark:text-blue-400 px-2 py-1 rounded-lg font-mono font-bold text-xs sm:text-sm truncate max-w-[200px] sm:max-w-none">WRANGLER_D1_ID</code>
                                            <CopyButton text="WRANGLER_D1_ID" />
                                        </div>
                                    </li>
                                </ol>
                            </div>
                        </div>
                    )}
                </div>
            </div>

            <div className="flex gap-4 justify-between items-center pt-8 border-t border-zinc-200/50 dark:border-white/5">
                <button
                    onClick={checkResources}
                    disabled={checking}
                    className="group px-8 py-4 bg-white dark:bg-white/5 border border-zinc-200 dark:border-white/10 text-zinc-700 dark:text-zinc-300 rounded-[1.5rem] font-bold text-sm hover:bg-zinc-50 dark:hover:bg-white/10 transition-all flex items-center gap-3 disabled:opacity-50 active:scale-95 shadow-sm"
                >
                    <svg className={`w-4 h-4 ${checking ? 'animate-spin' : 'group-hover:rotate-180 transition-transform duration-500'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357-2H15" />
                    </svg>
                    Refresh Status
                </button>
                <button
                    onClick={onNext}
                    disabled={!allReady}
                    className="px-12 py-4 bg-blue-600 text-white rounded-[1.5rem] font-black text-base uppercase tracking-widest hover:bg-blue-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-[0_10px_30px_-10px_rgba(37,99,235,0.5)] active:scale-95 hover:shadow-[0_15px_40px_-10px_rgba(37,99,235,0.6)]"
                >
                    Continue Onward →
                </button>
            </div>

            {/* Dev/Testing Link - Only show when resources exist and in dev environment */}
            {
                allReady && !forceShow && typeof window !== 'undefined' && (
                    window.location.hostname === 'localhost' ||
                    window.location.hostname === '127.0.0.1' ||
                    window.location.hostname.includes('.pages.dev')
                ) && (
                    <div className="text-center pt-8">
                        <a
                            href="/setup?force=true"
                            className="text-[10px] text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300 underline transition-colors"
                        >
                            🔧 Show setup instructions (dev)
                        </a>
                    </div>
                )
            }
        </div >
    );
}

function BusinessTypeStep({
    selectedBusinessType,
    onSelect,
    onNext,
    onBack
}: {
    selectedBusinessType: BusinessType | null;
    onSelect: (bt: BusinessType) => void;
    onNext: () => void;
    onBack: () => void;
}) {
    const popup = usePopup();
    const businessTypes = getAllBusinessTypes();
    const [keepExisting, setKeepExisting] = useState(true);
    const [initializing, setInitializing] = useState(false);
    const [deploymentError, setDeploymentError] = useState<{ message: string; type: string | null } | null>(null);

    const handleDeploy = async () => {
        if (!selectedBusinessType) return;

        setInitializing(true);
        setDeploymentError(null);
        try {
            // Initialize database with selected business type's seed
            const res = await fetch('/api/admin/init-database', {
                method: 'POST',
                body: JSON.stringify({
                    seedType: selectedBusinessType.seedFile,
                    keepExisting
                })
            });

            const data = await res.json() as any;

            if (res.ok) {
                popup.success('Database and content deployed successfully!');
                onNext();
            } else {
                const errorMsg = data.error || 'Failed to deploy content';
                let errorType = null;
                if (errorMsg.toLowerCase().includes('sql')) errorType = 'database';
                if (errorMsg.toLowerCase().includes('migration')) errorType = 'database';
                if (errorMsg.toLowerCase().includes('d1')) errorType = 'database';

                setDeploymentError({ message: errorMsg, type: errorType });
                popup.error('Deployment failed. See details below.');
            }
        } catch (err: any) {
            setDeploymentError({
                message: err.message || 'Connectivity loss during deployment.',
                type: 'network'
            });
            popup.error('Network error during deployment.');
        } finally {
            setInitializing(false);
        }
    };


    return (
        <div className="space-y-10 py-4 animate-in fade-in slide-in-from-right-8 duration-700">
            <div className="text-center space-y-4">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-600 dark:text-purple-400 text-[10px] font-bold uppercase tracking-widest">
                    <span className="w-1.5 h-1.5 rounded-full bg-purple-500 animate-pulse" />
                    Business Type Selection
                </div>
                <h2 className="text-4xl font-black text-zinc-900 dark:text-white tracking-tight">Choose Your Business Type</h2>
                <p className="text-zinc-500 dark:text-zinc-400 text-lg max-w-2xl mx-auto font-medium">
                    Select a business type to automatically load recommended theme, content, and features.
                </p>
            </div>

            {deploymentError && (
                <div className="max-w-2xl mx-auto p-6 bg-red-500/5 dark:bg-red-950/20 border border-red-500/20 rounded-2xl animate-in zoom-in-95 duration-300">
                    <div className="flex items-start gap-4 mb-4">
                        <div className="w-12 h-12 shrink-0 rounded-full bg-red-500 flex items-center justify-center text-white shadow-xl shadow-red-500/20">
                            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                            </svg>
                        </div>
                        <div className="flex-1 min-w-0">
                            <h3 className="text-sm font-black text-red-600 dark:text-red-400 uppercase tracking-widest mb-1">Content Deployment Failed</h3>
                            <p className="text-xs text-zinc-600 dark:text-zinc-400 font-medium leading-relaxed">
                                {deploymentError.message}
                            </p>
                        </div>
                    </div>

                    <div className="space-y-3 bg-white dark:bg-black/20 p-4 rounded-xl border border-red-500/10">
                        <p className="text-[10px] font-black uppercase tracking-[0.15em] text-red-500/80 mb-2">Recommended Fix</p>

                        {deploymentError.type === 'database' ? (
                            <p className="text-[11px] text-zinc-500 dark:text-zinc-400 leading-relaxed">
                                There was an issue initializing your D1 database. Ensure your D1 binding name is exactly <strong className="text-zinc-900 dark:text-white">DB</strong> and that the database is not in "read-only" mode.
                            </p>
                        ) : deploymentError.type === 'network' ? (
                            <p className="text-[11px] text-zinc-500 dark:text-zinc-400 leading-relaxed">
                                The connection to the Cloudflare API was lost. This often happens due to temporary Cloudflare maintenance or local network instability.
                            </p>
                        ) : (
                            <p className="text-[11px] text-zinc-500 dark:text-zinc-400 leading-relaxed">
                                Try selecting a different business type or retrying the deployment. If this persists, check your Cloudflare D1 settings.
                            </p>
                        )}

                        <div className="flex flex-col sm:flex-row gap-2 pt-2">
                            <Link
                                href="/docs/troubleshooting"
                                target="_blank"
                                className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-lg shadow-red-600/20"
                            >
                                <span>Open Troubleshooting Guide</span>
                                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                                </svg>
                            </Link>
                            <button
                                onClick={handleDeploy}
                                className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-600 dark:text-zinc-300 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all"
                            >
                                Retry Deployment
                            </button>
                        </div>
                    </div>
                </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

                {businessTypes.map((bt) => (
                    <div
                        key={bt.id}
                        onClick={() => onSelect(bt)}
                        className={`group cursor-pointer rounded-[2rem] border-2 transition-all duration-500 relative overflow-hidden flex flex-col h-full p-8 ${selectedBusinessType?.id === bt.id
                            ? 'border-blue-500 bg-blue-500/5 shadow-[0_30px_60px_-15px_rgba(37,99,235,0.2)] dark:shadow-[0_30px_60px_-15px_rgba(37,99,235,0.4)]'
                            : 'border-zinc-200 dark:border-white/10 bg-white/50 dark:bg-white/5 hover:border-blue-400/50 hover:-translate-y-2'
                            }`}
                    >
                        {selectedBusinessType?.id === bt.id && (
                            <div className="absolute inset-0 bg-gradient-to-br from-blue-600/10 via-transparent to-transparent pointer-events-none" />
                        )}

                        <div className="flex justify-between items-start mb-4">
                            <div className="w-14 h-14 bg-white/80 dark:bg-white/10 backdrop-blur-md rounded-2xl flex items-center justify-center text-3xl shadow-lg border border-white/50 dark:border-white/10 transition-transform group-hover:rotate-6 group-hover:scale-110">
                                {bt.icon}
                            </div>
                            {selectedBusinessType?.id === bt.id && (
                                <div className="p-2 bg-blue-600 rounded-full shadow-[0_0_15px_rgba(37,99,235,0.5)]">
                                    <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                                    </svg>
                                </div>
                            )}
                        </div>

                        <div className="space-y-3 flex-1 relative z-10">
                            <h3 className="font-black text-xl tracking-tight text-zinc-900 dark:text-white">{bt.name}</h3>
                            <p className="text-sm text-zinc-500 dark:text-zinc-400 font-medium leading-relaxed">{bt.description}</p>

                            <div className={`mt-4 pt-4 border-t space-y-2 ${selectedBusinessType?.id === bt.id ? 'border-blue-500/20' : 'border-zinc-200 dark:border-white/10'}`}>
                                <div className={`text-[10px] font-black uppercase tracking-widest mb-2 ${selectedBusinessType?.id === bt.id ? 'text-blue-600' : 'text-zinc-400'}`}>Includes:</div>
                                <div className="flex flex-wrap gap-1.5">
                                    {Object.entries(bt.features)
                                        .filter(([, enabled]) => enabled)
                                        .map(([feature]) => (
                                            <span key={feature} className={`px-2 py-1 text-[9px] font-bold uppercase tracking-wider rounded-full border ${selectedBusinessType?.id === bt.id ? 'bg-blue-600/10 text-blue-600 dark:text-blue-400 border-blue-600/10' : 'bg-zinc-100 dark:bg-white/10 text-zinc-500 dark:text-zinc-400 border-zinc-200 dark:border-white/5'}`}>
                                                {feature}
                                            </span>
                                        ))
                                    }
                                </div>
                                <div className="mt-3 text-[10px] text-zinc-500 dark:text-zinc-400">
                                    <strong>Theme:</strong> {bt.defaultTheme}
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            {selectedBusinessType && (
                <div className={`p-6 border rounded-2xl transition-all duration-300 ${!keepExisting
                    ? 'bg-red-500/5 border-red-500/30 shadow-[0_0_30px_-10px_rgba(239,68,68,0.2)]'
                    : 'bg-blue-500/5 border-blue-500/20'
                    }`}>
                    <label className="flex items-start gap-4 cursor-pointer group select-none">
                        <div className="relative flex items-center pt-1">
                            <input
                                type="checkbox"
                                checked={keepExisting}
                                onChange={(e) => setKeepExisting(e.target.checked)}
                                className="peer sr-only"
                            />
                            <div className={`w-6 h-6 rounded-md border-2 transition-all flex items-center justify-center ${keepExisting
                                ? 'bg-blue-600 border-blue-600'
                                : 'bg-transparent border-red-400 group-hover:border-red-500'
                                }`}>
                                <svg className={`w-4 h-4 text-white transition-all ${keepExisting ? 'opacity-100 scale-100' : 'opacity-0 scale-50'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                                </svg>
                            </div>
                        </div>
                        <div className="flex-1 space-y-1">
                            <div className="flex items-center gap-2">
                                <span className={`text-sm font-black uppercase tracking-wide transition-colors ${keepExisting ? 'text-zinc-900 dark:text-white' : 'text-red-600 dark:text-red-400'}`}>
                                    Keep Existing Content
                                </span>
                                {!keepExisting && (
                                    <span className="px-2 py-0.5 bg-red-100 dark:bg-red-500/20 text-red-700 dark:text-red-300 text-[10px] font-bold uppercase rounded animate-pulse">
                                        Danger
                                    </span>
                                )}
                            </div>
                            <p className="text-sm text-zinc-500 dark:text-zinc-400 font-medium">
                                {keepExisting
                                    ? "Safe Mode: We'll merge the new template data with your existing database content."
                                    : "Destructive Mode: This will WIPE your entire database and replace it with the template defaults."}
                            </p>
                        </div>
                    </label>
                </div>
            )}

            <div className="flex justify-between items-center pt-10 border-t border-zinc-200/50 dark:border-white/5">
                <button
                    onClick={onBack}
                    className="px-8 py-4 bg-white dark:bg-white/5 border border-zinc-200 dark:border-white/10 text-zinc-700 dark:text-zinc-300 rounded-[1.5rem] font-bold text-sm hover:bg-zinc-50 dark:hover:bg-white/10 transition-all flex items-center gap-2 active:scale-95"
                >
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" /></svg>
                    Go Back
                </button>
                <button
                    onClick={handleDeploy}
                    disabled={!selectedBusinessType || initializing}
                    className="px-12 py-4 bg-blue-600 text-white rounded-[1.5rem] font-black text-base uppercase tracking-widest hover:bg-blue-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-[0_10px_30px_-10px_rgba(37,99,235,0.5)] active:scale-95"
                >
                    {initializing ? (
                        <span className="flex items-center gap-3">
                            <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                            </svg>
                            Deploying...
                        </span>
                    ) : (
                        'Deploy & Continue →'
                    )}
                </button>
            </div>
        </div>
    );
}


const WelcomeStep = ({ onNext }: { onNext: () => void }) => (
    <div className="text-center space-y-10 max-w-3xl mx-auto py-12 animate-in fade-in zoom-in duration-1000">
        <div className="relative inline-block group">
            <div className="absolute inset-0 bg-blue-500/20 blur-[40px] rounded-full group-hover:bg-blue-500/30 transition-all duration-700" />
            <LizardLogo className="h-32 w-32 relative transform group-hover:scale-110 group-hover:rotate-3 transition-transform duration-700 ease-out" />
        </div>

        <div className="space-y-4">
            <h1 className="text-5xl md:text-6xl font-black tracking-tight text-zinc-900 dark:text-white">
                Forge Your <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-600 via-indigo-500 to-purple-600">Digital Realm</span>
            </h1>
            <p className="text-xl text-zinc-600 dark:text-zinc-400 font-medium leading-relaxed max-w-2xl mx-auto">
                Lizardware is a modern "edge-first" CMS. High performance, absolute security, and complete data sovereignty—now at your fingertips.
            </p>
        </div>

        <div className="pt-10 flex flex-col items-center gap-6">
            <button
                onClick={onNext}
                className="group relative px-12 py-5 bg-zinc-900 dark:bg-white text-white dark:text-black rounded-[2rem] font-black text-xl uppercase tracking-widest shadow-[0_20px_40px_-10px_rgba(0,0,0,0.3)] hover:shadow-[0_30px_60px_-15px_rgba(0,0,0,0.4)] transition-all hover:-translate-y-1 active:scale-95 overflow-hidden"
            >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 dark:via-black/5 to-transparent group-hover:translate-x-full transition-transform duration-1000 -translate-x-full" />
                Initiate Sequence
            </button>
            <p className="text-[10px] text-zinc-400 font-black uppercase tracking-[0.3em] flex items-center gap-2">
                <span className="w-1 h-1 rounded-full bg-zinc-400" />
                {!!process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY ? '6' : '7'} Steps to Deployment
                <span className="w-1 h-1 rounded-full bg-zinc-400" />
            </p>
        </div>
    </div>
);

// Template step removed - now unified with Business Type step

const SiteInfoStep = ({
    info,
    onChange,
    onNext,
    onBack
}: {
    info: { name: string; description: string; email: string };
    onChange: (info: { name: string; description: string; email: string }) => void;
    onNext: () => void;
    onBack: () => void;
}) => (
    <div className="max-w-2xl mx-auto space-y-10 py-4 animate-in fade-in slide-in-from-right-8 duration-700">
        <div className="text-center space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-500/10 border border-orange-500/20 text-orange-600 dark:text-orange-400 text-[10px] font-bold uppercase tracking-widest">
                <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse" />
                Branding Context
            </div>
            <h2 className="text-4xl font-black text-zinc-900 dark:text-white tracking-tight">Basic Site Info</h2>
            <p className="text-zinc-500 dark:text-zinc-400 text-lg font-medium">Let's define the primary identification for your new edge platform.</p>
        </div>

        <div className="space-y-8 bg-zinc-500/5 dark:bg-white/5 p-10 rounded-[3rem] border border-zinc-200 dark:border-white/10">
            <div className="space-y-2">
                <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-[0.2em] ml-2">Site Name</label>
                <div className="relative group">
                    <input
                        type="text"
                        value={info.name}
                        onChange={(e) => onChange({ ...info, name: e.target.value })}
                        className="w-full px-6 py-5 rounded-2xl bg-white dark:bg-zinc-900 border-2 border-zinc-200 dark:border-white/10 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all text-lg font-bold"
                        placeholder="e.g. My Awesome Business"
                    />
                </div>
                <p className="text-[10px] text-zinc-500 font-medium ml-2">The canonical title of your interface, used across all global headers.</p>
            </div>

            <div className="space-y-2">
                <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-[0.2em] ml-2">Tagline / Mission Statement</label>
                <textarea
                    rows={4}
                    value={info.description}
                    onChange={(e) => onChange({ ...info, description: e.target.value })}
                    className="w-full px-6 py-5 rounded-2xl bg-white dark:bg-zinc-900 border-2 border-zinc-200 dark:border-white/10 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all font-medium"
                    placeholder="Briefly describe what you do..."
                />
                <p className="text-[10px] text-zinc-500 font-medium ml-2">High-level meta description for global SEO and landing headers.</p>
            </div>
        </div>

        <div className="flex justify-between items-center pt-10 border-t border-zinc-200/50 dark:border-white/5">
            <button
                onClick={onBack}
                className="px-8 py-4 bg-white dark:bg-white/5 border border-zinc-200 dark:border-white/10 text-zinc-700 dark:text-zinc-300 rounded-[1.5rem] font-bold text-sm hover:bg-zinc-50 dark:hover:bg-white/10 transition-all flex items-center gap-2 active:scale-95"
            >
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" /></svg>
                Go Back
            </button>
            <button
                onClick={onNext}
                disabled={!info.name}
                className="px-12 py-4 bg-blue-600 text-white rounded-[1.5rem] font-black text-base uppercase tracking-widest hover:bg-blue-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-[0_10px_30px_-10px_rgba(37,99,235,0.5)] active:scale-95"
            >
                Confirm Branding →
            </button>
        </div>
    </div>
);



const ReviewStep = ({
    selectedBusinessType,
    siteInfo,
    onBack,
    onApply,
    isApplying,
    error
}: {
    selectedBusinessType: BusinessType | null;
    siteInfo: { name: string };
    onBack: () => void;
    onApply: () => void;
    isApplying: boolean;
    error: string;
}) => (
    <div className="max-w-2xl mx-auto space-y-10 py-4 animate-in fade-in slide-in-from-right-8 duration-700">
        <div className="text-center space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-green-500/10 border border-green-500/20 text-green-600 dark:text-green-400 text-[10px] font-bold uppercase tracking-widest">
                <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                Final Validation
            </div>
            <h2 className="text-4xl font-black text-zinc-900 dark:text-white tracking-tight">Review & Launch</h2>
            <p className="text-zinc-500 dark:text-zinc-400 text-lg font-medium">Verify your configuration parameters before final deployment.</p>
        </div>

        <div className="bg-white/80 dark:bg-zinc-900/50 backdrop-blur-xl rounded-[3rem] p-10 shadow-xl border border-zinc-200 dark:border-white/10 space-y-8 relative overflow-hidden">
            {/* Visual Background Flair */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 blur-[40px] rounded-full" />

            <div className="flex justify-between items-center border-b border-zinc-200 dark:border-white/5 pb-6">
                <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Business Type</span>
                <span className="font-bold flex items-center gap-3">
                    <span className="w-8 h-8 flex items-center justify-center bg-zinc-100 dark:bg-white/10 rounded-lg text-xl">{selectedBusinessType?.icon}</span>
                    {selectedBusinessType?.name}
                </span>
            </div>
            <div className="flex justify-between items-center border-b border-zinc-200 dark:border-white/5 pb-6">
                <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Site Identity</span>
                <span className="font-bold text-lg">{siteInfo.name}</span>
            </div>
            <div className="space-y-4">
                <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest block">Active Features</span>
                <div className="flex flex-wrap gap-2">
                    {selectedBusinessType &&
                        Object.entries(selectedBusinessType.features)
                            .filter(([, enabled]) => enabled)
                            .map(([key]) => (
                                <span key={key} className="px-4 py-1.5 bg-green-500/10 text-green-600 dark:text-green-400 text-[10px] font-black uppercase tracking-wider rounded-full border border-green-500/10">
                                    {key}
                                </span>
                            ))
                    }
                </div>
            </div>
        </div>

        {error && (
            <div className="max-w-xl mx-auto p-6 bg-red-500/5 dark:bg-red-950/20 border border-red-500/20 rounded-2xl animate-in zoom-in-95 duration-300">
                <div className="flex items-start gap-4 mb-4">
                    <div className="w-10 h-10 shrink-0 rounded-full bg-red-500 flex items-center justify-center text-white shadow-xl shadow-red-500/20">
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                        </svg>
                    </div>
                    <div className="flex-1 min-w-0">
                        <h3 className="text-sm font-black text-red-600 dark:text-red-400 uppercase tracking-widest mb-1">Configuration Error</h3>
                        <p className="text-xs text-zinc-600 dark:text-zinc-400 font-medium leading-relaxed">
                            {error}
                        </p>
                    </div>
                </div>

                <div className="space-y-3 bg-white dark:bg-black/20 p-4 rounded-xl border border-red-500/10">
                    <p className="text-[10px] font-black uppercase tracking-[0.15em] text-red-500/80">Likely Resolution</p>
                    <p className="text-[11px] text-zinc-500 dark:text-zinc-400 leading-relaxed">
                        This usually happens if the connection to the KV or D1 service is interrupted. Check your project environment variables in Cloudflare.
                    </p>
                    <div className="pt-2">
                        <Link
                            href="/docs/troubleshooting"
                            target="_blank"
                            className="inline-flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-red-600 dark:text-red-400 hover:opacity-80 transition-opacity"
                        >
                            Open Troubleshooting Guide
                            <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                            </svg>
                        </Link>
                    </div>
                </div>
            </div>
        )}


        <div className="flex flex-col sm:flex-row gap-4 pt-6">
            <button
                onClick={onBack}
                className="px-8 py-5 bg-white dark:bg-white/5 border border-zinc-200 dark:border-white/10 text-zinc-700 dark:text-zinc-300 rounded-[1.5rem] font-black text-sm uppercase tracking-widest hover:bg-zinc-50 dark:hover:bg-white/10 transition-all flex items-center justify-center gap-2 active:scale-95"
            >
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M15 19l-7-7 7-7" /></svg>
                Adjustment
            </button>
            <button
                onClick={onApply}
                disabled={isApplying}
                className="flex-1 px-8 py-5 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:scale-[1.02] active:scale-[0.98] text-white rounded-[1.5rem] font-black text-base uppercase tracking-[0.3em] shadow-[0_20px_40px_-10px_rgba(79,70,229,0.5)] transition-all disabled:opacity-50 relative overflow-hidden group"
            >
                <div className="absolute inset-0 bg-white/20 -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                {isApplying ? (
                    <span className="flex items-center justify-center gap-3">
                        <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" /></svg>
                        Applying Logic...
                    </span>
                ) : (
                    <span className="flex items-center justify-center gap-2">
                        Execute Launch Sequence 🚀
                    </span>
                )}
            </button>
        </div>
    </div>
);

const CompleteStep = ({ selectedBusinessType }: { selectedBusinessType: BusinessType | null }) => (
    <div className="text-center space-y-10 max-w-3xl mx-auto py-16 animate-in fade-in zoom-in-95 duration-1000">
        <div className="relative inline-block">
            <div className="absolute inset-0 bg-green-500/20 blur-[60px] rounded-full animate-pulse" />
            <div className="text-8xl relative animate-bounce">✨</div>
        </div>

        <div className="space-y-4">
            <h1 className="text-5xl md:text-6xl font-black text-green-600 dark:text-green-400 tracking-tight uppercase">
                Setup Complete
            </h1>
            <p className="text-xl text-zinc-600 dark:text-zinc-400 font-medium">
                Your <strong>{selectedBusinessType?.name}</strong> site has been successfully provisioned!
            </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-10">
            <Link
                href="/admin"
                className="px-6 py-5 bg-blue-600 text-white rounded-[2rem] font-black uppercase tracking-widest text-xs shadow-lg hover:shadow-xl transition-all hover:-translate-y-1 block text-center"
            >
                Control Center
            </Link>
            <Link
                href="/"
                target="_blank"
                className="px-6 py-5 bg-zinc-900 dark:bg-white text-white dark:text-black rounded-[2rem] font-black uppercase tracking-widest text-xs shadow-lg hover:shadow-xl transition-all hover:-translate-y-1 block text-center border border-transparent dark:border-white/10"
            >
                View Manifestation
            </Link>
            <Link
                href="/admin/system/config"
                className="px-6 py-5 bg-white dark:bg-white/5 border-2 border-zinc-200 dark:border-white/10 text-zinc-900 dark:text-white rounded-[2rem] font-black uppercase tracking-widest text-xs shadow-lg hover:shadow-xl transition-all hover:-translate-y-1 block text-center"
            >
                Architectural Settings
            </Link>
        </div>
    </div>
);

// --- Main Wizard Component ---


export default function SetupWizard() {
    const router = useRouter();
    const [isLocked, setIsLocked] = useState(false);
    const [loading, setLoading] = useState(true);

    const [step, setStep] = useState(0);
    const [selectedBusinessType, setSelectedBusinessType] = useState<BusinessType | null>(null);
    const [siteInfo, setSiteInfo] = useState({
        name: '',
        description: '',
        email: '',
    });
    const [isApplying, setIsApplying] = useState(false);
    const [error, setError] = useState('');

    const isClerkEnabled = !!process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY;
    const totalSteps = isClerkEnabled ? 6 : 7;
    // Map step indices to logical steps if needed, but direct index works if we handle the conditional render.
    // Flow without Clerk:
    // 0: Welcome
    // 1: Resources
    // 2: BusinessType (Init DB)
    // 3: Create Admin <-- New
    // 4: Site Info
    // 5: Review
    // 6: Complete

    const searchParams = useSearchParams();
    const templateParam = searchParams.get('template');
    const returnTo = searchParams.get('returnTo');

    useEffect(() => {
        Promise.all([
            fetch('/api/admin/setup-status').then(res => res.json() as Promise<{ setup_completed?: boolean }>),
            fetch('/api/config/site').then(res => res.json() as Promise<{ name?: string, description?: string }>)
        ])
            .then(([statusData, configData]) => {
                // Allow dev mode to always access setup for testing
                if (statusData.setup_completed && process.env.NODE_ENV !== 'development') {
                    setIsLocked(true);
                    router.push('/admin/system/advanced?setup_locked=true');
                } else {
                    // Auto-populate site info if it exists (e.g. from previous run or partial config)
                    setSiteInfo(prev => ({
                        ...prev,
                        name: configData.name || prev.name,
                        description: configData.description || prev.description
                    }));

                    // Handle Template/Business Type pre-selection
                    if (templateParam) {
                        const bt = getBusinessType(templateParam);
                        if (bt) {
                            setSelectedBusinessType(bt);
                            console.log('🎯 Pre-selecting Business Type:', bt.name);

                            // If we come from advanced settings, maybe jump to Step 2 (Selection) directly
                            // or Step 4 (Site Info) if selection is already done?
                            // For now, let's jump to Step 2 so they can see/confirm their selection.
                            if (returnTo) {
                                setStep(2);
                            }
                        }
                    }
                }
                setLoading(false);
            })
            .catch(() => setLoading(false));
    }, [router, templateParam, returnTo]);

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
                <div className="text-center">
                    <div className="text-2xl font-bold mb-2">Checking setup status...</div>
                    <div className="text-gray-500">Please wait</div>
                </div>
            </div>
        );
    }

    if (isLocked) {
        return null;
    }

    const handleNext = () => setStep((s) => s + 1);
    const handleBack = () => setStep((s) => s - 1);

    const applyBusinessType = async () => {
        if (!selectedBusinessType) return;
        setIsApplying(true);
        setError('');

        try {
            // 1. Update site config (including legacy template_id for D1 sync)
            await fetch('/api/config/site', {
                method: 'PUT',
                body: JSON.stringify({
                    name: siteInfo.name,
                    description: siteInfo.description,
                    business_type: selectedBusinessType.id,
                    template_id: selectedBusinessType.id, // For D1 compatibility
                    setup_completed: true,
                }),
            }).then(res => { if (!res.ok) throw new Error('Failed to update site config') });

            // 2. Set feature flags from business type
            await fetch('/api/admin/features', {
                method: 'POST',
                body: JSON.stringify(selectedBusinessType.features),
            }).then(res => { if (!res.ok) throw new Error('Failed to update features') });

            // 3. Apply Default Theme
            const themePreset = THEME_PRESETS.find(t => t.id === selectedBusinessType.defaultTheme);
            if (themePreset) {
                console.log('🎨 Applying theme preset:', themePreset.name);
                await fetch('/api/config/theme', {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        colors: themePreset.colors,
                        typography: themePreset.typography
                    }),
                }).then(res => { if (!res.ok) console.warn('Failed to apply theme preset, continuing...') });
            }

            handleNext(); // Move to completion
        } catch (err) {
            console.error(err);
            setError(`Failed to apply settings: ${err instanceof Error ? err.message : String(err)}`);
        } finally {
            setIsApplying(false);
        }
    };

    return (
        <div className="min-h-screen bg-slate-50 dark:bg-[#050510] relative overflow-hidden flex flex-col items-center justify-center p-4 md:p-8">
            {/* Aurora Background Elements */}
            <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none -z-10">
                <div className="absolute -top-[10%] -left-[10%] w-[40%] h-[40%] bg-blue-500/10 blur-[120px] rounded-full animate-pulse" />
                <div className="absolute top-[20%] -right-[10%] w-[35%] h-[35%] bg-purple-500/10 blur-[120px] rounded-full animate-pulse [animation-delay:2s]" />
                <div className="absolute -bottom-[10%] left-[20%] w-[30%] h-[30%] bg-indigo-500/10 blur-[120px] rounded-full animate-pulse [animation-delay:4s]" />
            </div>

            <div className="w-full max-w-5xl backdrop-blur-xl bg-white/80 dark:bg-slate-900/40 border border-zinc-200/50 dark:border-white/10 rounded-[2.5rem] shadow-[0_32px_64px_-16px_rgba(0,0,0,0.1)] dark:shadow-[0_32px_64px_-16px_rgba(0,0,0,0.5)] p-6 md:p-12 flex flex-col relative overflow-hidden transition-all duration-500">
                {/* Visual Accent */}
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-blue-500/50 to-transparent opacity-50" />

                {/* Progress Bar Container */}
                <div className="w-full mb-12">
                    <div className="flex justify-between items-center mb-3">
                        <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-400 dark:text-zinc-500">
                            Setup Progress
                        </span>
                        <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-blue-600 dark:text-blue-400">
                            Step {Math.min(step + 1, totalSteps)} of {totalSteps}
                        </span>
                    </div>
                    <div className="w-full bg-zinc-100 dark:bg-white/5 h-2 rounded-full overflow-hidden relative">
                        {/* Shimmer Effect */}
                        <div
                            className="absolute top-0 left-0 h-full bg-gradient-to-r from-blue-600 via-indigo-500 to-purple-600 transition-all duration-700 ease-out shadow-[0_0_15px_rgba(37,99,235,0.5)] rounded-full"
                            style={{ width: `${(((step + 1) > totalSteps ? totalSteps : (step + 1)) / totalSteps) * 100}%` }}
                        >
                            <div className="absolute inset-0 bg-[linear-gradient(110deg,transparent_25%,rgba(255,255,255,0.2)_50%,transparent_75%)] bg-[length:200%_100%] animate-[shimmer_2s_infinite]" />
                        </div>
                    </div>
                </div>

                <div className="flex-1 flex flex-col">
                    {step === 0 && <WelcomeStep onNext={handleNext} />}
                    {step === 1 && <ResourcePrerequisitesStep onNext={handleNext} />}
                    {step === 2 && (
                        <BusinessTypeStep
                            selectedBusinessType={selectedBusinessType}
                            onSelect={setSelectedBusinessType}
                            onNext={handleNext}
                            onBack={handleBack}
                        />
                    )}

                    {/* Conditional Step: Create Admin (if Clerk disabled) */}
                    {!isClerkEnabled && step === 3 && (
                        <CreateAdminStep onNext={handleNext} />
                    )}

                    {/* Shift steps if Clerk is disabled */}
                    {(step === (isClerkEnabled ? 3 : 4)) && (
                        <SiteInfoStep
                            info={siteInfo}
                            onChange={setSiteInfo}
                            onNext={handleNext}
                            onBack={handleBack}
                        />
                    )}
                    {(step === (isClerkEnabled ? 4 : 5)) && (
                        <ReviewStep
                            selectedBusinessType={selectedBusinessType}
                            siteInfo={siteInfo}
                            onBack={handleBack}
                            onApply={applyBusinessType}
                            isApplying={isApplying}
                            error={error}
                        />
                    )}
                    {(step === (isClerkEnabled ? 5 : 6)) && <CompleteStep selectedBusinessType={selectedBusinessType} />}
                </div>
            </div>

            {/* Context Help for Devs */}
            {process.env.NODE_ENV === 'development' && (
                <div className="mt-8 flex items-center gap-2 px-4 py-2 rounded-full bg-white/50 dark:bg-white/5 backdrop-blur-sm border border-zinc-200/50 dark:border-white/5 text-[10px] text-zinc-400 dark:text-zinc-500">
                    <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse" />
                    Dev Mode: Files are being saved to <code className="bg-transparent font-mono opacity-80">src/data/*.json</code>
                </div>
            )}

            {/* Footer Links */}
            <div className="mt-6 flex items-center justify-center gap-6">
                <Link
                    href="/admin"
                    className="text-[10px] uppercase font-bold tracking-widest text-zinc-400 dark:text-zinc-600 hover:text-blue-600 dark:hover:text-blue-400 transition-colors flex items-center gap-2 opacity-60 hover:opacity-100"
                >
                    <span>Already Configured?</span>
                    <span className="border-b border-current pb-0.5">Return to Admin</span>
                </Link>

                <Link
                    href="/docs/troubleshooting"
                    target="_blank"
                    className="text-[10px] uppercase font-bold tracking-widest text-orange-400 dark:text-orange-600 hover:text-orange-600 dark:hover:text-orange-400 transition-colors flex items-center gap-2 opacity-60 hover:opacity-100"
                >
                    <span>Stuck?</span>
                    <span className="border-b border-current pb-0.5 text-orange-500">Troubleshooting Guide</span>
                </Link>
            </div>

            <style jsx global>{`
                @keyframes shimmer {
                    from { background-position: 200% 0; }
                    to { background-position: -200% 0; }
                }
            `}</style>
        </div>
    );
}
