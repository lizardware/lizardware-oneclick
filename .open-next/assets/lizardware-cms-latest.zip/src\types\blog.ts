export type PostStatus = 'draft' | 'published';

export interface PostMeta {
    slug: string;
    title: string;
    description?: string; // Often used as excerpt
    excerpt?: string;
    date: string;
    status: PostStatus;
    author?: string;
    author_id?: string;
    tags?: string[];
    featured_image_id?: string;
    category_id?: string;
    scheduled_date?: string;
    view_count?: number;
    updated_at?: string;
    created_at?: string;

    // NEW: Navigation Sync fields
    show_in_nav?: boolean;           // Whether to show in navigation
    nav_label?: string;              // Optional custom nav label
    nav_parent?: string;             // ID of parent nav item
    nav_order?: number;              // Order within the parent
}

export interface Post extends PostMeta {
    content: string;
}
