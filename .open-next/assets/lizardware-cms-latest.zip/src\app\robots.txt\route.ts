import { NextResponse } from 'next/server';
import { getD1Database } from '@/lib/cloudflare';

export const dynamic = 'force-dynamic';

export async function GET() {
    const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://lizardware.dev';

    try {
        const db = await getD1Database();
        if (!db) {
            // Fallback if database not available
            return new NextResponse(`User-agent: *
Allow: /
Disallow: /admin/
Disallow: /api/
Disallow: /setup/

Sitemap: ${baseUrl}/sitemap.xml`, {
                headers: { 'Content-Type': 'text/plain' }
            });
        }

        const settings = await db.prepare('SELECT robots_txt FROM seo_global_settings WHERE id = 1').first() as { robots_txt: string } | null;

        let content = settings?.robots_txt;

        // Convert escaped newlines to actual newlines
        if (content) {
            content = content.replace(/\\n/g, '\n');
        }

        // Fallback if empty
        if (!content) {
            content = `User-agent: *
Allow: /
Disallow: /admin/
Disallow: /api/
Disallow: /setup/

Sitemap: ${baseUrl}/sitemap.xml`;
        }

        // Handle placeholders if they exist in the DB
        content = content.replace(/{{site_url}}/g, baseUrl);

        return new NextResponse(content, {
            headers: {
                'Content-Type': 'text/plain',
                'Cache-Control': 'public, s-maxage=86400, stale-while-revalidate=43200'
            },
        });
    } catch (error) {
        console.error('Robots.txt generation error:', error);
        return new NextResponse(`User-agent: *\nAllow: /`, {
            headers: { 'Content-Type': 'text/plain' }
        });
    }
}
