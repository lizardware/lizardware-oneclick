import { NextResponse } from 'next/server';
import { deletePage, upsertPage, getPageBySlug } from '@/lib/pages';
import { Page } from '@/types/page';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
    try {
        const { action, slugs, status } = await request.json() as {
            action: 'delete' | 'status',
            slugs: string[],
            status?: 'published' | 'draft'
        };

        if (!slugs || !Array.isArray(slugs) || slugs.length === 0) {
            return NextResponse.json({ error: 'No slugs provided' }, { status: 400 });
        }

        if (action === 'delete') {
            await Promise.all(slugs.map(slug => deletePage(slug)));
        } else if (action === 'status' && status) {
            await Promise.all(slugs.map(async (slug) => {
                const page = await getPageBySlug(slug);
                if (page) {
                    page.status = status;
                    await upsertPage(page);
                }
            }));
        } else {
            return NextResponse.json({ error: 'Invalid action or missing parameters' }, { status: 400 });
        }

        return NextResponse.json({ success: true, count: slugs.length });
    } catch (error) {
        console.error('Bulk operation failed:', error);
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
    }
}
