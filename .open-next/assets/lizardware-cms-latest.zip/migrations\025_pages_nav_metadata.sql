-- Add navigation control columns to pages table
ALTER TABLE pages ADD COLUMN show_in_nav INTEGER DEFAULT 0;
ALTER TABLE pages ADD COLUMN nav_label TEXT;
ALTER TABLE pages ADD COLUMN nav_parent TEXT;
ALTER TABLE pages ADD COLUMN nav_order INTEGER DEFAULT 0;
