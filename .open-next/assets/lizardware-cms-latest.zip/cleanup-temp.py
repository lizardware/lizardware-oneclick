import os
import shutil

target = r'.release-temp'
if os.path.exists(target):
    try:
        shutil.rmtree(target, ignore_errors=True)
        print(f"✅ Cleaned up {target}")
    except Exception as e:
        print(f"❌ Error: {e}")
        # Try renaming to something shorter
        try:
            os.rename(target, '.rt_old')
            print("⚠️ Renamed to .rt_old - delete manually or reboot")
        except:
            print("⚠️ Could not clean - try rebooting Windows")
else:
    print("✅ No cleanup needed")
