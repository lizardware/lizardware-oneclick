'use client';

import React, { useState, useEffect } from 'react';
import { Page } from '@/types/page';
import { StandardPageLayout, MinimalPageLayout, SidebarRightLayout, FullWidthLayout } from './layouts/LayoutLibrary';
import BlockRenderer from './BlockRenderer';

interface LivePreviewWrapperProps {
    initialPage: Page;
    siteConfig: any;
}

export default function LivePreviewWrapper({ initialPage, siteConfig }: LivePreviewWrapperProps) {
    const [page, setPage] = useState<Page>(initialPage);

    useEffect(() => {
        // Only run in iframe
        if (typeof window !== 'undefined' && window.self === window.top) return;

        const handleMessage = (event: MessageEvent) => {
            if (event.data?.type === 'UPDATE_CONTENT') {
                const { title, content, description, layout_id, metadata_json } = event.data.payload;

                setPage(prev => ({
                    ...prev,
                    title: title || prev.title,
                    content: content || prev.content,
                    description: description !== undefined ? description : prev.description,
                    layout_id: layout_id || prev.layout_id,
                    metadata_json: metadata_json || prev.metadata_json
                }));

                // Update browser tag title if in preview
                if (title) {
                    const siteName = siteConfig?.name || 'Lizardware';
                    document.title = `${title} | ${siteName}`;
                }
            }
        };

        window.addEventListener('message', handleMessage);
        return () => window.removeEventListener('message', handleMessage);
    }, [siteConfig]);

    const layoutId = page.layout_id || 'standard';
    const displayDate = page.updated_at ? new Date(page.updated_at).toLocaleDateString() : 'Recently';

    // Blocks Layout
    if (layoutId === 'blocks') {
        return <BlockRenderer content={page.metadata_json || page.content} />;
    }

    // Minimal Layout
    if (layoutId === 'minimal') {
        return (
            <MinimalPageLayout
                title={page.title}
                description={page.description}
                content={page.content}
                slug={page.slug}
            />
        );
    }

    // Sidebar Right Layout
    if (layoutId === 'sidebar_right') {
        return (
            <SidebarRightLayout
                title={page.title}
                description={page.description}
                content={page.content}
                updatedAt={displayDate}
                slug={page.slug}
            />
        );
    }

    // Full Width Layout
    if (layoutId === 'full_width') {
        return (
            <FullWidthLayout
                title={page.title}
                description={page.description}
                content={page.content}
                updatedAt={displayDate}
                slug={page.slug}
            />
        );
    }

    // Default to Standard Layout
    return (
        <StandardPageLayout
            title={page.title}
            description={page.description}
            content={page.content}
            updatedAt={displayDate}
            slug={page.slug}
        />
    );
}
