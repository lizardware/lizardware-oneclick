# Lizardware CMS - Starter Template

**Modern, Git-backed content management for the edge.**

This is a clean, white-label starter template for deploying your own instance of [Lizardware CMS](https://lizardware.dev). It is optimized for Cloudflare's global edge network, providing unmatched speed and security.

---

## ✨ Key Features

- **🚀 Template System:** Choose from industry-specific presets (business, blog, service, etc.) during setup.
- **✍️ Visual Editing:** WYSIWYG editor for blogs and pages, powered by Tiptap.
- **🎨 Theme Transformer:** customize your specific branding, colors, and fonts via the admin dashboard.
- **⚡ Edge Performance:** Runs on Cloudflare Workers (sub-100ms global latency).
- **🔒 Git-Backed:** Your content is version-controlled in your own GitHub repository.

---

## 🚀 Quick Start (Deployment)

### 1. Account Setup
You need a [GitHub](https://github.com) account and a [Cloudflare](https://www.cloudflare.com) account (Free tier works perfectly).

### 2. Fork & Deploy
The recommended way to deploy is via Cloudflare Workers (connected to GitHub).

1. **Fork** this repository to your GitHub account.
2. Log in to the Cloudflare Dashboard and go to **Workers & Pages**.
3. Create a **D1 Database** (named `my-cms-db`) and **KV Namespace** (named `my-cms-config`).
4. **CRITICAL:** Go to **Settings → Variables and Secrets** in your Cloudflare Project and add:
   - `WRANGLER_KV_ID`: Your actual KV Namespace ID
   - `WRANGLER_D1_ID`: Your actual D1 Database ID
5. Connect your repo and deploy!

> **Note:** The first deployment will launch in **Setup Mode**. Visit your site URL to run the Setup Wizard.

---

## 💻 Local Development

1. **Clone your fork:**
   ```bash
   git clone https://github.com/YOUR_USERNAME/lizardware-cms.git
   cd lizardware-cms
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Run development server:**
   ```bash
   npm run dev
   ```
   - Opens at `http://localhost:3000`.
   - Uses local filesystem (no D1/KV required) for quick UI checks.

4. **Run full preview (Simulates Cloudflare):**
   ```bash
   npm run preview
   ```
   - Builds the application and runs with local D1/KV emulation.
   - Required for testing the Admin Dashboard and database features.

---

## 📚 Documentation

For full guides on configuration, theming, and advanced usage, visit the official documentation:

👉 **[Lizardware CMS Documentation](https://lizardware.dev/docs)**

---

## 📄 License

This project is licensed under the MIT License. You are free to use, modify, and distribute it for personal or commercial projects.
