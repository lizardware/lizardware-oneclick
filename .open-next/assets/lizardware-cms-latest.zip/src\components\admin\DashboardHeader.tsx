"use client";

import React from "react";
import Link from "next/link";
import { Zap, FileText, Globe, PenLine, Database, Image as ImageIcon } from "lucide-react";
import { VERSION } from "@/lib/version";

/**
 * DashboardBanner
 * The primary identifier card for the Admin Dashboard.
 */
export function DashboardBanner() {
    const [siteName, setSiteName] = React.useState('Lizardware');

    React.useEffect(() => {
        fetch('/api/config/site')
            .then(res => res.json())
            .then((data: any) => {
                if (data.name) setSiteName(data.name);
            })
            .catch(err => console.error('Failed to load site config:', err));
    }, []);

    return (
        <div className="flex-1 flex items-center justify-between p-6 bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-[2rem] shadow-xl relative overflow-hidden group">
            <div className="relative z-10 flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center text-3xl shadow-inner group-hover:scale-110 transition-transform">
                    🦎
                </div>
                <div className="space-y-1">
                    <div className="flex items-center gap-2">
                        <h1 className="text-2xl font-black tracking-tight text-page-title leading-tight">
                            {siteName} <span className="text-primary">Command</span>
                        </h1>
                        <span className="px-2 py-0.5 bg-primary/10 text-primary rounded-full text-[9px] font-black uppercase tracking-widest animate-pulse">
                            v{VERSION}
                        </span>
                        <div className="flex items-center gap-1.5 px-2 py-0.5 bg-zinc-900 dark:bg-zinc-800 text-white rounded-md text-[8px] font-black uppercase tracking-wider border border-white/10 shadow-sm ml-1">
                            <span className="w-1 h-1 rounded-full bg-red-500 animate-pulse"></span>
                            Admin Access Only
                        </div>
                    </div>
                    <div className="flex items-center gap-2 text-[10px] text-gray-400 font-bold uppercase tracking-widest">
                        <div className="relative flex items-center justify-center w-2 h-2">
                            <span className="absolute inline-flex h-full w-full rounded-full opacity-75 animate-ping bg-emerald-500"></span>
                            <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
                        </div>
                        Edge Core Synchronized • {new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                    </div>
                </div>
            </div>

            {/* Decorative Elements */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full -mr-32 -mt-32 blur-3xl opacity-50 transition-opacity group-hover:opacity-100"></div>

            <div className="hidden md:flex items-center gap-3 relative z-10">
                <div className="h-10 w-[1px] bg-gray-100 dark:bg-zinc-800 mx-2" />
                <div className="text-right">
                    <div className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-0.5">Global Status</div>
                    <div className="text-[11px] font-bold text-emerald-500 uppercase tracking-tight">System Operational</div>
                </div>
            </div>
        </div>
    );
}

/**
 * QuickLinkRow
 * A horizontal set of important navigation links used in dashboard headers.
 */
export function QuickLinkRow() {
    return (
        <div className="flex flex-row md:flex-col justify-center items-center md:items-start px-6 py-4 bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-[2rem] shadow-xl relative overflow-hidden group min-w-[150px] gap-4 md:gap-0">
            <div className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-[0.2em] text-primary shrink-0 transition-transform group-hover:translate-x-0.5 md:mb-2.5">
                <Zap size={14} className="animate-pulse" />
                Quick Actions
            </div>

            {/* Divider: Vertical on mobile row, Hidden on desktop stack (replaced by border) */}
            <div className="md:hidden h-6 w-px bg-gray-100 dark:bg-zinc-800" />

            <nav className="flex flex-row md:flex-col gap-4 md:gap-1.5 text-[9px] font-black uppercase tracking-tight md:border-l border-gray-100 dark:border-zinc-800 md:pl-3 overflow-x-auto md:overflow-visible no-scrollbar">
                <Link href="/admin/content/blog" className="text-page-text hover:text-primary transition-all md:hover:translate-x-1 whitespace-nowrap">Write Post</Link>
                <Link href="/admin/content/pages" className="text-page-text hover:text-primary transition-all md:hover:translate-x-1 whitespace-nowrap">Manage Pages</Link>
                <Link href="/admin/design/theme" className="text-page-text hover:text-primary transition-all md:hover:translate-x-1 whitespace-nowrap">Theme Transformer</Link>
            </nav>

            {/* Subtle Background Glow */}
            <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-primary/5 rounded-full blur-2xl group-hover:bg-primary/10 transition-all"></div>
        </div>
    );
}

import { QuickStatsNav, StatItem } from "./QuickStatsNav";

// ... previous code ...

interface MediaCountsRowProps {
    pages: number;
    posts: number;
    media: number;
}

/**
 * MediaCountsRow
 * Displays counts for various content types using the standardized QuickStatsNav.
 */
export function MediaCountsRow({ pages, posts, media }: MediaCountsRowProps) {
    const stats: StatItem[] = [
        { label: 'Pages', value: pages, icon: <FileText />, color: 'text-blue-500', bg: 'bg-blue-500/10' },
        { label: 'Feed', value: posts, icon: <PenLine />, color: 'text-purple-500', bg: 'bg-purple-500/10' },
        { label: 'Assets', value: media, icon: <ImageIcon />, color: 'text-amber-500', bg: 'bg-amber-500/10' },
    ];

    return (
        <QuickStatsNav
            title="Data Matrix"
            titleIcon={<Database size={14} className="animate-pulse" />}
            titleColor="text-emerald-500"
            stats={stats}
            variant="responsive"
        />
    );
}

