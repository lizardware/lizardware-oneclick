import { Post } from "@/lib/blog";
import Link from "next/link";
import Image from "next/image";
import authorsData from "@/data/authors.json";

interface BlogCardProps {
    post: Omit<Post, 'content'>;
    imageUrl?: string;
}

export default function BlogCard({ post, imageUrl }: BlogCardProps) {
    // Try to find author in JSON fallback
    const author = post.author_id
        ? authorsData.authors.find(a => a.id === post.author_id)
        : undefined;

    return (
        <div
            className="group flex flex-col bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-3xl overflow-hidden shadow-sm hover:shadow-xl hover:border-primary/20 transition-all duration-500"
        >
            {/* Card Image */}
            <Link href={`/blog/${post.slug}`} className="relative aspect-[16/9] overflow-hidden block">
                {imageUrl ? (
                    <Image
                        src={imageUrl}
                        alt={post.title}
                        fill
                        className="object-cover group-hover:scale-110 transition-transform duration-700"
                    />
                ) : (
                    <div className="w-full h-full bg-gradient-to-br from-zinc-100 to-zinc-50 dark:from-zinc-800 dark:to-zinc-900 flex items-center justify-center">
                        <div className="w-12 h-12 rounded-2xl border-2 border-dashed border-zinc-200 dark:border-zinc-700 flex items-center justify-center text-zinc-300 dark:text-zinc-600 font-black">LZ</div>
                    </div>
                )}
                <div className="absolute inset-0 bg-black/5 group-hover:bg-black/0 transition-colors" />

                {/* Category Badge on Image */}
                {(post.category_id || post.tags?.[0]) && (
                    <div className="absolute top-4 left-4">
                        <span className="px-3 py-1 bg-white/90 dark:bg-zinc-900/90 backdrop-blur-md rounded-full text-[9px] font-black uppercase tracking-widest text-primary shadow-sm">
                            {post.category_id ? "Transmission" : post.tags?.[0]}
                        </span>
                    </div>
                )}
            </Link>

            <div className="flex flex-col p-6 flex-grow">
                {/* Post Meta */}
                <div className="flex flex-wrap items-center gap-3 text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-4">
                    {post.date && (
                        <span className="flex items-center gap-1.5">
                            <span className="w-1 h-1 rounded-full bg-primary" />
                            {new Date(post.date).toLocaleDateString('en-US', {
                                year: 'numeric',
                                month: 'short',
                                day: 'numeric'
                            })}
                        </span>
                    )}
                    <span className="flex items-center gap-1.5">
                        <span className="w-1 h-1 rounded-full bg-zinc-300" />
                        📈 {post.view_count || 0}
                    </span>
                </div>

                {/* Post Title */}
                <Link href={`/blog/${post.slug}`}>
                    <h2 className="text-xl font-black text-page-title hover:text-primary transition-colors mb-3 leading-tight line-clamp-2">
                        {post.title}
                    </h2>
                </Link>

                {/* Post Description */}
                <p className="text-sm text-page-text/70 leading-relaxed line-clamp-2 mb-6 flex-grow">
                    {post.description}
                </p>

                {/* Footer: Author & Action */}
                <div className="flex items-center justify-between mt-auto pt-6 border-t border-gray-50 dark:border-zinc-800/50">
                    <div className="flex items-center gap-2">
                        {author ? (
                            <>
                                {author.avatar && (
                                    <div className="relative w-6 h-6 rounded-full overflow-hidden border border-gray-100 dark:border-zinc-800">
                                        <Image
                                            src={author.avatar}
                                            alt={author.name}
                                            fill
                                            className="object-cover"
                                        />
                                    </div>
                                )}
                                <span className="text-[10px] font-bold text-page-text/60 uppercase tracking-tighter">
                                    {author.name}
                                </span>
                            </>
                        ) : (
                            <span className="text-[10px] font-bold text-page-text/40 uppercase tracking-tighter">
                                Lizardware Team
                            </span>
                        )}
                    </div>

                    <Link
                        href={`/blog/${post.slug}`}
                        className="flex items-center gap-1 text-[10px] font-black uppercase tracking-widest text-primary group/link"
                    >
                        Open
                        <span className="transform group-hover/link:translate-x-1 transition-transform">→</span>
                    </Link>
                </div>
            </div>
        </div>
    );
}
