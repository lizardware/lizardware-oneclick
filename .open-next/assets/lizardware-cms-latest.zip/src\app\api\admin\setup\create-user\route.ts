import { NextRequest, NextResponse } from 'next/server';
import { getD1Database } from '@/lib/cloudflare';
import { hashPassword, createLocalUser } from '@/lib/auth-local';

export async function POST(request: NextRequest) {
    try {
        const { username, password } = await request.json() as any;

        if (!username || !password || password.length < 8) {
            return NextResponse.json({ error: 'Invalid input' }, { status: 400 });
        }

        const db = await getD1Database();
        if (!db) {
            return NextResponse.json({ error: 'Database unavailable' }, { status: 503 });
        }

        // Check if user already exists? 
        // For setup, we might assume it's fresh, but safety first.
        const existing = await db.prepare('SELECT id FROM users WHERE username = ?').bind(username).first();
        if (existing) {
            return NextResponse.json({ error: 'Username already taken' }, { status: 409 });
        }

        const hashedPassword = await hashPassword(password);
        await createLocalUser(db, username, hashedPassword);

        return NextResponse.json({ success: true });
    } catch (error) {
        console.error('Create user error:', error);
        return NextResponse.json({ error: (error as Error).message }, { status: 500 });
    }
}
