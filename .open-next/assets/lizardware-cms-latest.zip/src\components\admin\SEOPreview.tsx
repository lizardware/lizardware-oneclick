"use client";

import { Search, Globe, ChevronRight } from "lucide-react";

interface SEOPreviewProps {
    title: string;
    description: string;
    slug: string;
    baseUrl?: string;
    featuredImage?: string;
    author?: string;
    date?: string;
}

export default function SEOPreview({
    title,
    description,
    slug,
    baseUrl = "lizardware.dev",
    featuredImage,
    author,
    date
}: SEOPreviewProps) {
    const displayUrl = `${baseUrl}/blog/${slug || "your-post-slug"}`;
    const displayTitle = title || "Transmission Title Here";
    const displayDescription = description || "Search engines will display your metadata here. Make it compelling to increase the signal-to-noise ratio.";

    return (
        <div className="space-y-6">
            <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 mb-4 flex items-center gap-2">
                <Search size={12} className="text-purple-500" />
                Signal Simulation (SEO Preview)
            </h3>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Google Search Preview */}
                <div className="space-y-3">
                    <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-2">
                        <Globe size={10} /> Search Result
                    </div>
                    <div className="bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-2xl p-6 shadow-sm">
                        <div className="space-y-1.5">
                            <div className="flex items-center gap-2 text-[#202124] dark:text-[#bdc1c6] text-sm truncate">
                                <span className="text-[11px] opacity-70">https://{baseUrl}</span>
                                <ChevronRight size={10} className="opacity-40" />
                                <span className="text-[11px] opacity-70">blog</span>
                                <ChevronRight size={10} className="opacity-40" />
                                <span className="text-[11px] opacity-70 truncate">{slug || "..."}</span>
                            </div>
                            <h4 className="text-[#1a0dab] dark:text-[#8ab4f8] text-xl font-medium hover:underline cursor-pointer leading-tight">
                                {displayTitle}
                            </h4>
                            <p className="text-[#4d5156] dark:text-[#bdc1c6] text-sm leading-relaxed line-clamp-2">
                                {displayDescription}
                            </p>
                        </div>
                    </div>
                </div>

                {/* Social Card Preview */}
                <div className="space-y-3">
                    <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-2">
                        <Search size={10} /> Social Card
                    </div>
                    <div className="bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-3xl overflow-hidden shadow-xl border-b-4 border-b-purple-500">
                        <div className="aspect-video bg-gray-100 dark:bg-zinc-800 relative overflow-hidden group">
                            {featuredImage ? (
                                <img src={featuredImage} alt="" className="w-full h-full object-cover" />
                            ) : (
                                <div className="w-full h-full flex flex-col items-center justify-center text-gray-300 gap-2">
                                    <div className="w-12 h-12 rounded-2xl border-2 border-dashed border-gray-200 dark:border-zinc-700 flex items-center justify-center font-black">LZ</div>
                                    <span className="text-[10px] font-bold uppercase tracking-[0.2em] opacity-40">Missing Frame</span>
                                </div>
                            )}
                            <div className="absolute top-4 left-4 flex items-center gap-2">
                                <div className="px-2 py-1 bg-black/60 backdrop-blur-md rounded text-[9px] font-black text-white uppercase tracking-widest border border-white/10">
                                    {baseUrl}
                                </div>
                            </div>
                        </div>
                        <div className="p-5 space-y-2 bg-gradient-to-br from-white to-gray-50/50 dark:from-zinc-900 dark:to-zinc-900/50">
                            <p className="text-[9px] font-black uppercase tracking-[0.2em] text-purple-500">{baseUrl}</p>
                            <h4 className="text-sm md:text-base font-black text-page-title leading-tight line-clamp-2">
                                {displayTitle}
                            </h4>
                            <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-2 leading-relaxed">
                                {displayDescription}
                            </p>

                            {author && (
                                <div className="pt-2 flex items-center gap-2 border-t border-gray-100 dark:border-zinc-800 mt-2">
                                    <div className="w-4 h-4 rounded-full bg-purple-500/20 text-purple-500 flex items-center justify-center text-[8px] font-black">
                                        {author.charAt(0)}
                                    </div>
                                    <span className="text-[9px] font-bold text-gray-400 uppercase tracking-tighter">Broadcast by {author}</span>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
