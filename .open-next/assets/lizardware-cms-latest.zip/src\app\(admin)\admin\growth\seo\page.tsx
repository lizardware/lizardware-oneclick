'use client';

import { Suspense, useEffect, useState } from 'react';
import Link from 'next/link';
import { FileSearch, Settings, ExternalLink, CheckCircle, AlertCircle, Sparkles, TrendingUp, Zap, Search as SearchIcon, ArrowLeft } from 'lucide-react';
import { useSearchParams } from 'next/navigation';
import { Breadcrumbs } from "@/components/admin/Breadcrumbs";
import { AdminLoadingState } from "@/components/admin/AdminLoadingState";
import { AdminHeader } from '@/components/admin/AdminHeader';

function SEODashboardContent() {
    const searchParams = useSearchParams();
    const wizardComplete = searchParams?.get('wizardComplete');

    const [redirectCount, setRedirectCount] = useState(0);
    const [seoHealth, setSeoHealth] = useState<number | null>(null);
    const [wizardCompleted, setWizardCompleted] = useState(false);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        Promise.all([
            fetch('/api/admin/seo/redirects').then(res => res.json()).then((data: any) => setRedirectCount(data.redirects?.length || 0)).catch(() => 0),
            fetch('/api/admin/seo/wizard').then(res => res.json()).then((data: any) => {
                setWizardCompleted(data.settings?.setup_wizard_completed === 1);
                // Calculate a mock health score for now (will be real in next phase)
                setSeoHealth(data.settings?.setup_wizard_completed ? 75 : 45);
            }).catch(() => { })
        ]).finally(() => setLoading(false));
    }, []);

    const healthColor = seoHealth === null ? 'gray' : seoHealth >= 80 ? 'green' : seoHealth >= 60 ? 'yellow' : 'red';
    const healthGrade = seoHealth === null ? '?' : seoHealth >= 90 ? 'Excellent' : seoHealth >= 70 ? 'Good' : seoHealth >= 50 ? 'Needs Work' : 'Poor';

    if (loading) return (
        <div className="max-w-7xl mx-auto px-6 pt-4 pb-12 space-y-8">
            <AdminLoadingState message="Scanning search parameters..." />
        </div>
    );

    return (
        <div className="space-y-6 pb-20">
            <AdminHeader
                title={<>SEO <span className="text-green-500">Toolkit</span></>}
                description="Optimize your site for search engines and organic traffic."
                breadcrumbs={[
                    { label: 'Admin', href: '/admin' },
                    { label: 'Growth', href: '/admin/growth' },
                    { label: 'SEO' }
                ]}
                badge={
                    <div className="px-3 py-1.5 bg-green-500/10 border border-green-500/20 rounded-lg text-[10px] font-bold uppercase tracking-widest text-green-600 dark:text-green-400 flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
                        Operational
                    </div>
                }
                actions={
                    <Link
                        href="/admin/growth"
                        className="px-4 py-2 bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 rounded-xl text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
                    >
                        <ArrowLeft size={12} />
                        Back
                    </Link>
                }
            />

            {/* Special Banners Section */}
            {
                (wizardComplete || (!wizardCompleted && !loading)) && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {wizardComplete && (
                            <div className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border border-green-200 dark:border-green-800 rounded-2xl p-4">
                                <div className="flex items-center gap-4">
                                    <div className="p-2 bg-green-500 rounded-xl shrink-0 shadow-lg shadow-green-500/20">
                                        <CheckCircle className="w-5 h-5 text-white" />
                                    </div>
                                    <div className="flex-1">
                                        <h3 className="font-bold text-green-900 dark:text-green-300 text-sm">🎉 Setup Complete!</h3>
                                        <p className="text-xs text-green-800 dark:text-green-400">
                                            Your site is now optimized. Individual pages can override these defaults.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        )}

                        {!wizardCompleted && !loading && (
                            <div className="bg-gradient-to-r from-primary/10 to-purple-500/10 border border-primary/30 rounded-2xl p-4">
                                <div className="flex items-center gap-4">
                                    <div className="p-2 bg-gradient-to-br from-primary to-purple-500 rounded-xl shrink-0 shadow-lg shadow-primary/20">
                                        <Sparkles className="w-5 h-5 text-white" />
                                    </div>
                                    <div className="flex-1">
                                        <h3 className="font-bold text-slate-900 dark:text-white text-sm">Get Started with SEO</h3>
                                        <div className="flex items-center justify-between gap-4">
                                            <p className="text-xs text-slate-600 dark:text-slate-400">
                                                Run our 5-minute setup wizard to configure the essentials.
                                            </p>
                                            <Link
                                                href="/admin/growth/seo/wizard"
                                                className="inline-flex items-center gap-2 px-4 py-1.5 bg-gradient-to-r from-primary to-purple-500 text-white rounded-lg hover:opacity-90 font-bold text-xs shadow-lg shadow-primary/20 transition-all shrink-0"
                                            >
                                                Start Wizard
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                )
            }

            {/* SEO Health Score */}
            {
                seoHealth !== null && (
                    <div className="bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-xl p-6 shadow-sm">
                        <div className="flex items-center justify-between mb-4">
                            <div>
                                <h3 className="font-bold text-lg dark:text-white">SEO Health Score</h3>
                                <p className="text-sm text-slate-500 dark:text-slate-400">Overall site optimization level</p>
                            </div>
                            <div className="text-right">
                                <div className={`text-4xl font-black ${healthColor === 'green' ? 'text-green-600 dark:text-green-400' :
                                    healthColor === 'yellow' ? 'text-yellow-600 dark:text-yellow-400' :
                                        'text-red-600 dark:text-red-400'
                                    }`}>
                                    {seoHealth}
                                </div>
                                <div className="text-sm font-bold text-slate-500">{healthGrade}</div>
                            </div>
                        </div>

                        {/* Visual Health Gauge */}
                        <div className="relative h-4 bg-slate-200 dark:bg-zinc-800 rounded-full overflow-hidden">
                            <div
                                className={`h-full transition-all duration-1000 ${healthColor === 'green' ? 'bg-gradient-to-r from-green-500 to-emerald-500' :
                                    healthColor === 'yellow' ? 'bg-gradient-to-r from-yellow-500 to-orange-500' :
                                        'bg-gradient-to-r from-red-500 to-orange-500'
                                    }`}
                                style={{ width: `${seoHealth}%` }}
                            />
                        </div>

                        {seoHealth < 80 && (
                            <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                                <p className="text-sm text-blue-900 dark:text-blue-300">
                                    <strong>💡 Tip:</strong> Complete the setup wizard and add meta descriptions to all pages to improve your score!
                                </p>
                            </div>
                        )}
                    </div>
                )
            }

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* Sitemap Status */}
                <div className="bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between mb-4">
                        <div className="p-3 bg-green-100 dark:bg-green-900/30 rounded-lg">
                            <CheckCircle className="w-6 h-6 text-green-600 dark:text-green-400" />
                        </div>
                        <a
                            href="/sitemap.xml"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-2 hover:bg-slate-100 dark:hover:bg-zinc-800 rounded-lg text-slate-600 dark:text-slate-400"
                        >
                            <ExternalLink size={18} />
                        </a>
                    </div>
                    <h3 className="font-bold text-lg mb-1 dark:text-white">XML Sitemap</h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
                        Auto-generated from your content
                    </p>
                    <a
                        href="/sitemap.xml"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm text-primary hover:underline font-medium"
                    >
                        View Sitemap →
                    </a>
                </div>

                {/* Robots.txt */}
                <div className="bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between mb-4">
                        <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
                            <FileSearch className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                        </div>
                        <a
                            href="/robots.txt"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-2 hover:bg-slate-100 dark:hover:bg-zinc-800 rounded-lg text-slate-600 dark:text-slate-400"
                        >
                            <ExternalLink size={18} />
                        </a>
                    </div>
                    <h3 className="font-bold text-lg mb-1 dark:text-white">Robots.txt</h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
                        Controls search engine crawlers
                    </p>
                    <Link
                        href="/admin/growth/seo/robots"
                        className="text-sm text-primary hover:underline font-medium"
                    >
                        Edit Configuration →
                    </Link>
                </div>

                {/* Redirects */}
                <div className="bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between mb-4">
                        <div className="p-3 bg-purple-100 dark:bg-purple-900/30 rounded-lg">
                            <Settings className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                        </div>
                        <div className="px-2 py-1 bg-slate-100 dark:bg-zinc-800 rounded text-sm font-bold dark:text-white">
                            {redirectCount}
                        </div>
                    </div>
                    <h3 className="font-bold text-lg mb-1 dark:text-white">Redirects</h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
                        Manage 301/302 URL redirects
                    </p>
                    <Link
                        href="/admin/growth/seo/redirects"
                        className="text-sm text-primary hover:underline font-medium"
                    >
                        Manage Redirects →
                    </Link>
                </div>

                {/* Schema Markup */}
                <div className="bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between mb-4">
                        <div className="p-3 bg-orange-100 dark:bg-orange-900/30 rounded-lg">
                            <CheckCircle className="w-6 h-6 text-orange-600 dark:text-orange-400" />
                        </div>
                    </div>
                    <h3 className="font-bold text-lg mb-1 dark:text-white">Schema Markup</h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
                        Structured data for rich snippets
                    </p>
                    <p className="text-xs text-slate-400 dark:text-slate-500">
                        Auto-applied to all posts and pages
                    </p>
                </div>

                {/* Meta Tags */}
                <div className="bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between mb-4">
                        <div className="p-3 bg-teal-100 dark:bg-teal-900/30 rounded-lg">
                            <CheckCircle className="w-6 h-6 text-teal-600 dark:text-teal-400" />
                        </div>
                    </div>
                    <h3 className="font-bold text-lg mb-1 dark:text-white">Meta Tags</h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
                        Open Graph & Twitter Cards
                    </p>
                    <Link
                        href="/admin/growth/seo/meta"
                        className="text-sm text-primary hover:underline font-medium"
                    >
                        Manage Settings →
                    </Link>
                </div>

                {/* Coming Soon: Analytics */}
                <div className="bg-white/50 dark:bg-zinc-900/50 border border-slate-200 dark:border-zinc-800 border-dashed rounded-xl p-6 shadow-sm">
                    <div className="flex items-start justify-between mb-4">
                        <div className="p-3 bg-slate-100 dark:bg-zinc-800 rounded-lg opacity-50">
                            <TrendingUp className="w-6 h-6 text-slate-400" />
                        </div>
                        <span className="text-xs px-2 py-1 bg-slate-100 dark:bg-zinc-800 rounded text-slate-500 dark:text-slate-400">
                            Coming Soon
                        </span>
                    </div>
                    <h3 className="font-bold text-lg mb-1 text-slate-400">SEO Analytics</h3>
                    <p className="text-sm text-slate-400 dark:text-slate-500 mb-4">
                        Track rankings and organic traffic
                    </p>
                </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-xl p-6 shadow-sm">
                <h3 className="font-bold text-lg mb-4 dark:text-white">Quick Actions</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <Link
                        href="/admin/growth/seo/wizard"
                        className="flex items-center gap-3 p-4 border border-slate-200 dark:border-zinc-800 rounded-lg hover:bg-slate-50 dark:hover:bg-zinc-800 transition-colors group"
                    >
                        <div className="p-2 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                            <Sparkles className="w-5 h-5 text-primary" />
                        </div>
                        <div className="flex-1">
                            <div className="font-bold text-sm dark:text-white">{wizardCompleted ? 'Re-run' : 'Start'} Setup Wizard</div>
                            <div className="text-xs text-slate-500 dark:text-slate-400">Configure SEO basics</div>
                        </div>
                    </Link>

                    <a
                        href="https://search.google.com/search-console"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-3 p-4 border border-slate-200 dark:border-zinc-800 rounded-lg hover:bg-slate-50 dark:hover:bg-zinc-800 transition-colors group"
                    >
                        <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-lg group-hover:bg-green-200 dark:group-hover:bg-green-900/50 transition-colors">
                            <ExternalLink className="w-5 h-5 text-green-600 dark:text-green-400" />
                        </div>
                        <div className="flex-1">
                            <div className="font-bold text-sm dark:text-white">Google Search Console</div>
                            <div className="text-xs text-slate-500 dark:text-slate-400">Monitor search performance</div>
                        </div>
                    </a>

                    <a
                        href="https://validator.schema.org"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-3 p-4 border border-slate-200 dark:border-zinc-800 rounded-lg hover:bg-slate-50 dark:hover:bg-zinc-800 transition-colors group"
                    >
                        <div className="p-2 bg-orange-100 dark:bg-orange-900/30 rounded-lg group-hover:bg-orange-200 dark:group-hover:bg-orange-900/50 transition-colors">
                            <Zap className="w-5 h-5 text-orange-600 dark:text-orange-400" />
                        </div>
                        <div className="flex-1">
                            <div className="font-bold text-sm dark:text-white">Schema Validator</div>
                            <div className="text-xs text-slate-500 dark:text-slate-400">Test structured data</div>
                        </div>
                    </a>
                </div>
            </div>

            <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-xl p-6">
                <h3 className="font-bold mb-2 text-blue-900 dark:text-blue-300">💡 SEO Tips</h3>
                <ul className="text-sm text-blue-800 dark:text-blue-400 space-y-2">
                    <li>• Submit your sitemap to <a href="https://search.google.com/search-console" target="_blank" rel="noopener noreferrer" className="underline">Google Search Console</a></li>
                    <li>• Use descriptive meta descriptions on all blog posts</li>
                    <li>• Set up 301 redirects for any moved or renamed pages</li>
                    <li>• Keep your content fresh and updated regularly</li>
                    <li>• Add internal links to related content to improve site structure</li>
                </ul>
            </div>
        </div>

    );
}

export default function SEODashboard() {
    return (
        <Suspense fallback={
            <div className="flex items-center justify-center min-h-[400px]">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
        }>
            <SEODashboardContent />
        </Suspense>
    );
}
