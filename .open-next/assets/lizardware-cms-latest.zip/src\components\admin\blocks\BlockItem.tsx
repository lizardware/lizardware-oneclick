'use client';

import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Block } from '@/types/blocks';
import { GripVertical, Trash2, ArrowUp, ArrowDown, Copy } from 'lucide-react';
import { BLOCK_REGISTRY } from '@/lib/blocks/registry';
import dynamic from 'next/dynamic';

// Recursive import needs to be handled carefully
const BlockList = dynamic(() => import('./BlockList'), { ssr: false });

interface BlockItemProps {
    block: Block;
    onDelete: (id: string) => void;
    onMoveUp: (id: string, direction: 'up' | 'down') => void;
    onMoveDown: (id: string, direction: 'up' | 'down') => void;

    // Recursive props
    isSelected: boolean;
    onSelect: (id: string) => void;
    selectedBlockId: string | null;
    onSelectBlock: (id: string | null) => void;
    onDeleteBlock: (id: string) => void;
    onMoveBlock: (id: string, direction: 'up' | 'down') => void;
    onDuplicateBlock: (id: string) => void;
    onDuplicate: () => void;
}

export default function BlockItem({
    block,
    onDelete,
    onMoveUp,
    onMoveDown,
    isSelected,
    onSelect,
    selectedBlockId,
    onSelectBlock,
    onDeleteBlock,
    onMoveBlock,
    onDuplicateBlock,
    onDuplicate
}: BlockItemProps) {
    const {
        attributes,
        listeners,
        setNodeRef,
        transform,
        transition,
        isDragging
    } = useSortable({ id: block.id });

    const style = {
        transform: CSS.Transform.toString(transform),
        transition,
        opacity: isDragging ? 0.5 : 1,
        zIndex: isDragging ? 999 : 1
    };

    const def = BLOCK_REGISTRY[block.type];
    const Icon = def?.icon || GripVertical;

    if (!def) return <div className="p-4 border border-red-500 bg-red-50">Unknown block type: {block.type}</div>;

    // A block is a container if its type is 'columns' or 'column'
    const isContainer = block.type === 'columns' || block.type === 'column';

    return (
        <div
            ref={setNodeRef}
            style={style}
            className={`relative group mb-4 rounded-xl border-2 transition-all bg-white dark:bg-zinc-900 ${isSelected
                ? 'border-primary ring-4 ring-primary/10 shadow-lg'
                : 'border-transparent hover:border-gray-200 dark:hover:border-zinc-700'
                }`}
            onClick={(e) => {
                e.stopPropagation();
                onSelect(block.id);
            }}
        >
            {/* Block Header / Controls */}
            <div className={`absolute -top-3 left-3 z-[100] bg-white dark:bg-zinc-800 rounded-lg shadow-sm border border-gray-200 dark:border-zinc-700 flex items-center p-1 gap-1 transition-opacity ${isSelected || 'opacity-0 group-hover:opacity-100'}`}>
                <div {...attributes} {...listeners} className="p-1 hover:bg-gray-100 dark:hover:bg-zinc-700 rounded cursor-grab active:cursor-grabbing">
                    <GripVertical size={14} className="text-gray-400" />
                </div>
                <div className="flex items-center gap-2 px-2 border-r border-gray-200 dark:border-zinc-700">
                    <Icon size={14} className="text-primary" />
                    <span className="text-[10px] font-bold uppercase tracking-wider text-gray-500">{def.label}</span>
                </div>
                <button onClick={(e) => { e.stopPropagation(); onMoveUp(block.id, 'up'); }} className="p-1 hover:bg-gray-100 dark:hover:bg-zinc-700 rounded text-gray-400 hover:text-gray-600">
                    <ArrowUp size={14} />
                </button>
                <button onClick={(e) => { e.stopPropagation(); onMoveDown(block.id, 'down'); }} className="p-1 hover:bg-gray-100 dark:hover:bg-zinc-700 rounded text-gray-400 hover:text-gray-600">
                    <ArrowDown size={14} />
                </button>
                <button onClick={(e) => { e.stopPropagation(); onDuplicate(); }} className="p-1 hover:bg-gray-100 dark:hover:bg-zinc-700 rounded text-gray-400 hover:text-blue-500" title="Duplicate">
                    <Copy size={14} />
                </button>
                <div className="w-px h-3 bg-gray-200 dark:bg-zinc-700 mx-1" />
                <button onClick={(e) => { e.stopPropagation(); onDelete(block.id); }} className="p-1 hover:bg-red-50 dark:hover:bg-red-900/20 rounded text-gray-400 hover:text-red-500">
                    <Trash2 size={14} />
                </button>
            </div>

            {/* Block Content Rendering */}
            <div className={`p-0 border-2 border-transparent hover:border-dashed hover:border-primary/20 rounded-lg m-2 transition-colors relative ${isContainer ? 'min-h-[100px]' : ''}`}>
                {/* Overlay to prevent interaction with block contents while sorting/selecting, UNLESS it's a container */}
                {!isContainer && <div className="absolute inset-0 z-10" />}

                {def.component && (() => {
                    const Component = def.component;

                    // If it's a Columns block, we want to render multiple BlockLists inside it  
                    if (block.type === 'columns') {
                        const cols = block.props.columns || 2;
                        const gap = block.props.gap || '1.5rem';

                        // Create grid layout for columns
                        const gridCols = {
                            1: 'grid-cols-1',
                            2: 'grid-cols-1 md:grid-cols-2',
                            3: 'grid-cols-1 md:grid-cols-3',
                            4: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4'
                        }[cols as 1 | 2 | 3 | 4] || 'grid-cols-1 md:grid-cols-2';

                        return (
                            <div className={`grid ${gridCols} items-start p-4`} style={{ gap }}>
                                {(block.children || []).map((child) => (
                                    <div key={child.id} className="min-h-[100px] bg-gray-50/50 dark:bg-zinc-900/30 rounded-lg border border-gray-200/50 dark:border-zinc-800/50 p-3">
                                        <BlockList
                                            blocks={[child]}
                                            parentId={block.id}
                                            selectedBlockId={selectedBlockId}
                                            onSelectBlock={onSelectBlock}
                                            onDeleteBlock={onDeleteBlock}
                                            onMoveBlock={onMoveBlock}
                                            onDuplicateBlock={onDuplicateBlock}
                                        />
                                    </div>
                                ))}
                            </div>
                        );
                    }

                    if (block.type === 'column') {
                        return (
                            <Component {...block.props}>
                                <BlockList
                                    blocks={block.children || []}
                                    parentId={block.id}
                                    selectedBlockId={selectedBlockId}
                                    onSelectBlock={onSelectBlock}
                                    onDeleteBlock={onDeleteBlock}
                                    onMoveBlock={onMoveBlock}
                                    onDuplicateBlock={onDuplicateBlock}
                                />
                            </Component>
                        );
                    }

                    return <Component {...block.props} />;
                })()}
            </div>
        </div>
    );
}
