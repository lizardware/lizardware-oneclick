"use client";

import { useEffect, useState } from "react";
import monetizationData from "@/data/monetization.json";

interface MonetizationWrapperProps {
    placement: "sidebar" | "post_top" | "post_bottom";
    children?: React.ReactNode;
}

export default function MonetizationWrapper({
    placement,
    children
}: MonetizationWrapperProps) {
    const [isLoaded, setIsLoaded] = useState(false);
    const config = monetizationData;

    useEffect(() => {
        setIsLoaded(true);
    }, []);

    if (!isLoaded) return null;

    // Placeholder Logic: In a real app, this would inject AdSense scripts or Amazon iFrames
    // For scaffolding, we render a visible placeholder or the custom banner

    const customAd = config.custom_ads.find(ad => ad.placement === placement && ad.enabled);

    if (customAd) {
        return (
            <div className="my-6 border border-borders rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                <a href={customAd.link} target="_blank" rel="noopener noreferrer" className="block">
                    <div className="bg-primary/5 p-4 text-center">
                        <span className="text-[10px] uppercase font-bold text-primary/40 tracking-widest block mb-2">Advertisement</span>
                        {customAd.type === "image" ? (
                            <div className="bg-slate-200 aspect-video flex items-center justify-center rounded-lg text-slate-400 font-bold mb-2">
                                [ {customAd.name} ]
                            </div>
                        ) : (
                            <p className="text-sm font-medium text-slate-700">{customAd.content}</p>
                        )}
                        <span className="text-xs text-primary font-bold">Learn More →</span>
                    </div>
                </a>
            </div>
        );
    }

    // If AdSense enabled for this slot
    const adsenseSlot = (config.google_adsense.enabled && config.google_adsense.slots[placement as keyof typeof config.google_adsense.slots]);

    if (adsenseSlot) {
        return (
            <div className="my-8 p-12 bg-slate-50 dark:bg-zinc-900 border border-dashed border-slate-300 dark:border-zinc-800 rounded-2xl flex flex-col items-center justify-center text-center">
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-widest mb-4">AdSense Placeholder</span>
                <div className="w-full h-32 bg-slate-100 dark:bg-zinc-800 rounded-lg flex items-center justify-center text-slate-300 font-mono text-xs">
                    Slot: {adsenseSlot}
                </div>
            </div>
        );
    }

    return children ? <>{children}</> : null;
}
