'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { createPortal } from 'react-dom';
import { Accordion } from '@/components/ui/Accordion';
import { THEME_PRESETS } from '@/lib/themes';
import { ThemeConfig } from '@/lib/config-storage';
import { Breadcrumbs } from "@/components/admin/Breadcrumbs";
import { AdminLoadingState } from "@/components/admin/AdminLoadingState";
import { Save, ExternalLink, Palette, Upload, Image as ImageIcon, ArrowLeft } from 'lucide-react';
import { GENERIC_FAVICONS, GENERIC_LOGOS } from '@/data/branding-assets';
import { usePopup } from '@/components/admin/AdminPopupProvider';
import AdminCommandBar, { CommandBarButton } from "@/components/admin/AdminCommandBar";
import { RoutePicker } from '@/components/admin/RoutePicker';
import { AdminHeader } from '@/components/admin/AdminHeader';

import { useAdminActions } from "@/hooks/useAdminActions";

export default function VisualIdentityPage() {
    const router = useRouter();
    const popup = usePopup();
    const [loading, setLoading] = useState(false);
    const [pageLoading, setPageLoading] = useState(true);
    const [activePreset, setActivePreset] = useState('classic');

    // Site Identity State
    const [siteName, setSiteName] = useState('Lizardware CMS');
    const [siteDescription, setSiteDescription] = useState('Build for the Edge.');
    const [logoUrl, setLogoUrl] = useState('🦎');
    const [favicon, setFavicon] = useState('🦎');
    const [homePageSlug, setHomePageSlug] = useState('');

    // Display State
    const [defaultMode, setDefaultMode] = useState<'light' | 'dark' | 'system'>('system');
    const [navbarStyle, setNavbarStyle] = useState<'sticky' | 'static' | 'floating'>('sticky');

    // Footer State
    const [copyrightText, setCopyrightText] = useState('© 2025 Lizardware. All rights reserved.');

    const handleSave = async () => {
        setLoading(true);

        try {
            // 1. Save Site Identity
            const siteRes = await fetch('/api/config/site');
            const currentSiteConfig = await siteRes.json() as any;

            await fetch('/api/config/site', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    ...currentSiteConfig,
                    name: siteName,
                    description: siteDescription,
                    logoUrl: logoUrl,
                    favicon: favicon,
                    homePageSlug: homePageSlug
                })
            });

            // 2. Save Theme Preset
            // Get current theme from API first to avoid overwriting other settings
            const themeRes = await fetch('/api/config/theme');
            const currentTheme = await themeRes.json() as ThemeConfig;

            // Find selected preset
            const preset = THEME_PRESETS.find(p => p.id === activePreset);

            if (preset) {
                // Merge preset colors into current theme
                const updatedTheme = {
                    ...currentTheme,
                    colors: {
                        light: { ...currentTheme.colors.light, ...preset.colors.light },
                        dark: { ...currentTheme.colors.dark, ...preset.colors.dark }
                    }
                };

                // Save back to API
                await fetch('/api/config/theme', {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(updatedTheme)
                });
            }

            setLoading(false);
            popup.success('Visual Identity settings and theme preset applied successfully!');
            router.refresh();
        } catch (err) {
            console.error(err);
            setLoading(false);
            popup.error('Error applying identity changes.');
        }
    };


    useAdminActions([
        {
            id: 'save-identity',
            label: loading ? 'Applying...' : 'Apply Identity',
            onClick: handleSave,
            variant: 'primary',
            disabled: loading,
            icon: <Save size={14} />,
            showOnMobile: true
        },
        {
            id: 'theme-transformer',
            label: 'Theme Transformer',
            onClick: () => router.push('/admin/design/theme'),
            icon: <ExternalLink size={14} />
        }
    ]);

    useEffect(() => {
        // Fetch current site config
        setPageLoading(true);
        fetch('/api/config/site')
            .then(res => res.json())
            .then((data: any) => {
                if (data.name) setSiteName(data.name);
                if (data.description) setSiteDescription(data.description);
                if (data.logoUrl) setLogoUrl(data.logoUrl);
                if (data.favicon) setFavicon(data.favicon);
                if (data.homePageSlug) setHomePageSlug(data.homePageSlug);
            })
            .catch(err => console.error('Failed to load site config:', err))
            .finally(() => setPageLoading(false));
    }, []);



    if (pageLoading) return (
        <div className="max-w-7xl mx-auto px-6 pt-4 pb-12 space-y-8">
            <AdminLoadingState message="Extracting brand DNA..." />
        </div>
    );

    return (
        <div className="min-h-screen bg-site-background pb-20">
            <div className="max-w-7xl mx-auto px-6 pt-0 space-y-8">
                <AdminHeader
                    title={<>Visual <span className="text-purple-500">Identity</span></>}
                    description="Establish your brand identity with logos, favicons, and site settings."
                    breadcrumbs={[
                        { label: 'Admin', href: '/admin' },
                        { label: 'Design', href: '/admin/design' },
                        { label: 'Identity' }
                    ]}
                    badge={
                        <div className="px-3 py-1.5 bg-purple-500/10 border border-purple-500/20 rounded-lg text-[10px] font-bold uppercase tracking-widest text-purple-600 dark:text-purple-400">
                            Identity Engine Active
                        </div>
                    }
                    actions={
                        <Link
                            href="/admin/design"
                            className="px-3 py-1.5 bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 rounded-lg text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
                        >
                            <ArrowLeft size={12} /> Back
                        </Link>
                    }
                />

                <div className="grid lg:grid-cols-3 gap-8">
                    {/* Main Content Areas */}
                    <div className="lg:col-span-2 space-y-12">

                        {/* Site Identity */}
                        <Accordion title="Site Identity" defaultOpen={true} variant="section">
                            <div className="grid gap-6">
                                <div className="grid md:grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-xs font-bold uppercase text-gray-500 mb-1.5">Site Name</label>
                                        <input
                                            type="text"
                                            value={siteName}
                                            onChange={(e) => setSiteName(e.target.value)}
                                            className="w-full p-3 bg-gray-50 dark:bg-zinc-950 border border-gray-200 dark:border-zinc-800 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold uppercase text-gray-500 mb-1.5">Tagline</label>
                                        <input
                                            type="text"
                                            value={siteDescription}
                                            onChange={(e) => setSiteDescription(e.target.value)}
                                            className="w-full p-3 bg-gray-50 dark:bg-zinc-950 border border-gray-200 dark:border-zinc-800 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none"
                                        />
                                    </div>
                                </div>

                                <div className="space-y-8">
                                    {/* Logo Section */}
                                    <div className="space-y-4">
                                        <div className="flex items-center justify-between">
                                            <label className="block text-xs font-bold uppercase text-gray-500">Site Logo</label>
                                            <span className="text-[10px] text-gray-400 font-medium">Select a preset or upload custom</span>
                                        </div>
                                        <div className="grid md:grid-cols-4 gap-6">
                                            {/* Preview & Upload */}
                                            <div className="md:col-span-1">
                                                <div className="group relative aspect-square bg-white dark:bg-zinc-900 border-2 border-dashed border-gray-200 dark:border-zinc-800 rounded-3xl flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50 dark:hover:bg-zinc-800/50 transition-all overflow-hidden">
                                                    <div className="text-4xl mb-2 transition-transform group-hover:scale-110 duration-300">
                                                        {logoUrl.startsWith('http') ? (
                                                            <img src={logoUrl} alt="Logo" className="w-16 h-16 object-contain" />
                                                        ) : (
                                                            logoUrl
                                                        )}
                                                    </div>
                                                    <div className="flex items-center gap-1.5 text-primary">
                                                        <Upload size={12} />
                                                        <span className="text-[10px] font-bold uppercase tracking-tight">Upload</span>
                                                    </div>
                                                    <input type="file" className="absolute inset-0 opacity-0 cursor-pointer" onChange={(e) => {
                                                        // Fallback for demo: just log it
                                                        popup.alert("File upload integrated with storage providers in Phase 3. For now, please select a preset.");
                                                    }} />
                                                </div>
                                            </div>
                                            {/* Preset Gallery */}
                                            <div className="md:col-span-3">
                                                <div className="bg-gray-50/50 dark:bg-zinc-950/50 p-4 rounded-3xl border border-gray-100 dark:border-zinc-800/50">
                                                    <div className="grid grid-cols-4 sm:grid-cols-8 gap-3">
                                                        {GENERIC_LOGOS.map((logo) => (
                                                            <button
                                                                key={logo.id}
                                                                onClick={() => setLogoUrl(logo.value)}
                                                                className={`aspect-square rounded-2xl flex items-center justify-center text-2xl transition-all duration-200 ${logoUrl === logo.value
                                                                    ? 'bg-white dark:bg-zinc-900 border-2 border-primary shadow-lg shadow-primary/10 scale-110 z-10'
                                                                    : 'bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 hover:border-primary/30 hover:scale-105'
                                                                    }`}
                                                                title={logo.label}
                                                            >
                                                                {logo.value}
                                                            </button>
                                                        ))}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Favicon Section */}
                                    <div className="space-y-4">
                                        <div className="flex items-center justify-between">
                                            <label className="block text-xs font-bold uppercase text-gray-500">Favicon</label>
                                            <span className="text-[10px] text-gray-400 font-medium">Browser tab icon</span>
                                        </div>
                                        <div className="grid md:grid-cols-4 gap-6">
                                            {/* Preview */}
                                            <div className="md:col-span-1">
                                                <div className="aspect-square bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-3xl flex flex-col items-center justify-center shadow-sm">
                                                    <div className="w-12 h-12 bg-gray-50 dark:bg-zinc-950 rounded-xl flex items-center justify-center text-2xl mb-2 border border-gray-100 dark:border-zinc-800">
                                                        {favicon}
                                                    </div>
                                                    <span className="text-[9px] font-bold text-gray-400 uppercase">Live Preview</span>
                                                </div>
                                            </div>
                                            {/* Preset Gallery */}
                                            <div className="md:col-span-3">
                                                <div className="bg-gray-50/50 dark:bg-zinc-950/50 p-4 rounded-3xl border border-gray-100 dark:border-zinc-800/50">
                                                    <div className="grid grid-cols-4 sm:grid-cols-8 gap-3">
                                                        {GENERIC_FAVICONS.map((fav) => (
                                                            <button
                                                                key={fav.id}
                                                                onClick={() => setFavicon(fav.value)}
                                                                className={`aspect-square rounded-2xl flex items-center justify-center text-2xl transition-all duration-200 ${favicon === fav.value
                                                                    ? 'bg-white dark:bg-zinc-900 border-2 border-primary shadow-lg shadow-primary/10 scale-110 z-10'
                                                                    : 'bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 hover:border-primary/30 hover:scale-105'
                                                                    }`}
                                                                title={fav.label}
                                                            >
                                                                {fav.value}
                                                            </button>
                                                        ))}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </Accordion>

                        {/* Theme Presets */}
                        <div className="space-y-4">
                            <div className="flex items-center justify-between">
                                <h2 className="text-xl font-bold flex items-center gap-2">
                                    <span>🌈</span> Theme Presets
                                </h2>
                                <span className="text-xs bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 px-2.5 py-1 rounded-full font-bold uppercase tracking-wider">Quick Start</span>
                            </div>
                            <div className="grid sm:grid-cols-2 gap-6">
                                {THEME_PRESETS.map((preset) => {
                                    const isDark = preset.preview.includes('900') ||
                                        preset.preview.includes('950') ||
                                        preset.preview.includes('800') ||
                                        preset.preview === 'bg-black';
                                    const textClass = isDark ? 'text-white' : 'text-gray-900';

                                    return (
                                        <button
                                            key={preset.id}
                                            onClick={() => setActivePreset(preset.id)}
                                            className={`group text-left p-1.5 rounded-[22px] border transition-all duration-300 relative overflow-hidden ${activePreset === preset.id
                                                ? 'border-primary ring-2 ring-primary/20 bg-primary/[0.05]'
                                                : 'border-gray-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 hover:border-gray-300 dark:hover:border-zinc-700'
                                                }`}
                                        >
                                            <div className={`h-44 w-full rounded-[18px] relative overflow-hidden ${preset.preview} flex flex-col justify-center items-center text-center px-6`}>
                                                <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/40"></div>

                                                {/* Text Content inside the card */}
                                                <div className={`relative z-10 ${textClass}`}>
                                                    <h3 className="font-extrabold text-xl mb-2 tracking-tight">{preset.name}</h3>
                                                    <p className="text-[11px] opacity-80 font-medium leading-relaxed max-w-[180px] mx-auto">{preset.description}</p>
                                                </div>

                                                <div className="absolute bottom-4 left-4 flex items-center gap-2 font-mono text-[9px] text-white/70 bg-black/20 backdrop-blur-md px-2 py-1 rounded-md">
                                                    <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: preset.accent }}></div>
                                                    <span>{preset.accent}</span>
                                                </div>

                                                {activePreset === preset.id && (
                                                    <div className="absolute top-4 right-4 bg-primary text-white p-1 rounded-full shadow-lg ring-4 ring-primary/20">
                                                        <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                                                        </svg>
                                                    </div>
                                                )}
                                            </div>
                                        </button>
                                    );
                                })}
                            </div>
                        </div>

                        {/* Navigation & Footer */}
                        <Accordion title="Layout & Structure" variant="section">
                            <div className="space-y-6">
                                <div className="grid md:grid-cols-2 gap-6">
                                    <div>
                                        <label className="block text-xs font-bold uppercase text-gray-500 mb-3">Navigation Behavior</label>
                                        <div className="grid grid-cols-3 gap-2 mb-4">
                                            {[
                                                { id: 'static', label: 'Static' },
                                                { id: 'sticky', label: 'Sticky' },
                                                { id: 'floating', label: 'Island' }
                                            ].map((style) => (
                                                <button
                                                    key={style.id}
                                                    onClick={() => setNavbarStyle(style.id as any)}
                                                    className={`p-3 rounded-xl border text-xs font-bold transition-all ${navbarStyle === style.id
                                                        ? 'bg-primary border-primary text-white shadow-lg shadow-primary/20 scale-[1.02]'
                                                        : 'bg-white dark:bg-zinc-900 border-gray-200 dark:border-zinc-800 text-gray-500 dark:text-gray-400 hover:border-primary/50'
                                                        }`}
                                                >
                                                    {style.label}
                                                </button>
                                            ))}
                                        </div>
                                        {/* Info Tip */}
                                        <div className="p-3 bg-gray-50 dark:bg-zinc-950 border border-gray-100 dark:border-zinc-800 rounded-xl space-y-2">
                                            <div className="flex items-center gap-2 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                                                <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
                                                Behavior Guide
                                            </div>
                                            <div className="grid gap-2">
                                                <div className="text-[11px] leading-relaxed">
                                                    <span className="font-bold text-page-title">Static:</span> Stays at the top and scrolls away with the page content.
                                                </div>
                                                <div className="text-[11px] leading-relaxed">
                                                    <span className="font-bold text-page-title">Sticky:</span> Persists at the top of the screen during scroll for easy access.
                                                </div>
                                                <div className="text-[11px] leading-relaxed">
                                                    <span className="font-bold text-page-title">Island:</span> A floating, modern pill-style navbar that hovers over content.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="space-y-4">
                                        <div>
                                            <label className="block text-xs font-bold uppercase text-gray-500 mb-3">Home Page Destination</label>
                                            <RoutePicker
                                                value={homePageSlug}
                                                onChange={setHomePageSlug}
                                                placeholder="Select a page to be your home page..."
                                            />
                                            <p className="text-[10px] text-gray-400 mt-2 italic">By default, the home page uses a static template. Select a CMS page to override it.</p>
                                        </div>

                                        <div>
                                            <label className="block text-xs font-bold uppercase text-gray-500 mb-3">Copyright Statement</label>
                                            <input
                                                type="text"
                                                value={copyrightText}
                                                onChange={(e) => setCopyrightText(e.target.value)}
                                                className="w-full p-3 bg-gray-50 dark:bg-zinc-950 border border-gray-200 dark:border-zinc-800 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none text-sm"
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </Accordion>
                    </div>

                    {/* Sidebar Configuration */}
                    <div className="space-y-6 sticky top-8 self-start">
                        {/* Default Mode Sidebar Box */}
                        <div className="bg-white dark:bg-zinc-900 p-6 rounded-2xl border border-gray-100 dark:border-zinc-800 shadow-sm space-y-4">
                            <div>
                                <h3 className="font-bold text-lg mb-1">Display Mode</h3>
                                <p className="text-xs text-gray-500">How should your site load by default?</p>
                            </div>

                            <div className="space-y-2">
                                {['light', 'dark', 'system'].map((mode) => (
                                    <button
                                        key={mode}
                                        onClick={() => setDefaultMode(mode as any)}
                                        className={`w-full flex items-center justify-between p-3 rounded-xl border transition-all ${defaultMode === mode
                                            ? 'bg-primary/10 border-primary/50 text-header-text ring-1 ring-primary/20'
                                            : 'border-transparent bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800'
                                            }`}
                                    >
                                        <div className="flex items-center gap-3">
                                            <span className="text-lg">
                                                {mode === 'light' ? '☀️' : mode === 'dark' ? '🌙' : '🌓'}
                                            </span>
                                            <span className="capitalize font-semibold text-sm">{mode}</span>
                                        </div>
                                        {defaultMode === mode && (
                                            <div className="w-2 h-2 rounded-full bg-primary animate-pulse"></div>
                                        )}
                                    </button>
                                ))}
                            </div>

                            <div className="pt-4 border-t border-gray-100 dark:border-zinc-800">
                                <h4 className="text-xs font-bold uppercase text-gray-400 mb-3 tracking-widest text-center">Preview</h4>
                                <div className={`h-32 w-full rounded-2xl border border-gray-200 dark:border-zinc-800 shadow-inner flex items-center justify-center text-[10px] uppercase font-bold tracking-tighter text-gray-300 dark:text-zinc-700 ${defaultMode === 'dark' ? 'bg-zinc-950' : 'bg-white'
                                    }`}>
                                    Preview Canvas
                                </div>
                            </div>
                        </div>

                        {/* SEO Quick Settings */}
                        <div className="bg-gradient-to-br from-indigo-500 to-purple-600 p-6 rounded-2xl text-white shadow-xl shadow-indigo-500/10">
                            <h3 className="font-bold text-lg mb-2 flex items-center gap-2">
                                <span>🚀</span> SEO Boost
                            </h3>
                            <p className="text-xs text-white/80 mb-4 leading-relaxed">Ensure your site looks professional when shared on social media and discovered by search engines.</p>
                            <Link
                                href="/admin/growth/seo/meta"
                                className="w-full py-2.5 bg-white/20 hover:bg-white/30 backdrop-blur-md rounded-xl font-bold text-sm transition-all border border-white/20 flex items-center justify-center"
                            >
                                Configure Meta Data
                            </Link>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    );
}
