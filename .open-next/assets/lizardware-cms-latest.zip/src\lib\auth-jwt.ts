import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || process.env.CLERK_SECRET_KEY || 'lizardware-insecure-dev-secret';

export interface LocalUser {
    id: string;
    username: string;
    role: string;
}

export function signToken(payload: LocalUser): string {
    return jwt.sign(payload, JWT_SECRET, { expiresIn: '7d' });
}

export function verifyToken(token: string): LocalUser | null {
    try {
        return jwt.verify(token, JWT_SECRET) as LocalUser;
    } catch (e) {
        return null;
    }
}
