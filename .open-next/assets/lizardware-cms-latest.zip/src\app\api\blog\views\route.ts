import { NextRequest, NextResponse } from "next/server";
import { getD1Database } from "@/lib/cloudflare";

export async function POST(request: NextRequest) {
    try {
        const { searchParams } = new URL(request.url);
        const slug = searchParams.get('slug');

        if (!slug) {
            return NextResponse.json({ error: "Missing slug" }, { status: 400 });
        }

        const db = await getD1Database();
        if (!db) {
            return NextResponse.json({ error: "D1 Database not available" }, { status: 503 });
        }

        // Increment view count
        await db.prepare('UPDATE posts SET view_count = view_count + 1 WHERE slug = ?').bind(slug).run();

        return NextResponse.json({ success: true }, { status: 200 });
    } catch (error) {
        console.error('Error incrementing view count:', error);
        return NextResponse.json({ error: (error as Error).message }, { status: 500 });
    }
}
