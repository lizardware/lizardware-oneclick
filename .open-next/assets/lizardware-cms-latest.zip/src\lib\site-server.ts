import { getSiteConfig } from './config-storage';
import { siteConfig as defaultSiteConfig } from '@/config/site';
import { getSafeCloudflareContext } from './cloudflare';

export async function getDynamicSiteConfig() {
    try {
        const cfContext = await getSafeCloudflareContext();
        const kv = cfContext?.env?.CONFIG_KV as unknown as KVNamespace;

        // In Workers runtime, try KV first
        if (kv) {
            const config = await getSiteConfig(kv);
            // If we got a config from KV, use it
            if (config) return config;
        }

        // Development fallback: Read from local JSON file to ensure freshness
        if (process.env.NODE_ENV === 'development') {
            try {
                const fs = await import('fs');
                const path = await import('path');
                const configPath = path.join(process.cwd(), 'src', 'data', 'site-config.json');
                if (fs.existsSync(configPath)) {
                    const fileContent = fs.readFileSync(configPath, 'utf-8');
                    return JSON.parse(fileContent);
                }
            } catch (err) {
                console.warn('[Site Server] Local filesystem fallback failed:', err);
            }
        }

        // Fallback to default config (KV empty or unavailable)
        return defaultSiteConfig;
    } catch (error) {
        // On any error, always return the default config
        console.error('Failed to load site config from KV, using default:', error);
        return defaultSiteConfig;
    }
}
