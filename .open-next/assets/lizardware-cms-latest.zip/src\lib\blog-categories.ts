import { getD1Database } from './cloudflare';

export interface Category {
    id: string;
    name: string;
    slug: string;
    description?: string;
    created_at?: string;
}

export async function getAllCategories(db: D1Database): Promise<Category[]> {
    const stmt = db.prepare('SELECT * FROM categories ORDER BY name ASC');
    const result = await stmt.all<Category>();
    return result.results;
}

export async function getCategoryBySlug(db: D1Database, slug: string): Promise<Category | null> {
    const stmt = db.prepare('SELECT * FROM categories WHERE slug = ? LIMIT 1').bind(slug);
    return await stmt.first<Category>();
}

export async function upsertCategory(db: D1Database, category: Category): Promise<void> {
    const stmt = db.prepare(`
        INSERT INTO categories (id, name, slug, description)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
            name = excluded.name,
            slug = excluded.slug,
            description = excluded.description
    `).bind(
        category.id,
        category.name,
        category.slug,
        category.description || null
    );
    await stmt.run();
}

export async function deleteCategory(db: D1Database, id: string): Promise<void> {
    const stmt = db.prepare('DELETE FROM categories WHERE id = ?').bind(id);
    await stmt.run();
}
