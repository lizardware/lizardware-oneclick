export interface SiteConfig {
    name: string;
    description: string;
    url: string;
    ogImage: string;
    links: {
        github?: string;
        twitter?: string;
        linkedin?: string;
    };
    seo: {
        title: string;
        description: string;
        keywords: string[];
        author: string;
        twitterHandle?: string;
    };
    openGraph: {
        type: string;
        locale: string;
        siteName: string;
    };
    favicon?: string;
    logoUrl?: string;
    whiteLabel?: boolean;
    homePageSlug?: string;
    business_type?: string;
    template_id?: string;
    setup_completed?: boolean;
}
