export interface PageMeta {
    slug: string;
    title: string;
    description?: string;
    status: 'draft' | 'published';
    created_at?: string;
    updated_at?: string;
    metadata_json?: string;

    // NEW: Template system fields
    is_template?: boolean;           // 1 = template, 0 = custom page
    template_category?: string;      // 'company' | 'legal' | 'support' | null
    sort_order?: number;             // Custom ordering (lower = higher priority)
    layout_id?: string;              // 'standard' | 'minimal' | etc.

    // NEW: Navigation Sync fields
    show_in_nav?: boolean;           // Whether to show in navigation
    nav_label?: string;              // Optional custom nav label
    nav_parent?: string;             // ID of parent nav item
    nav_order?: number;              // Order within the parent
}

export interface Page extends PageMeta {
    content: string; // Markdown/HTML content
}

