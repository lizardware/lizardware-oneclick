import { Metadata } from "next";
import { getPageBySlug } from "@/lib/pages";
import PageRenderer from "@/components/PageRenderer";
import TermsPage from "./TermsPage";

export const metadata: Metadata = {
    title: "Terms of Service",
};

export default async function Terms({ searchParams }: { searchParams: Promise<{ preview?: string }> }) {
    const { preview } = await searchParams;
    let page = await getPageBySlug("terms");

    // In preview mode, ensure we use the PageRenderer even if the page doesn't exist yet
    // This allows the ContentPreviewListener to populate the UI as the user types
    if (preview === 'true') {
        if (!page) {
            page = {
                slug: 'terms',
                title: 'Terms of Service',
                content: '<p>Start typing your terms of service content...</p>',
                description: '',
                status: 'draft'
            } as any;
        }
        return <PageRenderer page={page as any} />;
    }

    if (page && page.status === "published") {
        return <PageRenderer page={page} />;
    }

    return <TermsPage />;
}
