/**
 * Clerk Authentication Utilities
 * Abstraction layer for Clerk authentication to allow future migration if needed
 */

import { auth, currentUser } from '@clerk/nextjs/server';

export type UserRole = 'owner' | 'admin' | 'editor' | 'viewer';

export interface AuthUser {
    id: string;
    email: string;
    name: string;
    imageUrl: string | null;
    role: UserRole;
}

/**
 * Get the current authenticated user
 * Returns null if not authenticated
 */
export async function getCurrentUser(): Promise<AuthUser | null> {
    try {
        const user = await currentUser();
        if (!user) return null;

        const role = (user.publicMetadata?.role as UserRole) || 'editor';
        const email = user.emailAddresses[0]?.emailAddress || '';
        const name = user.fullName || user.username || email.split('@')[0];

        return {
            id: user.id,
            email,
            name,
            imageUrl: user.imageUrl,
            role,
        };
    } catch (error) {
        console.error('Error getting current user:', error);
        return null;
    }
}

/**
 * Get the current user's ID
 * Returns null if not authenticated
 */
export async function getCurrentUserId(): Promise<string | null> {
    try {
        const { userId } = await auth();
        return userId;
    } catch (error) {
        console.error('Error getting user ID:', error);
        return null;
    }
}

/**
 * Check if the current user has a specific role
 */
export async function hasRole(requiredRole: UserRole): Promise<boolean> {
    const user = await getCurrentUser();
    if (!user) return false;

    const roleHierarchy: Record<UserRole, number> = {
        owner: 4,
        admin: 3,
        editor: 2,
        viewer: 1,
    };

    const userLevel = roleHierarchy[user.role] || 0;
    const requiredLevel = roleHierarchy[requiredRole] || 0;

    return userLevel >= requiredLevel;
}

/**
 * Check if the current user is an owner
 */
export async function isOwner(): Promise<boolean> {
    return hasRole('owner');
}

/**
 * Check if the current user is an admin or higher
 */
export async function isAdmin(): Promise<boolean> {
    return hasRole('admin');
}

/**
 * Check if the current user is an editor or higher
 */
export async function isEditor(): Promise<boolean> {
    return hasRole('editor');
}

/**
 * Require authentication, throw error if not authenticated
 */
export async function requireAuth(): Promise<AuthUser> {
    const user = await getCurrentUser();
    if (!user) {
        throw new Error('Authentication required');
    }
    return user;
}

/**
 * Require a specific role, throw error if not authorized
 */
export async function requireRole(role: UserRole): Promise<AuthUser> {
    const user = await requireAuth();
    
    const roleHierarchy: Record<UserRole, number> = {
        owner: 4,
        admin: 3,
        editor: 2,
        viewer: 1,
    };

    const userLevel = roleHierarchy[user.role] || 0;
    const requiredLevel = roleHierarchy[role] || 0;

    if (userLevel < requiredLevel) {
        throw new Error(`Insufficient permissions. Required: ${role}, Current: ${user.role}`);
    }

    return user;
}

/**
 * Get user role display name
 */
export function getRoleDisplayName(role: UserRole): string {
    const names: Record<UserRole, string> = {
        owner: 'Owner',
        admin: 'Administrator',
        editor: 'Editor',
        viewer: 'Viewer',
    };
    return names[role] || 'Unknown';
}

/**
 * Get role badge color
 */
export function getRoleBadgeColor(role: UserRole): string {
    const colors: Record<UserRole, string> = {
        owner: 'text-purple-500',
        admin: 'text-emerald-500',
        editor: 'text-blue-500',
        viewer: 'text-zinc-500',
    };
    return colors[role] || 'text-zinc-500';
}
