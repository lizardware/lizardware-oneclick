import { NextResponse } from 'next/server';

export async function GET() {
    return NextResponse.json({
        status: 'ok',
        message: 'Nano diagnostic working - no external imports used',
        timestamp: new Date().toISOString()
    });
}
