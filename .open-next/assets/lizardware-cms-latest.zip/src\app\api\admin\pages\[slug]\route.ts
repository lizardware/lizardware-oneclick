import { NextRequest, NextResponse } from "next/server";
import { getPageBySlug, upsertPage, deletePage } from "@/lib/pages";

import { getD1Database, dbUnavailableResponse } from '@/lib/cloudflare';
import { Page } from "@/types/page";

// GET /api/admin/pages/[slug] - Get single page
export async function GET(
    request: NextRequest,
    { params }: { params: Promise<{ slug: string }> }
) {
    try {
        const db = await getD1Database();

        if (!db) {
            return dbUnavailableResponse();
        }

        const { slug } = await params;
        const page = await getPageBySlug(slug);

        if (!page) {
            return NextResponse.json(
                { error: "Page not found" },
                { status: 404 }
            );
        }

        return NextResponse.json({ page });
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error("Page fetch error:", message);

        return NextResponse.json(
            { error: message },
            { status: 500 }
        );
    }
}

// PUT /api/admin/pages/[slug] - Update page
export async function PUT(
    request: NextRequest,
    { params }: { params: Promise<{ slug: string }> }
) {
    try {
        const db = await getD1Database();

        if (!db) {
            return dbUnavailableResponse();
        }

        const { slug } = await params;
        const page = await request.json() as Page;
        page.slug = slug; // Ensure slug matches URL

        await upsertPage(page);

        return NextResponse.json({
            success: true,
            message: "Page updated successfully",
        });
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error("Page update error:", message);

        return NextResponse.json(
            { error: message },
            { status: 500 }
        );
    }
}

// DELETE /api/admin/pages/[slug] - Delete page
export async function DELETE(
    request: NextRequest,
    { params }: { params: Promise<{ slug: string }> }
) {
    try {
        const db = await getD1Database();

        if (!db) {
            return dbUnavailableResponse();
        }

        const { slug } = await params;
        await deletePage(slug);

        return NextResponse.json({
            success: true,
            message: "Page deleted successfully",
        });
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error("Page deletion error:", message);

        return NextResponse.json(
            { error: message },
            { status: 500 }
        );
    }
}
