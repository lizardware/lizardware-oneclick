import { servicesData, ServiceData } from "@/data/services";

export function getAllServices(): ServiceData[] {
    return Object.values(servicesData);
}

export function getServiceBySlug(slug: string): ServiceData | undefined {
    return servicesData[slug];
}

export function getAllServiceSlugs(): string[] {
    return Object.keys(servicesData);
}

export function getAllServicesWithSlugs(): (ServiceData & { slug: string })[] {
    return Object.entries(servicesData).map(([slug, service]) => ({ ...service, slug }));
}
