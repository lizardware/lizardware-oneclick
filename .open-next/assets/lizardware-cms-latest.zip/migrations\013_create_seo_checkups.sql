-- Migration: Create SEO checkups table
-- Version: 0.3.1
-- Purpose: Store automated SEO audit results for tracking page health over time

CREATE TABLE IF NOT EXISTS seo_checkups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  page_type TEXT NOT NULL, -- 'blog' or 'page'
  page_id INTEGER NOT NULL,
  score INTEGER NOT NULL, -- 0-100
  grade TEXT NOT NULL, -- 'excellent', 'good', 'needs-work', 'poor'
  issues TEXT, -- JSON array of issues
  checked_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_seo_checkups_page ON seo_checkups(page_type, page_id);
CREATE INDEX IF NOT EXISTS idx_seo_checkups_score ON seo_checkups(score);
