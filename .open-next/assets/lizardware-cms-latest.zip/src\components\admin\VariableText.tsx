'use client';

import { getVariable } from '@/lib/variables';

interface VariableTextProps {
    text: string;
    className?: string;
}

/**
 * Renders text with visual pills for {{variableName}} patterns
 */
export function VariableText({ text, className = "" }: VariableTextProps) {
    if (!text) return null;

    // Split by {{variable}} but keep the delimiters
    const parts = text.split(/(\{\{[a-zA-Z0-9_]+\}\})/g);

    return (
        <span className={className}>
            {parts.map((part, i) => {
                const match = part.match(/\{\{([a-zA-Z0-9_]+)\}\}/);
                if (match) {
                    const variableName = match[1];
                    const variable = getVariable(variableName);

                    return (
                        <span
                            key={i}
                            className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 rounded text-[10px] font-medium mx-0.5 align-middle select-none transition-colors border border-purple-200 dark:border-purple-800"
                            title={variable?.description || variableName}
                        >
                            <span className="text-[12px]">{variable?.icon || '⚡'}</span>
                            {variable?.label || variableName}
                        </span>
                    );
                }
                return <span key={i}>{part}</span>;
            })}
        </span>
    );
}
