'use client';

import { usePathname } from 'next/navigation';
import { Info, AlertTriangle, ShieldCheck } from 'lucide-react';
import { useEffect, useState } from 'react';

export function EnvironmentBanner({ position = 'top' }: { position?: 'top' | 'bottom' }) {
    const [env, setEnv] = useState<'dev' | 'preview' | 'prod' | null>(null);
    const pathname = usePathname();

    useEffect(() => {
        // Detect environment
        if (process.env.NODE_ENV === 'development') {
            setEnv('dev');
        } else {
            // Check if we are in wrangler preview mode (local preview only)
            if (typeof window !== 'undefined') {
                const host = window.location.hostname;
                // Preview mode is ONLY localhost/127.0.0.1 when NOT in dev mode
                // This happens during `npm run preview` with wrangler dev
                if (host === 'localhost' || host === '127.0.0.1') {
                    setEnv('preview');
                } else {
                    // Production: any deployed environment including *.workers.dev and custom domains
                    setEnv('prod');
                }
            }
        }
    }, [pathname]);

    if (!env || env === 'prod') return null;

    const isDev = env === 'dev';
    const isBottom = position === 'bottom';

    return (
        <div className={`w-full py-1.5 px-4 text-[10px] font-bold uppercase tracking-widest flex items-center justify-center gap-3 transition-colors duration-500 z-30 relative ${isDev
            ? `bg-amber-50 dark:bg-amber-950 text-amber-800 dark:text-amber-300 ${isBottom ? 'border-t' : 'border-b'} border-amber-200 dark:border-amber-800`
            : `bg-blue-50 dark:bg-blue-950 text-blue-800 dark:text-blue-300 ${isBottom ? 'border-t' : 'border-b'} border-blue-200 dark:border-blue-800`
            }`}>
            {isDev ? (
                <>
                    <AlertTriangle size={12} className="animate-pulse" />
                    <span>
                        Dev Environment: <span className="opacity-70 normal-case font-medium">No database connection. Settings are saved to</span> <code className="bg-amber-500/10 px-1 rounded lowercase">src/data/*.json</code>
                    </span>
                </>
            ) : (
                <>
                    <ShieldCheck size={12} />
                    <span>
                        Preview Environment: <span className="opacity-70 normal-case font-medium">Powered by local Wrangler Storage (KV/D1).</span>
                    </span>
                </>
            )}
        </div>
    );
}
