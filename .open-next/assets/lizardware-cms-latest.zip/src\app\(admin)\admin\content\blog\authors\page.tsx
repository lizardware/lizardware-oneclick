"use client";

import { AdminHeader } from "@/components/admin/AdminHeader";
import AuthorManager from "@/components/admin/AuthorManager";
import { ArrowLeft, User } from "lucide-react";
import Link from "next/link";

export default function BlogAuthorsPage() {
    return (
        <div className="bg-site-background">
            <div className="max-w-7xl mx-auto px-6 pt-4 space-y-8">
                <AdminHeader
                    breadcrumbs={[
                        { label: 'Admin', href: '/admin' },
                        { label: 'Content', href: '/admin/content' },
                        { label: 'Blog', href: '/admin/content/blog' },
                        { label: 'Authors' }
                    ]}
                    title={
                        <>
                            Blog <span className="text-purple-500">Broadcasters</span>
                        </>
                    }
                    description="Manage the identities and profiles of those broadcasting transmissions to the world."
                    badge={
                        <div className="inline-flex items-center gap-2 px-3 py-1 bg-purple-500/10 text-purple-600 dark:text-purple-400 rounded-full text-[9px] font-bold uppercase tracking-wider">
                            <span className="w-1 h-1 rounded-full bg-purple-500 animate-pulse"></span>
                            Personnel Database
                        </div>
                    }
                    actions={
                        <div className="flex items-center gap-3">
                            <Link
                                href="/admin/content/blog"
                                className="px-4 py-2 bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 rounded-xl text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
                            >
                                <ArrowLeft size={14} /> Back to Blog
                            </Link>
                        </div>
                    }
                />

                <div className="bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-3xl p-6 shadow-sm overflow-hidden">
                    <AuthorManager />
                </div>
            </div>
        </div>
    );
}
