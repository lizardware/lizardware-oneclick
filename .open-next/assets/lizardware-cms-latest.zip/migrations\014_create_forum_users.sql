-- Migration 014: Create forum users table
-- Version: 0.6.0
-- Purpose: User authentication and profiles for forum system

CREATE TABLE IF NOT EXISTS forum_users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  display_name TEXT,
  avatar_url TEXT,
  bio TEXT,
  reputation INTEGER DEFAULT 0,
  is_moderator BOOLEAN DEFAULT 0,
  is_banned BOOLEAN DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  last_seen_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_forum_users_email ON forum_users(email);
CREATE INDEX idx_forum_users_username ON forum_users(username);
CREATE INDEX idx_forum_users_reputation ON forum_users(reputation DESC);
