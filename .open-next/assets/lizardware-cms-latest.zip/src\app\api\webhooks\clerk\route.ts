import { Webhook } from 'svix';
import { headers } from 'next/headers';
import { WebhookEvent } from '@clerk/nextjs/server';
import { getD1Database } from '@/lib/cloudflare';
import { NextResponse } from 'next/server';

export async function POST(req: Request) {
    const WEBHOOK_SECRET = process.env.CLERK_WEBHOOK_SECRET;

    if (!WEBHOOK_SECRET) {
        throw new Error('Please add CLERK_WEBHOOK_SECRET from Clerk Dashboard to .env or .env.local');
    }

    // Get the headers
    const headerPayload = await headers();
    const svix_id = headerPayload.get("svix-id");
    const svix_timestamp = headerPayload.get("svix-timestamp");
    const svix_signature = headerPayload.get("svix-signature");

    // If there are no headers, error out
    if (!svix_id || !svix_timestamp || !svix_signature) {
        return new Response('Error occured -- no svix headers', {
            status: 400
        });
    }

    // Get the body
    const payload = await req.json();
    const body = JSON.stringify(payload);

    // Create a new Svix instance with your secret.
    const wh = new Webhook(WEBHOOK_SECRET);

    let evt: WebhookEvent;

    // Verify the payload with the headers
    try {
        evt = wh.verify(body, {
            "svix-id": svix_id,
            "svix-timestamp": svix_timestamp,
            "svix-signature": svix_signature,
        }) as WebhookEvent;
    } catch (err) {
        console.error('Error verifying webhook:', err);
        return new Response('Error occured', {
            status: 400
        });
    }

    // Handle the webhook
    const eventType = evt.type;

    if (eventType === 'user.created' || eventType === 'user.updated') {
        const { id, first_name, last_name, email_addresses, image_url, public_metadata } = evt.data;
        const email = email_addresses[0]?.email_address;
        const name = `${first_name || ''} ${last_name || ''}`.trim() || email.split('@')[0];
        const role = (public_metadata?.role as string) || 'editor';

        try {
            const db = await getD1Database();
            if (db) {
                await db.prepare(`
                    INSERT INTO authors (id, name, email, image_url, role, updated_at)
                    VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                    ON CONFLICT(id) DO UPDATE SET
                        name = excluded.name,
                        email = excluded.email,
                        image_url = excluded.image_url,
                        role = excluded.role,
                        updated_at = CURRENT_TIMESTAMP
                `).bind(id, name, email, image_url, role).run();

                console.log(`✅ Synced author: ${name} (${id})`);
            }
        } catch (error) {
            console.error('Error syncing author to D1:', error);
            return new Response('Error syncing to database', { status: 500 });
        }
    }

    if (eventType === 'user.deleted') {
        const { id } = evt.data;
        try {
            const db = await getD1Database();
            if (db) {
                await db.prepare('DELETE FROM authors WHERE id = ?').bind(id).run();
                console.log(`❌ Deleted author: ${id}`);
            }
        } catch (error) {
            console.error('Error deleting author from D1:', error);
            return new Response('Error deleting from database', { status: 500 });
        }
    }

    return NextResponse.json({ success: true });
}
