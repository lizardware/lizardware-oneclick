"use client";

import { PostMeta } from "@/types/blog";

interface BlogStatisticsProps {
    posts: PostMeta[];
}

export function BlogStatistics({ posts }: BlogStatisticsProps) {
    const stats = [
        {
            label: 'Total Transmissions',
            value: posts.length,
            icon: '📄',
            color: 'text-purple-500'
        },
        {
            label: 'Published',
            value: posts.filter(p => p.status === 'published').length,
            icon: '📡',
            color: 'text-emerald-500'
        },
        {
            label: 'Drafts',
            value: posts.filter(p => p.status === 'draft').length,
            icon: '✍️',
            color: 'text-amber-500'
        }
    ];

    return (
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
            {stats.map((stat, i) => (
                <div
                    key={i}
                    className="bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 p-4 rounded-2xl shadow-sm hover:shadow-md transition-shadow group overflow-hidden relative"
                >
                    <div className="relative z-10 flex flex-col gap-1">
                        <span className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">
                            {stat.label}
                        </span>
                        <div className="flex items-end gap-2">
                            <span className={`text-2xl font-black tracking-tighter ${stat.color}`}>
                                {stat.value}
                            </span>
                            <span className="text-xs mb-1 opacity-50">{stat.icon}</span>
                        </div>
                    </div>
                    <div className={`absolute -right-2 -bottom-2 text-4xl opacity-[0.03] group-hover:opacity-[0.08] transition-opacity transform group-hover:rotate-12`}>
                        {stat.icon}
                    </div>
                </div>
            ))}
        </div>
    );
}
