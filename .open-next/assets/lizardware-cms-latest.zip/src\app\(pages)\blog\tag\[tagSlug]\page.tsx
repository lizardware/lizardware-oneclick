import Link from "next/link";
import { getAllPosts, Post } from "@/lib/blog";
import BlogCard from "@/components/blog/BlogCard";
import { getD1Database } from "@/lib/cloudflare";
import { getAllMedia } from "@/lib/blog-media";

interface TagPageProps {
    params: Promise<{
        tagSlug: string;
    }>;
    searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}

export async function generateMetadata({ params }: TagPageProps) {
    const { tagSlug } = await params;
    const tagName = tagSlug.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');

    return {
        title: `${tagName} | Lizardware Blog`,
        description: `Discover articles and insights related to ${tagName}.`,
    };
}

export default async function TagDetailPage({ params, searchParams }: TagPageProps) {
    const [{ tagSlug }] = await Promise.all([params, searchParams.then(() => void 0)]);
    const allPosts = await getAllPosts();
    const postsWithTag = allPosts.filter((post: Post | Omit<Post, 'content'>) => {
        if (!post.tags || !Array.isArray(post.tags)) return false;
        return post.tags.some((tag: string) => tag.toLowerCase().replace(/\s+/g, '-') === tagSlug);
    });

    // Fetch media mapping
    const media: Record<string, string> = {};
    const db = await getD1Database();
    if (db) {
        const allMedia = await getAllMedia(db);
        allMedia.forEach(m => media[m.id] = m.url);
    }

    if (postsWithTag.length === 0) {
        // It's possible the tag exists but has no posts, or the slug is wrong.
        // We'll show a "No posts" message instead of 404 if we want to be friendly,
        // but if the tag isn't in any post at all, we could 404.
    }

    const tagName = tagSlug.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');

    return (
        <div className="max-w-[1024px] mx-auto px-4 py-12">
            <div className="mb-12">
                <div className="flex items-center gap-2 text-primary mb-4">
                    <Link href="/blog/tags" className="text-sm hover:underline">Tags</Link>
                    <span className="text-xs text-slate-300">/</span>
                    <span className="text-sm font-bold">#{tagSlug}</span>
                </div>
                <h1 className="text-title font-bold text-page-title mb-4 flex items-center gap-3">
                    Topic: <span className="text-primary">{tagName}</span>
                </h1>
                <p className="text-lg text-page-text">
                    Browse all technical articles and updates related to {tagName.toLowerCase()}.
                </p>
            </div>

            <div className="space-y-8">
                {postsWithTag.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
                        {postsWithTag.map((post) => (
                            <BlogCard
                                key={post.slug}
                                post={post}
                                imageUrl={post.featured_image_id ? media[post.featured_image_id] : undefined}
                            />
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-24 bg-info-box-bg border border-borders rounded-2xl border-dashed">
                        <p className="text-slate-500 italic">
                            No articles found for this topic yet.
                        </p>
                        <Link href="/blog" className="mt-4 text-primary font-medium hover:underline inline-block">
                            Browse All Posts →
                        </Link>
                    </div>
                )}
            </div>
        </div>
    );
}
