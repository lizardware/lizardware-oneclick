'use client';

import React, { useState, useEffect } from 'react';
import { ChevronDown } from 'lucide-react';

export interface AccordionProps {
    /**
     * The title/header text displayed in the accordion button
     */
    title: string | React.ReactNode;

    /**
     * The content to show/hide when accordion is toggled
     */
    children: React.ReactNode;

    /**
     * Whether the accordion should be open by default
     * @default false
     */
    defaultOpen?: boolean;

    /**
     * Optional icon to display before the title
     */
    icon?: React.ReactNode;

    /**
     * Optional badge/tag to display after the title
     */
    badge?: React.ReactNode;

    /**
     * Visual variant of the accordion
     * @default 'default'
     */
    variant?: 'default' | 'card' | 'section' | 'docs' | 'hub';

    /**
     * Custom className for the container
     */
    className?: string;

    /**
     * Custom className for the content area
     */
    contentClassName?: string;

    /**
     * Callback when accordion state changes
     */
    onToggle?: (isOpen: boolean) => void;

    /**
     * Optional accent color for the 'hub' variant (e.g., 'primary', 'amber-500', etc.)
     */
    accentColor?: string;

    /**
     * Optional key for persisting open/closed state to localStorage
     */
    persistenceKey?: string;
}

export function Accordion({
    title,
    children,
    defaultOpen = false,
    icon,
    badge,
    variant = 'default',
    className = '',
    contentClassName = '',
    onToggle,
    persistenceKey,
    accentColor = 'primary'
}: AccordionProps) {
    const [isOpen, setIsOpen] = useState(defaultOpen);

    // Load initial state if persistenceKey is provided
    useEffect(() => {
        if (persistenceKey) {
            const savedState = localStorage.getItem(`accordion_${persistenceKey}`);
            if (savedState !== null) {
                setIsOpen(savedState === 'true');
            }
        }
    }, [persistenceKey]);

    const handleToggle = () => {
        const newState = !isOpen;
        setIsOpen(newState);
        onToggle?.(newState);

        if (persistenceKey) {
            localStorage.setItem(`accordion_${persistenceKey}`, String(newState));
        }
    };

    // Variant-specific styles
    const containerStyles = {
        default: 'bg-accordion-background rounded-xl border border-borders shadow-sm overflow-hidden',
        card: 'bg-accordion-background/80 backdrop-blur-md rounded-[2rem] border border-borders shadow-xl overflow-hidden transition-all duration-300',
        section: 'bg-accordion-background border border-borders rounded-lg overflow-hidden',
        docs: 'bg-primary/5 dark:bg-primary/5 rounded-2xl border-2 border-primary/20 dark:border-primary/20 shadow-sm overflow-hidden',
        hub: `bg-accordion-background/40 backdrop-blur-md rounded-[2.5rem] border border-borders shadow-2xl transition-all duration-500 ${isOpen ? 'ring-1 ring-primary/20 bg-accordion-background/70 shadow-primary/5' : 'hover:border-primary/30 hover:shadow-primary/5'}`
    };

    const buttonStyles = {
        default: 'w-full flex items-center justify-between p-4 text-left hover:bg-header-background/10 transition-colors',
        card: 'w-full flex items-center justify-between px-6 py-4 text-left group/card-btn',
        section: 'w-full flex items-center justify-between px-4 py-3 text-left bg-header-background/20 hover:brightness-95 dark:hover:brightness-110 transition-all border-b border-borders',
        docs: 'w-full flex items-center justify-between px-6 py-4 text-left hover:bg-primary/10 transition-colors bg-white/50 dark:bg-zinc-900/50',
        hub: 'w-full flex items-center justify-between px-8 py-7 text-left group/hub-btn'
    };

    const titleStyles = {
        default: 'text-base font-semibold text-page-title',
        card: 'text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] group-hover/card-btn:text-primary transition-colors',
        section: 'text-xs font-semibold text-page-subtitle uppercase tracking-wide',
        docs: 'text-xl font-black text-header-text',
        hub: 'flex flex-col'
    };

    const contentWrapperStyles = {
        default: 'transition-all duration-300 ease-in-out',
        card: 'transition-all duration-300 ease-in-out',
        section: '',
        docs: 'transition-all duration-300 ease-in-out',
        hub: 'transition-all duration-500 ease-[cubic-bezier(0.4,0,0.2,1)]'
    };

    const contentStyles = {
        default: 'p-4 border-t border-borders',
        card: 'px-6 pb-5 pt-1 overflow-hidden',
        section: 'p-4 border-t border-borders',
        docs: 'px-6 pb-6 pt-4 border-t border-primary/10',
        hub: 'px-8 pb-8 pt-2 overflow-hidden'
    };

    return (
        <div className={`${containerStyles[variant] || containerStyles.default} ${className}`}>
            <button
                onClick={handleToggle}
                className={buttonStyles[variant] || buttonStyles.default}
                aria-expanded={isOpen}
            >
                <div className="flex items-center gap-3 flex-1">
                    {icon && <span className="flex-shrink-0">{icon}</span>}
                    <div className="flex items-center gap-2 flex-1">
                        <div className={titleStyles[variant] || titleStyles.default}>{title}</div>
                        {badge && <span className="flex-shrink-0">{badge}</span>}
                    </div>
                </div>
                <div className={`p-2 rounded-full transition-all duration-300 ${isOpen ? 'bg-primary/10 text-primary' : 'bg-zinc-100 dark:bg-zinc-800/50 text-zinc-400'}`}>
                    <ChevronDown
                        size={16}
                        className={`transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}
                    />
                </div>
            </button>

            {variant === 'section' ? (
                // Simple show/hide for section variant (like ThemeSection)
                isOpen && (
                    <div className={`${contentStyles[variant]} ${contentClassName}`}>
                        {children}
                    </div>
                )
            ) : (
                // Smooth height transition for default and card variants
                <div
                    className={`${contentWrapperStyles[variant] || contentWrapperStyles.default} ${isOpen ? 'max-h-[2000px] opacity-100' : 'max-h-0 opacity-0 pointer-events-none'
                        }`}
                >
                    <div className={`${contentStyles[variant] || contentStyles.default} ${contentClassName}`}>
                        {children}
                    </div>
                </div>
            )}
        </div>
    );
}
