"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useEffect } from "react";
import { createPortal } from "react-dom";
import BlogList from "@/components/admin/BlogList";
import AdminCommandBar, { CommandBarButton } from "@/components/admin/AdminCommandBar";
import { Plus, PenTool, FileText, Globe, PenLine } from "lucide-react";
import { Breadcrumbs } from "@/components/admin/Breadcrumbs";
import { AdminHeader } from '@/components/admin/AdminHeader';
import { Post } from "@/types/blog";
import { QuickStatsNav } from "@/components/admin/QuickStatsNav";
import { useFeature } from "@/hooks/useFeatures";

import { useAdminActions } from "@/hooks/useAdminActions";
import { ArrowLeft } from "lucide-react";

export default function BlogListPage() {
  const router = useRouter();
  const blogEnabled = useFeature('blog');

  useAdminActions([
    {
      id: "create-post",
      label: "New Broadcast",
      onClick: () => router.push('/admin/editor/blog/new'),
      variant: "primary",
      icon: <Plus size={18} />,
      showOnMobile: true
    }
  ]);

  useEffect(() => {
    if (!blogEnabled) {
      router.push('/admin?feature=blog&disabled=true');
    }
  }, [blogEnabled, router]);

  const [posts, setPosts] = useState<Post[]>([]);

  useEffect(() => {
    async function fetchPosts() {
      try {
        const response = await fetch("/api/admin/blog");
        if (response.ok) {
          const data = (await response.json()) as any;
          setPosts(Array.isArray(data) ? data : (data.posts || []));
        }
      } catch (err) {
        console.error("Error fetching posts for header stats:", err);
      }
    }
    fetchPosts();
  }, []);

  const stats = [
    { label: 'Feed', value: posts.length, icon: <FileText size={12} />, color: 'text-indigo-600', bg: 'bg-indigo-500/10' },
    { label: 'Live', value: posts.filter(p => p.status === 'published').length, icon: <Globe size={12} />, color: 'text-emerald-500', bg: 'bg-emerald-500/10' },
    { label: 'Draft', value: posts.filter(p => p.status === 'draft').length, icon: <PenLine size={12} />, color: 'text-amber-500', bg: 'bg-amber-500/10' },
  ];

  return (
    <div className="bg-site-background">
      <div className="max-w-7xl mx-auto px-6 pt-0 space-y-8">

        <AdminHeader
          title={<>Blazing <span className="text-blue-500">Blogger</span></>}
          description="Manage your broadcast channels and articles."
          breadcrumbs={[
            { label: 'Admin', href: '/admin' },
            { label: 'Content', href: '/admin/content' },
            { label: 'Blog' }
          ]}
          badge={
            <div className="px-3 py-1.5 bg-blue-500/10 border border-blue-500/20 rounded-lg text-[10px] font-bold uppercase tracking-widest text-blue-600 dark:text-blue-400">
              Broadcast Ready
            </div>
          }
          actions={
            <div className="flex flex-col items-end gap-3">
              <Link
                href="/admin/content"
                className="px-3 py-1.5 bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 rounded-lg text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
              >
                <ArrowLeft size={12} /> Back
              </Link>
              <div className="flex items-center gap-2">
                {stats.map((stat, idx) => (
                  <div key={idx} className={`px-2 py-1 rounded-md border border-zinc-100 dark:border-zinc-800 flex items-center gap-1.5 ${stat.bg}`}>
                    <div className={stat.color}>{stat.icon}</div>
                    <span className={`text-[10px] font-bold ${stat.color}`}>{stat.value}</span>
                  </div>
                ))}
              </div>
            </div>
          }
        />

        <BlogList />
      </div>
    </div>
  );
}
