"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { createPortal } from "react-dom";
import AdminCommandBar, { CommandBarButton } from "@/components/admin/AdminCommandBar";
import { Save, AlertCircle, CheckCircle2, DollarSign, Settings, ShoppingBag, Image as ImageIcon, Wallet, ArrowLeft } from "lucide-react";
import { AdminLoadingState } from "@/components/admin/AdminLoadingState";
import { AdminHeader } from "@/components/admin/AdminHeader";
import { useFeature } from "@/hooks/useFeatures";
import { useRouter } from "next/navigation";

interface MonetizationConfig {
    google_adsense: {
        enabled: boolean;
        client_id: string;
        slots: {
            sidebar: string;
            post_top: string;
            post_bottom: string;
        }
    };
    amazon_affiliate: {
        enabled: boolean;
        tag: string;
        market: string;
    };
    custom_ads: Array<{
        id: string;
        name: string;
        enabled: boolean;
        type: string;
        content: string;
        link: string;
        placement: string;
    }>;
}

export default function MonetizationAdminPage() {
    const router = useRouter();
    const monetizationEnabled = useFeature('monetization');
    const [config, setConfig] = useState<MonetizationConfig | null>(null);
    const [isSaving, setIsSaving] = useState(false);
    const [saveStatus, setSaveStatus] = useState<"idle" | "saving" | "success" | "error">("idle");
    const [activeTab, setActiveTab] = useState<"adsense" | "amazon" | "custom">("adsense");
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        if (!monetizationEnabled) {
            router.push('/admin?feature=monetization&disabled=true');
        }
    }, [monetizationEnabled, router]);

    useEffect(() => {
        setMounted(true);
    }, []);

    useEffect(() => {
        fetch("/api/admin/monetization")
            .then(res => res.json())
            .then(data => setConfig(data as MonetizationConfig))
            .catch(err => console.error("Failed to load config", err));
    }, []);

    const handleSave = async () => {
        if (!config) return;
        setIsSaving(true);
        setSaveStatus("saving");

        try {
            const res = await fetch("/api/admin/monetization", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(config),
            });

            if (res.ok) {
                setSaveStatus("success");
                setTimeout(() => setSaveStatus("idle"), 3000);
            } else {
                setSaveStatus("error");
            }
        } catch {
            setSaveStatus("error");
        } finally {
            setIsSaving(false);
        }
    };

    const updateConfig = (path: string, value: string | boolean | string[] | number) => {
        if (!config) return;
        const newConfig = { ...config };
        const parts = path.split(".");
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        let current: any = newConfig;

        for (let i = 0; i < parts.length - 1; i++) {
            current = current[parts[i]];
        }
        current[parts[parts.length - 1]] = value;
        setConfig(newConfig);
    };

    if (!config) return (
        <div className="max-w-7xl mx-auto px-6 pt-20">
            <AdminLoadingState message="Connecting to treasury..." />
        </div>
    );

    return (
        <div className="min-h-screen bg-site-background pb-20">
            <AdminHeader
                title={<>Revenue <span className="text-yellow-500">Reactor</span></>}
                description="Treasury calibration and advertising stream configuration."
                breadcrumbs={[
                    { label: 'Admin', href: '/admin' },
                    { label: 'Growth', href: '/admin/growth' },
                    { label: 'Monetization' }
                ]}
                badge={
                    <div className="px-3 py-1.5 bg-yellow-500/10 border border-yellow-500/20 rounded-lg text-[10px] font-bold uppercase tracking-widest text-yellow-600 dark:text-yellow-400">
                        Operational
                    </div>
                }
                actions={
                    <Link
                        href="/admin/growth"
                        className="px-3 py-1.5 bg-gray-50 dark:bg-zinc-950 hover:bg-gray-100 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 rounded-lg text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
                    >
                        <ArrowLeft size={12} /> Back
                    </Link>
                }
            />

            {saveStatus === "success" && (
                <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 rounded-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
                    <CheckCircle2 size={20} />
                    <span className="text-sm font-bold uppercase tracking-wide">Treasury Synchronized Successfully</span>
                </div>
            )}

            {saveStatus === "error" && (
                <div className="p-4 bg-red-500/10 border border-red-500/20 text-red-600 rounded-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
                    <AlertCircle size={20} />
                    <span className="text-sm font-bold uppercase tracking-wide">Signal Interrupted: Update Failed</span>
                </div>
            )}

            {/* Tactical Grid Layout */}
            <div className="grid lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-6">
                    {/* Tabs - Modernized */}
                    <div className="bg-white dark:bg-zinc-900/50 border border-gray-100 dark:border-zinc-800 p-1.5 rounded-2xl flex gap-1 overflow-x-auto no-scrollbar">
                        {[
                            { id: 'adsense', label: 'AdSense', icon: <DollarSign size={14} /> },
                            { id: 'amazon', label: 'Amazon', icon: <ShoppingBag size={14} /> },
                            { id: 'custom', label: 'Custom', icon: <ImageIcon size={14} /> },
                        ].map((tab) => (
                            <button
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id as any)}
                                className={`flex-1 flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all ${activeTab === tab.id
                                    ? "bg-white dark:bg-zinc-800 text-primary shadow-sm border border-gray-100 dark:border-zinc-700"
                                    : "text-gray-500 hover:text-primary hover:bg-white/50 dark:hover:bg-zinc-800"
                                    }`}
                            >
                                {tab.icon}
                                {tab.label}
                            </button>
                        ))}
                    </div>

                    {/* Tab Content */}
                    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-300">
                        {activeTab === "adsense" && (
                            <div className="bg-card border border-border rounded-2xl p-6 lg:p-8 space-y-6 shadow-sm">
                                <div className="flex items-center justify-between mb-4">
                                    <div>
                                        <h2 className="text-xl font-bold">Google AdSense Config</h2>
                                        <p className="text-sm text-muted-foreground">Injected via automated placeholders in blog posts.</p>
                                    </div>
                                    <div className="relative inline-flex items-center cursor-pointer">
                                        <input
                                            type="checkbox"
                                            checked={config.google_adsense.enabled}
                                            onChange={(e) => updateConfig("google_adsense.enabled", e.target.checked)}
                                            className="sr-only peer"
                                        />
                                        <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                        <span className="ml-3 text-sm font-medium text-muted-foreground">{config.google_adsense.enabled ? "Active" : "Disabled"}</span>
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="space-y-4">
                                        <label className="block text-sm font-semibold">Publisher ID (client_id)</label>
                                        <input
                                            type="text"
                                            value={config.google_adsense.client_id}
                                            onChange={(e) => updateConfig("google_adsense.client_id", e.target.value)}
                                            placeholder="ca-pub-XXXXXXXXXXXXXXXX"
                                            className="w-full px-4 py-2.5 bg-background border border-border rounded-lg"
                                        />
                                    </div>
                                    <div className="space-y-4">
                                        <label className="block text-sm font-semibold">Sidebar Slot ID</label>
                                        <input
                                            type="text"
                                            value={config.google_adsense.slots.sidebar}
                                            onChange={(e) => updateConfig("google_adsense.slots.sidebar", e.target.value)}
                                            className="w-full px-4 py-2.5 bg-background border border-border rounded-lg"
                                        />
                                    </div>
                                    <div className="space-y-4">
                                        <label className="block text-sm font-semibold">Post Top Slot ID</label>
                                        <input
                                            type="text"
                                            value={config.google_adsense.slots.post_top}
                                            onChange={(e) => updateConfig("google_adsense.slots.post_top", e.target.value)}
                                            className="w-full px-4 py-2.5 bg-background border border-border rounded-lg"
                                        />
                                    </div>
                                    <div className="space-y-4">
                                        <label className="block text-sm font-semibold">Post Bottom Slot ID</label>
                                        <input
                                            type="text"
                                            value={config.google_adsense.slots.post_bottom}
                                            onChange={(e) => updateConfig("google_adsense.slots.post_bottom", e.target.value)}
                                            className="w-full px-4 py-2.5 bg-background border border-border rounded-lg"
                                        />
                                    </div>
                                </div>
                            </div>
                        )}

                        {activeTab === "amazon" && (
                            <div className="bg-card border border-border rounded-2xl p-6 lg:p-8 space-y-6 shadow-sm">
                                <div className="flex items-center justify-between mb-4">
                                    <div>
                                        <h2 className="text-xl font-bold">Amazon Associates</h2>
                                        <p className="text-sm text-muted-foreground">Global tag for rewrite logic in links (Auto-Amazon feature).</p>
                                    </div>
                                    <div className="relative inline-flex items-center cursor-pointer">
                                        <input
                                            type="checkbox"
                                            checked={config.amazon_affiliate.enabled}
                                            onChange={(e) => updateConfig("amazon_affiliate.enabled", e.target.checked)}
                                            className="sr-only peer"
                                        />
                                        <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-orange-500"></div>
                                        <span className="ml-3 text-sm font-medium text-muted-foreground">{config.amazon_affiliate.enabled ? "Active" : "Disabled"}</span>
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
                                    <div className="space-y-4">
                                        <label className="block text-sm font-semibold">Tracking Tag</label>
                                        <input
                                            type="text"
                                            value={config.amazon_affiliate.tag}
                                            onChange={(e) => updateConfig("amazon_affiliate.tag", e.target.value)}
                                            className="w-full px-4 py-2.5 bg-background border border-border rounded-lg"
                                        />
                                    </div>
                                    <div className="space-y-4">
                                        <label className="block text-sm font-semibold">Default Market</label>
                                        <select
                                            value={config.amazon_affiliate.market}
                                            onChange={(e) => updateConfig("amazon_affiliate.market", e.target.value)}
                                            className="w-full px-4 py-3 bg-background border border-border rounded-lg"
                                        >
                                            <option value="us">United States (.com)</option>
                                            <option value="uk">United Kingdom (.co.uk)</option>
                                            <option value="ca">Canada (.ca)</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        )}

                        {activeTab === "custom" && (
                            <div className="space-y-6">
                                {config.custom_ads.map((ad, idx) => (
                                    <div key={ad.id} className="bg-card border border-border rounded-2xl p-6 shadow-sm">
                                        <div className="flex items-center justify-between mb-6">
                                            <div className="flex items-center gap-3">
                                                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center text-primary">
                                                    <Settings size={20} />
                                                </div>
                                                <div>
                                                    <h3 className="font-bold">{ad.name}</h3>
                                                    <p className="text-xs text-muted-foreground font-mono">{ad.id}</p>
                                                </div>
                                            </div>
                                            <div className="relative inline-flex items-center cursor-pointer">
                                                <input
                                                    type="checkbox"
                                                    checked={ad.enabled}
                                                    onChange={(e) => {
                                                        const newList = [...config.custom_ads];
                                                        newList[idx].enabled = e.target.checked;
                                                        setConfig({ ...config, custom_ads: newList });
                                                    }}
                                                    className="sr-only peer"
                                                />
                                                <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                            </div>
                                        </div>

                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                            <div className="space-y-4">
                                                <label className="block text-sm font-semibold">Link URL</label>
                                                <input
                                                    type="text"
                                                    value={ad.link}
                                                    onChange={(e) => {
                                                        const newList = [...config.custom_ads];
                                                        newList[idx].link = e.target.value;
                                                        setConfig({ ...config, custom_ads: newList });
                                                    }}
                                                    className="w-full px-4 py-2.5 bg-background border border-border rounded-lg"
                                                />
                                            </div>
                                            <div className="space-y-4">
                                                <label className="block text-sm font-semibold">Placement</label>
                                                <select
                                                    value={ad.placement}
                                                    onChange={(e) => {
                                                        const newList = [...config.custom_ads];
                                                        newList[idx].placement = e.target.value;
                                                        setConfig({ ...config, custom_ads: newList });
                                                    }}
                                                    className="w-full px-4 py-3 bg-background border border-border rounded-lg"
                                                >
                                                    <option value="sidebar">Sidebar</option>
                                                    <option value="post_top">Post Top</option>
                                                    <option value="post_bottom">Post Bottom</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                ))}

                                <button className="w-full py-4 border-2 border-dashed border-border rounded-2xl text-muted-foreground hover:text-primary hover:border-primary transition-all font-medium">
                                    + Add New Custom Banner Slot (Stub)
                                </button>
                            </div>
                        )}
                    </div>

                </div>

                {/* Right Sidebar: Intel & Docs */}
                <div className="space-y-6">
                    <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 text-zinc-400 shadow-2xl">
                        <div className="flex items-center gap-3 mb-4 text-zinc-100">
                            <div className="w-8 h-8 rounded-lg bg-zinc-800 flex items-center justify-center text-lg">💡</div>
                            <h3 className="font-bold text-xs uppercase tracking-widest">Architect's Note</h3>
                        </div>
                        <p className="text-[11px] leading-relaxed opacity-70">
                            This module calibrates <code>monetization.json</code>.
                            Edge-side rewrite logic will detect these IDs and inject the appropriate reactors into your content streams dynamically.
                        </p>
                        <div className="mt-4 pt-4 border-t border-zinc-800 flex flex-col gap-2">
                            <div className="flex items-center justify-between text-[9px] font-bold uppercase tracking-tighter">
                                <span>Protocol</span>
                                <span className="text-emerald-500">Secure Edge</span>
                            </div>
                            <div className="flex items-center justify-between text-[9px] font-bold uppercase tracking-tighter">
                                <span>Sync Status</span>
                                <span className="text-blue-500">Wait for Deploy</span>
                            </div>
                        </div>
                    </div>

                    <div className="bg-gradient-to-br from-indigo-500 to-purple-600 p-6 rounded-3xl text-white shadow-xl shadow-indigo-500/10">
                        <h3 className="font-bold text-sm mb-2 flex items-center gap-2">
                            <span>🚀</span> Monetization Boost
                        </h3>
                        <p className="text-[10px] text-white/80 mb-4 leading-relaxed font-medium">
                            Enable the Amazon Auto-Link feature to automatically convert all commerce links into affiliate gateways.
                        </p>
                        <button className="w-full py-2 bg-white/20 hover:bg-white/30 backdrop-blur-md rounded-xl font-black text-xs uppercase tracking-widest transition-all border border-white/20">
                            View Docs
                        </button>
                    </div>
                </div>
            </div>
            {/* Admin Actions Portal */}
            {mounted && (() => {
                const portalTarget = document.getElementById('admin-actions-portal');
                if (!portalTarget) return null;

                return createPortal(
                    <div className="flex items-center gap-2 pointer-events-auto">
                        <CommandBarButton
                            onClick={handleSave}
                            disabled={isSaving}
                            label={isSaving ? "Syncing..." : "Deploy Config"}
                            variant="primary"
                            icon={<Save size={14} />}
                        />
                    </div>,
                    portalTarget
                );
            })()}
        </div>

    );
}
