'use client';

import { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { useTheme } from 'next-themes';
import { Page } from '@/types/page';
import { Post } from '@/types/blog';
import { Block } from '@/types/blocks';
import { replaceVariables } from '@/lib/variables';
import EditorSidebar from './EditorSidebar';
import EditorPreview from './EditorPreview';
import { usePopup } from './AdminPopupProvider';
import { CommandBarButton } from '@/components/admin/AdminCommandBar';
import { ArrowLeft, RotateCcw, Zap, Save, Check } from 'lucide-react';

// DnD Kit
import { DndContext, DragOverlay, DragStartEvent, DragEndEvent, useSensor, useSensors, PointerSensor, closestCorners } from '@dnd-kit/core';
import {
    findBlockById,
    updateBlockInTree,
    deleteBlockFromTree,
    moveBlockInTree,
    insertBlockInTree,
    duplicateBlockInTree
} from '@/lib/blocks/tree';
import { arrayMove } from '@dnd-kit/sortable';
import BlockCanvas from './blocks/BlockCanvas';
import BlockCard from './blocks/BlockCard';
import { getBlockDefinition } from '@/lib/blocks/registry';
import { generateMdxFromBlocks } from '@/lib/blocks/generator';

type EditorType = 'page' | 'blog';
type AnyContent = Page | Post;

interface UnifiedEditorProps {
    type: EditorType;
    initialContent: AnyContent;
    slug: string;
}

export default function UnifiedEditor({ type, initialContent, slug }: UnifiedEditorProps) {
    const router = useRouter();
    const popup = usePopup();

    // Editor State
    const [editorMode, setEditorMode] = useState<'rich-text' | 'builder'>('rich-text');
    const [content, setContent] = useState<AnyContent>(initialContent);
    const [blocks, setBlocks] = useState<Block[]>([]);

    // Sync State
    const [savedContent, setSavedContent] = useState<AnyContent>(initialContent);
    const [isSaving, setIsSaving] = useState(false);
    const [isSyncing, setIsSyncing] = useState(false);
    const [selectedBlockId, setSelectedBlockId] = useState<string | null>(null);

    // UI Refs
    const iframeRef = useRef<HTMLIFrameElement>(null);
    const containerRef = useRef<HTMLDivElement>(null);
    const [autoSaveEnabled, setAutoSaveEnabled] = useState(false);
    const [sidebarWidth, setSidebarWidth] = useState(50);
    const [isResizing, setIsResizing] = useState(false);

    // DnD State
    const [activeDragId, setActiveDragId] = useState<string | null>(null);

    // Initialize Blocks from metadata_json (only on mount/mode change, not on content updates)
    useEffect(() => {
        if (type === 'page' && (initialContent as Page).metadata_json) {
            try {
                const parsed = JSON.parse((initialContent as Page).metadata_json || '[]');
                if (Array.isArray(parsed)) {
                    setBlocks(parsed);
                    // Auto-switch to builder mode if blocks exist
                    if (parsed.length > 0 && editorMode === 'rich-text') {
                        setEditorMode('builder');
                    }
                }
            } catch (e) {
                console.error('Failed to parse blocks from metadata_json', e);
            }
        } else {
            // Clear blocks if metadata_json is empty/missing
            setBlocks([]);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [type]); // Only run on mount or type change

    // DnD Sensors
    const sensors = useSensors(
        useSensor(PointerSensor, { activationConstraint: { distance: 8 } })
    );

    const handleDragStart = (event: DragStartEvent) => {
        setActiveDragId(event.active.id as string);
    };


    const handleDragEnd = (event: DragEndEvent) => {
        const { active, over } = event;
        setActiveDragId(null);

        if (!over) return;

        // 1. Dragging from Library to Canvas
        if ((active.id as string).startsWith('lib-')) {
            const type = active.data.current?.type;
            const def = getBlockDefinition(type);
            if (def) {
                const newBlock: Block = {
                    id: crypto.randomUUID(),
                    type: type,
                    props: { ...def.defaultProps },
                    children: type === 'columns' ? [
                        { id: crypto.randomUUID(), type: 'column', props: {}, children: [] },
                        { id: crypto.randomUUID(), type: 'column', props: {}, children: [] }
                    ] : undefined
                };

                const overId = over.id as string;
                setBlocks(prev => insertBlockInTree(prev, overId, newBlock));
            }
        }
        // 2. Reordering within Canvas
        else {
            const activeId = active.id as string;
            const overId = over.id as string;

            if (activeId !== overId) {
                // If moving into a non-root droppable
                if (overId.startsWith('droppable-')) {
                    const parentId = overId.replace('droppable-', '');
                    setBlocks(prev => {
                        // Remove from old position and add to new parent
                        const cleaned = deleteBlockFromTree(prev, activeId);
                        const blockToMove = findBlockById(prev, activeId);
                        if (!blockToMove) return prev;
                        return insertBlockInTree(cleaned, overId, blockToMove);
                    });
                } else {
                    // Standard reorder or moving between lists
                    setBlocks(prev => {
                        const activeItem = findBlockById(prev, activeId);
                        if (!activeItem) return prev;

                        const cleaned = deleteBlockFromTree(prev, activeId);
                        return insertBlockInTree(cleaned, overId, activeItem);
                    });
                }
            }
        }
    };

    // Auto-Generate MDX from Blocks when in Builder Mode
    useEffect(() => {
        if (editorMode === 'builder') {
            const mdx = generateMdxFromBlocks(blocks);
            const json = JSON.stringify(blocks);

            // Only update content if changed to prevent loops
            // But we need to update 'content' state so 'hasChanges' becomes true
            // We check against current content to avoid redundant sets
            const currentJson = (content as Page).metadata_json;
            const currentMdx = content.content;

            if (json !== currentJson || mdx !== currentMdx) {
                setContent(prev => ({
                    ...prev,
                    content: mdx,
                    metadata_json: json
                } as AnyContent));
            }
        }
    }, [blocks, editorMode, content]);


    const startResizing = useCallback(() => {
        setIsResizing(true);
    }, []);

    const stopResizing = useCallback(() => {
        setIsResizing(false);
    }, []);

    const resize = useCallback((e: MouseEvent) => {
        if (isResizing && containerRef.current) {
            const newWidth = (e.clientX / containerRef.current.offsetWidth) * 100;
            if (newWidth > 20 && newWidth < 85) {
                setSidebarWidth(newWidth);
            }
        }
    }, [isResizing]);

    useEffect(() => {
        if (isResizing) {
            window.addEventListener('mousemove', resize);
            window.addEventListener('mouseup', stopResizing);
        } else {
            window.removeEventListener('mousemove', resize);
            window.removeEventListener('mouseup', stopResizing);
        }
        return () => {
            window.removeEventListener('mousemove', resize);
            window.removeEventListener('mouseup', stopResizing);
        };
    }, [isResizing, resize, stopResizing]);

    const hasChanges = useMemo(() => {
        return JSON.stringify(content) !== JSON.stringify(savedContent);
    }, [content, savedContent]);

    // Use content.slug instead of prop slug to ensure URL updates when saving
    const previewUrl = type === 'page' ? `/${content.slug}?preview=true` : `/blog/${content.slug}?preview=true`;

    const updatePreview = useCallback((newContent: AnyContent) => {
        setIsSyncing(true);
        if (iframeRef.current?.contentWindow) {
            iframeRef.current.contentWindow.postMessage({
                type: 'UPDATE_CONTENT',
                payload: {
                    title: replaceVariables(newContent.title),
                    content: replaceVariables(newContent.content),
                    description: replaceVariables(newContent.description || ''),
                    layout_id: (newContent as Page).layout_id,
                    metadata_json: (newContent as Page).metadata_json
                }
            }, '*');
        }
        setTimeout(() => setIsSyncing(false), 500);
    }, []);

    // Debounced update for Preview
    useEffect(() => {
        const timer = setTimeout(() => {
            if (hasChanges) {
                updatePreview(content);
            }
        }, 300);
        return () => clearTimeout(timer);
    }, [content, hasChanges, updatePreview]);

    // Auto-Save Logic
    useEffect(() => {
        if (!autoSaveEnabled || !hasChanges) return;
        const timer = setTimeout(() => {
            handleSave(false);
        }, 2000);
        return () => clearTimeout(timer);
    }, [content, autoSaveEnabled, hasChanges]);

    const { resolvedTheme } = useTheme();

    // Sync theme
    useEffect(() => {
        if (iframeRef.current?.contentWindow) {
            iframeRef.current.contentWindow.postMessage({
                type: 'SET_THEME',
                theme: resolvedTheme === 'dark' ? 'dark' : 'light'
            }, '*');
        }
    }, [resolvedTheme]);


    const handleSave = async (exit = true) => {
        setIsSaving(true);
        try {
            const isNew = slug === 'new';
            const endpoint = type === 'page'
                ? (isNew ? '/api/admin/pages' : `/api/admin/pages/${slug}`)
                : (isNew ? '/api/admin/blog' : `/api/admin/blog/${slug}`);

            const method = isNew ? 'POST' : 'PUT';
            const finalEndpoint = isNew
                ? (type === 'page' ? '/api/admin/pages' : '/api/admin/blog')
                : endpoint;

            const response = await fetch(finalEndpoint, {
                method: method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(content)
            });

            if (!response.ok) throw new Error('Failed to save');

            setSavedContent(content);

            if (exit) {
                router.push(type === 'page' ? '/admin/content/pages' : '/admin/content/blog');
                router.refresh();
            } else {
                if (isNew) {
                    router.push(`/admin/editor/${type}/${content.slug}`);
                } else {
                    router.refresh();
                }
            }
        } catch (err) {
            console.error(err);
            popup.error('Failed to commit changes to the edge.');
        } finally {
            setIsSaving(false);
        }
    };

    const handleRevert = async () => {
        const confirmed = await popup.confirm('Are you sure you want to revert all unsaved changes?', { isDanger: true });
        if (confirmed) {
            setContent(savedContent);
            // Re-sync blocks from saved content
            if (type === 'page' && (savedContent as Page).metadata_json) {
                try {
                    const parsed = JSON.parse((savedContent as Page).metadata_json || '[]');
                    if (Array.isArray(parsed)) setBlocks(parsed);
                } catch (e) { }
            }
            updatePreview(savedContent);
        }
    };

    const handleCancel = async () => {
        if (hasChanges) {
            const confirmed = await popup.confirm('You have unsaved changes. Exit anyway?', { isDanger: true });
            if (!confirmed) return;
        }
        router.push(type === 'page' ? '/admin/content/pages' : '/admin/content/blog');
    };

    useEffect(() => {
        const handleBeforeUnload = (e: BeforeUnloadEvent) => {
            if (hasChanges) {
                e.preventDefault();
                e.returnValue = '';
            }
        };
        window.addEventListener('beforeunload', handleBeforeUnload);
        return () => window.removeEventListener('beforeunload', handleBeforeUnload);
    }, [hasChanges]);





    // Identify drag item for overlay
    const activeBlockDef = activeDragId && activeDragId.startsWith('lib-')
        ? getBlockDefinition(activeDragId.replace('lib-', '') as any)
        : null;

    const activeBlockItem = activeDragId && !activeDragId.startsWith('lib-')
        ? blocks.find(b => b.id === activeDragId)
        : null;

    return (
        <DndContext
            sensors={sensors}
            collisionDetection={closestCorners}
            onDragStart={handleDragStart}
            onDragEnd={handleDragEnd}
        >
            <div
                ref={containerRef}
                className={`fixed inset-0 z-[100] flex h-screen overflow-hidden bg-gray-50 dark:bg-zinc-900 pb-14 ${isResizing ? 'cursor-col-resize select-none' : ''}`}
            >
                <EditorSidebar
                    type={type}
                    content={content}
                    onChange={setContent}
                    onSave={() => handleSave(true)}
                    onRevert={handleRevert}
                    onCancel={handleCancel}
                    isSaving={isSaving}
                    hasChanges={hasChanges}
                    isSyncing={isSyncing}
                    autoSaveEnabled={autoSaveEnabled}
                    onAutoSaveToggle={setAutoSaveEnabled}
                    width={`${sidebarWidth}%`}

                    // New Props
                    editorMode={editorMode}
                    onModeChange={setEditorMode}
                    blocks={blocks}
                    selectedBlockId={selectedBlockId}
                    onSelectedBlockChange={setSelectedBlockId}
                    onBlocksChange={setBlocks}
                />

                {/* Draggable Divider */}
                <div
                    onMouseDown={startResizing}
                    className="w-1.5 h-full cursor-col-resize hover:bg-primary transition-colors flex-shrink-0 z-50 bg-gray-200 dark:bg-zinc-800"
                />

                {/* Right Panel: Preview OR Canvas */}
                {editorMode === 'builder' ? (
                    <BlockCanvas
                        blocks={blocks}
                        selectedBlockId={selectedBlockId}
                        onSelectBlock={setSelectedBlockId}
                        onDeleteBlock={(id) => setBlocks(prev => deleteBlockFromTree(prev, id))}
                        onMoveBlock={(id, dir) => setBlocks(prev => moveBlockInTree(prev, id, dir))}
                        onDuplicateBlock={(id) => setBlocks(prev => duplicateBlockInTree(prev, id))}
                    />
                ) : (
                    <EditorPreview
                        ref={iframeRef}
                        url={previewUrl}
                        type={type}
                        isResizing={isResizing}
                    />
                )}
            </div>

            <DragOverlay>
                {activeBlockDef ? (
                    <div className="p-3 bg-white dark:bg-zinc-900 rounded-xl shadow-xl border-2 border-primary w-[300px] opacity-90 cursor-grabbing">
                        <div className="flex items-center gap-3">
                            <div className="p-2 rounded-lg bg-gray-50 dark:bg-zinc-800 text-primary">
                                {(() => { const Icon = activeBlockDef.icon; return <Icon size={20} />; })()}
                            </div>
                            <div className="font-semibold">{activeBlockDef.label}</div>
                        </div>
                    </div>
                ) : activeBlockItem ? (
                    <div className="p-3 bg-white dark:bg-zinc-900 rounded-xl shadow-xl border-2 border-primary w-[300px] opacity-90 cursor-grabbing">
                        Moving Block...
                    </div>
                ) : null}
            </DragOverlay>

            {/* Manual Admin Command Bar - Independent from Global Layout */}
            <div className="fixed bottom-0 inset-x-0 h-14 bg-white/90 dark:bg-zinc-900/90 backdrop-blur-xl border-t border-gray-200 dark:border-zinc-800 z-[120] flex items-center px-4 pointer-events-auto">
                <div className="flex items-center gap-2">
                    <CommandBarButton
                        label="Exit"
                        onClick={handleCancel}
                        icon={<ArrowLeft size={16} />}
                        variant="default"
                    />
                    <div className="w-px h-6 bg-gray-200 dark:bg-zinc-800/50 mx-1 hidden sm:block" />
                    <div className="hidden sm:block">
                        <CommandBarButton
                            label="Revert"
                            onClick={handleRevert}
                            icon={<RotateCcw size={16} />}
                            variant="danger"
                            disabled={!hasChanges}
                        />
                    </div>
                </div>

                {/* Center: Status & Save */}
                <div className="absolute left-1/2 -translate-x-1/2 hidden md:flex items-center gap-3">
                    <CommandBarButton
                        label={autoSaveEnabled ? "Auto-Save: On" : "Auto-Save: Off"}
                        onClick={() => setAutoSaveEnabled(!autoSaveEnabled)}
                        icon={<Zap size={16} />}
                        variant={autoSaveEnabled ? "primary" : "default"}
                    />

                    <div className={`flex items-center gap-2.5 px-3 py-1.5 rounded-lg border transition-all duration-300 ${isSyncing
                        ? 'bg-blue-500/10 border-blue-500/20 text-blue-500'
                        : 'bg-zinc-500/5 border-zinc-500/10 text-zinc-500/40'}`}>
                        <div className="relative flex items-center justify-center w-1.5 h-1.5">
                            {isSyncing && <span className="absolute inline-flex h-full w-full rounded-full opacity-75 animate-ping bg-current"></span>}
                            <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-current"></span>
                        </div>
                        <span className="text-[10px] font-bold uppercase tracking-widest">{isSyncing ? 'Syncing...' : 'Ready'}</span>
                    </div>

                    <CommandBarButton
                        label="Save"
                        onClick={() => handleSave(false)}
                        icon={<Save size={16} />}
                        variant="secondary"
                        disabled={!hasChanges || isSaving}
                    />
                </div>

                {/* Right: Exit Action */}
                <div className="ml-auto">
                    <CommandBarButton
                        label="Save & Exit"
                        onClick={() => handleSave(true)}
                        icon={<Check size={16} />}
                        variant="primary"
                        disabled={!hasChanges || isSaving}
                    />
                </div>
            </div>
        </DndContext >
    );
}
