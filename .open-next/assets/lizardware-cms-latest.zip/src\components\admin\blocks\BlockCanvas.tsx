'use client';

import { Block } from '@/types/blocks';
import BlockList from './BlockList';

interface BlockCanvasProps {
    blocks: Block[];
    selectedBlockId: string | null;
    onSelectBlock: (id: string | null) => void;
    onDeleteBlock: (id: string) => void;
    onMoveBlock: (id: string, direction: 'up' | 'down') => void;
    onDuplicateBlock: (id: string) => void;
}

export default function BlockCanvas({ blocks, selectedBlockId, onSelectBlock, onDeleteBlock, onMoveBlock, onDuplicateBlock }: BlockCanvasProps) {
    return (
        <div className="flex-1 bg-gray-100 dark:bg-zinc-950/50 p-8 overflow-y-auto h-full min-h-full">
            <div className="bg-white dark:bg-zinc-900 shadow-sm border border-gray-200 dark:border-zinc-800 rounded-xl overflow-hidden">
                <BlockList
                    blocks={blocks}
                    parentId="root"
                    selectedBlockId={selectedBlockId}
                    onSelectBlock={onSelectBlock}
                    onDeleteBlock={onDeleteBlock}
                    onMoveBlock={onMoveBlock}
                    onDuplicateBlock={onDuplicateBlock}
                    isRoot={true}
                />
            </div>
        </div>
    );
}
