import type { MediaStorage, MediaAsset } from './MediaStorage';

export class R2Storage implements MediaStorage {
    getName(): string {
        return 'Cloudflare R2';
    }

    async upload(file: File, metadata?: { altText?: string; caption?: string }): Promise<string> {
        // TODO: Implement R2 upload
        // 1. Get R2 client from Cloudflare binding
        // 2. Upload file to bucket
        // 3. Return public URL
        throw new Error('R2 storage not yet implemented');
    }

    async delete(url: string): Promise<void> {
        // TODO: Implement R2 delete
        throw new Error('R2 storage not yet implemented');
    }

    async list(): Promise<MediaAsset[]> {
        // TODO: Implement R2 list
        return [];
    }

    async get(id: string): Promise<MediaAsset | null> {
        // TODO: Implement R2 get
        return null;
    }
}
