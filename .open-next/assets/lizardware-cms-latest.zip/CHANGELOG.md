# Changelog

All notable changes to Lizardware CMS will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).


## [0.4.7] - 2026-01-05
### Added
- **Distribution Strategy Infrastructure**: Built the foundation for dual-model distribution (GitHub Fork vs Direct ZIP).
  - Created `docs/SETUP-FORK.md` and `docs/UPDATING.md` for GitHub Fork users.
  - Created `docs/SETUP-DIRECT.md` for direct ZIP-based deployments.
  - Built `scripts/package-release.js` (PowerShell-based) with branch safety locks to ensure clean release artifacts.
  - Created `.agent/workflows/release-process.md` to formalize the release cycle.
- **Admin Update Hub**: New system dashboard at `/admin/system/updates` for version tracking and update management.
  - Implemented `src/lib/git-detection.ts` to identify deployment mode.
  - Added mock `/api/admin/updates/check` API layer for update availability.

### Fixed
- **Development Environment Access**: Resolved critical issue where `npm run dev` required authentication (redirecting to login) despite missing D1 bindings.
  - Implemented `NODE_ENV === 'development'` bypass in `src/middleware.ts`
  - Restored ability to access `/admin` routes locally without configuring a database
  - Maintains security by strictly enforcing auth in Preview and Production environments

## [0.4.6] - 2026-01-05
### Fixed
- **CRITICAL: Database Initialization - Build-Time Migration**: Resolved "Too many subrequests" error by splitting database initialization into two phases:
  - **Phase 1 (Build-Time)**: Run structural migrations via `wrangler d1 execute` in GitHub Actions workflow (Step 6.5), bypassing Cloudflare Worker subrequest limits
  - **Phase 2 (Runtime)**: Setup Wizard now only runs lightweight business-type seed data (~10 statements), staying well under 50 subrequest limit
  - Updated `.github/workflows/deploy.yml` to automatically initialize D1 database structure after build, before deployment
  - Modified `/api/admin/init-database` to remove `INSTALL_STRUCTURE_SQL` execution, now only applies business-type seeds
  - Fixes "D1_ERROR: no such table: users" error during admin account creation
  - **Impact**: Database is fully initialized before first user request, eliminating runtime initialization errors
  
### Admin & Testing
- **Distribution Strategy Hub**: Added interactive `/admin/testing/distribution-strategy` page to compare GitHub Fork vs Direct Deployment workflows.
- **Testing Navigation**: Added "Strategic" quick-link card to Testing Hub index.

### Template Branch (Genericization)
- **Public Content White-Labeling**: Removed specific "Lizardware" branding from default content, schema, block registry, and SEO metadata.
- **Seed Data Refactor**: Genericized source SQL files for `software-dev` preset and sitemap generation.
- **Documentation**: Simplified `README.md` to serve as a user-friendly "Starter Template" guide.
- **Cleanup**: Removed internal developer documentation (`docs/`) to reduce clone size.

### Changed
- **Production Deployment Strategy**: Documented recommended approach using native Cloudflare Dashboard integration with environment variables instead of GitHub Actions-only deployment
- **Quick Start Documentation**: Fixed incorrect "Select Pages tab" instruction to correct "Select Get started next to Import a repository" (Workers deployment flow)

### Added
- **Deployment Documentation**: Created comprehensive production deployment guide (`production-deployment-walkthrough.md`) with step-by-step instructions
- **Repository Strategy Guide**: Documented decisions on repository structure, template repository feature usage, and naming conventions
- **Manual Database Init Guide**: Created fallback guide for initializing database via Cloudflare Dashboard Console

### Fixed (Jan 5, 2026 - Session 2: Wrangler Authentication)
-  **CRITICAL: Wrangler CLI Authentication**: Resolved persistent authentication errors blocking local database management
  - Fixed GitHub Actions Step 6.5 script: Changed from `require('./wrangler.jsonc')` to `fs.readFileSync()` + `JSON.parse()` to handle `.jsonc` extension
  - Identified and removed `.env.local` file containing placeholder values (`your_api_token_here`) that wrangler auto-loaded
  - Cleared stale wrangler authentication cache from `~/.wrangler` and `AppData/.wrangler`  
  - Re-authenticated via OAuth (browser-based) instead of unreliable API token method
  - Successfully initialized production database via Cloudflare Dashboard Console after wrangler CLI proved unreliable for large SQL files
- **Wrangler Configuration**: Updated `wrangler.jsonc` with correct production resource IDs (KV: `3b2de033748f4b158765b473e767e6e2`, D1: `e580d5ed-280a-4ee1-8532-021dc1bd1dbd`)

### Action Required
> **CRITICAL:** GitHub repository secrets contain incorrect Cloudflare Account ID. The `CLOUDFLARE_ACCOUNT_ID` secret must be updated from `4c2b9264fa7406616421045aa3019326` to `49fdf4c3f5ee28fcb734d719f1c26f2d` (Production Account) in repository Settings → Secrets and variables → Actions. Without this, automated deployments will fail to access Cloudflare resources.

### Fixed (Jan 4, 2026 - Prior Entry)
- **Database Initialization**: Fixed critical SQL parsing bug where inline comments (e.g., `-- uuid`) caused silent failure of table creation during setup/upgrades.
  - Updated `runSql` in `init-database` API to preserve newlines, ensuring comments don't swallow subsequent code.

## [0.4.5] - 2026-01-04
### Fixed
- **Theme Persistence System**: Resolved critical bug where saving a theme preset deleted global design tokens (border radius, spacing), causing the entire admin UI to revert to square corners.
  - Implemented **Deep Merging** in `/api/config/theme` to preserve existing architecture tokens when only colors/typography are updated.
  - Added robust **CSS Variable Fallbacks** in `CustomThemeManager` to prevent UI breakage if theme data is incomplete.
  - Expanded **Tailwind Radius Scale** to include `rounded-3xl` mapping in `globals.css` and `theme-tokens.css`.
- **Development Environment Compatibility**: Fixed `/api/admin/setup-lock` to gracefully handle missing D1 bindings in `npm run dev` mode.
  - API now defaults to "unlocked" state in dev mode (unless overridden by local config) without attempting D1 queries.
  - Mirrors behavior of `setup-status` API for consistent local development experience.

## [0.4.4] - 2026-01-04
### Added
- **Build-Time Provisioning**: Automated Cloudflare resource creation (KV, D1, R2) via `scripts/provision-cloudflare.js` in prebuild pipeline.
  - Zero-config setup: Auto-detects project name from `wrangler.jsonc`
  - Eliminates runtime API token exposure in Setup Wizard

  - Provisions resources automatically on first build/deploy
- **R2 Deployment Fix**: Updated build scripts to conditionally include R2 bindings only if explicitly configured, preventing build failures for accounts without R2 enabled.
- **System Diagnostics**: New `/admin/diagnostics` page showing real-time connection status for KV, D1, and R2 bindings.
- **Error Reporting**: Enhanced Setup Wizard error details with expandable JSON/Stack trace views.
- **Documentation**: Rewrote Deployment Guide and Quick Start to prioritize the new automated GitHub Actions workflow over manual configuration.
- **Documentation Audit**: Comprehensive overhaul of `.ai.docs/environments.md` to reflect v0.4.4 architecture and created `.ai.docs/environments-archive.md` for legacy methods.

### Changed
- **Setup Wizard Flow**: Removed resource provisioning steps from runtime wizard (now handled at build time). Wizard now focuses solely on content seeding.
- **Environment Configuration**: Added `.env.example` with build-time provisioning variables (`CLOUDFLARE_ACCOUNT_ID`, `CLOUDFLARE_API_TOKEN`).
- **Runtime Persistence**: Injected build-time Cloudflare variables into runtime environment via `next.config.ts` to support automatic provisioning in CI/CD (Pages/Workers) environments.

### Fixed
- **CRITICAL:** Changed Cloudflare resource naming from hyphens to underscores (`lizardware_cms_config_kv` instead of `lizardware-cms-config-kv`) to comply with Cloudflare API validation requirements
- **D1 Migration Parser**: Fixed critical bug where inline SQL comments (`-- comment`) caused "Incomplete input" errors during migration execution.
- **Authentication Error Handling**: Improved guidance for API token permission errors during setup/build.
- **Multi-User Forks**: Fixed project name collision issue by adding dynamic project naming to `generate-wrangler-config.js`
- **GitHub Actions Workflow**: Resolved `ENOENT: no such file` error by creating `scripts/wrangler.template.jsonc` and adding robustness to configuration generation.
- **Alpha Testing Guide**: Improved usability with always-visible copy buttons and comprehensive troubleshooting section for deployment failures.

### Fixed (Session Patch)
- **Admin Route Standardization**: Updated legacy admin links in documentation (`getting-started.mdx`, `alpha-tester-notes`) to point to new hub-based routes (`/admin/content/blog`, `/admin/design/theme`, etc.).
- **Codebase Hygiene**: Resolved syntax errors (mismatched tags) in `monetization`, `seo`, and `diagnostics` pages that were blocking type-checking.
- **Component Integrity**: Fixed missing props (`badge`) in `AdminHeader` usage across `diagnostics` and `profile` pages.
- **Navigation Sync**: Corrected import in `admin/design/nav` to ensure Navigation Intelligence works correctly.

## [0.4.3] - 2026-01-03
### Changed
- **Admin Navigation Architecture**: Complete restructuring into hierarchical hubs for improved scalability and UX
  - **Content Hub** (`/admin/content`): Blog, Pages, Media, Categories, Authors
  - **Design Hub (Visual Forge)** (`/admin/design`): Visual Identity, Theme Transformer, Features, Navigation
  - **Growth Hub** (`/admin/growth`): SEO Toolkit, Monetization
  - **System Hub** (`/admin/system`): Advanced Settings, Documentation, Roadmap, Changelog, Configuration
- **Global Navigation Sync**: Updated `OrbitalNav` component and mobile drawer to reflect new hierarchy
- **Hub Card Gradient System**: Standardized color tokens in `admin-hub-styles.ts` (added `indigo` gradient to `CARD_GRADIENTS`)
- **Theme System Refinement**: Introduced Tier 1.5 theme variables for granular component control
  - Added `accordionBackground`, `buttonBackground`, `cardBackground`, and `inputBackground` variables
  - Updated all 6 theme presets with calibrated component palettes
  - Migrated Homepage, Accordion, ContactForm, and Block components to use new variables
  - Reorganized Theme Transformer UI into logical foundations, components, and sections


### Fixed
- **500 Internal Server Errors**: Resolved critical production errors caused by static `fs`/`path` imports in non-Node environments
  - `src/lib/theme-server.ts`: Converted to dynamic imports in `getTheme()` function
  - `src/app/api/config/site/route.ts`: Converted to dynamic imports in GET/PUT handlers
  - **Impact**: Fixed crashes on `/admin/design` and `/favicon.ico` routes in Cloudflare Workers
- **Server-Side Rendering Compatibility**: Prevented Node.js module loading errors in Edge runtime
- **Auto-Provisioning Failure**: Fixed critical SQL parsing bug in `executeD1Migration` where valid SQL statements were discarded if they were preceded by comments (causing "no such table" errors during setup).
- **Troubleshooting & Support**: Integrated comprehensive troubleshooting documentation and "Build Token" error resolution
  - Added "Troubleshooting Guide" links to Setup Wizard and Quick Start documentation
  - Documented Cloudflare API Token requirements and Workers CI/CD error resolutions


**Files Changed**: 34 files (255 insertions, 160 deletions)  
**Git Commit**: f22020f  
**Value**: Scalable admin architecture for future module expansion; eliminated critical deployment blockers.

### Visual Polish (Session Patch)
- **Admin Dashboard Layout**: Removed `min-h-screen` and redundant padding from all admin pages to eliminate "ghost scrolling" behavior. The main layout now handles vertical spacing globally.
- **Accordion Component**: Introduced a new `hub` variant for admin dashboard section cards, featuring glassmorphism, accent colors, and refined interaction states.
- **Admin Header Standardization**: Applied the standardized `AdminHeader` component to Blog Authors, Categories, Media, and Content pages, ensuring a unified visual hierarchy.
- **Content Styling**: Standardized backgrounds (`bg-site-background`) and corner radii (`rounded-[2rem]`) across Feature Modules and Content Hub quick actions for a premium feel.
- **Footer Visibility**: Added explicit bottom margin (`mb-14`) to the footer to prevent it from being obscured by the fixed bottom navigation bar, and ensured text contrast is accessible.


## [0.4.2] - 2026-01-03
### Added
- **Block-Based Page Builder Core (Phase 1)**: Initial implementation of the block-based editing system
  - **Block Registry**: Foundation for modular, reusable UI components (`registry.tsx`)
  - **Block Renderer**: Recursive rendering engine for nested block structures (`BlockRenderer.tsx`)
  - **Drag-and-Drop Infrastructure**: Integrated `@dnd-kit` for visual block reordering
  - **Block Storage**: JSON-based serialization for page metadata persistence
  - **Block UI Library**: Sidebar library for discovery and insertion of new blocks
  - **Properties Panel**: Dynamic configuration UI with support for Rich Text, selects, and color pickers
- **Database Resilience**: Refactored SQL seeds to use `INSERT OR IGNORE`, preventing user content overwrites during upgrades.
- **New Business Presets**: Added `restaurant.sql`, `blog.sql`, `service.sql`, and `blank.sql` with specialized placeholder content.
- **Live Preview Engine**: Refactored the preview renderer with a reactive client-side wrapper (`LivePreviewWrapper`), enabling instant hot-refresh for Page Architecture (Layout) changes.
- **New Page Layouts**: Added 2 new specialized page layouts for the Classic Editor: "Documentation" (Sidebar Right) and "Hero Power" (Full Width).
- **Block Rendering Fixes**: Resolved issue where HTML tags from the WYSIWYG editor rendered literally in block previews.
- **Documentation Refactor**: Split `roadmap.md` into `tech-stack.md`, `architecture.md`, `strategy.md`.


## [0.4.1] - 2025-12-30
### Added
- **Cloudflare API Automation**: `setup/auto-provision` endpoint for creating KV, D1, R2 resources.
- **Setup Wizard Integration**: "Instant Provisioning" UI.

## [0.4.0] - 2025-12-30
### Added
- **Authentication**: Clerk integration, Role-Based Access Control (RBAC).
- **Security**: Middleware protection for `/admin` routes.
- **User Management**: `/admin/profile` and role badges.

## [0.3.35] - 2026-01-02
### Changed
- **Setup Wizard Safety Enhancement**: "Keep Existing Content" checkbox now defaults to checked for safer database operations.
  - Changed default state from `false` to `true` in `BusinessTypeStep`
  - Prevents accidental data loss during template/seed application
  - Particularly important for version upgrades and testing scenarios
  
### Added
- **Visual Warning System for Setup Wizard**:
  - Implemented red "Danger" mode styling when "Keep Existing Content" is unchecked
  - Added contextual messaging: "Safe Mode" vs "Destructive Mode"
  - Pulsing "Danger" badge appears when user opts for destructive database wipe
  - Explicit warning text: "This will WIPE your entire database and replace it with template defaults"

- **Admin UI Standardization - Phase 2**: Extended compact header design to 5 additional pages:
  - `/admin/config` (Settings Studio)
  - `/admin/nav` (Navigation Manager) 
  - `/admin/docs` (Documentation Hub)
  - `/admin/roadmap` (Project Roadmap)
  - `/admin/changelog` (Release History)
  - Applied same design pattern: integrated breadcrumbs, `p-5 md:p-6` padding, `pt-0` containers
  - Smaller decorative elements with `pointer-events-none`

**Value**: Completed visual unification of all 13 major admin pages and significantly improved setup safety to prevent accidental data loss.

## [0.3.34] - 2026-01-02
### Changed
- **Admin Hub Layout Polish**: Comprehensive refinement of all admin hub pages and sub-pages for improved space efficiency and visual consistency.
  - **Compact Header Design**:
    - Integrated breadcrumbs into header cards (saves vertical space)
    - Reduced padding throughout headers: `p-5 md:p-6` (from `p-6 md:p-8`)
    - Reduced page top padding: `pt-0` for hub containers, `pt-1` for admin layout
    - Smaller title sizing for better hierarchy: `text-2xl md:text-3xl`
    - Inline descriptions on desktop with vertical separator
    - Condensed mobile descriptions
    - Smaller decorative elements with `pointer-events-none`
  - **Pages Updated**:
    - **Hub Pages**: `/admin/growth`, `/admin/content`, `/admin/appearance`, `/admin/system`
    - **Sub-Pages**: `/admin/pages`, `/admin/blog`, `/admin/advanced`, `/admin/visual-identity`
  - **Action Hook Standardization**:
    - Migrated all pages from manual `createPortal` to `useAdminActions` hook
    - Standardized bottom navigation bar action buttons
    - Removed deprecated portal logic and `mounted` state
  - **Design Tokens Updated**:
    - `HUB_PAGE_STYLES.topPadding`: `pt-4` → `pt-0`
    - Admin layout main padding: `pt-8` → `pt-1`

### Fixed
- Removed unused `mounted` state from Pages Playground, Blog Manager, Advanced Settings, and Visual Identity pages
- Fixed missing imports for `useAdminActions` and `ArrowLeft` icons

**Value**: Minimized wasted vertical space across the admin dashboard, creating a more efficient and professional user experience. All hub pages now follow a consistent, compact design pattern.

## [0.3.32] - 2025-12-30
### Fixed
- **Admin Navigation**: Fixed React Error #310 in `/admin/nav` caused by `useMemo` hook placed after conditional returns - moved to top of component for consistent hook ordering
- **Edge Runtime Compliance**: Removed incompatible `runtime = 'edge'` export from routes API, allowing proper Node.js runtime via OpenNext
- **Environment Safety**: Refactored `src/lib/blog.ts` to use dynamic imports for Node.js modules (`fs`, `path`, `glob`, `gray-matter`, `marked`), preventing Edge bundling errors
- **Setup Wizard Mobile UX**: Improved copy button layouts with flex-wrap and responsive breakpoints for better mobile experience
- **Documentation**: Corrected Flash model references from "Gemini 2.0" to "Gemini 3.0" in project documentation

### Changed
- Blog utilities now lazy-load filesystem dependencies only when needed, improving compatibility with Cloudflare Workers runtime

**Value**: Restored critical admin functionality and ensured codebase compliance with multi-environment architecture patterns.

## [0.3.30] - 2025-12-30
### Added
- **Navigation Intelligence System**:
    - **Route Registry** (`src/lib/routes.ts`): Centralized list of all system routes and dynamic content paths.
    - **RoutePicker Component** (`src/components/admin/RoutePicker.tsx`): Smart autocomplete input for internal linking with 404 detection.
    - **Menu Builder Integration**: Updated Admin Nav structure editor to use RoutePicker.
- **Setup Wizard Flow Improvements**:
    - Reordered onboarding flow: Welcome Screen (Step 0) now appears *before* Technical Prerequisites (Step 1).
    - Validated step counting and progress bar visualization.

### Fixed
- Improved "Magic String" handling in navigation editor - users can now discover valid paths instead of guessing.

## [0.3.29] - 2025-12-30
### Added
- **Feature Flags Implementation**: Made existing feature flags fully functional across the application.
    - **Feature Utilities** (`src/lib/features.ts`, `src/hooks/useFeatures.ts`): Server and client-side functions for checking feature flags.
    - **Navigation Filtering**: `OrbitalNav` now dynamically shows/hides menu items based on feature flags (Blog, Media Library, Revenue Streams, Analytics, Newsletter).
    - **Route Guards**: Added protection to `/admin/blog`, `/admin/media`, and `/admin/monetization` pages - redirects to admin dashboard with warning if feature is disabled.
    - **Disabled Feature Warning**: Admin dashboard displays a yellow alert banner when users are redirected from disabled features, with link to Advanced Forge.
    - **Enhanced UI in Advanced Forge**: Feature flags now display with:
        - Status badges ("Active" / "Disabled")
        - Color-coded backgrounds (emerald for enabled, gray for disabled)
        - "(Hidden from navigation)" warning below disabled features
        - Improved toggle styling and accessibility

### Changed
- Feature flags are no longer just cosmetic placeholders - they now control actual application behavior
- Navigation dropdown items are filtered based on user's enabled features
- Advanced Forge feature section includes explanatory text about navigation hiding

**Value**: Completes the Business Type Architecture by making feature flags functional. Users can now truly customize their admin experience based on their business type, reducing clutter from unused features.


## [0.3.28] - 2025-12-29
### Added
- **Admin Hub Pages**: Created centralized landing pages for Content and System sections.
    - **Content Hub** (`/admin/content`): Overview page with quick stats (Posts, Pages, Categories, Authors), section cards, and quick action buttons for creating new content.
    - **System Core** (`/admin/system`): System administration page with version info, status indicators, and links to all system tools (Core Forge, Docs, Roadmap, Changelog, etc.).

### Changed
- **Navigation Structure**: Updated OrbitalNav dropdown links to point to proper hub pages.
    - Content dropdown now links to `/admin/content` (was `/admin/blog`)
    - System dropdown now links to `/admin/system` (was `/admin/advanced`)

**Value**: Improved navigation consistency and provides users with a helpful overview before diving into specific admin sections.

## [0.3.27] - 2025-12-29
### Added
- **Business Type Architecture**: Comprehensive unification of template, theme, and seed selection into a cohesive system.
    - **Business Type Registry**: 5 business types (Software Dev, Restaurant, Blog, Service, Blank Canvas) with recommended themes and feature flags.
    - **Unified Setup Flow**: New BusinessTypeStep combines business type selection with automatic database deployment.
    - **Merge Mode**: "Keep existing content" checkbox allows merging new seed data with existing database content.
    - **Feature Integration**: Each business type automatically configures feature flags based on business needs.

### Changed
- **Setup Wizard Reordering**: Moved "Welcome" (Forge Your Digital Realm) to Step 1, before infrastructure checks.
- **Reduced Steps**: Setup flow now 6 steps (down from 7) - Welcome → Resources → Business Type → Site Info → Review → Complete.
- **Removed Template Step**: Template selection unified with Business Type selection for streamlined onboarding.
- **Simplified Apply Process**: No longer applies complex theme configurations during setup - focuses on business type and feature flags only.

### Removed
- **Separate Template Selection Step**: Functionality absorbed into Business Type step.
- **Template Theme Application**: Removed complex theme override logic from setup wizard.

### Technical
- Removed `SiteTemplate` from setup wizard state (now uses `BusinessType`).
- Updated `init-database` API to accept `keepExisting` parameter.
- Cleaned up setup wizard to remove getAllTemplates() and template-related imports.

**Value**: Dramatically simplified onboarding experience while providing smart defaults. New users get coherent, business-appropriate starting content without manual coordination of disconnected systems.

## [0.3.26] - 2025-12-29
### Added
- **Unified Editor Theme Sync**: Complete synchronization of dark/light mode across the Editor Sidebar, Toolbar, and Live Preview iframe.
    - **Global Context**: Rich Text Editor now consumes `next-themes` context.
    - **Cross-Window Comms**: `SET_THEME` message broadcast to live preview for instant switching.
- **Page Layout Architecture**: Added ability to select "Standard" or "Minimal" layouts for custom pages.

### Changed
- **Admin Header Polish**: Refined "Data Matrix" (Quick Stats) component.
    - **Responsive Layout**: Stacks vertically on desktop (sidebar style) and flows horizontally on mobile.
    - **Typography**: Context-aware font sizing for better information density.
- **Unified Editor**: Standardized "Back" button and layout behavior.

## [0.3.24] - 2025-12-29

### Changed
- **Admin Popups Overhaul**: Replaced all native browser `alert()` and `confirm()` dialogs with a custom, promise-based `AdminPopupProvider`.
    - **Consistent UI**: All confirmations and alerts now match the application's glassmorphism design system.
    - **Enhanced UX**: Added "Danger" variants for destructive actions and success/error variants for feedback.
    - **Affected Areas**: `AuthorManager`, `VisualIdentity`, `ThemeEditor`, `SetupWizard`, and `UnifiedEditor`.

### Removed
- **ConfirmationModal**: Removed the legacy `ConfirmationModal` component (superseded by `AdminPopupProvider`).

## [0.3.23] - 2025-12-29
### Added
- **Software Development Preset**: Added a new "Software Dev" content preset with specialized migrations and seed content.
- **Content Seeding**: Pre-populated "About," "Features," and "Pricing" pages for the software preset.

## [0.3.22] - 2025-12-29
### Changed
- **Strategic Navigation Overhaul**: Complete refactor of the Admin Navigation system.
    - **OrbitalNav**: New unified component for top/bottom navigation bars.
    - **Pathfinding Station**: Enhanced Navigation Editor with "Orbital" design system and real-time preview theater.
    - **State Management**: Fixed drag-and-drop glitches and persistence issues in the nav editor.
    - **Mobile Optimization**: Improved drawer behavior and touch targets.
- **Breadcrumb Intelligence**: Auto-generated breadcrumbs based on URL structure, removing manual boilerplate from 5+ admin pages.

## [0.3.21] - 2025-12-29
### Added
- **Navigation Architecture Overhaul**: Reorganized the Admin Navigation into logical hubs: Content, Growth, Design, and System.
- **Media Library & SEO Toolkit**: Promoted these critical tools to the primary desktop navigation.
- **Reusable Dashboard Components**: Created modular `DashboardBanner`, `QuickLinkRow`, and `SystemStatusBubble` components for consistent admin UX.
- **Accordion State Persistence**: All admin dashboard sidebar cards now remember their expanded/collapsed state across sessions.
- **Responsive Quick Actions**: Vertical stack on desktop (space-efficient), horizontal row on mobile (height-efficient).

### Changed
- **Navigation Refactoring**: Merged "Appearance" and "Structure" into **Design Studio**; merged "Advanced" and "Docs" into **System Core**.
- **Deduplicated Site Configuration**: Removed redundant Site Name and Description fields from the Advanced Settings page; Visual Identity is now the single source of truth.
- **Standardized Action Buttons**: Verified all SEO and content management pages use the `AdminCommandBar` (Bottom Portal) for primary actions, removing non-standard inline buttons.
- **Dashboard Header**: Replaced "Quick Connection" card with functional "Quick Actions" navigation (Write Post, Manage Pages, Theme Transformer).
- **Dynamic Versioning**: All version displays now pull from centralized `VERSION` constant for consistency.

### Removed
- **Edge Operational Bubble**: Removed from bottom navigation bar (information now centralized in dashboard header); preserved as reusable component.
- **Redundant Quick Access**: Deleted sidebar accordion (functionality moved to primary header).

## [0.3.21] - 2025-12-29

### Changed
- **Admin Navigation**: Complete overhaul of Information Architecture (IA).
    - Grouped into 4 logical hubs: **Content**, **Growth**, **Design**, **System**.
    - Added direct desktop links for **Media Library** and **SEO Toolkit**.
- **Admin UX**: Standardized all primary actions (Save, Create, Revert) to the **Bottom Command Bar**.
    - Moved "Create Post" and "Create Page" from top headers to bottom bar.
    - Unified "Save" buttons in SEO editors.

### Removed
- **Legacy Config**: Deleted `src/app/(admin)/admin/config` (redundant).
- **Advanced Settings**: Removed duplicate "Site Information" form (now exclusively in Visual Identity).

## [0.3.20] - 2025-12-29

### Removed
- Deprecated `MarkdownEditor` component.

### Security / Performance
- Performance baseline established (`docs/performance/v0.3.20-baseline.md`).
- Validated admin dashboard dark mode stability.

## [0.3.19] - 2025-12-29

### Added
- **Deployment Activity Tracking** - Integrated a "Last Updated" timestamp in the Admin Command Center to track the latest edge deployment.

### Changed
- **Navigational Layout Optimization** - Moved the "Launch Site" button to the bottom status bar to consolidate external actions and improved the "Edge: Operational" status badge alignment.

## [0.3.18] - 2025-12-29

### Changed
- **Breadcrumb & UI Polish** - Standardized breadcrumb placement and improved navigational flow across admin sub-pages.

## [0.3.17] - 2025-12-29

### Added
- **Dynamic Wrangler Configuration** - Transitioned `wrangler.jsonc` to a generated build artifact, ensuring local build stability while maintaining CI/CD security.
- **Environment ID Injection** - Integrated `scripts/init-config.js` to automatically populate resource IDs from `.env.local` or Cloudflare Build Variables.
- **Simplified Local Setup** - Introduced `npm run setup:bindings` CLI tool to guide developers through configuring local Cloudflare bindings.
- **Comprehensive Configuration Guide** - Added `docs/developers/wrangler-configuration.md` covering architecture, setup, and troubleshooting.

### Changed
- **Blog List Standardization** - Comprehensive visual and functional overhaul to match the Pages Playground design.
- **Enhanced Content Metrics** - Integrated a new statistics bar showing live/draft transmission counts.
- **Smart Filtering & Sorting** - Implemented status-based filter tabs and a unified sorting system (Date, Title, Views).
- **Proactive Search** - Improved search engine matching across titles, slugs, excerpts, and authors with real-time feedback.
- **Git Hygiene** - Added `wrangler.jsonc` to `.gitignore` to prevent configuration drift and accidental secret commits.
- **Build Pre-requisites** - `npm run build` is now the mandatory entry point for all bundled deployments to ensure config generation.

### Fixed
- **Cloudflare Build Stability** - Resolved `D1_ERROR: no such table: posts` by explicitly skipping static generation during the production build phase (`generateStaticParams`).
- **OpenNext Bundle Compatibility** - Removed unsupported `edge` runtime declaration from `setup-lock` API route.
- **Admin Navigation** - Fixed broken blog editor link in `AdminLayout` to correctly point to the unified editor.


## [0.3.16] - 2025-12-29

### Added
- **Setup Wizard Visual Update** - Complete "Next-Gen" visual overhaul for `/setup` with glassmorphism and animations.
- **Sticky Environment Banners** - Environment indicators now stick to top/bottom of viewports site-wide for better developer visibility.
- **Dedicated Setup Layout** - `/setup` now has a focused layout (no global admin nav/footer) to reduce distraction.

### Changed
- **AdminHeaderHider** - Enhanced logic to handle `/setup` route specifically.
- **EnvironmentBanner** - Updated to be fully opaque and sticky-aware to prevent content scroll-through.
- **Page Transitions** - Added kinetic entrance animations to setup steps.

## [0.3.15] - 2025-12-29

### Added
- **Resizable Editor Layout** - 50/50 split view with draggable divider for Unified Editor.
- **Live Preview Polish** - High-contrast "Breathing" status badge and reduced padding.
- **Variable Rendering** - Live preview now resolves `{{variables}}` in real-time.

### Changed
- **Editor Toolbar** - Consolidated formatting options into dropdowns for cleaner UI.
- **Preview Behavior** - Improved pointer event handling during resizing.

## [0.3.7] - 2025-12-29

### Added
- **Environment-Aware Default Content** - New seeding system with three options (Professional, Demo, Blank)
- **Enhanced Setup Wizard** - Integrated environment selection into the database initialization step
- **Branch Management Strategy** - Established `main` → `develop` → `feature/*` workflow
- **Git Cleanup** - Automated deletion of 14+ stale local and remote branches
- **PR Template** - New `.github/PULL_REQUEST_TEMPLATE.md` with content audit checklist
- **Seed Optimization** - Separated structural migrations from seed content for lean production deployments

### Changed
- **Database Initialization** - API now supports targeted seeding based on user choice in wizard
- **Migration Structure** - Seed data moved from numbered migrations to `migrations/seeds/`

## [0.3.6] - 2025-12-28

### Added
- **Typography Controls Enhancement** - Converted all font sizes from `rem` to `px` for user familiarity
- **Separated Page Description Control** - Independent slider for site description (10-60px range)
- **Environment Architecture Documentation** - Comprehensive guide in `.ai.docs/environments.md`
- **Bundled Migration SQL** - Generated TypeScript file for edge-compatible initialization
- **Database Init Resilience** - API now handles redundant migration statements (e.g. duplicate columns) gracefully

### Fixed
- **Admin Config Page Errors** - Resolved undefined nested object access (seo, links, openGraph)
- **Merge-with-Defaults Pattern** - API routes now always return complete config structure
- **Database Init in Preview** - Fixed fs.readFileSync error and redundant column errors in Cloudflare Workers
- **Site Config Corruption** - Prevented incomplete saves from wiping nested fields

### Changed
- **Typography Ranges** - More intuitive px-based sliders (Title: 12-120px, Description: 10-60px, Body: 8-48px)
- **Default Typography** - Updated to px values (Title: 60px, Subtitle: 30px, Description: 24px, Base: 16px)

## [0.3.5] - 2025-12-27

### Added
- **Categories Management UI** - Full CRUD for blog categories in the admin dashboard.
- **Author Personnel System** - Migration of authors from JSON to D1 with a dedicated management UI.
- **SEO & Social Preview** - Real-time Google Search and Social Card preview in the blog editor.
- **Post View Tracking** - Automatic view count incrementation for public posts.
- **Scheduling Logic** - Backend logic to hide "Published" posts until their `scheduled_date` has passed.
- **Database Migration 023** - Expanded `posts` table and added `categories`, `authors`, `media`, and `blog_settings`.

### Changed
- **Blog UI** - Public blog posts now display featured images, categories, and view counts.
- **Admin Navigation** - Reorganized blog section to include Taxonomy (Categories) and Personnel (Authors).
- **Type Safety** - Improved API route typing and explicitly casted JSON responses.

## [Unreleased]


### Planned for v0.4.1+
- Version alignment and documentation updates
- Admin dashboard standardization and polish
- Content management improvements (draft/published status, bulk actions)
- Performance and build optimization
- **Authentication system** (Clerk integration - CRITICAL FOR BETA)
- Beta preparation and genericization
- Testing and validation suite

### v0.5.0 Beta Target Features
- Proper admin authentication (replacing Cloudflare Access)
- Role-based access control (Owner, Admin, Editor)
- Genericized codebase (removed Lizardware-specific branding)
- Complete end-user documentation
- Security audit and testing

## [0.3.3] - 2025-12-26

### Added
- **White-Label Footer Support** - Optional "Powered by Lizardware CMS" attribution with `whiteLabel` prop
- **Blog Post Status System** - Draft vs Published status toggle for blog posts
- **Database Migration 022** - Added post status tracking to database
- **Generic Template Content** - Removed hardcoded "Lizardware" branding from service pages and templates

### Changed
- **Mobile Navigation** - Improved header and admin header responsiveness
- **Blog Editor** - Enhanced with status management UI
- **Quick Start Guide** - Updated with latest deployment instructions
- **Documentation Generation** - Improved `generate-docs.js` script

### Fixed
- Mobile navigation display issues on smaller screens
- Generic content references to maintain white-label readiness

**Purpose:** Alpha release preparation - ensuring site name/logo editing, page management, and white-label capabilities for first external tester.

## [0.4.0] - 2025-12-26

### Summary
Consolidated work from v0.2.x releases into v0.4.0 baseline. This version represents completion of Phase 3 (Admin Foundation) and partial Phase 4 (Content Management Suite) features.

### Added - SEO Toolkit
- URL redirect management (301/302) with admin UI
- Robots.txt editor
- SEO setup wizard (6-step flow)
- Meta tag management (Open Graph, Twitter Cards)
- XML sitemap auto-generation
- SEO health score dashboard
- Database tables: `redirects`, `seo_config`, `seo_global_settings`, `seo_checkups`, `robots_txt`

### Added - Theme System
- **Theme Transformer** with advanced controls:
  - 7-shade color system with 10 swatches
  - Hero gradient system (start/end colors)
  - 4 Artstyle presets (Quick theme switching)
  - Design architecture controls (navbar height, spacing, shadows, corners)
  - Real-time preview synchronization
- **Appearance Dashboard:**
  - Theme preset system (4 built-in: Lizard Classic, Midnight Pro, Nature's Edge, Clean Minimal)
  - Social links configuration
  - Layout settings (nav style, footer config)
  - Custom CSS injection
- **Visual Identity System:**
  - Logo and favicon management
  - Banner and social media assets
  - Typography controls

### Added - Content Platform
- **Pages Editor:** MDX-based custom page creation with full CRUD
- **Template System:** 5 industry templates (MSP, Restaurant, Blogger, Service, Healthcare)
- **Setup Wizard:** 6-step onboarding (template selection, site info, environment config)
- **Feature Flags:** Database-backed feature management
- **Storage Abstraction:** MediaStorage interface with GitHub/R2 scaffolding
- **Advanced Settings Dashboard:** Template switcher, env vars UI, feature toggles

### Changed
- Admin tool names rebranded with creative, alliterative naming
- Navigation structure reorganized (Blog top-level, docs categorized)
- Dark mode for Next.js/Turbopack error overlay
- Header component now responsive to `--spacing-header` CSS variable

### Fixed
- Setup wizard input focus bug
- Theme API errors during template application
- KV migration errors
- D1 database integration issues
- ESLint warnings reduced to 0 errors

### Database Migrations
- Posts, pages, site_config, feature_flags
- SEO tables (010-013, 021)
- **Forum prep work:** migrations 014-020 (deferred to Phase 8 post-Beta)
- Setup lock mechanism (007)

### Added
- **Theme Selector v0.2.3** - Major theming system overhaul
  - Advanced color picker with theme shades and classic swatches
  - Floating color panel with visual shade selection
  - Hero gradient system with start/end color controls
  - Gradient toggle for hero sections
  - Quick Artstyles preset system for rapid design changes
  - Redesigned UI with creative workflow language
  - Real-time preview synchronization status indicator
  - Fixed sidebar layout with sticky header and footer
- **Design Architecture Controls** - Comprehensive spacing and styling
  - Navbar height slider (2rem - 6rem) now controls actual header height
  - Section Breath slider (0.25rem - 8rem) for vertical spacing
  - Inner Padding controls for container spacing
  - Element Gaps for grid/flex layouts
  - Shadow Density slider for elevation effects
  - Corner Roundness presets (0, 0.25, 0.5, 0.75, 1, 1.25rem)
- **Developer Experience Improvements**
  - Dark theme for Next.js/Turbopack error overlay
  - Comprehensive error styling to prevent eye strain during development
  - CSS variables for all design tokens

### Changed
- **Header Component** - Now responsive to `--spacing-header` CSS variable
- **Theme Transformer UI** - Reorganized with sections:
  - Global Atmosphere (light/dark mode toggle)
  - Quick Artstyles (theme presets)
  - Canvas & Backdrop (site backgrounds)
  - Reading Experience (typography colors)
  - Navigation & Identity (header/footer)
  - Component Ecosystem (info boxes, CTAs)
  - Impact Elements (hero section with gradient support)
  - Design Architecture (spacing, shadows, radius)
- **Theme Variable Injection** - Enhanced preview listener with all variables
  - Added hero gradient variables
  - Improved sidebar CSS variable scope
  - Better real-time sync

### Fixed
- Navbar Height slider now correctly controls height (previously controlled width)
- Section Breath range updated to include fractional values (0.25, 0.50, 0.75, 1, 1.25)
- Element Gaps minimum changed from 0.5 to 0.25 for finer control
- Rounded corners updated to use 1.25rem instead of 1.5rem
- Theme Transformer sidebar scroll behavior (fixed header/footer)
- Hero gradient colors now properly sync to preview

## [0.2.3] - 2025-12-20

### Added
- **Theme Selector Branch** - Advanced color picker development
- Initial gradient support implementation
- Color picker UI with swatches and shades

## [0.2.2] - 2025-12-20

### Added
- **Appearance Settings Dashboard** - New centralized UI at `/admin/appearance`
  - Site Identity: Logo, favicon, and banner/OG image management
  - Social Links: GitHub and Twitter/X integration
  - Display & Layout: Default color mode, navigation bar style, footer configuration
  - Advanced Customization: SEO defaults (title template, meta description), custom CSS
  - Collapsible sections using ThemeSection component
  - Cross-linking to Theme Transformer for granular design control
- **Theme Presets System** - 4 pre-built themes
  - Lizard Classic (signature slate/orange)
  - Midnight Pro (high-contrast violet)
  - Nature's Edge (earth-toned green)
  - Clean Minimal (neutral blue)
- **Hero Section Theming** - Dedicated controls
  - Hero background color
  - Hero text color
  - Integration with theme presets

### Changed
- Navigation label updated from "Settings" to "Documentation"
- Admin dashboard now links to Appearance hub

## [0.2.1] - 2025-12-20

### Changed
- **Feature Pages Content** - Professional, detailed content for all 6 feature pages
- Enhanced descriptions with real-world examples and use cases
- Added specific benefits and metrics to performance and security features

## [0.2.0] - 2025-12-19

### Added
- **Site Template System** - Industry-specific quick-start templates
  - 5 templates: MSP, Restaurant, Blogger, Service Industry, Healthcare
  - Each template includes custom navigation, theme presets, and feature configurations
- **Setup Wizard** - 6-step onboarding flow for new sites
  - Welcome screen with feature highlights
  - Template selection with preview
  - Site information collection
  - Environment configuration
  - Review and confirmation
  - Completion with quick actions
- **Feature Flag System** - Database-backed feature management
  - Toggle features on/off per site
  - Supports: blog, gallery, newsletter, monetization, comments, service pages, menu, booking, customer portal, analytics
- **Environment Configuration** - Deployment settings management
  - Site URL configuration
  - Cloudflare Account ID
  - Storage provider selection (GitHub/R2)
  - GitHub token and repository (optional)
  - Creates `.env.local` automatically
- **Storage Abstraction Layer** - Dual provider support
  - `MediaStorage` interface for pluggable storage
  - GitHub storage implementation (scaffolded)
  - R2 storage implementation (scaffolded)
  - Factory pattern for runtime provider selection
- **Advanced Settings Dashboard** - Central configuration UI at `/admin/advanced`
  - Template switcher
  - Site information editor
  - Environment variables UI
  - Feature toggle controls
  - Reset to defaults option

### Changed
- **Admin Dashboard Rebranding** - Creative, alliterative tool names
  - Blog Editor → Blazing Blogger 🔥
  - Pages Editor → Page Playground 🎪
  - Theme Engine → Theme Transformer ✨
  - Navigation Editor → Nifty Navigation 🧭
  - General Settings → Settings Studio 🎛️
  - Integrations → Sync Station 🔄
  - Site Analytics → Traffic Tracker 📊
  - Monetization Engine → Revenue Reactor 💸
  - Activity Logs → History Hub 📜
- **Navigation Structure** - Reorganized for better UX
  - Blog moved to top-level navigation
  - Documents organized into categories (Getting Started, Configuration, Content Management, Help)
  - Services renamed to Features with CMS-focused content
- **Version Bumped** - From 0.1.7 to 0.2.0 (major feature release)

### Fixed
- **Setup Wizard Input Focus Bug** - Fixed React re-render causing focus loss in form fields
- **Theme API Error** - Fixed error when applying template theme colors
- **Blog API MDX Fallback** - Improved error handling for missing content
- **Navigation 404 Errors** - Fixed markdown rendering with `marked` library
- **Documentation Rendering** - Enhanced GitHub-style markdown styling

## [0.3.0] - 2025-12-20

### Added - Admin Dashboard & Blog Engine
- D1 database integration with hybrid storage (D1 + MDX)
- Blog API endpoints (full CRUD operations)
- MDX pipeline with frontmatter support
- WYSIWYG editor (Tiptap) with custom CSS styling:
  - H5/H6 headers, horizontal rules, clear formatting
  - Code blocks, task lists, text alignment
  - Link, image, and table support
- GitHub API integration for Git-backed storage
- Author & tag taxonomy with directory/detail pages
- Slug UX (auto-populate from title, manual override)

### Added - Admin UI
- Cloudflare Access protection
- Blog post editor with live preview
- Theme editor with semantic color controls
- Navigation config editor (JSON-backed)
- Site config editor (SEO, branding, social)
- Monetization admin (AdSense, Amazon, banners)

### Infrastructure
- Tooling upgrades (npm audit, dependencies)
- Build optimization (OpenNext --noMinify)
- KV-based theme loading for Cloudflare Workers
- Next.js 15.1.3 compatibility documented

### Added
- **Pages Editor** - WYSIWYG editing for static pages
  - Admin UI at `/admin/pages` with list and editor views
  - D1 database integration for page metadata
  - MDX-based page storage architecture
  - API routes: `/api/admin/pages/*`
- **D1 Database Migrations** - Structured schema changes
  - Pages table with metadata
  - Migration tracking

### Fixed
- **Theme Editor 500 Errors** - KV migration complete
- **Config Editor 500 Errors** - KV migration complete
- **Blog Editor GitHub Token Errors** - D1 migration complete
- **ESLint Warnings** - Reduced to 0 errors

### Changed
- **KV Storage Migration** - Theme and config now use Cloudflare KV for production
- **Build Optimization** - OpenNext deployment improvements

## [0.2.0] - 2025-12-15

### Added
- Next.js App Router migration (from Pages Router)
- Route Groups: `(pages)`, `(categories)`, `(admin)` organization
- Component architecture: `ui/`, `layout/`, `sections/` folders
- Logic separation: `src/lib/` utilities
- TypeScript strict mode enabled
- Tailwind CSS 4 integration

### Added
- **Dark Mode** - Persistent theme switching with `next-themes`
- **Metadata System** - Proper SEO for all pages
- **Favicon** - Site branding improvements

### Fixed
- **Build Errors** - Resolved local development issues
- **Deployment Pipeline** - Cloudflare Pages integration working

## [0.1.5] - 2025-12-09

### Added
- **Blog Publishing Workflow** - Enhanced WYSIWYG editor
  - Tiptap editor with custom styling
  - H5/H6 support, horizontal rules, clear formatting
- **MDX Content Support** - Hybrid D1 + MDX storage
- **Author & Tag Taxonomy** - Directory and detail pages

### Changed
- **Navigation Layout** - Improved responsive design
- **Component Architecture** - Organized into `ui/`, `layout/`, `sections/`

## [0.1.0] - 2025-12-10

### Initial Release
- GitHub repository setup
- Cloudflare Pages + Workers deployment pipeline
- Lizardware brand identity (logo, colors, typography)
- Dark mode with `next-themes` persistence
- Basic blog engine (D1 + MDX)
- Admin dashboard skeleton
- Navigation management
- Responsive dark/light theme system

### Added
- **Initial Release** - Lizardware CMS launched
- **Next.js 15** - Modern React framework with App Router
- **Cloudflare Pages** - Edge deployment
- **Cloudflare Workers** - Serverless API routes
- **D1 Database** - SQLite at the edge
- **Blog Engine** - CRUD operations for blog posts
- **Admin Dashboard** - Protected with Cloudflare Access
- **Theme Customization** - Visual theme editor
- **Navigation Management** - JSON-backed navigation config
- **Site Configuration** - SEO, branding, social settings
- **Monetization** - AdSense, Amazon Affiliates integration
- **Tailwind CSS 4** - Utility-first styling

---

## Version Numbering Strategy (Updated Dec 26, 2025)

**Moving Forward:**
- **v0.4.x** - Quick wins + Beta preparation (current phase)
- **v0.5.0** - BETA RELEASE 🚀 (target milestone)
- **v0.6.x** - Beta improvements
- **v0.7.x** - White-label & polish
- **v1.0.0** - Production release (stable, public)

**Increment Rules:**
- **Patch (0.4.X):** Bug fixes, minor improvements
- **Minor (0.X.0):** New features, major milestones
- **Major (X.0.0):** Production-ready releases

**Current Version:** 0.4.0 (SEO Toolkit & Theme System)  
**Next Milestone:** 0.5.0 (First Public Beta Release)  

**Roadmap Alignment Note:** 
As of December 26, 2025, version tracking is now strictly aligned with the roadmap. All changes will be properly versioned and committed to Git.

---

**Last Updated:** January 3, 2026  
**Branch:** `main`
