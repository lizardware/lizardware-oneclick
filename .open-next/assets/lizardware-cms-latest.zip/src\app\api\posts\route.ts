import { NextResponse } from 'next/server';
import { getAllPosts } from '@/lib/blog';

export async function GET() {
  console.log('[API] GET /api/posts triggered');

  try {
    // Use getAllPosts() which handles both D1 and MDX fallback
    // Force 'published' status so public API never leaks drafts
    const posts = await getAllPosts({ status: 'published' });

    console.log(`[API] Found ${posts.length} posts`);

    return NextResponse.json(posts);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    const stack = error instanceof Error ? error.stack : undefined;
    console.error('[API] Error fetching posts:', message);
    return NextResponse.json({
      error: message,
      stack: stack
    }, { status: 500 });
  }
}
