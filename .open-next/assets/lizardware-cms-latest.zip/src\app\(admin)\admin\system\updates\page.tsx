'use client';

import { useState, useEffect } from 'react';
import { AdminHeader } from "@/components/admin/AdminHeader";
import { HUB_PAGE_STYLES } from "@/lib/admin-hub-styles";
import { ArrowLeft, RefreshCw, Zap, GitFork, Package, ShieldCheck, ChevronRight, ExternalLink, AlertTriangle, CheckCircle2, Info } from "lucide-react";
import Link from "next/link";

interface UpdateInfo {
    currentVersion: string;
    latestVersion: string;
    isUpdateAvailable: boolean;
    releaseDate: string;
    changelog: string[];
    critical: boolean;
}

export default function UpdatesPage() {
    const [loading, setLoading] = useState(true);
    const [updateInfo, setUpdateInfo] = useState<UpdateInfo | null>(null);
    const [repoMode, setRepoMode] = useState<'fork' | 'direct' | 'unknown'>('unknown');

    useEffect(() => {
        checkUpdates();
        // In a real app, repoMode detection would happen via a server-side lib
        // For alpha, we'll default to detection logic
        fetch('/api/admin/updates/check')
            .then(res => res.json())
            .then(data => {
                setUpdateInfo(data as UpdateInfo);
                setLoading(false);
            });
    }, []);

    const checkUpdates = () => {
        setLoading(true);
        // Simulate check
        setTimeout(() => setLoading(false), 800);
    };

    return (
        <div className={HUB_PAGE_STYLES.container}>
            <div className={`${HUB_PAGE_STYLES.maxWidth} ${HUB_PAGE_STYLES.topPadding} space-y-6 pb-20`}>
                <AdminHeader
                    title={<>System <span className="text-emerald-500">Updates</span> 🚀</>}
                    description="Keep your CMS secure and up-to-date with the latest improvements."
                    badge={
                        <div className="px-3 py-1.5 bg-zinc-100 dark:bg-zinc-800 rounded-lg text-[10px] font-bold uppercase tracking-widest text-zinc-500">v0.4.7</div>
                    }
                    breadcrumbs={[
                        { label: 'Admin', href: '/admin' },
                        { label: 'System', href: '/admin/system' },
                        { label: 'Updates' }
                    ]}
                    actions={
                        <Link
                            href="/admin/system"
                            className="px-3 py-1.5 bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 border border-zinc-200 dark:border-zinc-700 rounded-lg text-[10px] font-bold uppercase tracking-widest text-zinc-500 transition-colors flex items-center gap-2"
                        >
                            <ArrowLeft size={12} /> Back
                        </Link>
                    }
                />

                <div className="grid lg:grid-cols-3 gap-6">
                    {/* Status Card */}
                    <div className="lg:col-span-2 space-y-6">
                        <div className="bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200 dark:border-zinc-800 p-8 shadow-sm">
                            <div className="flex items-start justify-between mb-8">
                                <div className="flex items-center gap-4">
                                    <div className={`p-4 rounded-2xl ${updateInfo?.isUpdateAvailable ? 'bg-orange-100 dark:bg-orange-900/30 text-orange-600' : 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600'}`}>
                                        {updateInfo?.isUpdateAvailable ? <Zap size={32} /> : <ShieldCheck size={32} />}
                                    </div>
                                    <div>
                                        <h2 className="text-2xl font-black text-zinc-900 dark:text-zinc-100">
                                            {updateInfo?.isUpdateAvailable ? 'Update Available!' : 'System Up to Date'}
                                        </h2>
                                        <p className="text-sm text-zinc-500">
                                            Currently running v{updateInfo?.currentVersion || '...'}
                                        </p>
                                    </div>
                                </div>
                                <button
                                    onClick={checkUpdates}
                                    disabled={loading}
                                    className="p-2 bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 rounded-xl transition-all"
                                >
                                    <RefreshCw size={18} className={loading ? 'animate-spin' : ''} />
                                </button>
                            </div>

                            {updateInfo?.isUpdateAvailable && (
                                <div className="space-y-6 animate-in fade-in slide-in-from-top-2 duration-300">
                                    <div className="p-6 bg-zinc-50 dark:bg-zinc-950 rounded-2xl border border-zinc-100 dark:border-zinc-800">
                                        <div className="flex items-center gap-2 text-sm font-bold text-zinc-900 dark:text-zinc-100 mb-4">
                                            <Zap size={16} className="text-orange-500" /> What's New in v{updateInfo.latestVersion}
                                        </div>
                                        <ul className="space-y-3">
                                            {updateInfo.changelog.map((item, i) => (
                                                <li key={i} className="flex items-start gap-2 text-xs text-zinc-600 dark:text-zinc-400">
                                                    <div className="w-1.5 h-1.5 rounded-full bg-orange-500 mt-1.5 shrink-0" />
                                                    {item}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>

                                    <div className="p-6 bg-orange-500/5 border border-orange-500/20 rounded-2xl flex items-center justify-between">
                                        <div className="flex items-center gap-3">
                                            <AlertTriangle className="text-orange-500" size={24} />
                                            <div>
                                                <div className="text-sm font-black text-orange-600 dark:text-orange-400 uppercase tracking-widest">Action Required</div>
                                                <p className="text-xs text-orange-800/60 dark:text-orange-200/40">Choose your update path below to apply v{updateInfo.latestVersion}.</p>
                                            </div>
                                        </div>
                                        <button className="px-6 py-2.5 bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold rounded-xl transition-all shadow-lg shadow-orange-500/20 underline decoration-white/30 offset-2">
                                            Begin Upgrade
                                        </button>
                                    </div>
                                </div>
                            )}

                            {!updateInfo?.isUpdateAvailable && (
                                <div className="p-12 text-center space-y-4 text-zinc-400">
                                    <CheckCircle2 size={48} className="mx-auto text-emerald-500/50 mb-6" />
                                    <p className="text-sm font-medium">You are running the latest version of Lizardware CMS.</p>
                                    <div className="text-[10px] uppercase font-bold tracking-[0.2em] opacity-50">Last checked: Just now</div>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Sidebar: Implementation Mode */}
                    <div className="space-y-6">
                        <div className="bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200 dark:border-zinc-800 p-8 shadow-sm">
                            <h3 className="text-sm font-black uppercase tracking-widest text-zinc-400 mb-6">Update Strategy</h3>

                            <div className="space-y-6">
                                {/* GitHub Fork Strategy */}
                                <div className="relative pl-8 pb-8 border-l border-zinc-100 dark:border-zinc-800">
                                    <div className="absolute -left-3 top-0 p-1.5 bg-orange-500 rounded-lg text-white">
                                        <GitFork size={14} />
                                    </div>
                                    <h4 className="text-sm font-bold text-zinc-900 dark:text-zinc-100 mb-2">GitHub Fork</h4>
                                    <p className="text-[11px] text-zinc-500 leading-relaxed mb-4">Best for developers. Pull from <code>upstream/template</code> and merge manually.</p>
                                    <a
                                        href="https://github.com/Lizardministrator/Lizardware-Dev/blob/develop/docs/UPDATING.md"
                                        target="_blank"
                                        className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-orange-500 hover:text-orange-600 transition-colors"
                                    >
                                        Read Guide <ExternalLink size={10} />
                                    </a>
                                </div>

                                {/* Direct ZIP Strategy */}
                                <div className="relative pl-8">
                                    <div className="absolute -left-3 top-0 p-1.5 bg-blue-500 rounded-lg text-white">
                                        <Package size={14} />
                                    </div>
                                    <h4 className="text-sm font-bold text-zinc-900 dark:text-zinc-100 mb-2">Direct ZIP</h4>
                                    <p className="text-[11px] text-zinc-500 leading-relaxed mb-4">Fastest for users. Download the new release and redeploy via <code>wrangler</code>.</p>
                                    <Link
                                        href="/admin/system/docs"
                                        className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-blue-500 hover:text-blue-600 transition-colors"
                                    >
                                        View Docs <ExternalLink size={10} />
                                    </Link>
                                </div>
                            </div>
                        </div>

                        {/* Quick Help */}
                        <div className="bg-emerald-500/5 dark:bg-emerald-500/10 rounded-3xl border border-emerald-500/20 p-8 group hover:bg-emerald-500/10 transition-all cursor-help">
                            <h3 className="text-sm font-bold text-emerald-600 dark:text-emerald-400 mb-2 flex items-center gap-2">
                                <Info size={16} /> Update Tips
                            </h3>
                            <p className="text-[11px] text-emerald-700/60 dark:text-emerald-300/40 leading-relaxed">
                                Always back up your database before applying updates. Significant updates may require running SQL migrations shown in the changelog.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
