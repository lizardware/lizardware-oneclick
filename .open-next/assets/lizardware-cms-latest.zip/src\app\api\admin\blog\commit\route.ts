import { NextRequest, NextResponse } from "next/server";
import { upsertPostToD1 } from "@/lib/blog-storage";
import { getD1Database } from "@/lib/cloudflare";

/**
 * POST /api/admin/blog/commit
 * 
 * Admin endpoint to save blog post to D1 database.
 * Protected by Cloudflare Access at edge (check CF_Authorization header in production).
 * 
 * Request body:
 * {
 *   title: string
 *   slug: string
 *   date: string (YYYY-MM-DD)
 *   author?: string
 *   author_id?: string
 *   tags?: string[]
 *   description?: string
 *   status?: "draft" | "published"
 *   body: string (markdown content)
 * }
 */
export async function POST(request: NextRequest) {
  try {
    // Verify Cloudflare Access token in production
    const cfAuth = request.headers.get("cf-authorization");
    if (!cfAuth && process.env.NODE_ENV === "production") {
      console.warn(
        "Warning: cf-authorization header missing in production. Ensure Cloudflare Access is configured."
      );
    }

    const body = await request.json() as {
      title: string;
      slug: string;
      date: string;
      author?: string;
      author_id?: string;
      tags?: string[];
      description?: string;
      excerpt?: string;
      status?: "draft" | "published";
      featured_image_id?: string;
      category_id?: string;
      scheduled_date?: string;
      body: string;
    };

    // Validate required fields
    if (!body.title || !body.slug || !body.body) {
      return NextResponse.json(
        { error: "Missing required fields: title, slug, body" },
        { status: 400 }
      );
    }

    // Get D1 database
    const db = await getD1Database();
    if (!db) {
      return NextResponse.json(
        {
          error: "D1 Database not available",
          details: "The database connection is not configured. This means:",
          steps: [
            "1. You need to bind the D1 database in Cloudflare Dashboard",
            "2. Go to: Workers & Pages → [Your Project] → Settings → Functions",
            "3. Scroll to 'D1 database bindings' and add binding name 'DB'",
            "4. Select your 'lizardware-db' database",
            "5. Click 'Save' and retry your deployment"
          ],
          quickFix: "If you just added the binding, try re-deploying your worker (can take 2-10 minutes)"
        },
        { status: 503 }
      );
    }

    // Save to D1
    await upsertPostToD1(db, {
      slug: body.slug,
      title: body.title,
      content: body.body,
      date: body.date,
      author: body.author,
      author_id: body.author_id,
      tags: body.tags,
      description: body.description,
      excerpt: body.excerpt,
      status: body.status || "draft",
      featured_image_id: body.featured_image_id,
      category_id: body.category_id,
      scheduled_date: body.scheduled_date,
    });

    return NextResponse.json(
      {
        success: true,
        message: "Post saved to database successfully",
        slug: body.slug,
      },
      { status: 200 }
    );
  } catch (_error) {
    const error = _error instanceof Error ? _error : new Error(String(_error));
    console.error("Blog save error:", error.message);

    return NextResponse.json(
      { error: error.message },
      { status: 500 }
    );
  }
}
