// Cloudflare Workers types are provided via tsconfig.json types
import { getAllPostsFromD1, getPostBySlugFromD1 } from './blog-storage';
import { getD1Database } from './cloudflare';
import { Post, PostStatus } from '@/types/blog';
export type { Post, PostStatus };

interface GetAllPostsOptions {
  status?: PostStatus;
  includeDrafts?: boolean;
}

export async function getAllPosts(options: GetAllPostsOptions = {}): Promise<Omit<Post, 'content'>[]> {
  // Determine status filter
  const statusFilter = options.status ??
    (options.includeDrafts || process.env.NODE_ENV !== 'production' ? undefined : 'published');

  // Try D1 first
  try {
    const db = await getD1Database();

    if (db) {
      const d1Posts = await getAllPostsFromD1(
        db,
        false,
        statusFilter
      );
      // If we have posts in D1, use them. 
      if (d1Posts.length > 0) {
        return d1Posts;
      }
    } else {
      console.warn('D1 binding not found, checking files');
    }
  } catch (error) {
    console.error('D1 fetch error:', error);
    // Fall through to file-based approach
  }

  // Fallback to file-based approach
  try {
    const path = await import("path");
    const { glob } = await import("glob");
    const fs = await import("fs");
    const matter = (await import("gray-matter")).default;

    const POSTS_DIR = path.join(process.cwd(), "src/content/blog");
    const files = await glob(`${POSTS_DIR}/**/*.mdx`);

    const posts = await Promise.all(
      files.map(async (file) => {
        const content = await fs.promises.readFile(file, "utf-8");
        const slug = path.basename(file, ".mdx");
        const { data } = matter(content);
        return { slug, ...data } as Omit<Post, 'content'>;
      })
    );

    // Filter posts
    return posts.filter(post => {
      // 1. Explicit status filter
      if (statusFilter && post.status !== statusFilter) {
        return false;
      }

      // 2. Skip test/example posts in production (unless explicitly requested)
      if (process.env.NODE_ENV === 'production' && !options.includeDrafts &&
        (post.slug.startsWith('test-') || post.slug.startsWith('example-'))) {
        return false;
      }

      return true;
    });
  } catch (error) {
    console.error('Failed to read MDX files:', error);
    return [];
  }

}

export async function getPostBySlug(slug: string): Promise<Post | null> {
  // Try D1 first
  try {
    const db = await getD1Database();

    if (db) {
      const post = await getPostBySlugFromD1(
        db,
        slug
      );
      if (post) {
        return post;
      }
    }
    // If not found in D1, fall through to MDX
  } catch (error) {
    console.error('D1 fetch error for slug:', slug, error);
    // Fall through to file-based approach
  }

  // Try file-based approach as final fallback
  try {
    const path = await import("path");
    const fs = await import("fs");
    const matter = (await import("gray-matter")).default;
    const { marked } = await import('marked');

    const POSTS_DIR = path.join(process.cwd(), "src/content/blog");

    const file = path.join(POSTS_DIR, `${slug}.mdx`);
    if (fs.existsSync(file)) {
      const fileContent = await fs.promises.readFile(file, "utf-8");
      const { data, content } = matter(fileContent);
      const htmlContent = await marked(content);
      return { slug, ...data, content: htmlContent } as Post;
    }
  } catch (e) {
    console.warn(`Post file not found: ${slug}`, e);
  }

  return null;
}

