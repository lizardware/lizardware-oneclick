import { GitHubStorage } from './GitHubStorage';
import { R2Storage } from './R2Storage';
import type { MediaStorage } from './MediaStorage';

export function getMediaStorage(): MediaStorage {
    // Check environment variable or config to determine which storage to use
    const storageType = process.env.MEDIA_STORAGE_PROVIDER || 'github';

    switch (storageType.toLowerCase()) {
        case 'r2':
            return new R2Storage();
        case 'github':
        default:
            return new GitHubStorage();
    }
}

export type { MediaStorage, MediaAsset } from './MediaStorage';
