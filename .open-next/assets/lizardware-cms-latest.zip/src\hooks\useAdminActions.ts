'use client';

import { useEffect, useRef } from 'react';
import { useAdminActionsContext, AdminAction } from '@/context/AdminActionsContext';

export function useAdminActions(actions: AdminAction[]) {
    const { setActions } = useAdminActionsContext();

    // Use a ref to track if component is mounted to prevent state updates on unmount
    const isMounted = useRef(true);

    // Deep compare hack for dependency array to avoid infinite loops if user passes new array literal
    // We only care about properties that affect the rendering/logic
    // Functions (onClick) are hard to compare, we assume if other props change, it's a new action set
    const actionsKey = JSON.stringify(actions.map(a => ({
        id: a.id,
        label: typeof a.label === 'string' ? a.label : 'react-node',
        href: a.href,
        variant: a.variant,
        disabled: a.disabled,
        showOnMobile: a.showOnMobile
    })));

    useEffect(() => {
        isMounted.current = true;
        setActions(actions);

        return () => {
            isMounted.current = false;
            // On unmount, we clear the actions ONLY if this component was the one setting them.
            // However, in a page storage, unmounting means leaving the page, so clearing is correct.
            // There's a race condition if the next page mounts before this unmounts, keeping the old actions?
            // Next.js app directory handles navigation by unmounting old segement and mounting new.
            // But sometimes they overlap.
            // A safer approach: The next page's useEffect will overwrite this.
            // We set to empty array on cleanup.
            // Wait, if next page mounts first, it sets actions. Then this unmounts and clears them?
            // That would be bad.
            // Next.js navigating: Old Page Unmount -> New Page Mount.
            // So clearing on unmount is predominantly safe.
            setActions([]);
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [actionsKey, setActions]);
}
