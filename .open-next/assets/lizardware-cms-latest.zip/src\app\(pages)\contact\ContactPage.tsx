import { Suspense } from "react";
import ContactForm from "@/components/sections/ContactForm";

export default function ContactPage() {
    return (
        <div className="max-w-3xl mx-auto px-4 py-section">
            <div className="text-center mb-12 space-y-4">
                <h1 className="text-title font-bold tracking-tight text-header-text">
                    Contact Us
                </h1>
                <h2 className="text-subtitle text-page-text">
                    We'd love to hear from you. Fill out the form below to get in touch.
                </h2>
            </div>

            <div className="bg-info-box-bg p-container rounded-2xl border border-borders shadow-2xl">
                <Suspense fallback={<div>Loading form...</div>}>
                    <ContactForm />
                </Suspense>
            </div>
        </div>
    );
}
