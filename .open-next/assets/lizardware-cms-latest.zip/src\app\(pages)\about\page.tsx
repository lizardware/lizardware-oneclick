import { Metadata } from "next";
import { getPageBySlug } from "@/lib/pages";
import PageRenderer from "@/components/PageRenderer";
import AboutPage from "./AboutPage";

export const metadata: Metadata = {
    title: "About Us",
};

export default async function About({ searchParams }: { searchParams: Promise<{ preview?: string }> }) {
    const { preview } = await searchParams;
    let page = await getPageBySlug("about");

    // In preview mode, ensure we use the PageRenderer even if the page doesn't exist yet
    // This allows the ContentPreviewListener to populate the UI as the user types
    if (preview === 'true') {
        if (!page) {
            page = {
                slug: 'about',
                title: 'About Us',
                content: '<p>Start typing your about page content...</p>',
                description: '',
                status: 'draft'
            } as any;
        }
        // Type assertion: page is guaranteed non-null at this point
        return <PageRenderer page={page!} />;
    }

    if (page && page.status === "published") {
        return <PageRenderer page={page} />;
    }

    return <AboutPage />;
}
