# Getting Your Food Blog Online - Complete Setup Guide

Welcome! This guide will walk you through setting up your own food blog website from scratch. No technical experience needed.

**What you'll have at the end:** A live website where you can write blog posts, upload photos, and customize the design.

**Time needed:** 2-3 hours

**Cost:** Free (using free tiers of GitHub and Cloudflare)

---

## Prerequisites

Before you start, you'll need:
- A computer with internet access
- An email address
- About 2-3 hours of uninterrupted time

That's it! No coding experience required.

---

## Step 1: Create Your Accounts (30 minutes)

You'll need two free accounts to host your blog.

### 1A: Create a GitHub Account

**What is GitHub?** Think of it as Google Drive for website code. It's where your blog's files will live.

1. Go to [github.com](https://github.com)
2. Click **Sign Up** in the top right
3. Enter your email address and create a password
4. Choose a username (this will be part of your blog's initial URL)
5. Complete the verification puzzle
6. Click **Create account**
7. Verify your email address (check your inbox)

**✓ Save your login info:** Write down your GitHub username and password somewhere safe.

### 1B: Create a Cloudflare Account

**What is Cloudflare?** This is the company that will host your website and make it fast and secure for visitors around the world.

1. Go to [dash.cloudflare.com/sign-up](https://dash.cloudflare.com/sign-up)
2. Enter your email address and create a password
3. Click **Create Account**
4. Verify your email address (check your inbox)
5. When asked about adding a site, click **Skip** for now

**✓ Save your login info:** Write down your Cloudflare email and password.

---

## Step 2: Get the Blog Code (15 minutes)

Now you'll create your own copy of the blog software.

1. **Log in to GitHub** (if you're not already)
2. **Go to the template repository** (your provider will give you this link)
3. Click the green **"Use this template"** button
4. Select **"Create a new repository"**
5. **Name your repository:** Choose something like `my-food-blog` or `baking-adventures`
   - Use lowercase letters, numbers, and hyphens only (no spaces)
6. **Description:** Add something like "My personal food blog"
7. Choose **Private** (you can make it public later if you want)
8. Click **"Create repository"**

**✓ What just happened:** You now have your own copy of the blog code in your GitHub account!

---

## Step 3: Set Up Cloudflare Resources (45 minutes)

This is the most technical part, but just follow along step-by-step.

### 3A: Create a KV Namespace (for site settings)

**What is KV?** It's a small database that stores your site's settings (like colors and configuration).

1. Log in to [Cloudflare Dashboard](https://dash.cloudflare.com)
2. Click **Workers & Pages** in the left sidebar
3. Click **KV** tab at the top
4. Click **Create a namespace**
5. Name it: `my-blog-config` (or similar)
6. Click **Add**
7. **✓ IMPORTANT:** Copy the **Namespace ID** that appears (it looks like `25b3d929b4344cce9dc6eb680458eff5`)
   - Paste it into a notepad temporarily - you'll need it soon!

### 3B: Create a D1 Database (for blog posts)

**What is D1?** This is where all your blog posts will be stored.

1. Still in Cloudflare Dashboard, click **Workers & Pages**
2. Click **D1** tab at the top
3. Click **Create database**
4. Name it: `my-blog-posts`
5. Click **Create**
6. **✓ IMPORTANT:** Copy the **Database ID** that appears (it looks like `8b2719e3-7032-4671-9f99-d8a330c1fd7e`)
   - Paste it into your notepad - you'll need this too!

### 3C: Initialize Your Database

Your database needs tables (like folders) to organize your blog posts.

1. Click on your newly created database (`my-blog-posts`)
2. Click the **Console** tab
3. You'll see a text box where you can enter SQL commands

**Now you'll run 3 commands. Copy each one exactly and click "Execute" after pasting:**

**Command 1** - Create posts table:
```sql
CREATE TABLE posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slug TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    description TEXT,
    author TEXT,
    author_id INTEGER,
    date TEXT NOT NULL,
    status TEXT DEFAULT 'draft',
    tags TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

Click **Execute**. You should see "Success" ✓

**Command 2** - Create pages table:
```sql
CREATE TABLE pages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slug TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    description TEXT,
    status TEXT DEFAULT 'draft',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

Click **Execute**. You should see "Success" ✓

**Command 3** - Create indexes for better performance:
```sql
CREATE INDEX idx_posts_status ON posts(status);
CREATE INDEX idx_posts_date ON posts(date);
CREATE INDEX idx_pages_status ON pages(status);
```

Click **Execute**. You should see "Success" ✓

**✓ Your database is ready!**

---

## Step 4: Configure Your Blog (30 minutes)

Now you'll connect everything together by editing one configuration file.

### 4A: Open the Configuration File

1. Go to your GitHub repository (the one you created in Step 2)
2. Click on the file called **`wrangler.jsonc`**
3. Click the **pencil icon** (✏️) in the top right to edit

### 4B: Update the Values

You'll see a file with some settings. You need to replace the placeholder values with YOUR IDs from Step 3.

**Find this section and update it:**

```jsonc
"kv_namespaces": [
    {
        "binding": "CONFIG_KV",
        "id": "YOUR_KV_NAMESPACE_ID_HERE"  // Replace this!
    }
]
```

Replace `YOUR_KV_NAMESPACE_ID_HERE` with the KV Namespace ID you saved earlier.

**Find this section and update it:**

```jsonc
"d1_databases": [
    {
        "binding": "DB",
        "database_name": "my-blog-posts",
        "database_id": "YOUR_D1_DATABASE_ID_HERE"  // Replace this!
    }
]
```

Replace `YOUR_D1_DATABASE_ID_HERE` with the D1 Database ID you saved earlier.

### 4C: Save Your Changes

1. Scroll to the bottom
2. In the "Commit message" box, type: `Configure database IDs`
3. Click **Commit changes**

**✓ Configuration complete!**

---

## Step 5: Deploy to Cloudflare (30 minutes)

Time to make your blog live on the internet!

### 5A: Connect GitHub to Cloudflare

1. Go back to [Cloudflare Dashboard](https://dash.cloudflare.com)
2. Click **Workers & Pages**
3. Click **Create application**
4. Click the **Pages** tab
5. Click **Connect to Git**
6. Click **GitHub** and authorize Cloudflare to access your GitHub account
7. Select your repository (the one you created in Step 2)
8. Click **Begin setup**

### 5B: Configure Build Settings

You'll see a form with several fields. Enter these values **exactly**:

- **Project name:** `my-food-blog` (or whatever you want - this will be in your URL)
- **Production branch:** `main`
- **Framework preset:** Select **Next.js**
- **Build command:** `npm run build`
- **Build output directory:** `.vercel/output/static`

### 5C: Add Environment Variables

Before clicking "Save and Deploy," scroll down to **Environment variables**:

1. Click **Add variable**
2. **Variable name:** `USE_D1_BLOG`
3. **Value:** `true`
4. Click **Add variable** again
5. **Variable name:** `NEXT_PUBLIC_SITE_URL`
6. **Value:** `https://my-food-blog.pages.dev` (replace `my-food-blog` with your actual project name from above)

### 5D: Add Compatibility Flag

**CRITICAL STEP** - Without this, your site won't work:

1. Click **Save and Deploy** to create the project
2. Wait for the initial deployment (it will fail - that's expected!)
3. Once it's done, click on your project name
4. Go to **Settings** → **Functions**
5. Scroll to **Compatibility flags**
6. In both boxes (Production and Preview), add: `nodejs_compat`
7. Click **Save**

### 5E: Bind Your Resources

Now connect the KV and D1 resources you created:

1. Still in **Settings**, scroll to **Functions**
2. Find **KV namespace bindings**
3. Click **Add binding**
   - **Variable name:** `CONFIG_KV`
   - **KV namespace:** Select your `my-blog-config` namespace
   - Click **Save**
4. Find **D1 database bindings**
5. Click **Add binding**
   - **Variable name:** `DB`
   - **D1 database:** Select your `my-blog-posts` database
   - Click **Save**

### 5F: Trigger a New Deployment

1. Go to **Deployments** tab
2. Click **Retry deployment** on the most recent one
3. Watch the build logs (this takes 3-5 minutes)
4. When you see "Success", your site is LIVE! 🎉

**✓ Your blog is online!**

---

## Step 6: Access Your Blog

### Find Your URL

1. In Cloudflare Dashboard, go to your Pages project
2. You'll see a URL like: `https://my-food-blog.pages.dev`
3. Click it to visit your live blog!

### Access the Admin Dashboard

To write blog posts and customize your site:

1. Go to: `https://your-site.pages.dev/admin`
2. You may be asked to set up Cloudflare Access (simple email verification)
3. Once logged in, you'll see the admin dashboard!

---

## Step 7: Write Your First Blog Post

1. In the admin dashboard, click **Blog** → **New Post**
2. Fill in:
   - **Title:** Something tasty like "My First Recipe Post"
   - **Author:** Your name
   - **Description:** A brief summary
   - **Content:** Use the visual editor to write your post
3. Click **Publish** (or **Save Draft** if you're not ready)
4. Visit your blog homepage to see it live!

---

## Step 8: Customize Your Site

### Change Colors

1. Go to `/admin/theme` in your admin dashboard
2. Use the color pickers to change:
   - Background colors
   - Text colors
   - Navigation colors
3. Click **Save** when you like what you see
4. Your changes go live instantly!

### Edit Your About Page

1. Go to `/admin/pages` in your admin dashboard
2. Click on **About**
3. Edit the content to tell your story
4. Click **Update**

---

## Troubleshooting

**"My site shows an error"**
- Check that you entered the correct KV and D1 IDs in `wrangler.jsonc`
- Make sure you added the `nodejs_compat` compatibility flag
- Verify your D1 database has tables (run the SQL commands again if needed)

**"I can't access /admin"**
- Set up Cloudflare Access from your Cloudflare Dashboard
- Make sure you're using the correct email address

**"Build failed"**
- Check the build logs in Cloudflare Pages → Deployments
- Common issue: Environment variables not set correctly

**"Blog posts aren't showing"**
- Make sure `USE_D1_BLOG` is set to `true` in environment variables
- Check that your D1 database is bound correctly

---

## Next Steps

Now that your blog is live, you can:

- **Write more posts** - Share your recipes and food adventures
- **Upload images** - Make your posts visual and engaging
- **Customize your theme** - Make it uniquely yours
- **Set up a custom domain** - Get your own domain name (like `myblog.com`)
- **Optimize for SEO** - Help people find your content on Google

---

## Getting Help

If you get stuck:
1. Check the troubleshooting section above
2. Review the detailed documentation at `/docs`
3. Contact your site administrator

**Congratulations! You now have a professional food blog!** 🎉
