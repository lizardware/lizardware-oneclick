"use client";

import { useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";

export default function ContactForm() {
    const searchParams = useSearchParams();
    const [reason, setReason] = useState("");

    useEffect(() => {
        const r = searchParams.get("reason");
        if (r) setReason(r);
    }, [searchParams]);

    return (
        <form className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                    <label htmlFor="name" className="text-sm font-medium text-slate-700 dark:text-slate-300">Name</label>
                    <input
                        type="text"
                        id="name"
                        className="w-full p-3 rounded-lg bg-background border border-border text-foreground focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all"
                        placeholder="Your Name"
                        required
                    />
                </div>
                <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium text-slate-700 dark:text-slate-300">Email</label>
                    <input
                        type="email"
                        id="email"
                        className="w-full p-3 rounded-lg bg-background border border-border text-foreground focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all"
                        placeholder="you@company.com"
                        required
                    />
                </div>
            </div>

            <div className="space-y-2">
                <label htmlFor="reason" className="text-sm font-medium text-slate-700 dark:text-slate-300">Primary Reason for Contact</label>
                <select
                    id="reason"
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    className="w-full p-3 rounded-lg bg-background border border-border text-foreground focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all"
                >
                    <option value="">-- Select a reason --</option>
                    <option value="general">General Inquiry</option>
                    <option value="sales">Sales</option>
                    <option value="support">Support</option>
                    <option value="other">Other</option>
                </select>
            </div>

            <div className="space-y-2">
                <label htmlFor="message" className="text-sm font-medium text-slate-700 dark:text-slate-300">Message</label>
                <textarea
                    id="message"
                    rows={5}
                    className="w-full p-3 rounded-lg bg-background border border-border text-foreground focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all"
                    placeholder="How can we help you?"
                    required
                ></textarea>
            </div>

            <button
                type="submit"
                className="w-full md:w-auto bg-primary hover:bg-primary/90 text-white font-bold py-3 px-8 rounded-lg shadow-lg hover:shadow-primary/25 transition-all transform hover:-translate-y-0.5"
            >
                Send Message
            </button>
        </form>
    );
}
