'use client';

import { SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { useDroppable } from '@dnd-kit/core';
import { Block } from '@/types/blocks';
import BlockItem from './BlockItem';
import { Plus } from 'lucide-react';

interface BlockListProps {
    blocks: Block[];
    parentId: string;
    selectedBlockId: string | null;
    onSelectBlock: (id: string | null) => void;
    onDeleteBlock: (id: string) => void;
    onMoveBlock: (id: string, direction: 'up' | 'down') => void;
    onDuplicateBlock: (id: string) => void;
    isRoot?: boolean;
}

export default function BlockList({
    blocks,
    parentId,
    selectedBlockId,
    onSelectBlock,
    onDeleteBlock,
    onMoveBlock,
    onDuplicateBlock,
    isRoot = false
}: BlockListProps) {
    const droppableId = isRoot ? 'canvas-droppable' : `droppable-${parentId}`;
    const { setNodeRef, isOver } = useDroppable({
        id: droppableId,
    });

    return (
        <div
            ref={setNodeRef}
            onClick={() => onSelectBlock(null)}
            className={`min-h-[50px] transition-colors rounded-lg ${isOver ? 'bg-primary/5 ring-2 ring-primary/20' : ''} ${isRoot ? 'max-w-4xl mx-auto min-h-[500px] p-8' : 'p-2 border-2 border-dashed border-gray-100 dark:border-zinc-800 mt-2 cursor-default'}`}
        >
            {blocks.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-gray-400 py-10">
                    {isRoot ? (
                        <>
                            <div className="w-16 h-16 rounded-2xl bg-gray-50 dark:bg-zinc-800 flex items-center justify-center mb-4">
                                <Plus size={32} />
                            </div>
                            <p className="font-medium">Drag blocks here to build your page</p>
                        </>
                    ) : (
                        <p className="text-[10px] uppercase tracking-widest font-bold opacity-30">Empty Slot</p>
                    )}
                </div>
            ) : (
                <SortableContext items={blocks.map(b => b.id)} strategy={verticalListSortingStrategy}>
                    {blocks.map((block) => (
                        <BlockItem
                            key={block.id}
                            block={block}
                            isSelected={selectedBlockId === block.id}
                            onSelect={() => onSelectBlock(block.id)}
                            onDelete={() => onDeleteBlock(block.id)}
                            onMoveUp={() => onMoveBlock(block.id, 'up')}
                            onMoveDown={() => onMoveBlock(block.id, 'down')}

                            // Pass down the recursive props
                            selectedBlockId={selectedBlockId}
                            onSelectBlock={onSelectBlock}
                            onDeleteBlock={onDeleteBlock}
                            onMoveBlock={onMoveBlock}
                            onDuplicateBlock={onDuplicateBlock}
                            onDuplicate={() => onDuplicateBlock(block.id)}
                        />
                    ))}
                </SortableContext>
            )}
        </div>
    );
}
