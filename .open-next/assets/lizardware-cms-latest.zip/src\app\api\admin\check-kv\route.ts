import { NextResponse } from 'next/server';
import { getSafeCloudflareContext } from '@/lib/cloudflare';

export async function GET() {
    try {
        // In local development, we use filesystem fallbacks, so we don't strictly NEED bindings
        if (process.env.NODE_ENV === 'development') {
            return NextResponse.json({ exists: true });
        }

        const context = await getSafeCloudflareContext();
        const exists = !!context?.env?.CONFIG_KV;

        return NextResponse.json({ exists });
    } catch (error) {
        console.error('KV check error:', error);
        return NextResponse.json({ exists: false });
    }
}
