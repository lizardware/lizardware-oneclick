import { servicesData } from "@/data/services";
import { Metadata } from "next";
import ServicePage from "./ServicePage";
import { getDynamicSiteConfig } from "@/lib/site-server";

export async function generateStaticParams() {
    return Object.keys(servicesData).map((slug) => ({
        slug,
    }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
    const { slug } = await params;
    const service = servicesData[slug];
    const siteConfig = await getDynamicSiteConfig();
    const siteName = siteConfig.name || "Lizardware CMS";

    return {
        title: service?.title,
        description: service?.intro.replace(/{{siteName}}/g, siteName),
    };
}

export default async function ServicePageRoute(props: {
    params: Promise<{ slug: string }>;
    searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
    const [{ slug }] = await Promise.all([props.params, props.searchParams.then(() => void 0)]);

    return <ServicePage slug={slug} />;
}
