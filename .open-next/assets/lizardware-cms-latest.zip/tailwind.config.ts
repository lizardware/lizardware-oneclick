import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      borderRadius: {
        'sm': 'var(--radius-sm)',
        'DEFAULT': 'var(--radius-md)',
        'md': 'var(--radius-md)',
        'lg': 'var(--radius-lg)',
        'xl': 'var(--radius-xl)',
        '2xl': 'var(--radius-2xl)',
        '3xl': 'calc(var(--radius-2xl) + 8px)',
      },
      spacing: {
        'section': 'var(--spacing-section)',
        'container': 'var(--spacing-container)',
        'gap': 'var(--spacing-gap)',
        'header': 'var(--spacing-header)',
      },
      gap: {
        'system': 'var(--spacing-gap)',
      },
      boxShadow: {
        'sm': '0 1px 2px 0 rgba(var(--shadow-color), calc(var(--shadow-strength) * 0.5))',
        'DEFAULT': '0 1px 3px 0 rgba(var(--shadow-color), var(--shadow-strength)), 0 1px 2px -1px rgba(var(--shadow-color), var(--shadow-strength))',
        'md': '0 4px 6px -1px rgba(var(--shadow-color), var(--shadow-strength)), 0 2px 4px -2px rgba(var(--shadow-color), var(--shadow-strength))',
        'lg': '0 10px 15px -3px rgba(var(--shadow-color), var(--shadow-strength)), 0 4px 6px -4px rgba(var(--shadow-color), var(--shadow-strength))',
        'xl': '0 20px 25px -5px rgba(var(--shadow-color), var(--shadow-strength)), 0 8px 10px -6px rgba(var(--shadow-color), var(--shadow-strength))',
        '2xl': '0 25px 50px -12px rgba(var(--shadow-color), var(--shadow-strength))',
      },
      colors: {
        // Site & Layout
        'site-background': "var(--site-background)",
        'page-background': "var(--page-background)",
        'borders': "var(--borders)",
        // Header & Footer
        'header-bg': "var(--header-bg)",
        'header-text': "var(--header-text)",
        'footer-bg': "var(--footer-bg)",
        'footer-text': "var(--footer-text)",
        // Pages
        'page-title': "var(--page-title)",
        'page-subtitle': "var(--page-subtitle)",
        'page-text': "var(--page-text)",
        // Info Boxes
        'info-box-bg': "var(--info-box-bg)",
        'info-box-text': "var(--info-box-text)",
        'info-box-link-bg': "var(--info-box-link-bg)",
        'info-box-link-text': "var(--info-box-link-text)",
        'info-box-link-hover': "var(--info-box-link-hover)",
        // Section Headers
        'section-header-bg': "var(--section-header-bg)",
        // Convenience
        primary: "var(--page-subtitle)",
      },
      fontSize: {
        'title': 'var(--font-size-title)',
        'subtitle': 'var(--font-size-subtitle)',
        'body': 'var(--font-size-base)',
      },
    },
  },
  plugins: [],
};
export default config;
