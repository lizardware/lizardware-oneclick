// Utility to safely access Cloudflare context in Next.js Edge runtime
// This avoids bundling issues with @opennextjs/cloudflare that causes 
// "TypeError: Cannot read properties of undefined (reading 'default')"

import { NextResponse } from 'next/server';

export interface CloudflareContext {
    env: {
        DB?: D1Database;
        CONFIG_KV?: KVNamespace;
        [key: string]: unknown;
    };
    cf?: unknown;
    ctx?: unknown;
}

export async function getSafeCloudflareContext(): Promise<CloudflareContext | null> {
    let context: CloudflareContext | null = null;

    try {
        // Try the official way first
        // We use a dynamic import to prevent the entire file from crashing if the module fails to load
        const { getCloudflareContext } = await import('@opennextjs/cloudflare');
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const rawContext = await getCloudflareContext({ async: true }) as any;
        if (rawContext && rawContext.env) {
            context = {
                env: rawContext.env,
                cf: rawContext.cf,
                ctx: rawContext.ctx
            };
        }
    } catch (e) {
        console.warn('[Cloudflare Lib] Official getCloudflareContext failed, trying manual fallback', e);
    }

    // Manual fallback for OpenNext environments
    if (!context || !context.env) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const globalContext = (globalThis as any).__NEXT_CLOUDFLARE_CONTEXT__;
        if (globalContext && globalContext.env) {
            context = {
                env: globalContext.env,
                cf: globalContext.cf,
                ctx: globalContext.ctx
            };
        } else if (typeof process !== 'undefined' && process.env) {
            // Some environments put bindings in process.env
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            context = { env: process.env as any };
        }
    }

    return context;
}

/**
 * Helper to get the D1 database binding
 */
export async function getD1Database(): Promise<D1Database | null> {
    const context = await getSafeCloudflareContext();
    return (context?.env?.DB as D1Database) || null;
}

/**
 * Standard error response for missing database
 */
export function dbUnavailableResponse() {
    return NextResponse.json(
        {
            error: "Database or Cloudflare context not available",
            hint: "Check D1 bindings in wrangler.jsonc or project configuration."
        },
        { status: 503 }
    );
}
/**
 * Check if CONFIG_KV binding exists
 */
export async function checkKVExists(): Promise<boolean> {
    try {
        const context = await getSafeCloudflareContext();
        return !!context?.env?.CONFIG_KV;
    } catch {
        return false;
    }
}

/**
 * Check if D1 database binding exists
 */
export async function checkD1Exists(): Promise<boolean> {
    try {
        const db = await getD1Database();
        return !!db;
    } catch {
        return false;
    }
}

/**
 * Check if database has been initialized (site_config table exists)
 */
export async function checkDatabaseInitialized(): Promise<boolean> {
    try {
        const db = await getD1Database();
        if (!db) return false;

        const result = await db.prepare(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='site_config'"
        ).first();

        return !!result;
    } catch {
        return false;
    }
}
