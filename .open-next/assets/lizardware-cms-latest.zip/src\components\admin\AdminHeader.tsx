import Link from "next/link";
import { ReactNode } from "react";

export interface BreadcrumbItem {
    label: string;
    href?: string;
}

export interface AdminHeaderProps {
    title: ReactNode;
    description: string;
    badge: ReactNode;
    breadcrumbs: BreadcrumbItem[];
    actions?: ReactNode;
    className?: string;
}

export function AdminHeader({
    title,
    description,
    badge,
    breadcrumbs,
    actions,
    className = ""
}: AdminHeaderProps) {
    return (
        <header className={`bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-3xl p-5 md:p-6 shadow-xl overflow-hidden group relative ${className}`}>
            <div className="relative z-10 flex flex-col md:flex-row justify-between md:items-center gap-6">
                <div className="space-y-4 md:space-y-1">
                    {/* Integrated Breadcrumbs */}
                    <div className="flex items-center gap-2 mb-3 md:mb-1">
                        {breadcrumbs.map((crumb, idx) => (
                            <div key={idx} className="flex items-center gap-2">
                                {idx > 0 && <span className="text-[10px] text-zinc-300">/</span>}
                                {crumb.href ? (
                                    <Link
                                        href={crumb.href}
                                        className="text-[10px] font-bold uppercase tracking-widest text-zinc-400 hover:text-primary transition-colors"
                                    >
                                        {crumb.label}
                                    </Link>
                                ) : (
                                    <div className="inline-flex items-center gap-2 px-2 py-0.5 bg-primary/10 text-primary rounded text-[9px] font-bold uppercase tracking-wider">
                                        <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse shadow-[0_0_8px_rgba(var(--primary),0.5)]"></span>
                                        {crumb.label}
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>

                    <div className="space-y-2">
                        <div className="inline-flex md:hidden mb-2">{badge}</div>
                        <h1 className="text-2xl md:text-3xl font-black tracking-tight text-page-title leading-tight">
                            {title}
                        </h1>
                        <p className="text-xs text-gray-400 font-medium max-w-xl leading-relaxed">
                            {description}
                        </p>
                    </div>
                </div>

                {/* Desktop Badge & Actions */}
                <div className="flex flex-col items-end gap-3">
                    <div className="hidden md:block">{badge}</div>
                    {actions && <div className="mt-2">{actions}</div>}
                </div>
            </div>

            {/* Decorative Elements */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full -mr-32 -mt-32 blur-3xl opacity-50 transition-opacity group-hover:opacity-100 pointer-events-none"></div>
        </header>
    );
}
