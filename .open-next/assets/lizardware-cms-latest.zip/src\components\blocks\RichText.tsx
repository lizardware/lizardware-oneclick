'use client';

interface RichTextProps {
    content: string;
    className?: string;
}

export default function RichText({ content, className = '' }: RichTextProps) {
    // Fix for preview rendering escaped HTML tags
    // If the content arrives escaped (e.g. &lt;p&gt;), we need to unescape it
    // to ensure dangerouslySetInnerHTML renders the actual tags.
    const unescapedContent = typeof content === 'string'
        ? content
            .replace(/&lt;/g, '<')
            .replace(/&gt;/g, '>')
            .replace(/&quot;/g, '"')
            .replace(/&#39;/g, "'")
            .replace(/&amp;/g, '&')
        : content;

    return (
        <div
            className={`prose prose-lg dark:prose-invert max-w-none ${className}`}
            dangerouslySetInnerHTML={{ __html: unescapedContent }}
        />
    );
}
