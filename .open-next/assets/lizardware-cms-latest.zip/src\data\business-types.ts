/**
 * Business Type Registry
 * 
 * Unified system that ties together:
 * - Content seeds
 * - Theme presets
 * - Feature flags
 * - Navigation structures
 */

export interface BusinessType {
    id: string;
    name: string;
    icon: string;
    description: string;

    // Content
    seedFile: 'software-dev' | 'restaurant' | 'blog' | 'service' | 'blank';

    // Visual Identity
    defaultTheme: 'classic' | 'msp_orange' | 'saas' | 'cyber' | 'blogger' | 'studio';

    // Features
    features: {
        blog: boolean;
        gallery: boolean;
        newsletter: boolean;
        monetization: boolean;
        comments: boolean;
        services: boolean;
        menu: boolean;
        booking: boolean;
        customerPortal: boolean;
        analytics: boolean;
        forum: boolean;
    };

    // SEO Defaults
    tagline?: string;
}

export const BUSINESS_TYPES: Record<string, BusinessType> = {
    'software-dev': {
        id: 'software-dev',
        name: 'Software Development',
        icon: '💻',
        description: 'Full-stack development agency, SaaS product site, or developer portfolio. Includes technical blog, feature showcase, and community forums.',
        seedFile: 'software-dev',
        defaultTheme: 'saas',
        tagline: 'Building the future of edge computing',
        features: {
            blog: true,
            forum: true,
            gallery: false,
            newsletter: true,
            monetization: false,
            comments: true,
            services: true,
            menu: false,
            booking: false,
            customerPortal: false,
            analytics: true,
        }
    },

    'restaurant': {
        id: 'restaurant',
        name: 'Restaurant & Hospitality',
        icon: '🍽️',
        description: 'Restaurant, café, or catering business. Menu showcase, online reservations, location info, and event booking.',
        seedFile: 'restaurant',
        defaultTheme: 'classic',
        tagline: 'Exceptional dining experiences',
        features: {
            blog: false,
            forum: false,
            gallery: true,
            newsletter: true,
            monetization: false,
            comments: false,
            services: false,
            menu: true,
            booking: true,
            customerPortal: false,
            analytics: true,
        }
    },

    'blog': {
        id: 'blog',
        name: 'Blog & Publishing',
        icon: '✍️',
        description: 'Personal blog, magazine, or content publishing platform. Rich writing tools, categories, tags, and newsletter integration.',
        seedFile: 'blog',
        defaultTheme: 'blogger',
        tagline: 'Stories that matter',
        features: {
            blog: true,
            forum: false,
            gallery: true,
            newsletter: true,
            monetization: true,
            comments: true,
            services: false,
            menu: false,
            booking: false,
            customerPortal: false,
            analytics: true,
        }
    },

    'service': {
        id: 'service',
        name: 'Service Business',
        icon: '🏢',
        description: 'Consulting, agency, or professional services. Service listings, client portal, case studies, and lead generation.',
        seedFile: 'service',
        defaultTheme: 'msp_orange',
        tagline: 'Professional solutions, delivered',
        features: {
            blog: true,
            forum: false,
            gallery: true,
            newsletter: true,
            monetization: false,
            comments: false,
            services: true,
            menu: false,
            booking: true,
            customerPortal: true,
            analytics: true,
        }
    },

    'blank': {
        id: 'blank',
        name: 'Blank Canvas',
        icon: '🎨',
        description: 'Start from scratch with empty database. Build your own custom structure without any pre-populated content.',
        seedFile: 'blank',
        defaultTheme: 'classic',
        tagline: 'Your vision, your way',
        features: {
            blog: true,
            forum: false,
            gallery: true,
            newsletter: false,
            monetization: false,
            comments: false,
            services: false,
            menu: false,
            booking: false,
            customerPortal: false,
            analytics: false,
        }
    },
};

export function getBusinessType(id: string): BusinessType | undefined {
    return BUSINESS_TYPES[id];
}

export function getAllBusinessTypes(): BusinessType[] {
    return Object.values(BUSINESS_TYPES);
}
