import { Metadata } from "next";
import { siteConfig } from "@/config/site";

export const metadata: Metadata = {
    title: `Blog | ${siteConfig.name}`,
    description: "Industry insights, technology updates, and expert analysis on IT consulting, cybersecurity, and business technology solutions.",
    keywords: [...siteConfig.seo.keywords, "technology blog", "IT insights", "industry news"],
    alternates: {
        canonical: `${siteConfig.url}/blog`,
    },
    openGraph: {
        title: "Blog | Lizardware",
        description: "Industry insights & technology updates from Lizardware",
        url: `${siteConfig.url}/blog`,
        siteName: siteConfig.openGraph.siteName,
        locale: siteConfig.openGraph.locale,
        type: "website",
        images: [
            {
                url: siteConfig.ogImage,
                width: 1200,
                height: 630,
                alt: "Lizardware Blog",
            },
        ],
    },
    twitter: {
        card: "summary_large_image",
        title: "Blog | Lizardware",
        description: "Industry insights & technology updates from Lizardware",
        images: [siteConfig.ogImage],
        creator: siteConfig.seo.twitterHandle,
    },
};

export default function BlogLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return children;
}
