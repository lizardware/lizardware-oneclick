import { NextRequest, NextResponse } from "next/server";
import { getD1Database } from "@/lib/cloudflare";
import { getAllMedia, getMediaById, registerMediaAsset, deleteMediaAsset } from "@/lib/blog-media";

export async function GET(request: NextRequest) {
    try {
        const { searchParams } = new URL(request.url);
        const id = searchParams.get('id');
        const db = await getD1Database();
        if (!db) {
            return NextResponse.json({ error: "D1 Database not available" }, { status: 503 });
        }

        if (id) {
            const asset = await getMediaById(db, id);
            return NextResponse.json({ asset }, { status: 200 });
        }

        const media = await getAllMedia(db);
        return NextResponse.json({ media }, { status: 200 });
    } catch (error) {
        return NextResponse.json({ error: (error as Error).message }, { status: 500 });
    }
}

export async function POST(request: NextRequest) {
    try {
        const db = await getD1Database();
        if (!db) {
            return NextResponse.json({ error: "D1 Database not available" }, { status: 503 });
        }
        const body = await request.json() as { url: string, filename: string, alt_text?: string, caption?: string, file_size?: number, mime_type?: string, uploaded_by?: string };

        // Option C: Manual URL entry for MVP
        if (!body.url || !body.filename) {
            return NextResponse.json({ error: "Missing required fields: url, filename" }, { status: 400 });
        }

        const asset = {
            id: crypto.randomUUID(),
            filename: body.filename,
            url: body.url,
            alt_text: body.alt_text,
            caption: body.caption,
            file_size: body.file_size,
            mime_type: body.mime_type,
            uploaded_by: body.uploaded_by || 'admin'
        };

        await registerMediaAsset(db, asset);
        return NextResponse.json({ success: true, asset }, { status: 201 });
    } catch (error) {
        return NextResponse.json({ error: (error as Error).message }, { status: 500 });
    }
}

export async function DELETE(request: NextRequest) {
    try {
        const db = await getD1Database();
        if (!db) {
            return NextResponse.json({ error: "D1 Database not available" }, { status: 503 });
        }
        const { searchParams } = new URL(request.url);
        const id = searchParams.get('id');
        if (!id) {
            return NextResponse.json({ error: "Missing required field: id" }, { status: 400 });
        }
        await deleteMediaAsset(db, id);
        return NextResponse.json({ success: true, message: "Asset deleted successfully" }, { status: 200 });
    } catch (error) {
        return NextResponse.json({ error: (error as Error).message }, { status: 500 });
    }
}
