import { NextResponse } from 'next/server';
import { writeFile, readFile } from 'fs/promises';
import path from 'path';

// Force Node.js runtime to access filesystem
export const runtime = 'nodejs';

export async function GET() {
    return NextResponse.json({
        siteUrl: process.env.NEXT_PUBLIC_SITE_URL || '',
        cloudflareAccountId: process.env.CLOUDFLARE_ACCOUNT_ID || '',
        cloudflareZoneId: process.env.CLOUDFLARE_ZONE_ID || '',
        mediaStorageProvider: process.env.MEDIA_STORAGE_PROVIDER || 'github',
        githubRepo: process.env.GITHUB_REPO || '',
        // Don't leak the actual token, just indicate if it's set
        githubToken: process.env.GITHUB_TOKEN ? '********' : ''
    });
}

export async function POST(request: Request) {
    // Safety check for Cloudflare / Edge runtime (cannot use fs)
    if (process.env.NEXT_RUNTIME !== 'nodejs' || process.env.NODE_ENV === 'production') {
        console.warn('[Env API] Skipping filesystem write in production/edge environment.');
        return NextResponse.json({
            success: false,
            message: 'Environment variables must be configured via Cloudflare Dashboard in production.'
        }, { status: 403 });
    }

    try {
        const config = await request.json() as Record<string, string>;
        // ... rest of the code

        // If githubToken is '********', it means the user didn't change it, so we should keep the old one
        const githubToken = config.githubToken === '********' ? process.env.GITHUB_TOKEN : config.githubToken;

        // Helper to update or append a variable
        const updateEnvVar = (content: string, key: string, value: string) => {
            const regex = new RegExp(`^${key}=.*`, 'm');
            if (regex.test(content)) {
                return content.replace(regex, `${key}=${value}`);
            } else {
                return content + `\n${key}=${value}`;
            }
        };

        const envPath = path.join(process.cwd(), '.env.local');

        let envContent = '';
        try {
            // Try to read existing file
            const existingFile = await readFile(envPath, 'utf-8');
            envContent = existingFile;
        } catch (e) {
            // File doesn't exist, start fresh
            envContent = '# Site Configuration\n';
        }

        // 1. Update Site Config
        if (config.siteUrl) envContent = updateEnvVar(envContent, 'NEXT_PUBLIC_SITE_URL', config.siteUrl);

        // 2. Update Cloudflare
        if (config.cloudflareAccountId) envContent = updateEnvVar(envContent, 'CLOUDFLARE_ACCOUNT_ID', config.cloudflareAccountId);
        if (config.cloudflareZoneId) envContent = updateEnvVar(envContent, 'CLOUDFLARE_ZONE_ID', config.cloudflareZoneId);

        // 3. Update GitHub
        // Only update if it's not the masked value '********'
        if (config.githubToken && config.githubToken !== '********') {
            envContent = updateEnvVar(envContent, 'GITHUB_TOKEN', config.githubToken);
        }
        if (config.githubRepo) envContent = updateEnvVar(envContent, 'GITHUB_REPO', config.githubRepo);

        // 4. Update Storage
        if (config.mediaStorageProvider) envContent = updateEnvVar(envContent, 'MEDIA_STORAGE_PROVIDER', config.mediaStorageProvider);

        // Ensure newline at end
        if (!envContent.endsWith('\n')) envContent += '\n';

        await writeFile(envPath, envContent);

        return NextResponse.json({ success: true });
    } catch (error) {
        console.error('Environment config error:', error);
        return NextResponse.json({ error: 'Failed to save environment config' }, { status: 500 });
    }
}
